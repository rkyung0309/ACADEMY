    // [설정] 서버 URL (로그인 용)
    let currentUser = sessionStorage.getItem('shorthand_user');

    // --- [1] 기본 앱 초기화 및 로그인/로그아웃 로직 ---
    function initApp() {
    currentUser = sessionStorage.getItem('shorthand_user');
        if (currentUser) {
            document.getElementById('login-wrapper').style.display = 'none';
            document.getElementById('app-wrapper').style.display = 'flex'; // 수정됨: flex로 변경
            document.getElementById('userNameSide').innerText = currentUser;
            document.getElementById('userAvatar').innerText = currentUser.charAt(0);
            populateVoiceList(); // TTS 로드
        } else {
            document.getElementById('login-wrapper').style.display = 'flex';
            document.getElementById('app-wrapper').style.display = 'none';
        }
    }

    async function login() {
        location.href = 'index.html';
    }

    function logout() {
        if(confirm("로그아웃 하시겠습니까?")) {
            window.SorizavaAuth.signOut();
        }
    }

    function toggleSidebar() {
        const sidebar = document.querySelector('.sidebar');
        const overlay = document.querySelector('.sidebar-overlay');
        sidebar.classList.toggle('active');
        overlay.classList.toggle('active');
    }

    // --- [2] 사설 연습 로직 (기존 로직 이식) ---
    let startTime = null;
    let timerInterval = null;
    let isPlaying = false;
    let synth = window.speechSynthesis;
    let utterance = null;
    let voices = [];

    // 실시간 속도 표시용: 전체 누적 평균이 아니라 최근 입력 흐름 기준으로 계산
    const LIVE_SPEED_WINDOW_MS = 5000;
    let liveSpeedSamples = [];
    let lastPureTypedCount = 0;

    // ESC 키 이벤트
    window.addEventListener('keydown', function(e) {
        if(e.key === "Escape") {
            const modal = document.getElementById('resultModal');
            if(modal.style.display === 'block') {
                modal.style.display = 'none'; return;
            }
            const inputVal = document.getElementById('typingArea').value;
            if(inputVal.length > 0) {
                stopTimer(); calculateAccuracy();
            }
        }
    });

    // 목소리 로드
    function populateVoiceList() {
        voices = synth.getVoices().filter(voice => voice.lang.includes('ko') || voice.lang.includes('KR'));
        const voiceSelect = document.getElementById('voiceSelect');
        voiceSelect.innerHTML = '';
        if(voices.length === 0) {
            const option = document.createElement('option'); option.textContent = "기본 목소리"; voiceSelect.appendChild(option); return;
        }
        voices.sort((a, b) => {
            const aName = a.name.toLowerCase(); const bName = b.name.toLowerCase();
            if ((aName.includes('google') || aName.includes('natural')) && !(bName.includes('google') || bName.includes('natural'))) return -1;
            if (!(aName.includes('google') || aName.includes('natural')) && (bName.includes('google') || bName.includes('natural'))) return 1;
            return 0;
        });
        voices.forEach((voice) => {
            const option = document.createElement('option');
            let label = voice.name;
            if(label.includes("Google")) label = "🗣️ Google";
            else if(label.includes("Natural") || label.includes("Online")) label = "🗣️ Natural";
            else label = voice.name.slice(0, 10) + ".."; 
            
            option.textContent = label; option.value = voice.name; voiceSelect.appendChild(option);
        });
    }
    if (speechSynthesis.onvoiceschanged !== undefined) { speechSynthesis.onvoiceschanged = populateVoiceList; }

    // 카운트 및 정제
    function getPureCount(text) { return text.replace(/[^a-zA-Z0-9가-힣]/g, "").length; }
    function updateSourceCount() { document.getElementById('sourceCount').innerText = getPureCount(document.getElementById('sourceArea').value) + "자"; }
    function cleanSourceText() {
        let text = document.getElementById('sourceArea').value;
        text = text.replace(/\([^)]*\)/g, ""); 
        text = text.replace(/\n/g, " ");       
        text = text.replace(/[^a-zA-Z0-9가-힣\s.,?%]/g, ""); 
        text = text.replace(/\s+/g, " ").trim(); 
        document.getElementById('sourceArea').value = text;
        updateSourceCount();
    }

    // 타이머 및 입력
    function handleTyping() {
        const inputVal = document.getElementById('typingArea').value;
        const currentCount = getPureCount(inputVal);
        const now = Date.now();
        document.getElementById('typingCount').innerText = currentCount + "자";

        if (!startTime && currentCount > 0) {
            startTime = now;
            liveSpeedSamples = [];
            lastPureTypedCount = 0;
            startTimer();
        }

        const increasedCount = currentCount - lastPureTypedCount;
        if (startTime && increasedCount > 0) {
            liveSpeedSamples.push({ time: now, count: increasedCount });
        }
        lastPureTypedCount = currentCount;

        updateLiveSpeed(now);
        if (currentCount === 0) { stopTimer(); resetMetrics(); }
    }

    function getElapsedSeconds() {
        return startTime ? (Date.now() - startTime) / 1000 : 0;
    }

    function updateTimerDisplay() {
        const elapsedSeconds = getElapsedSeconds();
        const min = Math.floor(elapsedSeconds / 60).toString().padStart(2, '0');
        const sec = Math.floor(elapsedSeconds % 60).toString().padStart(2, '0');
        document.getElementById('timer').innerText = `${min}:${sec}`;
    }

    function updateLiveSpeed(now = Date.now()) {
        if (!startTime) {
            document.getElementById('speedDisplay').innerText = "0";
            return;
        }

        const cutoff = now - LIVE_SPEED_WINDOW_MS;
        liveSpeedSamples = liveSpeedSamples.filter(sample => sample.time >= cutoff);

        if (liveSpeedSamples.length === 0) {
            document.getElementById('speedDisplay').innerText = "0";
            return;
        }

        const typedInWindow = liveSpeedSamples.reduce((sum, sample) => sum + sample.count, 0);
        const firstSampleTime = liveSpeedSamples[0].time;
        const windowSeconds = Math.max((now - firstSampleTime) / 1000, 1);
        const cpm = Math.round((typedInWindow / windowSeconds) * 60);
        document.getElementById('speedDisplay').innerText = cpm;
    }

    function getAverageCpm() {
        const elapsedSeconds = getElapsedSeconds();
        const typedCount = getPureCount(document.getElementById('typingArea').value);
        return elapsedSeconds > 0 ? Math.round((typedCount / elapsedSeconds) * 60) : 0;
    }

    function startTimer() {
        if (timerInterval) return;
        timerInterval = setInterval(() => {
            updateTimerDisplay();
            updateLiveSpeed();
        }, 250);
    }
    function stopTimer() { clearInterval(timerInterval); timerInterval = null; }
    function resetMetrics() {
        startTime = null;
        liveSpeedSamples = [];
        lastPureTypedCount = 0;
        document.getElementById('timer').innerText = "00:00";
        document.getElementById('speedDisplay').innerText = "0";
    }
    function resetPractice() {
        document.getElementById('typingArea').value = ""; document.getElementById('typingCount').innerText = "0자";
        stopTimer(); resetMetrics(); document.getElementById('typingArea').focus();
    }

    // TTS
    function toggleTTS() {
        if (isPlaying) {
            synth.cancel(); isPlaying = false;
            document.getElementById('btnTTS').innerText = "🔊 읽기"; document.getElementById('btnTTS').style.backgroundColor = ""; document.getElementById('btnTTS').style.color = "";
        } else {
            const text = document.getElementById('sourceArea').value;
            if (!text) { alert("읽을 원문이 없습니다."); return; }
            utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = 'ko-KR'; utterance.rate = document.getElementById('ttsRate').value;
            const selectedVoiceName = document.getElementById('voiceSelect').value;
            const selectedVoice = voices.find(v => v.name === selectedVoiceName);
            if (selectedVoice) utterance.voice = selectedVoice;
            utterance.onend = function() {
                isPlaying = false; document.getElementById('btnTTS').innerText = "🔊 읽기"; document.getElementById('btnTTS').style.backgroundColor = "";
            };
            synth.speak(utterance); isPlaying = true;
            document.getElementById('btnTTS').innerText = "⏹ 멈춤"; document.getElementById('btnTTS').style.backgroundColor = "#e74c3c"; document.getElementById('btnTTS').style.color = "white";
        }
    }
    document.getElementById('ttsRate').addEventListener('change', function() { if (isPlaying) { synth.cancel(); toggleTTS(); } });

    // 채점
    function calculateAccuracy() {
        const rawO = document.getElementById('sourceArea').value;
        const rawS = document.getElementById('typingArea').value;
        if(!rawO.trim()) { alert("원문이 없습니다!"); return; }
        if(!rawS.trim()) { alert("입력된 내용이 없습니다!"); return; }

        let pureLength = rawO.replace(/[^0-9a-zA-Z\uAC00-\uD7A3]/g, '').length;
        if(pureLength === 0) pureLength = 1;

        let oArr = rawO.trim().split(''); let sArr = rawS.trim().split('');
        let n = oArr.length; let m = sArr.length;
        let dp = Array.from(Array(n + 1), () => Array(m + 1).fill(0));
        for (let i = 1; i <= n; i++) {
            for (let j = 1; j <= m; j++) {
                if (oArr[i-1] === sArr[j-1]) dp[i][j] = dp[i-1][j-1] + 1;
                else dp[i][j] = Math.max(dp[i-1][j], dp[i][j-1]);
            }
        }
        let i = n, j = m, diffs = [];
        while (i > 0 || j > 0) {
            if (i > 0 && j > 0 && oArr[i-1] === sArr[j-1]) { diffs.push({ t: 'same', c: oArr[i-1] }); i--; j--; }
            else if (j > 0 && (i === 0 || dp[i][j-1] >= dp[i-1][j])) { diffs.push({ t: 'added', c: sArr[j-1] }); j--; }
            else { diffs.push({ t: 'missing', c: oArr[i-1] }); i--; }
        }
        diffs.reverse();

        let html = "", w=0, mi=0, ad=0;
        let mBuffer = [], aBuffer = []; 
        const isSpecial = (char) => /[^0-9a-zA-Z\uAC00-\uD7A3]/.test(char);
        const toHtmlChar = (ch) => (ch === " ") ? "&nbsp;" : ch.replace(/</g, "&lt;");

        function flushBuffer() {
            let mIdx = 0, aIdx = 0;
            while (mIdx < mBuffer.length || aIdx < aBuffer.length) {
                let mChar = mBuffer[mIdx], aChar = aBuffer[aIdx];
                if (mIdx < mBuffer.length && isSpecial(mChar)) { html += `<span>${toHtmlChar(mChar)}</span>`; mIdx++; continue; }
                if (aIdx < aBuffer.length && isSpecial(aChar)) { html += `<span style="color:#ccc;">${toHtmlChar(aChar)}</span>`; aIdx++; continue; }
                if (mIdx < mBuffer.length && aIdx < aBuffer.length) { 
                    html += `<span class="d-wrong">${toHtmlChar(aChar)}<span class="correction">${toHtmlChar(mChar)}</span></span>`; 
                    w++; mIdx++; aIdx++; continue; 
                }
                if (mIdx < mBuffer.length) { html += `<span class="d-missing">${toHtmlChar(mChar)}</span>`; mi++; mIdx++; continue; }
                if (aIdx < aBuffer.length) { html += `<span class="d-added">${toHtmlChar(aChar)}</span>`; ad++; aIdx++; continue; }
            }
            mBuffer = []; aBuffer = [];
        }
        for (let k = 0; k < diffs.length; k++) {
            let item = diffs[k];
            if (item.t === 'same') { flushBuffer(); html += `<span>${toHtmlChar(item.c)}</span>`; } 
            else if (item.t === 'missing') { mBuffer.push(item.c); } 
            else if (item.t === 'added') { aBuffer.push(item.c); }
        }
        flushBuffer();

        let adPenalty = Math.floor(ad / 3);
        let score = Math.max(0, 100 - ((w + mi + adPenalty) / pureLength * 100)).toFixed(1);
        document.getElementById('finalScore').innerText = score + "%";
        document.getElementById('scoreDetail').innerText = `총 글자: ${pureLength}자 / 오자: ${w} / 탈자: ${mi} / 첨자: ${ad}`;
        document.getElementById('diffOutput').innerHTML = html;
        document.getElementById('resultModal').style.display = 'block';
        if (window.SorizavaRecords) {
            const elapsedSeconds = Math.floor(getElapsedSeconds());
            window.SorizavaRecords.savePracticeRecord({
                tool_type: 'editorial',
                practice_title: '사설연습',
                original_length: pureLength,
                typed_length: document.getElementById('typingArea').value.length,
                accuracy: Number(score),
                score: Number(score),
                cpm: getAverageCpm(),
                elapsed_seconds: elapsedSeconds,
                wrong_count: w,
                missing_count: mi,
                added_count: ad,
                source_text_snapshot: String(document.getElementById('sourceArea')?.value || document.getElementById('originalText')?.value || document.getElementById('original')?.value || '').slice(0, 12000),
                typed_text_snapshot: String(document.getElementById('typingArea')?.value || '').slice(0, 12000),
                diff_summary: `오자 ${w} / 탈자 ${mi} / 첨자 ${ad}`,
                memo: '사설연습 자동 저장'
            });
        }
    }
    function closeModal(e) { if(e.target === document.getElementById('resultModal')) document.getElementById('resultModal').style.display = 'none'; }
