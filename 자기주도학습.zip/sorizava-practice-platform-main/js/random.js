// --- 사이드바 토글 ---
function toggleSidebar() {
  document.querySelector('.sidebar')?.classList.toggle('active');
  document.querySelector('.sidebar-overlay')?.classList.toggle('active');
}

// --- 변수 및 상태 ---
const DICT_STORAGE_KEY = 'sorizava_abbr_dictionary_v2';
let practiceMode = 'file'; // file | dictionary_visual | dictionary_voice | abbr_wrong_visual | abbr_wrong_voice
let loadedPersonalDictItems = []; // [내 약어장 불러오기]로 확정한 본인 약어장 목록
let personalDictLoadedAt = null;
let abbreviations = []; // 현재 남은 문제: { prompt, answer, label }
let totalCount = 0;
let currentItem = null;
let currentAbbr = '';
let currentAnswer = '';
let currentWrongAttempts = 0;
let totalStartTime = null;
let isFinished = false;
let correctList = [];
let wrongList = [];

// TTS 관련 변수
let ttsMode = false;
let combo = 0;
let speechRate = 1.0;
let speechVol = 1.0;
let selectedVoice = null;

const $ = (id) => document.getElementById(id);

// 사용자 이름 로드
let currentUser = sessionStorage.getItem('shorthand_user');
if (currentUser && document.getElementById('sideUserName')) {
  document.getElementById('sideUserName').innerText = currentUser;
}

// --- 초기화 ---
document.addEventListener('DOMContentLoaded', () => {
  bindInputs();
  loadVoices();
  injectWrongReviewButtons();
  updatePersonalDictLoadUI(false);
  syncModeUI();
  const params = new URLSearchParams(location.search);
  if (params.get('mode') === 'abbr-wrong') {
    setTimeout(() => startWrongAbbrReview('visual'), 250);
  }
});

if ('speechSynthesis' in window) {
  window.speechSynthesis.onvoiceschanged = loadVoices;
}

function bindInputs() {
  $('fileInput')?.addEventListener('change', handleFileLoad);
  $('userInput')?.addEventListener('input', () => {
    if (!totalStartTime && currentItem && !isFinished) totalStartTime = Date.now();
  });
  $('userInput')?.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') checkEntry();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Shift') replayAudio();
  });
}

function loadVoices() {
  if (!window.speechSynthesis) return;
  const voices = window.speechSynthesis.getVoices();
  selectedVoice = voices.find(v => v.name.includes('Google') && v.lang.includes('ko')) ||
                  voices.find(v => v.lang.includes('ko')) ||
                  voices[0] || null;
}

// --- 모드 판별 ---
function isDictionaryMode(mode = practiceMode) {
  return mode === 'dictionary_visual' || mode === 'dictionary_voice';
}

function isWrongReviewMode(mode = practiceMode) {
  return mode === 'abbr_wrong_visual' || mode === 'abbr_wrong_voice';
}

function isAbbrPracticeMode(mode = practiceMode) {
  return isDictionaryMode(mode) || isWrongReviewMode(mode);
}

function isVoiceMode(mode = practiceMode) {
  return mode === 'dictionary_voice' || mode === 'abbr_wrong_voice';
}

function getPracticeLabel(mode = practiceMode) {
  return {
    file: '파일 랜덤',
    dictionary_visual: '내 약어장 보고치기',
    dictionary_voice: '내 약어장 듣고치기',
    abbr_wrong_visual: '약어 오답 보고치기',
    abbr_wrong_voice: '약어 오답 듣고치기'
  }[mode] || '약어랜덤';
}

function getRecordToolType() {
  return {
    file: 'random',
    dictionary_visual: 'random_dictionary',
    dictionary_voice: 'random_voice_dictionary',
    abbr_wrong_visual: 'random_abbr_wrong_visual',
    abbr_wrong_voice: 'random_abbr_wrong_voice'
  }[practiceMode] || 'random';
}

// --- 모드 제어 ---
function setPracticeMode(mode) {
  practiceMode = mode === 'file' ? 'file' : mode;
  if (practiceMode === 'file') {
    if (ttsMode) setTTS(false);
    abbreviations = [];
    totalCount = 0;
    currentItem = null;
    currentAbbr = '';
    currentAnswer = '';
    currentWrongAttempts = 0;
    resetTest();
  }
  syncModeUI();
}

function startDictionaryVisualMode() {
  startDictionaryPractice('visual');
}

function startDictionaryVoiceMode() {
  startDictionaryPractice('voice');
}

function startDictionaryPractice(mode) {
  const voice = mode === 'voice';
  if (!loadedPersonalDictItems.length) {
    const storedCount = loadDictionaryPracticeItems().length;
    syncModeUI();
    $('abbrDisplay').innerText = storedCount ? '약어장 불러오기 필요' : '약어장 없음';
    $('answerHint').innerText = '';
    $('modeStatus').innerText = storedCount
      ? '먼저 [내 약어장 불러오기] 버튼을 눌러 본인 약어장을 이 화면에 불러온 뒤 보고치기/듣고치기를 선택하세요.'
      : '약어사전 페이지에 저장된 본인 약어장이 없습니다. 약어사전에서 약어 파일을 먼저 불러온 뒤 다시 진행하세요.';
    alert(storedCount
      ? '먼저 [내 약어장 불러오기]를 눌러 주세요. 보고치기와 듣고치기 모두 같은 본인 약어장을 사용합니다.'
      : '불러올 본인 약어장이 없습니다. 약어사전 페이지에서 약어 파일을 먼저 불러와 주세요.');
    return;
  }
  practiceMode = voice ? 'dictionary_voice' : 'dictionary_visual';
  abbreviations = shuffle(loadedPersonalDictItems);
  totalCount = abbreviations.length;
  setTTS(voice, { force: true, silent: true });
  resetTest();
  syncModeUI();
}
function loadPersonalDictionaryForRandom() {
  const items = loadDictionaryPracticeItems();
  if (!items.length) {
    loadedPersonalDictItems = [];
    personalDictLoadedAt = null;
    updatePersonalDictLoadUI(false);
    syncModeUI();
    $('abbrDisplay').innerText = '약어장 없음';
    $('answerHint').innerText = '';
    $('modeStatus').innerText = '약어사전 페이지에 저장된 본인 약어장이 없습니다. 약어사전에서 약어 파일을 먼저 불러온 뒤 다시 시도하세요.';
    alert('불러올 본인 약어장이 없습니다. 약어사전 페이지에서 약어 파일을 먼저 불러와 주세요.');
    return false;
  }
  loadedPersonalDictItems = items;
  personalDictLoadedAt = new Date();
  $('abbrDisplay').innerText = '약어장 준비 완료';
  $('answerHint').innerText = '';
  $('modeStatus').innerText = `본인 약어장 ${items.length}개를 불러왔습니다. 이제 보고치기 또는 듣고치기를 선택하세요.`;
  updatePersonalDictLoadUI(true);
  syncModeUI();
  return true;
}

function updatePersonalDictLoadUI(showStatus = true) {
  const count = loadedPersonalDictItems.length;
  const loadBtn = $('dictLoadBtn');
  if (loadBtn) {
    loadBtn.classList.toggle('loaded', count > 0);
    loadBtn.innerText = count > 0 ? `📚 내 약어장 ${count}개 불러옴` : '📚 내 약어장 불러오기';
  }
  ['dictVisualModeBtn', 'dictVoiceModeBtn', 'wrongReviewVisualModeBtn', 'wrongReviewVoiceModeBtn'].forEach(id => {
    const btn = $(id);
    if (!btn) return;
    btn.disabled = count === 0;
    btn.classList.toggle('is-disabled', count === 0);
  });
  if (showStatus && $('modeStatus') && count > 0 && practiceMode === 'file') {
    $('modeStatus').innerText = `본인 약어장 ${count}개를 불러왔습니다. 보고치기 또는 듣고치기를 선택하세요.`;
  }
}

function getLoadedPersonalDictKeySet() {
  return new Set(loadedPersonalDictItems.map(item => getAbbrMatchKey(item.answer || item.prompt, item.abbrCode)));
}

function getAbbrMatchKey(abbr, abbrCode = '') {
  return `${String(abbrCode || '').trim()}__${String(abbr || '').trim()}`;
}


function syncModeUI() {
  updatePersonalDictLoadUI(false);
  const loadedCount = loadedPersonalDictItems.length;
  $('fileModeBtn')?.classList.toggle('active', practiceMode === 'file');
  $('dictVisualModeBtn')?.classList.toggle('active', practiceMode === 'dictionary_visual');
  $('dictVoiceModeBtn')?.classList.toggle('active', practiceMode === 'dictionary_voice');
  $('wrongReviewVisualModeBtn')?.classList.toggle('active', practiceMode === 'abbr_wrong_visual');
  $('wrongReviewVoiceModeBtn')?.classList.toggle('active', practiceMode === 'abbr_wrong_voice');

  const guide = $('dictVoiceGuide');
  if (guide) guide.style.display = (isAbbrPracticeMode() || loadedCount > 0) ? 'flex' : 'none';
  if ($('dictGuideTitle')) {
    $('dictGuideTitle').innerText = isAbbrPracticeMode() ? getPracticeLabel() : (loadedCount ? '내 약어장 준비 완료' : '내 약어장 불러오기 필요');
  }
  if ($('dictGuideText')) {
    if (practiceMode === 'dictionary_visual') $('dictGuideText').innerText = `불러온 본인 약어장 ${loadedCount}개를 눈으로 보고 그대로 입력합니다.`;
    else if (practiceMode === 'dictionary_voice') $('dictGuideText').innerText = `불러온 본인 약어장 ${loadedCount}개를 음성으로 듣고 그대로 입력합니다.`;
    else if (practiceMode === 'abbr_wrong_visual') $('dictGuideText').innerText = `현재 불러온 본인 약어장 기준 오답만 보고치기로 복습합니다.`;
    else if (practiceMode === 'abbr_wrong_voice') $('dictGuideText').innerText = `현재 불러온 본인 약어장 기준 오답만 듣고치기로 복습합니다.`;
    else if (loadedCount) $('dictGuideText').innerText = `보고치기와 듣고치기 모두 이 약어장 ${loadedCount}개를 사용합니다.`;
  }

  if ($('loadFileBtn')) $('loadFileBtn').style.display = practiceMode === 'file' ? 'block' : 'none';
  if ($('userInput')) {
    $('userInput').placeholder = isVoiceMode() ? '들은 약어 입력 후 Enter' : '정답 입력 후 Enter';
  }
  if ($('ttsToggle')) {
    if (isVoiceMode()) $('ttsToggle').innerText = '🎧 듣고치기 ON';
    else if (isAbbrPracticeMode()) $('ttsToggle').innerText = '🎧 듣고치기로 전환';
    else $('ttsToggle').innerText = ttsMode ? '🎧 듣고 치기 ON' : '🎧 듣고 치기 OFF';
    $('ttsToggle').classList.toggle('active', isVoiceMode() || ttsMode);
  }
  if ($('modeStatus')) {
    if (practiceMode === 'dictionary_visual') $('modeStatus').innerText = `내 약어장 보고치기 모드입니다. 불러온 본인 약어장 ${loadedCount}개를 보고 그대로 입력하세요.`;
    else if (practiceMode === 'dictionary_voice') $('modeStatus').innerText = `내 약어장 듣고치기 모드입니다. 불러온 본인 약어장 ${loadedCount}개를 음성으로 듣고 그대로 입력하세요.`;
    else if (practiceMode === 'abbr_wrong_visual') $('modeStatus').innerText = `현재 불러온 본인 약어장 기준 약어 오답 ${totalCount || 0}개를 보고치기로 복습합니다.`;
    else if (practiceMode === 'abbr_wrong_voice') $('modeStatus').innerText = `현재 불러온 본인 약어장 기준 약어 오답 ${totalCount || 0}개를 듣고치기로 복습합니다. Shift 키로 다시 들을 수 있습니다.`;
    else if (loadedCount) $('modeStatus').innerText = `본인 약어장 ${loadedCount}개가 준비되었습니다. 보고치기 또는 듣고치기를 선택하세요.`;
    else $('modeStatus').innerText = '파일 랜덤 모드입니다. TXT 파일을 불러오거나, 내 약어장은 [내 약어장 불러오기]를 먼저 누른 뒤 시작하세요.';
  }
}

// --- 파일 로드 ---
function handleFileLoad(e) {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function(ev) {
    practiceMode = 'file';
    const rows = String(ev.target.result || '').split('\n').map(s => s.trim()).filter(Boolean);
    abbreviations = shuffle(rows.map(text => ({ prompt: text, answer: text, label: text, source: 'file' })));
    totalCount = abbreviations.length;
    resetTest();
    syncModeUI();
    if ($('modeStatus')) $('modeStatus').innerText = `파일 랜덤 모드입니다. 불러온 TXT 약어 ${totalCount}개로 연습합니다.`;
  };
  reader.readAsText(file);
}

// --- 본인 약어장 목록 불러오기 ---
function loadDictionaryPracticeItems() {
  const entries = readDictionaryEntriesFromStorage();
  return entries
    .map(entry => {
      const abbrText = cleanSpeakText(entry.outputRaw || entry.word || entry.약어 || '');
      const abbrCode = String(entry.abbrCode || entry.약어자리 || entry.약어키 || '').trim();
      if (!abbrText) return null;
      return {
        prompt: abbrText,
        answer: abbrText,
        label: abbrText,
        abbrCode,
        source: 'dictionary'
      };
    })
    .filter(Boolean);
}

function readDictionaryEntriesFromStorage() {
  try {
    const raw = localStorage.getItem(DICT_STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.warn('약어사전 목록을 읽지 못했습니다.', err);
    return [];
  }
}

// --- 리셋 및 시작 ---
function resetTest() {
  totalStartTime = null;
  isFinished = false;
  correctList = [];
  wrongList = [];
  currentWrongAttempts = 0;
  combo = 0;
  updateComboUI();
  $('timerLabel').innerText = '0초';
  $('answerHint').innerText = '';

  if (totalCount === 0) {
    currentItem = null;
    currentAbbr = '';
    currentAnswer = '';
    currentWrongAttempts = 0;
    $('abbrDisplay').innerText = 'Start!';
    updateUI();
    return;
  }

  loadNewAbbr();
  updateUI();
}

// --- 문제 출제 ---
function loadNewAbbr() {
  if (abbreviations.length > 0) {
    currentItem = abbreviations[Math.floor(Math.random() * abbreviations.length)];
    currentAbbr = currentItem.prompt;
    currentAnswer = currentItem.answer;
    currentWrongAttempts = 0;

    const display = $('abbrDisplay');
    display.innerText = currentAbbr;
    display.classList.remove('blind', 'reveal', 'mosaic-flash', 'mosaic-correct-preview');
    $('answerHint').innerText = '';

    if (isVoiceMode()) {
      setTTS(true, { force: true, silent: true });
      display.classList.add('blind');
      if ($('modeStatus')) $('modeStatus').innerText = practiceMode === 'abbr_wrong_voice'
        ? '틀렸던 약어를 음성으로 듣고 그대로 입력하세요. Shift 키로 다시 들을 수 있습니다.'
        : '음성으로 나오는 약어를 그대로 입력하세요. Shift 키로 다시 들을 수 있습니다.';
      speak(currentAbbr);
    } else if (practiceMode === 'file' && ttsMode) {
      speak(currentAbbr);
    } else {
      setTTS(false, { silent: true });
    }

    $('userInput').value = '';
    $('userInput').focus();
  } else {
    finishPractice();
  }
}

function finishPractice() {
  isFinished = true;
  currentItem = null;
  currentAbbr = '';
  currentAnswer = '';
  $('abbrDisplay').innerText = 'Finish!';
  $('abbrDisplay').classList.remove('blind', 'mosaic-flash');
  $('answerHint').innerText = '';

  const elapsed = totalStartTime ? Math.floor((Date.now() - totalStartTime) / 1000) : null;
  const correctCount = correctList.length;
  const wrongCount = wrongList.length;
  const acc = totalCount > 0 ? ((correctCount / totalCount) * 100).toFixed(1) : 0;
  if (window.SorizavaRecords) {
    window.SorizavaRecords.savePracticeRecord({
      tool_type: getRecordToolType(),
      practice_title: getPracticeLabel(),
      accuracy: Number(acc),
      score: Number(acc),
      wrong_count: wrongCount,
      elapsed_seconds: elapsed,
      memo: `정답 ${correctCount}개 / 오답 ${wrongCount}개`
    });
  }
  alert(`수고하셨습니다! 모든 연습이 끝났습니다.\n정답 ${correctCount}개 / 오답 ${wrongCount}개 / 정답률 ${acc}%`);
}

function getRandomUserKey() {
  return sessionStorage.getItem('shorthand_user_id') || sessionStorage.getItem('shorthand_user') || 'guest';
}
function getAbbrWrongStorageKey() {
  return `sorizava_abbr_wrong_${getRandomUserKey()}_v1`;
}
function readLocalJson(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (error) {
    return fallback;
  }
}
function writeLocalJson(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}
function getWrongItemKey(item) {
  return getAbbrMatchKey(item?.answer || item?.prompt || item?.abbr, item?.abbrCode || item?.code);
}
function normalizeWrongVaultItem(item) {
  const abbr = String(item?.abbr || item?.answer || item?.label || '').trim();
  if (!abbr) return null;
  const abbrCode = String(item?.abbrCode || item?.code || '').trim();
  return {
    key: String(item?.key || `${abbrCode}__${abbr}`),
    abbr,
    abbrCode,
    wrongCount: Math.max(0, Number(item?.wrongCount || item?.count || 0)),
    correctCount: Math.max(0, Number(item?.correctCount || 0)),
    lastTyped: String(item?.lastTyped || '').trim(),
    firstWrongAt: item?.firstWrongAt || item?.createdAt || '',
    lastWrongAt: item?.lastWrongAt || item?.updatedAt || item?.createdAt || '',
    lastCorrectAt: item?.lastCorrectAt || '',
    mastered: Boolean(item?.mastered),
    source: item?.source || 'dictionary'
  };
}
function readWrongVault() {
  const rows = readLocalJson(getAbbrWrongStorageKey(), []);
  return Array.isArray(rows) ? rows.map(normalizeWrongVaultItem).filter(Boolean) : [];
}
function saveWrongVault(list) {
  const sorted = list
    .map(normalizeWrongVaultItem)
    .filter(Boolean)
    .sort((a, b) => Number(b.wrongCount) - Number(a.wrongCount) || String(b.lastWrongAt).localeCompare(String(a.lastWrongAt)))
    .slice(0, 300);
  writeLocalJson(getAbbrWrongStorageKey(), sorted);
}
function recordDictionaryWrong(item, typed) {
  if (!isAbbrPracticeMode() || !item) return;
  const key = getWrongItemKey(item);
  const list = readWrongVault();
  const now = new Date().toISOString();
  const idx = list.findIndex(row => row.key === key);
  const base = idx >= 0 ? list[idx] : {
    key,
    abbr: String(item.answer || item.prompt || '').trim(),
    abbrCode: String(item.abbrCode || '').trim(),
    wrongCount: 0,
    correctCount: 0,
    firstWrongAt: now,
    source: item.source || 'dictionary'
  };
  const next = {
    ...base,
    abbr: String(item.answer || item.prompt || base.abbr || '').trim(),
    abbrCode: String(item.abbrCode || base.abbrCode || '').trim(),
    wrongCount: Number(base.wrongCount || 0) + 1,
    lastTyped: String(typed || '').trim(),
    lastWrongAt: now,
    mastered: false
  };
  if (idx >= 0) list[idx] = next;
  else list.unshift(next);
  saveWrongVault(list);
}
function recordDictionaryCorrect(item) {
  if (!isAbbrPracticeMode() || !item) return;
  const key = getWrongItemKey(item);
  const list = readWrongVault();
  const idx = list.findIndex(row => row.key === key);
  if (idx < 0) return;
  list[idx] = {
    ...list[idx],
    correctCount: Number(list[idx].correctCount || 0) + 1,
    lastCorrectAt: new Date().toISOString(),
    mastered: isWrongReviewMode() ? true : false,
    masteredAt: isWrongReviewMode() ? new Date().toISOString() : list[idx].masteredAt
  };
  saveWrongVault(list);
}
function injectWrongReviewButtons() {
  const panel = document.querySelector('.practice-mode-panel');
  if (!panel || document.getElementById('wrongReviewVisualModeBtn')) return;

  const visualBtn = document.createElement('button');
  visualBtn.type = 'button';
  visualBtn.className = 'mode-chip wrong-review-chip';
  visualBtn.id = 'wrongReviewVisualModeBtn';
  visualBtn.textContent = '🧾 오답 보고치기';
  visualBtn.onclick = () => startWrongAbbrReview('visual');
  panel.appendChild(visualBtn);

  const voiceBtn = document.createElement('button');
  voiceBtn.type = 'button';
  voiceBtn.className = 'mode-chip wrong-review-chip';
  voiceBtn.id = 'wrongReviewVoiceModeBtn';
  voiceBtn.textContent = '🎧 오답 듣고치기';
  voiceBtn.onclick = () => startWrongAbbrReview('voice');
  panel.appendChild(voiceBtn);
}
function startWrongAbbrReview(mode = 'visual') {
  if (!loadedPersonalDictItems.length) {
    syncModeUI();
    $('abbrDisplay').innerText = '약어장 불러오기 필요';
    $('answerHint').innerText = '';
    $('modeStatus').innerText = '약어 오답 복습도 현재 불러온 본인 약어장을 기준으로 진행합니다. 먼저 [내 약어장 불러오기]를 눌러 주세요.';
    alert('약어 오답 복습도 먼저 [내 약어장 불러오기]가 필요합니다. 보고치기와 듣고치기 모두 같은 본인 약어장을 기준으로 복습합니다.');
    return;
  }

  const loadedKeySet = getLoadedPersonalDictKeySet();
  const list = readWrongVault()
    .filter(item => !item.mastered)
    .filter(item => loadedKeySet.has(getAbbrMatchKey(item.abbr, item.abbrCode)));

  if (!list.length) {
    alert('현재 불러온 본인 약어장 기준으로 복습할 약어 오답이 없습니다. 먼저 이 약어장으로 보고치기 또는 듣고치기를 진행해 주세요.');
    return;
  }
  practiceMode = mode === 'voice' ? 'abbr_wrong_voice' : 'abbr_wrong_visual';
  abbreviations = shuffle(list.map(item => ({
    prompt: item.abbr,
    answer: item.abbr,
    label: item.abbr,
    abbrCode: item.abbrCode,
    source: 'abbr_wrong'
  })));
  totalCount = abbreviations.length;
  setTTS(practiceMode === 'abbr_wrong_voice', { force: true, silent: true });
  resetTest();
  syncModeUI();
}

// --- 정답 체크 로직 ---
function checkEntry() {
  if (!currentItem || isFinished) return;

  const rawUser = $('userInput').value;
  const user = normalizeAnswer(rawUser);
  const target = normalizeAnswer(currentAnswer);
  const promptTarget = normalizeAnswer(currentAbbr);

  const isCorrect = isAbbrPracticeMode()
    ? user === target
    : user === promptTarget || user === normalizeFlexibleParticle(currentAbbr);

  if (isCorrect) {
    if (isAbbrPracticeMode()) recordDictionaryCorrect(currentItem);
    if (!wrongList.some(item => item.key === getItemKey(currentItem))) {
      correctList.push(resultLine(currentItem, true));
    }
    abbreviations = abbreviations.filter(item => getItemKey(item) !== getItemKey(currentItem));
    const input = $('userInput');
    input.style.borderColor = 'var(--success)';
    setTimeout(() => input.style.borderColor = '#E1E4E8', 300);
    combo++;
    updateComboUI();
    updateUI();

    if (isVoiceMode()) {
      flashMosaicThenNext();
    } else {
      loadNewAbbr();
    }
  } else {
    if (!wrongList.some(item => item.key === getItemKey(currentItem))) {
      wrongList.push({ key: getItemKey(currentItem), text: resultLine(currentItem, false, rawUser) });
    }
    combo = 0;
    updateComboUI();
    const inputEl = $('userInput');
    inputEl.classList.add('shake');
    setTimeout(() => inputEl.classList.remove('shake'), 400);

    if (isAbbrPracticeMode()) {
      currentWrongAttempts += 1;
      recordDictionaryWrong(currentItem, rawUser);
      revealAbbrPracticeAnswer(currentWrongAttempts);
    } else if (ttsMode) {
      $('abbrDisplay').classList.add('reveal');
      speak(currentAbbr);
    }
    $('userInput').value = '';
  }
}

function flashMosaicThenNext() {
  const display = $('abbrDisplay');
  if (!display) {
    loadNewAbbr();
    return;
  }

  display.innerText = currentAbbr;
  display.classList.remove('blind', 'reveal', 'mosaic-flash', 'mosaic-correct-preview');

  // class 전환이 겹치면 blur가 풀리다 만 것처럼 보이므로 reflow 후 전용 효과만 적용한다.
  void display.offsetWidth;

  display.classList.add('mosaic-correct-preview');
  $('answerHint').innerText = '';

  setTimeout(() => {
    display.classList.remove('mosaic-correct-preview');
    loadNewAbbr();
  }, 760);
}

function revealAbbrPracticeAnswer(wrongAttempts) {
  const display = $('abbrDisplay');
  if (display) {
    display.innerText = currentAbbr;
    display.classList.remove('blind', 'mosaic-flash');
    display.classList.add('reveal');
  }

  if (wrongAttempts >= 2) {
    const code = String(currentItem?.abbrCode || '').trim();
    $('answerHint').innerText = code ? `약어 자리: ${code}` : `정답: ${currentAnswer}`;
  } else {
    $('answerHint').innerText = '다시 입력해보세요';
  }
  if (isVoiceMode()) speak(currentAbbr);
}
function normalizeAnswer(value) {
  return String(value || '')
    .replace(/[\s,./|#]+/g, '')
    .replace(/[‐‑‒–—―－]/g, '-')
    .replace(/[^ㄱ-ㅎㅏ-ㅣ가-힣a-zA-Z0-9-]/g, '')
    .toLowerCase();
}

function normalizeFlexibleParticle(value) {
  const target = normalizeAnswer(value);
  if (target.startsWith('을')) return normalizeAnswer('를' + target.substring(1));
  if (target.startsWith('를')) return normalizeAnswer('을' + target.substring(1));
  if (target.startsWith('와')) return normalizeAnswer('과' + target.substring(1));
  if (target.startsWith('과')) return normalizeAnswer('와' + target.substring(1));
  if (target.startsWith('이')) return normalizeAnswer('가' + target.substring(1));
  if (target.startsWith('가')) return normalizeAnswer('이' + target.substring(1));
  return target;
}

function getItemKey(item) {
  return `${item.source || ''}|${item.abbrCode || ''}|${item.prompt}|${item.answer}`;
}

function resultLine(item, ok, typed = '') {
  if (isAbbrPracticeMode()) {
    return "약어:" + item.answer + (item.abbrCode ? "\t자리:" + item.abbrCode : '') + (typed ? "\t입력:" + typed : "");
  }
  return item.prompt;
}

// --- TTS 및 오디오 제어 ---
function toggleTTS() {
  if (practiceMode === 'dictionary_visual') {
    practiceMode = 'dictionary_voice';
    setTTS(true, { force: true });
    syncModeUI();
    if (currentAbbr) speak(currentAbbr);
    return;
  }
  if (practiceMode === 'abbr_wrong_visual') {
    practiceMode = 'abbr_wrong_voice';
    setTTS(true, { force: true });
    syncModeUI();
    if (currentAbbr) speak(currentAbbr);
    return;
  }
  if (isVoiceMode()) {
    setTTS(true, { force: true });
    speak(currentAbbr);
    return;
  }
  setTTS(!ttsMode);
}

function setTTS(next, options = {}) {
  if (isVoiceMode() && next === false && !options.force) return;
  ttsMode = Boolean(next);
  const btn = $('ttsToggle');
  const display = $('abbrDisplay');
  const panel = $('audioPanel');

  if (ttsMode) {
    btn.classList.add('active');
    btn.innerText = isVoiceMode() ? '🎧 듣고치기 ON' : '🎧 듣고 치기 ON';
    display.classList.add('blind');
    panel.style.display = 'grid';
    if (!options.silent && currentAbbr) speak(currentAbbr);
  } else {
    btn.classList.remove('active');
    btn.innerText = isAbbrPracticeMode() ? '🎧 듣고치기로 전환' : '🎧 듣고 치기 OFF';
    display.classList.remove('blind');
    panel.style.display = 'none';
  }
  $('userInput').focus();
}

function updateAudioSettings() {
  speechRate = $('rateRange').value;
  speechVol = $('volRange').value;
  $('rateVal').innerText = speechRate;
  $('volVal').innerText = speechVol;
}

function replayAudio() {
  if (currentAbbr) speak(currentAbbr);
  $('userInput').focus();
}

function speak(text) {
  if (!window.speechSynthesis || !text) return;
  window.speechSynthesis.cancel();
  const utter = new SpeechSynthesisUtterance(cleanSpeakText(text));
  utter.lang = 'ko-KR';
  utter.rate = Number(speechRate) || 1.0;
  utter.volume = Number(speechVol) || 1.0;
  if (selectedVoice) utter.voice = selectedVoice;
  window.speechSynthesis.speak(utter);
}

function cleanSpeakText(text) {
  return String(text || '')
    .replace(/↙/g, ' ')
    .replace(/#/g, ' ')
    .replace(/\|/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

// --- 기타 유틸리티 ---
function updateComboUI() {
  const badge = $('comboBadge');
  badge.innerText = `🔥 ${combo} COMBO`;
  if (combo > 1) badge.classList.add('show');
  else badge.classList.remove('show');
}

function downloadResults(type) {
  const list = type === '정답' ? correctList : wrongList.map(item => item.text);
  if (list.length === 0) return alert('저장할 데이터가 없습니다.');
  const blob = new Blob([[...new Set(list)].join('\n')], { type: 'text/plain;charset=utf-8;' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `${type}_목록.txt`;
  a.click();
  URL.revokeObjectURL(a.href);
}

setInterval(() => {
  if (totalStartTime && !isFinished) {
    const elapsed = Math.floor((Date.now() - totalStartTime) / 1000);
    $('timerLabel').innerText = `${elapsed}초`;
  }
}, 1000);

function updateUI() {
  $('counterLabel').innerText = `${abbreviations.length} / ${totalCount}`;
}

function shuffle(list) {
  const arr = Array.isArray(list) ? list.slice() : [];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function logout() {
  if (confirm('로그아웃 하시겠습니까?')) window.SorizavaAuth.signOut();
}
