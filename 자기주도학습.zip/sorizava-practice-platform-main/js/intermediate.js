(function () {
  const COURSE_CONFIG = {
    intermediate: {
      key: 'intermediate',
      navKey: 'intermediate',
      icon: '🧩',
      title: '중급반 공부방',
      shortLabel: '중급반',
      description: '관리자가 등록한 중급반 자료를 선택해 보고 치기와 듣고 치기로 연습합니다. 보고 치기는 페이스메이커가 자동으로 작동합니다.',
      levelFieldLabel: '글자수',
      levelTitle: '중급반 글자수 선택',
      levelHelp: '110자부터 170자까지 선택 후 등록 자료를 고릅니다.',
      adminHelp: '글자수별로 4~10개 자료까지 등록할 수 있습니다. 원문은 채점 기준으로 사용되고, 오디오는 듣고 치기에서만 재생됩니다.',
      adminPlaceholder: '예: 110자 1번 / 120자 논설 3번',
      levels: [110, 120, 130, 140, 150, 160, 170].map(v => ({ value: v, label: `${v}자`, pace: v })),
      toolType: 'intermediate',
      abbrToolType: 'intermediate_abbreviations',
      progressKind: 'intermediate_progress',
      storageFolder: 'intermediate',
      historyKey: 'sorizava_intermediate_history',
      progressKey: 'sorizava_intermediate_progress_logs_v1',
      localMaterialsKey: 'sorizava_intermediate_materials_v3',
      localAbbrKey: 'sorizava_intermediate_abbreviations_v1',
      legacySourcePrefix: 'sorizava_intermediate_source_'
    },
    advanced: {
      key: 'advanced',
      navKey: 'advanced',
      icon: '🚀',
      title: '고급반 공부방',
      shortLabel: '고급반 공부방',
      description: '관리자가 등록한 고급반 공부방 자료를 선택해 보고 치기와 듣고 치기로 연습합니다.',
      levelFieldLabel: '글자수',
      levelTitle: '고급반 글자수 선택',
      levelHelp: '190자부터 250자까지 선택 후 등록 자료를 고릅니다.',
      adminHelp: '고급반 공부방 글자수별 자료를 등록합니다. 원문은 채점 기준으로 사용되고, 오디오는 듣고 치기에서만 재생됩니다.',
      adminPlaceholder: '예: 190자 연설 1번 / 230자 논설 2번',
      levels: [190, 210, 230, 250].map(v => ({ value: v, label: `${v}자`, pace: v })),
      toolType: 'advanced',
      abbrToolType: 'advanced_abbreviations',
      progressKind: 'advanced_progress',
      storageFolder: 'advanced',
      historyKey: 'sorizava_advanced_history',
      progressKey: 'sorizava_advanced_progress_logs_v1',
      localMaterialsKey: 'sorizava_advanced_materials_v1',
      localAbbrKey: 'sorizava_advanced_abbreviations_v1',
      legacySourcePrefix: 'sorizava_advanced_source_'
    },
    grade: {
      key: 'grade',
      navKey: 'grade',
      icon: '🏅',
      title: '급수반 공부방',
      shortLabel: '급수반 공부방',
      description: '관리자가 등록한 급수반 공부방 자료를 선택해 시험 급수별로 보고 치기와 듣고 치기를 연습합니다.',
      levelFieldLabel: '급수',
      levelTitle: '급수반 급수 선택',
      levelHelp: '3급, 2급, 1급 자료를 선택 후 등록 자료를 고릅니다.',
      adminHelp: '급수반 공부방 급수별 자료를 등록합니다. 원문은 채점 기준으로 사용되고, 오디오는 듣고 치기에서만 재생됩니다.',
      adminPlaceholder: '예: 3급 연설 1번 / 1급 논설 2번',
      levels: [
        { value: 170, label: '3급', pace: 170 },
        { value: 210, label: '2급', pace: 210 },
        { value: 250, label: '1급', pace: 250 }
      ],
      toolType: 'grade',
      abbrToolType: 'grade_abbreviations',
      progressKind: 'grade_progress',
      storageFolder: 'grade',
      historyKey: 'sorizava_grade_history',
      progressKey: 'sorizava_grade_progress_logs_v1',
      localMaterialsKey: 'sorizava_grade_materials_v1',
      localAbbrKey: 'sorizava_grade_abbreviations_v1',
      legacySourcePrefix: 'sorizava_grade_source_'
    }
  };
  function resolveCourseKey() {
    const params = new URLSearchParams(location.search);
    const raw = String(params.get('course') || params.get('track') || params.get('type') || 'intermediate').toLowerCase();
    if (['advanced', 'high', '고급', '고급반'].includes(raw)) return 'advanced';
    if (['grade', 'level', '급수', '급수반'].includes(raw)) return 'grade';
    return 'intermediate';
  }
  const COURSE_KEY = resolveCourseKey();
  const COURSE = COURSE_CONFIG[COURSE_KEY] || COURSE_CONFIG.intermediate;
  const LEVELS = COURSE.levels.map(item => item.value);
  const HISTORY_KEY = COURSE.historyKey;
  const PROGRESS_LOG_KEY = COURSE.progressKey;
  const PASS_ACCURACY = 90;
  const UNLOCK_DAILY_LIMIT = 3; // 구버전 호환용: 실제 승급은 unlock-room.html에서 주 3회로 처리
  const UNLOCK_EXTRA_CHANCES_KEY = `sorizava_${COURSE.key}_unlock_extra_chances_v1`;
  const LOCAL_MATERIALS_KEY = COURSE.localMaterialsKey;
  const LOCAL_ABBR_KEY = COURSE.localAbbrKey;
  const LEGACY_SOURCE_PREFIX = COURSE.legacySourcePrefix;
  const AUDIO_STORAGE_BUCKET = 'practice-audios';
  const LOCAL_AUDIO_INLINE_MAX_BYTES = 900 * 1024;
  const AUDIO_UPLOAD_TIMEOUT_MS = 60000;
  const DB_SAVE_TIMEOUT_MS = 45000;

  let currentLevel = LEVELS[0];
  let currentMode = 'view';
  let roomMode = 'study';
  let currentMaterialId = null;
  let currentMaterial = null;
  let currentParagraph = 'all';
  let materials = [];
  let startTime = null;
  let timerInterval = null;
  let currentSpeed = 1.0;
  let smartPauseTimer = null;
  let isSmartPausing = false;
  let isMaterialManager = false;
  let isStrictAdmin = false;
  let adminAudioDataUrl = '';
  let adminAudioName = '';
  let adminAudioFile = null;
  let pacemakerTimer = null;
  let pacemakerIndex = 0;
  let pacemakerActive = false;
  let autoFinishLock = false;
  let unlockAttemptSubmitted = false;
  let abbreviations = [];
  let pendingAbbreviations = null;
  let abbreviationRowId = null;
  let isAbbrVisible = false;

  const $ = (id) => document.getElementById(id);
  function courseBaseLabel() { return String(COURSE.shortLabel || COURSE.title || '').replace(/\s*공부방$/, ''); }

  function levelMeta(level) {
    const numeric = Number(level);
    return COURSE.levels.find(item => Number(item.value) === numeric) || { value: numeric, label: `${numeric}자`, pace: numeric };
  }
  function levelLabel(level) { return levelMeta(level).label; }
  function levelPace(level) { return Number(levelMeta(level).pace || level || 1); }
  function levelIndex(level) { return LEVELS.indexOf(Number(level)); }
  function nextLevel(level) {
    const idx = levelIndex(level);
    return idx >= 0 ? LEVELS[idx + 1] || null : null;
  }
  function previousLevel(level) {
    const idx = levelIndex(level);
    return idx > 0 ? LEVELS[idx - 1] : null;
  }
  function stripLevelPrefix(title) {
    let value = String(title || '').trim();
    COURSE.levels.forEach(meta => {
      const escapedLabel = meta.label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      value = value.replace(new RegExp(`^\\s*${escapedLabel}\\s*`), '');
    });
    return value.replace(/^\s*\d+\s*자\s*/, '').replace(/^\s*[123]\s*급\s*/, '').trim();
  }
  function normalizeLevelValue(value, title = '') {
    const raw = String(value ?? '').trim();
    if (raw) {
      const byLabel = COURSE.levels.find(meta => raw === String(meta.value) || raw === meta.label || raw.includes(meta.label));
      if (byLabel) return Number(byLabel.value);
      const num = Number(raw.replace(/[^0-9]/g, ''));
      if (Number.isFinite(num)) {
        const direct = COURSE.levels.find(meta => Number(meta.value) === num);
        if (direct) return Number(direct.value);
        const grade = COURSE.levels.find(meta => meta.label === `${num}급`);
        if (grade) return Number(grade.value);
      }
    }
    return extractLevel(title) || LEVELS[0];
  }

  function applyCourseUi() {
    document.title = `SHORTHAND PRO - ${COURSE.title}`;
    document.body?.setAttribute('data-course', COURSE.key);
    document.querySelectorAll('.nav-item').forEach(item => item.classList.toggle('active', item.dataset.navKey === COURSE.navKey));
    const pageTitle = document.querySelector('.page-title h2');
    if (pageTitle) pageTitle.innerText = `${COURSE.icon} ${COURSE.title}`;
    const pageDesc = document.querySelector('.page-title p');
    if (pageDesc) pageDesc.innerText = COURSE.description;
    const adminHelp = document.querySelector('.admin-head p');
    if (adminHelp) adminHelp.innerText = COURSE.adminHelp;
    const adminLevelLabel = $('adminLevel')?.closest('label')?.querySelector('span');
    if (adminLevelLabel) adminLevelLabel.innerText = COURSE.levelFieldLabel;
    if ($('adminTitle')) $('adminTitle').placeholder = COURSE.adminPlaceholder;
    const progressTitle = document.querySelector('.progress-title');
    if (progressTitle) progressTitle.innerText = `${COURSE.shortLabel} 진도 잠금`;
    const progressDesc = document.querySelector('.progress-head p');
    if (progressDesc) progressDesc.innerText = `각 단계의 모든 파일을 듣고치기 정확도 ${PASS_ACCURACY}% 이상으로 통과해야 다음 단계가 열립니다.`;
    const progressBtn = document.querySelector('.progress-head button');
    if (progressBtn) progressBtn.innerText = '진도 현황 보기';
    const levelTitle = document.querySelector('.level-title');
    if (levelTitle) levelTitle.innerText = COURSE.levelTitle;
    const levelHelp = document.querySelector('.level-help');
    if (levelHelp) levelHelp.innerText = COURSE.levelHelp;
    const historyTitle = document.querySelector('.history-title');
    if (historyTitle) historyTitle.innerText = `📋 최근 ${COURSE.shortLabel} 연습 기록`;
    const modalBtn = document.querySelector('.modal-actions .btn-secondary');
    if (modalBtn) modalBtn.innerText = '진도 현황 보기';
    const studyBtn = $('roomStudyBtn');
    const unlockBtn = $('roomUnlockBtn');
    if (studyBtn) studyBtn.innerText = `${courseBaseLabel()} 공부방`;
    if (unlockBtn) unlockBtn.innerText = `${courseBaseLabel()} 진도 승급실`;
  }

  function pureText(text) { return String(text || '').replace(/[^a-zA-Z0-9가-힣]/g, ''); }
  function pureCount(text) { return pureText(text).length; }
  function isPaceCountedChar(ch) { return /[a-zA-Z0-9가-힣]/.test(String(ch || '')); }
  function escapeHtml(text) {
    return String(text || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
  function toHtmlChar(ch) {
    if (ch === ' ') return ' ';
    if (ch === '\n') return '<br>';
    return escapeHtml(ch);
  }
  function formatTime(seconds) {
    const min = Math.floor(seconds / 60);
    const sec = Math.floor(seconds % 60);
    return `${min}:${sec < 10 ? '0' : ''}${sec}`;
  }
  function formatClock(seconds) {
    const min = Math.floor(seconds / 60).toString().padStart(2, '0');
    const sec = Math.floor(seconds % 60).toString().padStart(2, '0');
    return `${min}:${sec}`;
  }
  function formatFileSize(bytes) {
    const size = Number(bytes || 0);
    if (size >= 1024 * 1024) return `${(size / 1024 / 1024).toFixed(1)}MB`;
    if (size >= 1024) return `${Math.round(size / 1024)}KB`;
    return `${size}B`;
  }
  function safeFileName(name) {
    const original = String(name || 'audio.mp3').normalize('NFKD');
    const extMatch = original.match(/\.([a-zA-Z0-9]{1,8})$/);
    const ext = extMatch ? extMatch[1].toLowerCase() : 'mp3';
    const stem = original
      .replace(/\.[^/.]+$/, '')
      .replace(/[^a-zA-Z0-9_-]+/g, '_')
      .replace(/_+/g, '_')
      .replace(/^_+|_+$/g, '')
      .slice(0, 60);
    return `${stem || 'audio'}_${Date.now()}.${ext || 'mp3'}`;
  }
  function makeAudioStoragePath(level, file) {
    const random = Math.random().toString(36).slice(2, 8);
    return `${COURSE.storageFolder}/${level}/${Date.now()}_${random}_${safeFileName(file?.name)}`;
  }
  function readFileAsDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = () => reject(reader.error || new Error('오디오 파일을 읽지 못했습니다.'));
      reader.readAsDataURL(file);
    });
  }
  function withTimeout(promise, ms, label) {
    let timer;
    const timeout = new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error(label || '요청 시간이 초과되었습니다.')), ms);
    });
    return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
  }
  function getMaterialAudioSrc(item) {
    return item ? (item.audioUrl || item.audioDataUrl || '') : '';
  }
  function setAdminSaveBusy(isBusy) {
    const btn = document.querySelector('button[onclick="saveAdminMaterial()"]');
    if (!btn) return;
    if (isBusy) {
      btn.dataset.originalText = btn.dataset.originalText || btn.innerText;
      btn.disabled = true;
      btn.innerText = '저장 중...';
    } else {
      btn.disabled = false;
      btn.innerText = btn.dataset.originalText || '저장/수정';
    }
  }
  function isAudioStorageError(error) {
    const message = String(error?.message || error || '');
    return message.includes('오디오') || message.includes('Storage') || message.includes('storage') || message.includes(AUDIO_STORAGE_BUCKET);
  }
  function normalizeRole(value) { return String(value || '').trim().toLowerCase(); }
  function getCachedProfileRole() {
    try {
      const cached = JSON.parse(sessionStorage.getItem('sorizava_profile') || '{}');
      return cached.role || '';
    } catch (error) {
      return '';
    }
  }
  function showCourseLockedScreen() {
    document.body?.classList.add('course-entry-locked');
    const main = document.querySelector('.main-content');
    if (!main) {
      alert(window.SorizavaCourseGate?.message || '입문반 졸업시험을 먼저 통과해야 중급반 공부방이 열립니다.');
      location.href = 'exam.html';
      return;
    }
    main.innerHTML = `
      <section class="course-locked-card">
        <div class="course-locked-icon">🔒</div>
        <h2>중급반 공부방 입장 전 입문반 졸업시험 통과가 필요합니다.</h2>
        <p>공부방 메뉴는 숨기지 않습니다. 다만 클릭했을 때 현재 필요한 선행 조건을 안내합니다.</p>
        <div class="course-locked-rule">
          <b>승급 순서</b>
          <span>입문반 졸업시험 합격 → 110자 자동 승급 → 진도 승급실에서 120자부터 단계별 승급</span>
        </div>
        <button type="button" class="btn-primary" onclick="location.href='exam.html'">입문반 졸업시험 보러 가기</button>
      </section>
    `;
  }
  async function ensureCourseEntryAllowed(ctx) {
    if (hasMaterialManageAccess(ctx) || hasStrictAdminAccess(ctx)) return true;
    if (window.SorizavaCourseGate?.hasGraduationPassed) {
      const ok = await window.SorizavaCourseGate.hasGraduationPassed(true);
      if (ok) return true;
    } else if (localStorage.getItem('sorizava_graduation_exam_passed') === 'true') {
      return true;
    }
    showCourseLockedScreen();
    return false;
  }

  function collectRoles(ctx) {
    return [
      ctx?.profile?.role,
      sessionStorage.getItem('shorthand_role'),
      getCachedProfileRole()
    ].map(normalizeRole).filter(Boolean);
  }
  function hasStrictAdminAccess(ctx) {
    const strictRoles = ['admin', 'administrator', 'super_admin', 'superadmin', 'owner', 'manager', 'operator', 'staff', '관리자', '운영팀'];
    return collectRoles(ctx).some(role => strictRoles.includes(role));
  }
  function hasMaterialManageAccess(ctx) {
    const materialRoles = ['admin', 'administrator', 'super_admin', 'superadmin', 'owner', 'manager', 'operator', 'staff', 'teacher', '강사', '선생님', '관리자', '운영팀'];
    return collectRoles(ctx).some(role => materialRoles.includes(role));
  }

  async function init(ctx) {
    applyCourseUi();
    isStrictAdmin = hasStrictAdminAccess(ctx);
    isMaterialManager = hasMaterialManageAccess(ctx) || isStrictAdmin;
    if (!(await ensureCourseEntryAllowed(ctx))) return;
    initRoomModeFromUrl();
    renderLevelButtons();
    renderAdminLevels();
    bindEvents();
    updateUserBox();

    if (isMaterialManager && $('adminPanelToggle')) $('adminPanelToggle').style.display = 'inline-flex';
    if (isStrictAdmin && $('adminBtn')) $('adminBtn').style.display = 'block';

    await loadAbbreviations();
    await loadMaterials();
    await syncRemoteProgressLogs();
    applyInitialSelection();
    setRoomMode(roomMode);
    loadHistory();
  }

  function updateUserBox() {
    const currentUser = sessionStorage.getItem('shorthand_user') || 'User';
    const nameEl = $('userNameSide');
    const avatarEl = $('userAvatar');
    if (nameEl) nameEl.innerText = currentUser;
    if (avatarEl) avatarEl.innerText = currentUser.charAt(0);
  }

  function bindEvents() {
    $('typingArea').addEventListener('input', () => {
      const typedCount = pureCount($('typingArea').value);
      $('typingCount').innerText = typedCount + '자';
      if (!startTime && typedCount > 0) startTimer();
      if (typedCount === 0) resetTimerOnly();
      handleSmartPause();
      keepTypingAreaAtCursor();
      syncSourceToTypedProgress();
      checkParagraphAutoFinish();
    });

    $('materialSelect').addEventListener('change', () => {
      currentMaterialId = $('materialSelect').value || null;
      currentMaterial = findMaterial(currentMaterialId);
      currentParagraph = 'all';
      applyCurrentMaterial();
      resetPractice(false);
    });

    $('seekBar').addEventListener('input', () => {
      const audio = $('audioPlayer');
      if (!audio.duration) return;
      audio.currentTime = ($('seekBar').value / 100) * audio.duration;
    });

    const audio = $('audioPlayer');
    audio.addEventListener('loadedmetadata', () => {
      $('totalTime').innerText = formatTime(audio.duration || 0);
      $('audioLeft').innerText = Math.floor(audio.duration || 0);
      $('seekBar').max = 100;
    });
    audio.addEventListener('timeupdate', () => {
      if (!audio.duration) return;
      $('seekBar').value = (audio.currentTime / audio.duration) * 100;
      $('currentTime').innerText = formatTime(audio.currentTime);
      $('audioLeft').innerText = Math.max(0, Math.floor(audio.duration - audio.currentTime));
    });
    audio.addEventListener('ended', () => { $('playBtn').innerText = '▶ 재생'; });

    $('adminLevel').addEventListener('change', () => {
      renderAdminMaterialSelect();
      newMaterialForm(false);
    });
    $('adminMaterialSelect').addEventListener('change', () => {
      const value = $('adminMaterialSelect').value;
      if (value === '__new') newMaterialForm(false);
      else populateAdminForm(value);
    });
    $('adminSourceFile').addEventListener('change', (event) => {
      const file = event.target.files && event.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        $('adminSourceText').value = String(reader.result || '');
        event.target.value = '';
      };
      reader.readAsText(file, 'utf-8');
    });
    $('adminAudioFile').addEventListener('change', (event) => {
      const file = event.target.files && event.target.files[0];
      if (!file) return;
      if (file.size > 30 * 1024 * 1024) alert('오디오 용량이 큽니다. 가능하면 30MB 이하 mp3 파일을 권장합니다.');
      adminAudioFile = file;
      adminAudioDataUrl = '';
      adminAudioName = file.name;
      $('adminAudioName').innerText = `${file.name} (${formatFileSize(file.size)})`;
      event.target.value = '';
    });

    if ($('adminAbbrFile')) {
      $('adminAbbrFile').addEventListener('change', async (event) => {
        const file = event.target.files && event.target.files[0];
        if (!file) return;
        try {
          pendingAbbreviations = await readAbbreviationExcel(file);
          renderAbbreviationAdminState();
          alert(`약어 ${pendingAbbreviations.length}개를 불러왔습니다. 전체 학생에게 적용하려면 '약어 목록 저장'을 누르세요.`);
        } catch (error) {
          console.warn(error);
          alert('약어 엑셀을 읽지 못했습니다. 첫 번째 열에 약어가 들어 있는 .xlsx 파일인지 확인하세요.');
        } finally {
          event.target.value = '';
        }
      });
    }

    window.addEventListener('keydown', (event) => {
      if (event.key !== 'Escape') return;
      const modal = $('resultModal');
      if (modal && modal.style.display === 'block') {
        modal.style.display = 'none';
        return;
      }
      if ($('typingArea').value.trim()) finishPractice();
    });
  }

  function renderLevelButtons() {
    const box = $('levelList');
    if (!box) return;
    box.innerHTML = LEVELS.map(level => {
      const progress = getLevelProgress(level);
      const unlocked = isMaterialManager || isLevelUnlocked(level);
      const active = Number(level) === Number(currentLevel);
      const passed = progress.unlockPassed;
      const status = passed ? '승급완료' : unlocked ? (roomMode === 'unlock' ? '응시가능' : '공부가능') : '잠금';
      const reason = unlocked ? `${levelLabel(level)} 선택` : getNextLockedReason(level);
      return `
        <button type="button" class="level-btn ${active ? 'active' : ''} ${passed ? 'passed' : ''} ${unlocked ? '' : 'locked'}" data-level="${level}" title="${escapeHtml(reason)}" onclick="selectLevel(${level})">
          <strong>${unlocked ? '' : '🔒 '}${levelLabel(level)}</strong>
          <small>${escapeHtml(status)}</small>
        </button>
      `;
    }).join('');
  }
  function renderAdminLevels() {
    $('adminLevel').innerHTML = LEVELS.map(level => `<option value="${level}">${levelLabel(level)}</option>`).join('');
  }

  function normalizeAbbreviationList(list) {
    const seen = new Set();
    return (Array.isArray(list) ? list : [])
      .map(value => String(value || '').trim())
      .filter(value => value.length > 1)
      .filter(value => {
        const key = value.toLowerCase();
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      })
      .sort((a, b) => b.length - a.length || a.localeCompare(b, 'ko'));
  }
  function readLocalAbbreviations() {
    try {
      const saved = JSON.parse(localStorage.getItem(LOCAL_ABBR_KEY) || '[]');
      return normalizeAbbreviationList(saved);
    } catch (error) {
      return [];
    }
  }
  function writeLocalAbbreviations(list) {
    localStorage.setItem(LOCAL_ABBR_KEY, JSON.stringify(normalizeAbbreviationList(list)));
  }
  function parseAbbreviationPayload(content) {
    let payload = content;
    if (typeof payload === 'string') {
      try { payload = JSON.parse(payload); }
      catch (error) { payload = { abbreviations: payload.split(/\r?\n|,/g) }; }
    }
    if (Array.isArray(payload)) return normalizeAbbreviationList(payload);
    return normalizeAbbreviationList(payload?.abbreviations || payload?.list || payload?.items || []);
  }
  async function loadAbbreviations() {
    let loaded = [];
    abbreviationRowId = null;
    try {
      const client = window.SORIZAVA_SUPABASE;
      if (!client) throw new Error('Supabase client missing');
      const { data, error } = await client
        .from('practice_materials')
        .select('id, content, created_at')
        .eq('tool_type', COURSE.abbrToolType)
        .eq('is_active', true)
        .order('created_at', { ascending: false })
        .limit(1);
      if (error) throw error;
      const row = data && data[0];
      if (row) {
        abbreviationRowId = row.id;
        loaded = parseAbbreviationPayload(row.content);
      }
    } catch (error) {
      console.warn('약어 목록 서버 조회 실패, 로컬 약어로 대체:', error);
      loaded = readLocalAbbreviations();
    }
    if (!loaded.length) loaded = readLocalAbbreviations();
    abbreviations = normalizeAbbreviationList(loaded);
    pendingAbbreviations = abbreviations.slice();
    renderAbbreviationAdminState();
    renderAbbreviationToggleState();
  }
  function readAbbreviationExcel(file) {
    return new Promise((resolve, reject) => {
      if (!window.XLSX) {
        reject(new Error('XLSX library missing'));
        return;
      }
      const reader = new FileReader();
      reader.onerror = () => reject(reader.error || new Error('file read failed'));
      reader.onload = (event) => {
        try {
          const data = new Uint8Array(event.target.result);
          const workbook = XLSX.read(data, { type: 'array' });
          const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
          const rows = XLSX.utils.sheet_to_json(firstSheet, { header: 1 });
          const list = rows.map(row => row && row[0]).filter(Boolean);
          resolve(normalizeAbbreviationList(list));
        } catch (error) {
          reject(error);
        }
      };
      reader.readAsArrayBuffer(file);
    });
  }
  function renderAbbreviationAdminState() {
    const list = normalizeAbbreviationList(pendingAbbreviations || abbreviations);
    if ($('adminAbbrCount')) $('adminAbbrCount').innerText = `약어 ${list.length}개`;
    if ($('adminAbbrPreview')) {
      $('adminAbbrPreview').innerHTML = list.length
        ? list.slice(0, 80).map(item => `<span>${escapeHtml(item)}</span>`).join('') + (list.length > 80 ? `<em>외 ${list.length - 80}개</em>` : '')
        : '등록된 약어가 없습니다.';
    }
  }
  function renderAbbreviationToggleState() {
    const btn = $('abbrToggleBtn');
    if (!btn) return;
    const count = abbreviations.length;
    if (!count) isAbbrVisible = false;
    btn.innerText = isAbbrVisible ? '약어표시 ON' : '약어표시 OFF';
    btn.classList.toggle('on', isAbbrVisible);
    btn.classList.toggle('off', !isAbbrVisible);
    btn.disabled = false;
    btn.title = count ? '보고치기 원문에 등록 약어를 표시합니다.' : '관리자 자료 관리에서 약어 엑셀을 먼저 등록하세요.';
    if ($('abbrCountLabel')) $('abbrCountLabel').innerText = `약어 ${count}개`;
  }
  function toggleAbbreviationDisplay(force) {
    if (!abbreviations.length) {
      isAbbrVisible = false;
      renderAbbreviationToggleState();
      alert('등록된 약어 목록이 없습니다. 관리자 자료 관리에서 약어 엑셀을 먼저 저장하세요.');
      return;
    }
    isAbbrVisible = typeof force === 'boolean' ? force : !isAbbrVisible;
    renderAbbreviationToggleState();
    renderSourceText();
  }
  function getAbbreviationHighlightSet(text) {
    const marks = new Set();
    if (!isAbbrVisible || currentMode !== 'view' || !abbreviations.length || !text) return marks;
    abbreviations.forEach(abbr => {
      let start = String(text).indexOf(abbr);
      while (start !== -1) {
        let overlaps = false;
        for (let i = start; i < start + abbr.length; i += 1) {
          if (marks.has(i)) { overlaps = true; break; }
        }
        if (!overlaps) {
          for (let i = start; i < start + abbr.length; i += 1) marks.add(i);
        }
        start = String(text).indexOf(abbr, start + Math.max(1, abbr.length));
      }
    });
    return marks;
  }
  async function saveAbbreviationList() {
    if (!isMaterialManager) return alert('약어 목록 저장 권한이 없습니다.');
    const list = normalizeAbbreviationList(pendingAbbreviations || abbreviations);
    if (!list.length) return alert('저장할 약어가 없습니다. 약어 엑셀을 먼저 불러오세요.');
    const payload = { abbreviations: list, updatedAt: new Date().toISOString() };
    try {
      const client = window.SORIZAVA_SUPABASE;
      if (!client) throw new Error('Supabase client missing');
      if (abbreviationRowId) {
        const { error } = await client
          .from('practice_materials')
          .update({ title: `${COURSE.shortLabel} 약어 표시 목록`, content: JSON.stringify(payload), is_active: true })
          .eq('id', abbreviationRowId);
        if (error) throw error;
      } else {
        const { data, error } = await client
          .from('practice_materials')
          .insert({ tool_type: COURSE.abbrToolType, title: `${COURSE.shortLabel} 약어 표시 목록`, content: JSON.stringify(payload), is_active: true, created_by: sessionStorage.getItem('shorthand_user_id') })
          .select('id')
          .single();
        if (error) throw error;
        abbreviationRowId = data?.id || null;
      }
      abbreviations = list;
      pendingAbbreviations = list.slice();
      writeLocalAbbreviations(list);
      alert(`약어 ${list.length}개를 저장했습니다.`);
    } catch (error) {
      console.warn('약어 목록 서버 저장 실패, 로컬 저장으로 대체:', error);
      abbreviations = list;
      pendingAbbreviations = list.slice();
      writeLocalAbbreviations(list);
      alert('서버 저장에 실패해 현재 브라우저에 임시 저장했습니다. 전체 학생 공유용 Supabase 권한 설정을 확인해야 합니다.');
    }
    renderAbbreviationAdminState();
    renderAbbreviationToggleState();
    renderSourceText();
  }
  async function clearAbbreviationList() {
    if (!isMaterialManager) return alert('약어 목록 수정 권한이 없습니다.');
    if (!confirm('등록된 약어 목록을 비우시겠습니까?')) return;
    try {
      const client = window.SORIZAVA_SUPABASE;
      if (client && abbreviationRowId) {
        const { error } = await client
          .from('practice_materials')
          .update({ content: JSON.stringify({ abbreviations: [], updatedAt: new Date().toISOString() }), is_active: true })
          .eq('id', abbreviationRowId);
        if (error) throw error;
      }
    } catch (error) {
      console.warn('약어 목록 서버 비우기 실패:', error);
    }
    abbreviations = [];
    pendingAbbreviations = [];
    isAbbrVisible = false;
    writeLocalAbbreviations([]);
    renderAbbreviationAdminState();
    renderAbbreviationToggleState();
    renderSourceText();
  }

  function normalizeMaterial(row, index = 0, source = 'supabase') {
    let payload = {};
    if (typeof row.content === 'string') {
      try { payload = JSON.parse(row.content); }
      catch (e) { payload = { sourceText: row.content }; }
    } else if (row.content && typeof row.content === 'object') {
      payload = row.content;
    }
    const level = normalizeLevelValue(payload.level || row.level, row.title || payload.title || '');
    const cleanTitle = payload.title || row.display_title || row.title || `${levelLabel(level)} 자료 ${index + 1}`;
    return {
      id: String(row.id || payload.id || `${source}_${level}_${index}_${Date.now()}`),
      source,
      rowId: row.id || null,
      level,
      title: stripLevelPrefix(cleanTitle),
      sourceText: payload.sourceText || payload.text || '',
      audioName: payload.audioName || payload.audio_name || '',
      audioDataUrl: payload.audioDataUrl || payload.audio_data_url || '',
      audioUrl: payload.audioUrl || payload.audio_url || row.audio_url || '',
      audioPath: payload.audioPath || payload.audio_path || '',
      audioMime: payload.audioMime || payload.audio_mime || '',
      createdAt: row.created_at || payload.createdAt || ''
    };
  }
  function extractLevel(title) {
    const text = String(title || '');
    const byLabel = COURSE.levels.find(meta => text.includes(meta.label));
    if (byLabel) return Number(byLabel.value);
    const values = COURSE.levels.map(meta => meta.value).join('|');
    const match = text.match(new RegExp(`(${values})`));
    return match ? Number(match[1]) : null;
  }

  async function loadMaterials() {
    let loaded = [];
    try {
      const client = window.SORIZAVA_SUPABASE;
      if (!client) throw new Error('Supabase client missing');
      const { data, error } = await client
        .from('practice_materials')
        .select('*')
        .eq('tool_type', COURSE.toolType)
        .eq('is_active', true)
        .order('created_at', { ascending: true });
      if (error) throw error;
      loaded = (data || []).map((row, idx) => normalizeMaterial(row, idx, 'supabase'));
    } catch (error) {
      console.warn(`${COURSE.shortLabel} 자료 서버 조회 실패, 로컬 자료로 대체:`, error);
      loaded = readLocalMaterials();
    }
    const localLoaded = readLocalMaterials();
    if (localLoaded.length) {
      const map = new Map();
      [...loaded, ...localLoaded].forEach(item => {
        if (!item) return;
        const key = `${item.source || 'row'}|${item.rowId || item.id || item.level + '_' + item.title}`;
        map.set(key, item);
      });
      loaded = Array.from(map.values());
    }
    if (!loaded.length) loaded = readLegacySources();
    materials = loaded.sort((a, b) => levelIndex(a.level) - levelIndex(b.level) || a.title.localeCompare(b.title, 'ko')); 
    renderProgressState();
    renderAdminMaterialSelect();
  }

  function readLocalMaterials() {
    try {
      const rows = JSON.parse(localStorage.getItem(LOCAL_MATERIALS_KEY) || '[]');
      return rows.map((row, idx) => normalizeMaterial(row, idx, 'local'));
    } catch (e) { return []; }
  }
  function writeLocalMaterials(list) {
    const compact = list.map(item => ({
      id: item.id,
      level: item.level,
      title: item.title,
      content: JSON.stringify({
        level: item.level,
        title: item.title,
        sourceText: item.sourceText,
        audioName: item.audioName,
        audioDataUrl: item.audioDataUrl,
        audioUrl: item.audioUrl || '',
        audioPath: item.audioPath || '',
        audioMime: item.audioMime || '',
        createdAt: item.createdAt || new Date().toISOString()
      })
    }));
    localStorage.setItem(LOCAL_MATERIALS_KEY, JSON.stringify(compact));
  }
  function readLegacySources() {
    return LEVELS.map(level => {
      const text = localStorage.getItem(LEGACY_SOURCE_PREFIX + level);
      if (!text) return null;
      return { id: `legacy_${level}`, source: 'legacy', rowId: null, level, title: `${levelLabel(level)} 기존 저장 원문`, sourceText: text, audioName: '', audioDataUrl: '', audioUrl: '', audioPath: '', audioMime: '', createdAt: '' };
    }).filter(Boolean);
  }
  function materialsForLevel(level = currentLevel) { return materials.filter(item => Number(item.level) === Number(level)); }
  function findMaterial(id) { return materials.find(item => String(item.id) === String(id)) || null; }
  function materialKey(item) { return item ? String(item.rowId || item.id || item.title || '') : ''; }
  function readProgressLogs() {
    try {
      const rows = JSON.parse(localStorage.getItem(PROGRESS_LOG_KEY) || '[]');
      return Array.isArray(rows) ? rows : [];
    } catch (error) {
      return [];
    }
  }
  function writeProgressLogs(rows) {
    const clean = (Array.isArray(rows) ? rows : [])
      .filter(row => row && row.level && row.materialKey)
      .sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0))
      .slice(0, 800);
    localStorage.setItem(PROGRESS_LOG_KEY, JSON.stringify(clean));
  }
  function progressLogKey(row) {
    return [row.createdAt || '', row.level || '', row.materialKey || '', row.mode || '', row.accuracy || ''].join('|');
  }
  function mergeProgressLogs(...groups) {
    const map = new Map();
    groups.flat().forEach(row => {
      if (!row || !row.level || !row.materialKey) return;
      map.set(progressLogKey(row), row);
    });
    return Array.from(map.values());
  }
  function parseProgressMemo(record) {
    const memo = record && record.memo;
    if (!memo || typeof memo !== 'string') return null;
    try {
      const parsed = JSON.parse(memo);
      return parsed && parsed.kind === COURSE.progressKind ? parsed : null;
    } catch (error) {
      return null;
    }
  }
  async function syncRemoteProgressLogs() {
    try {
      if (!window.SorizavaRecords || !window.SorizavaRecords.getMyRecentRecords) return;
      const records = await window.SorizavaRecords.getMyRecentRecords(700);
      const remoteLogs = (records || [])
        .filter(record => record.tool_type === COURSE.toolType)
        .map(record => {
          const meta = parseProgressMemo(record);
          if (!meta || !meta.materialKey) return null;
          return {
            id: meta.id || String(record.id || ''),
            level: Number(meta.level),
            materialId: meta.materialId || '',
            materialKey: meta.materialKey || '',
            materialTitle: meta.materialTitle || record.practice_title || '',
            mode: meta.mode || 'view',
            paragraph: meta.paragraph || '전체 원문',
            abbrEnabled: Boolean(meta.abbrEnabled),
            accuracy: Number(record.accuracy ?? record.score ?? meta.accuracy ?? 0),
            cpm: Number(record.cpm || meta.cpm || 0),
            elapsed: Number(record.elapsed_seconds || meta.elapsed || 0),
            wrong: Number(record.wrong_count || meta.wrong || 0),
            missing: Number(record.missing_count || meta.missing || 0),
            added: Number(record.added_count || meta.added || 0),
            resultLabel: meta.resultLabel || '',
            createdAt: record.created_at || meta.createdAt || new Date().toISOString()
          };
        }).filter(Boolean);
      if (remoteLogs.length) writeProgressLogs(mergeProgressLogs(remoteLogs, readProgressLogs()));
    } catch (error) {
      console.warn(`${COURSE.shortLabel} 원격 기록 동기화 실패:`, error);
    }
  }
  function bestListenLogForMaterial(item) {
    const key = materialKey(item);
    return readProgressLogs()
      .filter(row => Number(row.level) === Number(item.level) && row.materialKey === key && row.mode === 'listen')
      .sort((a, b) => Number(b.accuracy || 0) - Number(a.accuracy || 0))[0] || null;
  }
  function kstDateKey(date = new Date()) {
    return new Date(date.getTime() + 9 * 60 * 60 * 1000).toISOString().slice(0, 10);
  }
  function readUnlockAttempts() {
    try {
      const rows = JSON.parse(localStorage.getItem(`sorizava_${COURSE.key}_unlock_attempts_v1`) || '[]');
      return Array.isArray(rows) ? rows : [];
    } catch (error) {
      return [];
    }
  }
  function writeUnlockAttempts(rows) {
    localStorage.setItem(`sorizava_${COURSE.key}_unlock_attempts_v1`, JSON.stringify((Array.isArray(rows) ? rows : []).slice(-500)));
  }
  function dailyUnlockLimit() {
    const extra = Number(localStorage.getItem(UNLOCK_EXTRA_CHANCES_KEY) || 0);
    return UNLOCK_DAILY_LIMIT + Math.max(0, Number.isFinite(extra) ? extra : 0);
  }
  function todaysUnlockAttempts() {
    const today = kstDateKey();
    return readUnlockAttempts().filter(row => row && row.dateKey === today);
  }
  function remainingUnlockAttempts() {
    return Math.max(0, dailyUnlockLimit() - todaysUnlockAttempts().length);
  }
  function recordUnlockAttempt(record) {
    const attempts = readUnlockAttempts();
    attempts.push({
      id: record.id || `${Date.now()}_${Math.random().toString(16).slice(2)}`,
      dateKey: kstDateKey(),
      course: COURSE.key,
      level: Number(record.level || currentLevel),
      materialKey: record.materialKey || '',
      accuracy: Number(record.accuracy || 0),
      passed: Number(record.accuracy || 0) >= PASS_ACCURACY,
      createdAt: record.createdAt || new Date().toISOString()
    });
    writeUnlockAttempts(attempts);
  }
  function bestUnlockLogForLevel(level) {
    return readProgressLogs()
      .filter(row => Number(row.level) === Number(level) && row.mode === 'unlock')
      .sort((a, b) => Number(b.accuracy || 0) - Number(a.accuracy || 0))[0] || null;
  }
  function isLevelPassedForUnlock(level) {
    if (Number(level) === LEVELS[0]) return true;
    const best = bestUnlockLogForLevel(level);
    return Boolean(best && Number(best.accuracy || 0) >= PASS_ACCURACY);
  }
  function unlockStatusText(level) {
    const best = bestUnlockLogForLevel(level);
    if (best && Number(best.accuracy || 0) >= PASS_ACCURACY) return `승급 완료 · ${Number(best.accuracy).toFixed(1)}%`;
    if (best) return `최고 ${Number(best.accuracy).toFixed(1)}%`;
    return '승급 대기';
  }

  function getLevelProgress(level) {
    const list = materialsForLevel(level);
    const rows = list.map(item => {
      const best = bestListenLogForMaterial(item);
      return {
        material: item,
        best,
        passed: Boolean(best && Number(best.accuracy) >= PASS_ACCURACY),
        bestAccuracy: best ? Number(best.accuracy) : null
      };
    });
    const passedCount = rows.filter(row => row.passed).length;
    const unlockBest = bestUnlockLogForLevel(level);
    const unlockPassed = Boolean(unlockBest && Number(unlockBest.accuracy || 0) >= PASS_ACCURACY);
    return {
      level: Number(level),
      total: list.length,
      passedCount,
      rows,
      practicePassed: list.length > 0 && passedCount === list.length,
      unlockBest,
      unlockPassed,
      passed: unlockPassed
    };
  }
  function isLevelUnlocked(level) {
    const target = Number(level);
    if (target === LEVELS[0]) return true;
    const prev = previousLevel(target);
    return Boolean(prev && isLevelPassedForUnlock(prev));
  }
  function getHighestUnlockedLevel() {
    let highest = LEVELS[0];
    for (const step of LEVELS) {
      if (isLevelUnlocked(step)) highest = step;
      else break;
    }
    return highest;
  }
  function getNextLockedReason(level) {
    const target = Number(level);
    const prev = previousLevel(target);
    if (!prev) return '첫 단계(110자)는 입문반 졸업시험 통과 후 바로 열립니다.';
    const best = bestUnlockLogForLevel(prev);
    const bestText = best ? ` 현재 최고 ${Number(best.accuracy || 0).toFixed(1)}%.` : '';
    return `${levelLabel(prev)}를 진도 승급실에서 사전 연습 없이 듣고치기 ${PASS_ACCURACY}% 이상으로 먼저 통과해야 ${levelLabel(target)}가 열립니다.${bestText}`;
  }
  function getNextUnlockTarget() {
    return LEVELS.find(level => Number(level) !== Number(LEVELS[0]) && !isLevelPassedForUnlock(level)) || null;
  }
  function renderUnlockRoomStatus() {
    const box = $('unlockRoomStatus');
    if (!box) return;
    const remaining = remainingUnlockAttempts();
    const target = getNextUnlockTarget();
    const rows = LEVELS.map(level => {
      const unlocked = isMaterialManager || isLevelUnlocked(level);
      const passed = isLevelPassedForUnlock(level);
      const cls = passed ? 'passed' : unlocked ? 'ready' : 'locked';
      const label = passed ? '통과' : unlocked ? '응시 가능' : '잠금';
      const detail = passed ? unlockStatusText(level) : unlocked ? `${levelLabel(level)} 진도 승급실 듣고치기 90% 필요` : getNextLockedReason(level);
      return `<div class="unlock-step ${cls}"><b>${levelLabel(level)}</b><span>${label}</span><small>${escapeHtml(detail)}</small></div>`;
    }).join('');
    box.innerHTML = `
      <div class="unlock-room-head">
        <div><strong>오늘 진도 승급실 응시</strong><span>${dailyUnlockLimit()}회 중 ${todaysUnlockAttempts().length}회 사용 · 남은 ${remaining}회</span></div>
        <b>${target ? `${levelLabel(target)} 승급 진행` : '전체 승급 완료'}</b>
      </div>
      <div class="unlock-steps">${rows}</div>
    `;
  }
  function updateUnlockAttemptAvailability() {
    const area = $('typingArea');
    if (!area) return;
    if (roomMode !== 'unlock') {
      area.disabled = false;
      return;
    }
    const remaining = remainingUnlockAttempts();
    const noAudio = !currentMaterial || !getMaterialAudioSrc(currentMaterial);
    area.disabled = remaining <= 0 || noAudio;
    if (remaining <= 0) area.placeholder = '오늘 진도 승급실 응시 2회를 모두 사용했습니다. 내일 다시 응시할 수 있습니다.';
    else if (noAudio) area.placeholder = '진도 승급실은 듣고치기만 가능합니다. 이 자료에는 등록 오디오가 없습니다.';
    else area.placeholder = '진도 승급실 응시: 원문 없이 오디오를 듣고 한 번에 입력하세요. 채점 시 오늘 응시 횟수가 1회 차감됩니다.';
  }
  function initRoomModeFromUrl() {
    // 진도 승급실은 unlock-room.html로 분리했습니다.
    roomMode = 'study';
    document.body?.setAttribute('data-room-mode', roomMode);
  }
  function setRoomMode(mode) {
    // 기존 공부방 안의 승급 모드는 사용하지 않습니다.
    roomMode = 'study';
    document.body?.setAttribute('data-room-mode', roomMode);
    const studyBtn = $('roomStudyBtn');
    const unlockBtn = $('roomUnlockBtn');
    if (studyBtn) studyBtn.classList.toggle('active', roomMode === 'study');
    if (unlockBtn) unlockBtn.classList.toggle('active', roomMode === 'unlock');
    if ($('roomModeLabel')) $('roomModeLabel').innerText = roomMode === 'unlock' ? '진도 승급실' : '공부방';
    updateModeTip();
    renderProgressSummary();
    renderLevelButtons();
    renderUnlockRoomStatus();
    updateUnlockAttemptAvailability();
  }

  function renderProgressState() {
    renderLevelButtons();
    renderProgressSummary();
    renderMaterialSelect();
    renderUnlockRoomStatus();
    updateUnlockAttemptAvailability();
    if (currentMaterialId && $('materialSelect')) $('materialSelect').value = currentMaterialId;
  }
  function renderProgressSummary() {
    const box = $('progressSummary');
    if (!box) return;
    const current = getLevelProgress(currentLevel);
    const highest = getHighestUnlockedLevel();
    const next = nextLevel(highest);
    const currentText = current.unlockPassed
      ? `${levelLabel(currentLevel)} 승급 완료 · 최고 ${Number(current.unlockBest?.accuracy || 0).toFixed(1)}%`
      : `${levelLabel(currentLevel)} 진도 승급실 통과 필요`;
    const nextText = next
      ? `${levelLabel(next)} 잠금 해제 조건: ${levelLabel(highest)} 진도 승급실 듣고치기 ${PASS_ACCURACY}% 이상`
      : `${levelLabel(LEVELS[LEVELS.length - 1])}까지 모두 열렸습니다.`;
    box.innerHTML = `
      <div class="progress-pill"><span>현재 열린 진도</span><b>${levelLabel(highest)}</b></div>
      <div class="progress-pill"><span>현재 단계</span><b>${escapeHtml(currentText)}</b></div>
      <div class="progress-pill wide"><span>다음 진도 기준</span><b>${escapeHtml(nextText)}</b></div>
    `;
  }
  function applyInitialSelection() {
    const params = new URLSearchParams(location.search);
    const requestedLevel = params.get('level') ? normalizeLevelValue(params.get('level')) : getHighestUnlockedLevel();
    const initialLevel = (isMaterialManager || isLevelUnlocked(requestedLevel)) ? requestedLevel : getHighestUnlockedLevel();
    currentMaterialId = params.get('material') || null;
    selectLevel(initialLevel, false);
    if (currentMaterialId && materialsForLevel(currentLevel).some(item => String(item.id) === String(currentMaterialId))) {
      $('materialSelect').value = currentMaterialId;
      currentMaterial = findMaterial(currentMaterialId);
      applyCurrentMaterial();
    }
    setMode(params.get('mode') === 'listen' ? 'listen' : 'view');
  }

  function selectLevel(level, shouldReset = true) {
    const requested = Number(level);
    if (!isMaterialManager && !isLevelUnlocked(requested)) {
      const fallback = getHighestUnlockedLevel();
      alert(`${levelLabel(requested)}는 아직 열리지 않았습니다.\n\n${getNextLockedReason(requested)}\n\n공부방에서 메뉴는 계속 보이지만, 선행 조건을 통과해야 사용할 수 있습니다.`);
      level = fallback;
    }
    currentLevel = Number(level);
    renderLevelButtons();
    renderProgressSummary();
    $('currentLevelLabel').innerText = levelLabel(currentLevel);
    $('practiceTitle').innerText = `${levelLabel(currentLevel)} ${COURSE.shortLabel} 연습`;
    $('paceSpeedLabel').innerText = levelPace(currentLevel);
    $('adminLevel').value = String(currentLevel);
    currentParagraph = 'all';
    renderMaterialSelect();
    renderAdminMaterialSelect();
    const levelItems = materialsForLevel(currentLevel);
    if (levelItems.length) {
      const stillExists = levelItems.some(item => item.id === currentMaterialId);
      currentMaterialId = stillExists ? currentMaterialId : levelItems[0].id;
      $('materialSelect').value = currentMaterialId;
      currentMaterial = findMaterial(currentMaterialId);
    } else {
      currentMaterialId = null;
      currentMaterial = null;
    }
    applyCurrentMaterial();
    renderUnlockRoomStatus();
    updateUnlockAttemptAvailability();
    if (shouldReset) resetPractice(false);
  }

  function renderMaterialSelect() {
    const select = $('materialSelect');
    const list = materialsForLevel(currentLevel);
    if (!list.length) {
      select.innerHTML = '<option value="">등록된 자료 없음</option>';
      select.disabled = true;
      $('materialCount').innerText = '0개 자료';
      $('materialNotice').innerText = `${levelLabel(currentLevel)}에 등록된 자료가 없습니다.`;
      return;
    }
    select.disabled = false;
    select.innerHTML = list.map((item, idx) => {
      const best = bestListenLogForMaterial(item);
      const mark = best && Number(best.accuracy) >= PASS_ACCURACY ? ' ✅' : '';
      const acc = best ? ` · 최고 ${Number(best.accuracy).toFixed(1)}%` : '';
      return `<option value="${escapeHtml(item.id)}">${idx + 1}. ${escapeHtml(item.title)}${mark}${acc}</option>`;
    }).join('');
    $('materialCount').innerText = `${list.length}개 자료`;
    const progress = getLevelProgress(currentLevel);
    $('materialNotice').innerText = roomMode === 'unlock'
      ? `현재 ${levelLabel(currentLevel)} 진도 승급실 자료 ${list.length}개 · 오늘 남은 응시 ${remainingUnlockAttempts()}회`
      : `현재 ${levelLabel(currentLevel)} 자료 ${list.length}개 · 공부방 연습 통과 ${progress.passedCount}/${progress.total}개 · 승급 상태 ${progress.unlockPassed ? '완료' : '대기'}`;
  }
  function renderAdminMaterialSelect() {
    const level = Number($('adminLevel').value || currentLevel);
    const list = materialsForLevel(level);
    $('adminMaterialSelect').innerHTML = [
      '<option value="__new">새 자료 등록</option>',
      ...list.map((item, idx) => `<option value="${escapeHtml(item.id)}">${idx + 1}. ${escapeHtml(item.title)}</option>`)
    ].join('');
  }

  function getFullSourceText() { return currentMaterial ? currentMaterial.sourceText || '' : ''; }
  function getParagraphs(text = getFullSourceText()) {
    const normalized = String(text || '').replace(/\r\n/g, '\n').trim();
    if (!normalized) return [];
    let chunks = normalized.split(/\n\s*\n+/).map(v => v.trim()).filter(Boolean);
    if (chunks.length <= 1) chunks = normalized.split(/\n+/).map(v => v.trim()).filter(Boolean);
    return chunks.slice(0, 5);
  }
  function getPracticeSourceText() {
    const full = getFullSourceText();
    if (currentMode === 'view' && currentParagraph !== 'all') {
      const paragraphs = getParagraphs(full);
      return paragraphs[Number(currentParagraph)] || full;
    }
    return full;
  }
  function paragraphLabel() {
    if (currentMode !== 'view' || currentParagraph === 'all') return '전체 원문';
    return `${Number(currentParagraph) + 1}단락`;
  }

  function applyCurrentMaterial() {
    const text = getFullSourceText();
    const title = currentMaterial ? currentMaterial.title : '자료 없음';
    $('currentMaterialTitle').innerText = title;
    renderParagraphButtons();
    renderSourceText();
    $('sourceCount').innerText = pureCount(getPracticeSourceText()) + '자';
    $('sourceCountTop').innerText = pureCount(text) + '자';
    $('targetCount').innerText = pureCount(getPracticeSourceText()) + '자';

    const audio = $('audioPlayer');
    audio.pause();
    audio.removeAttribute('src');
    audio.load();
    $('playBtn').innerText = '▶ 재생';
    $('currentTime').innerText = '0:00';
    $('totalTime').innerText = '0:00';
    $('audioLeft').innerText = '0';
    $('seekBar').value = 0;
    const audioSrc = getMaterialAudioSrc(currentMaterial);
    if (audioSrc) {
      audio.src = audioSrc;
      audio.load();
      $('audioFileName').innerText = currentMaterial.audioName || '등록 오디오';
    } else {
      $('audioFileName').innerText = '오디오 없음';
    }
    updateModeTip();
    updateCounts();
    updateUnlockAttemptAvailability();
  }

  function renderParagraphButtons() {
    const box = $('paragraphButtons');
    const paragraphs = getParagraphs();
    if (!box) return;
    if (!paragraphs.length) {
      box.innerHTML = '<span class="paragraph-empty">등록된 단락이 없습니다.</span>';
      return;
    }
    const buttons = ['<button type="button" class="paragraph-btn" data-paragraph="all" onclick="selectParagraph(\'all\')">전체</button>'];
    paragraphs.forEach((paragraph, idx) => {
      buttons.push(`<button type="button" class="paragraph-btn" data-paragraph="${idx}" onclick="selectParagraph(${idx})">${idx + 1}단락 <small>${pureCount(paragraph)}자</small></button>`);
    });
    box.innerHTML = buttons.join('');
    updateParagraphActiveButton();
  }
  function updateParagraphActiveButton() {
    document.querySelectorAll('.paragraph-btn').forEach(btn => {
      btn.classList.toggle('active', String(btn.dataset.paragraph) === String(currentParagraph));
    });
  }
  function selectParagraph(value) {
    currentParagraph = value === 'all' ? 'all' : Number(value);
    autoFinishLock = false;
    updateParagraphActiveButton();
    renderSourceText();
    updateCounts();
    resetPractice(true);
  }

  function renderSourceText() {
    const text = getPracticeSourceText();
    const box = $('sourceReadonly');
    if (!text.trim()) {
      box.innerHTML = '<span class="pace-empty">등록된 원문이 없습니다.</span>';
    } else {
      const abbrMarks = getAbbreviationHighlightSet(text);
      box.innerHTML = text.split('').map((ch, idx) => {
        const classes = abbrMarks.has(idx) ? ' class="abbr-highlight"' : '';
        return `<span${classes} data-pace-idx="${idx}" data-pace-counted="${isPaceCountedChar(ch) ? '1' : '0'}">${toHtmlChar(ch)}</span>`;
      }).join('');
    }
    box.scrollTop = 0;
    renderAbbreviationToggleState();
    setPaceStatus('입력을 시작하면 페이스메이커가 자동으로 출발합니다.');
  }

  function setMode(mode, options = {}) {
    if (roomMode === 'unlock' && mode !== 'listen' && !options.keepUnlockMode) {
      alert('진도 승급실은 사전 연습 없이 듣고치기 90% 이상으로만 통과할 수 있습니다. 보고 치기는 공부방에서만 사용할 수 있습니다.');
      mode = 'listen';
    }
    currentMode = mode === 'listen' ? 'listen' : 'view';
    document.body.classList.toggle('listen-mode', currentMode === 'listen');
    $('modeViewBtn').classList.toggle('active', currentMode === 'view');
    $('modeListenBtn').classList.toggle('active', currentMode === 'listen');
    $('modeViewBtn').disabled = roomMode === 'unlock';
    $('modeLabel').innerText = currentMode === 'listen' ? '듣고 치기' : '보고 치기';
    stopPacemaker();
    currentParagraph = currentMode === 'listen' ? 'all' : currentParagraph;
    renderSourceText();
    renderParagraphButtons();
    resetPractice(false);
    updateModeTip();
    updateCounts();
    updateUnlockAttemptAvailability();
  }

  function updateModeTip() {
    const hasAudio = currentMaterial && getMaterialAudioSrc(currentMaterial);
    if (roomMode === 'unlock') {
      $('practiceTip').innerText = hasAudio
        ? `진도 승급실: 오늘 남은 응시 ${remainingUnlockAttempts()}회 · 원문 없이 듣고치기 ${PASS_ACCURACY}% 이상이면 다음 단계가 열립니다.`
        : '진도 승급실은 듣고치기만 가능합니다. 이 자료에는 등록된 오디오가 없습니다.';
      return;
    }
    if (currentMode === 'listen') {
      $('practiceTip').innerText = hasAudio
        ? 'Tip: 원문은 보이지 않습니다. 등록 오디오를 듣고 입력하세요. 공부방 기록은 승급 기준에 반영되지 않습니다.'
        : 'Tip: 이 자료에는 등록된 오디오가 없습니다. 관리자 자료 관리에서 오디오를 등록해야 합니다.';
    } else {
      $('practiceTip').innerText = `Tip: 보고 치기는 ${levelPace(currentLevel)}자 페이스메이커가 자동 작동합니다. 단락치기는 1분 안에 입력하는 방식입니다. 승급은 진도 승급실에서만 가능합니다.`;
    }
  }

  function updateCounts() {
    const typedCount = pureCount($('typingArea').value);
    const sourceCount = pureCount(getPracticeSourceText());
    $('typingCount').innerText = typedCount + '자';
    $('targetCount').innerText = sourceCount + '자';
    $('sourceCount').innerText = sourceCount + '자';
    $('sourceCountTop').innerText = pureCount(getFullSourceText()) + '자';
  }

  function startTimer() {
    startTime = Date.now();
    if (timerInterval) clearInterval(timerInterval);
    timerInterval = setInterval(updateStats, 500);
    updateStats();
    const audio = $('audioPlayer');
    if (currentMode === 'listen' && audio.src && audio.paused) audio.play().catch(() => {});
    if (currentMode === 'view' && !pacemakerActive) startPacemaker();
  }
  function updateStats() {
    if (!startTime) return;
    const elapsed = (Date.now() - startTime) / 1000;
    const typedCount = pureCount($('typingArea').value);
    $('timer').innerText = formatClock(elapsed);
    $('charVal').innerText = typedCount;
    $('speedDisplay').innerText = elapsed > 0 ? Math.floor(typedCount / (elapsed / 60)) : 0;
  }
  function resetTimerOnly() {
    clearInterval(timerInterval);
    timerInterval = null;
    startTime = null;
    $('timer').innerText = '00:00';
    $('speedDisplay').innerText = '0';
    $('charVal').innerText = '0';
    stopPacemaker();
  }
  function resetPractice(keepFocus = true) {
    clearInterval(timerInterval);
    clearTimeout(smartPauseTimer);
    timerInterval = null;
    smartPauseTimer = null;
    isSmartPausing = false;
    startTime = null;
    autoFinishLock = false;
    unlockAttemptSubmitted = false;
    $('typingArea').disabled = false;
    $('typingArea').value = '';
    $('typingArea').classList.remove('paused-warning');
    $('typingCount').innerText = '0자';
    $('timer').innerText = '00:00';
    $('charVal').innerText = '0';
    $('speedDisplay').innerText = '0';
    stopPacemaker();
    const audio = $('audioPlayer');
    if (audio) {
      audio.pause();
      if (audio.src) audio.currentTime = 0;
      $('playBtn').innerText = '▶ 재생';
      $('currentTime').innerText = '0:00';
      $('seekBar').value = 0;
    }
    updateUnlockAttemptAvailability();
    if (keepFocus && !$('typingArea').disabled) $('typingArea').focus();
  }

  function handleSmartPause() {
    if (currentMode !== 'listen') return;
    if (!$('smartPauseToggle').checked) return;
    const audio = $('audioPlayer');
    if (!audio || !audio.src || !startTime) return;
    clearTimeout(smartPauseTimer);
    $('typingArea').classList.remove('paused-warning');
    if (audio.paused && isSmartPausing) {
      audio.play().catch(() => {});
      isSmartPausing = false;
    }
    const delay = Math.max(0.5, Number($('smartPauseTime').value || 1.5)) * 1000;
    smartPauseTimer = setTimeout(() => {
      if (!audio.paused) {
        audio.pause();
        isSmartPausing = true;
        $('typingArea').classList.add('paused-warning');
      }
    }, delay);
  }

  function toggleAudio() {
    const audio = $('audioPlayer');
    if (!audio.src) return alert('이 자료에는 등록된 오디오가 없습니다.');
    if (audio.paused) {
      audio.play().catch(() => {});
      $('playBtn').innerText = '⏸ 정지';
    } else {
      audio.pause();
      $('playBtn').innerText = '▶ 재생';
    }
  }
  function skipAudio(seconds) {
    const audio = $('audioPlayer');
    if (!audio.duration) return;
    audio.currentTime = Math.min(Math.max(audio.currentTime + seconds, 0), audio.duration);
  }
  function adjustSpeed(amount) {
    let newSpeed = Math.round((currentSpeed + amount) * 10) / 10;
    if (newSpeed < 0.5) newSpeed = 0.5;
    if (newSpeed > 2.0) newSpeed = 2.0;
    currentSpeed = newSpeed;
    $('audioPlayer').playbackRate = currentSpeed;
    $('audioSpeed').innerText = currentSpeed.toFixed(1);
  }

  function setPaceStatus(text) {
    const label = $('paceStatus');
    if (label) label.innerText = text;
  }
  function startPacemaker() {
    const box = $('sourceReadonly');
    const spans = Array.from(box.querySelectorAll('[data-pace-idx]'));
    if (currentMode !== 'view' || !spans.length) return;
    stopPacemaker(false);

    const countedPositions = spans
      .map((span, idx) => span.dataset.paceCounted === '1' ? idx : null)
      .filter(idx => idx !== null);
    if (!countedPositions.length) return;

    pacemakerActive = true;
    pacemakerIndex = 0;
    const msPerCountedChar = 60000 / Math.max(1, currentLevel);
    setPaceStatus(`${levelPace(currentLevel)}자 페이스 진행 중 · 공백/문장부호 제외 기준`);

    const paintPace = () => {
      spans.forEach(span => span.classList.remove('pace-current', 'pace-passed'));
      const currentRawIndex = countedPositions[pacemakerIndex];
      if (currentRawIndex === undefined) {
        stopPacemaker(false);
        setPaceStatus('페이스메이커 종료');
        return;
      }
      for (let i = 0; i < currentRawIndex; i += 1) {
        spans[i]?.classList.add('pace-passed');
      }
      const current = spans[currentRawIndex];
      if (current) {
        current.classList.add('pace-current');
        scrollSourceToElement(current);
      }
      pacemakerIndex += 1;
    };

    paintPace();
    pacemakerTimer = setInterval(paintPace, msPerCountedChar);
  }
  function stopPacemaker(clearHighlight = true) {
    if (pacemakerTimer) clearInterval(pacemakerTimer);
    pacemakerTimer = null;
    pacemakerActive = false;
    pacemakerIndex = 0;
    if (clearHighlight && $('sourceReadonly')) {
      $('sourceReadonly').querySelectorAll('span').forEach(span => span.classList.remove('pace-current', 'pace-passed'));
      if (currentMode === 'view') setPaceStatus('입력을 시작하면 페이스메이커가 자동으로 출발합니다.');
    }
  }
  function scrollSourceToElement(el) {
    const box = $('sourceReadonly');
    if (!box || !el) return;
    const boxRect = box.getBoundingClientRect();
    const elRect = el.getBoundingClientRect();
    const offset = elRect.top - boxRect.top - box.clientHeight * 0.45;
    box.scrollTo({ top: box.scrollTop + offset, behavior: 'smooth' });
  }
  function keepTypingAreaAtCursor() {
    const area = $('typingArea');
    requestAnimationFrame(() => { area.scrollTop = area.scrollHeight; });
  }
  function syncSourceToTypedProgress() {
    if (currentMode !== 'view') return;
    const typedCount = Math.max(0, pureCount($('typingArea').value) - 1);
    const countedSpans = Array.from($('sourceReadonly').querySelectorAll('[data-pace-counted="1"]'));
    const target = countedSpans[typedCount];
    if (target) scrollSourceToElement(target);
  }

  function checkParagraphAutoFinish() {
    if (currentMode !== 'view' || currentParagraph === 'all' || autoFinishLock) return;
    const target = pureCount(getPracticeSourceText());
    const typed = pureCount($('typingArea').value);
    if (target > 0 && typed >= target) {
      autoFinishLock = true;
      setTimeout(() => finishPractice({ paragraphAuto: true }), 120);
    }
  }

  function getResultLabel(score, elapsed, isParagraphMode) {
    if (!isParagraphMode) {
      if (score >= 98) return 'GREAT';
      if (score >= 95) return 'NICE';
      return '더 연습';
    }
    if (elapsed > 60) return '시간 초과';
    if (score === 100) return 'PERFECT';
    if (score >= 98) return 'GREAT';
    if (score >= 95) return 'NICE';
    return '더 연습';
  }
  function saveIntermediateProgressLog(record) {
    const rows = readProgressLogs();
    rows.unshift(record);
    writeProgressLogs(rows);
    sessionStorage.setItem(`sorizava_${COURSE.key}_last_result`, JSON.stringify(record));
  }
  function openStudyRoom() {
    const modal = $('resultModal');
    if (modal) modal.style.display = 'none';
    const target = $('progressCard') || document.querySelector('.history-card');
    if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function finishPractice(options = {}) {
    clearInterval(timerInterval);
    clearTimeout(smartPauseTimer);
    stopPacemaker(false);
    const audio = $('audioPlayer');
    if (audio) audio.pause();
    $('typingArea').classList.remove('paused-warning');
    calculateAccuracy(options);
  }

  function calculateAccuracy(options = {}) {
    const rawO = getPracticeSourceText();
    const rawS = $('typingArea').value;
    if (!rawO.trim()) return alert('등록된 원문이 없습니다.');
    if (!rawS.trim()) return alert('입력된 내용이 없습니다.');
    if (roomMode === 'unlock') {
      if (currentMode !== 'listen') return alert('진도 승급실은 듣고치기만 채점할 수 있습니다.');
      if (!currentMaterial || !getMaterialAudioSrc(currentMaterial)) return alert('진도 승급실은 등록 오디오가 있는 자료만 응시할 수 있습니다.');
      if (unlockAttemptSubmitted) return alert('이미 채점한 진도 승급실 응시입니다. 다시 응시하려면 리셋 후 새로 입력하세요.');
      if (remainingUnlockAttempts() <= 0) {
        updateUnlockAttemptAvailability();
        return alert('오늘 진도 승급실 응시 2회를 모두 사용했습니다. 내일 다시 응시할 수 있습니다.');
      }
    }

    let pureLength = pureCount(rawO);
    if (pureLength === 0) pureLength = 1;
    const oArr = rawO.trim().split('');
    const sArr = rawS.trim().split('');
    const n = oArr.length;
    const m = sArr.length;
    const dp = Array.from({ length: n + 1 }, () => Array(m + 1).fill(0));
    for (let i = 1; i <= n; i++) {
      for (let j = 1; j <= m; j++) {
        dp[i][j] = oArr[i - 1] === sArr[j - 1] ? dp[i - 1][j - 1] + 1 : Math.max(dp[i - 1][j], dp[i][j - 1]);
      }
    }
    let i = n;
    let j = m;
    const diffs = [];
    while (i > 0 || j > 0) {
      if (i > 0 && j > 0 && oArr[i - 1] === sArr[j - 1]) {
        diffs.push({ t: 'same', c: oArr[i - 1] }); i--; j--;
      } else if (j > 0 && (i === 0 || dp[i][j - 1] >= dp[i - 1][j])) {
        diffs.push({ t: 'added', c: sArr[j - 1] }); j--;
      } else {
        diffs.push({ t: 'missing', c: oArr[i - 1] }); i--;
      }
    }
    diffs.reverse();

    let html = '';
    let wrong = 0;
    let missing = 0;
    let added = 0;
    let mBuffer = [];
    let aBuffer = [];
    const isSpecial = (char) => /[^0-9a-zA-Z\uAC00-\uD7A3]/.test(char);
    function flushBuffer() {
      let mIdx = 0;
      let aIdx = 0;
      while (mIdx < mBuffer.length || aIdx < aBuffer.length) {
        const mChar = mBuffer[mIdx];
        const aChar = aBuffer[aIdx];
        if (mIdx < mBuffer.length && isSpecial(mChar)) { html += `<span>${toHtmlChar(mChar)}</span>`; mIdx++; continue; }
        if (aIdx < aBuffer.length && isSpecial(aChar)) { html += `<span style="color:#bbb;">${toHtmlChar(aChar)}</span>`; aIdx++; continue; }
        if (mIdx < mBuffer.length && aIdx < aBuffer.length) {
          html += `<span class="d-wrong">${toHtmlChar(aChar)}<span class="correction">${toHtmlChar(mChar)}</span></span>`;
          wrong++; mIdx++; aIdx++; continue;
        }
        if (mIdx < mBuffer.length) { html += `<span class="d-missing">${toHtmlChar(mChar)}</span>`; missing++; mIdx++; continue; }
        if (aIdx < aBuffer.length) { html += `<span class="d-added">${toHtmlChar(aChar)}</span>`; added++; aIdx++; }
      }
      mBuffer = [];
      aBuffer = [];
    }
    diffs.forEach(item => {
      if (item.t === 'same') { flushBuffer(); html += `<span>${toHtmlChar(item.c)}</span>`; }
      else if (item.t === 'missing') mBuffer.push(item.c);
      else if (item.t === 'added') aBuffer.push(item.c);
    });
    flushBuffer();

    const addedPenalty = Math.floor(added / 3);
    const score = Math.max(0, 100 - ((wrong + missing + addedPenalty) / pureLength * 100));
    const scoreText = score.toFixed(1);
    const elapsed = startTime ? Math.floor((Date.now() - startTime) / 1000) : 0;
    const cpm = elapsed > 0 ? Math.floor(pureCount(rawS) / (elapsed / 60)) : Number($('speedDisplay').innerText || 0);
    const modeText = currentMode === 'listen' ? '듣고 치기' : '보고 치기';
    const isParagraphMode = currentMode === 'view' && currentParagraph !== 'all';

    $('resultModalTitle').innerText = isParagraphMode ? '⏱️ 단락치기 결과' : '📊 채점 결과';
    $('finalScore').innerText = scoreText + '%';
    $('scoreGrade').innerText = makeGradeMessage(score, elapsed, isParagraphMode);
    $('scoreDetail').innerText = `시간 ${formatClock(elapsed)} / 속도 ${cpm}자/분 / 오자 ${wrong} / 탈자 ${missing} / 첨자 ${added}`;
    $('diffOutput').innerHTML = html;
    $('resultModal').style.display = 'block';

    const resultLabel = getResultLabel(Number(scoreText), elapsed, isParagraphMode);
    const progressRecord = {
      kind: COURSE.progressKind,
      id: `${Date.now()}_${Math.random().toString(16).slice(2)}`,
      level: currentLevel,
      materialId: currentMaterial ? currentMaterial.id : '',
      materialKey: currentMaterial ? materialKey(currentMaterial) : '',
      materialTitle: currentMaterial ? currentMaterial.title : '자료 없음',
      title: currentMaterial ? currentMaterial.title : '자료 없음',
      mode: roomMode === 'unlock' ? 'unlock' : currentMode,
      roomMode,
      paragraph: roomMode === 'unlock' ? '진도 승급실' : paragraphLabel(),
      abbrEnabled: Boolean(isAbbrVisible && currentMode === 'view'),
      accuracy: Number(scoreText),
      score: Number(scoreText),
      cpm,
      chars: pureCount(rawS),
      elapsed,
      wrong,
      missing,
      added,
      resultLabel,
      createdAt: new Date().toISOString(),
      date: new Date().toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })
    };

    if (roomMode === 'unlock') {
      recordUnlockAttempt(progressRecord);
      unlockAttemptSubmitted = true;
    }
    saveHistory(progressRecord);
    saveIntermediateProgressLog(progressRecord);
    loadHistory();
    renderProgressState();

    const progress = getLevelProgress(currentLevel);
    if (roomMode === 'unlock') {
      const passedUnlock = Number(scoreText) >= PASS_ACCURACY;
      const next = nextLevel(currentLevel);
      if (passedUnlock && next) $('scoreGrade').innerText = `${$('scoreGrade').innerText} · 승급 통과, ${levelLabel(next)} 열림`;
      else if (passedUnlock) $('scoreGrade').innerText = `${$('scoreGrade').innerText} · ${COURSE.shortLabel} ${levelLabel(LEVELS[LEVELS.length - 1])}까지 승급 완료`;
      else $('scoreGrade').innerText = `${$('scoreGrade').innerText} · 승급 미통과, ${PASS_ACCURACY}% 이상 필요 · 오늘 남은 응시 ${remainingUnlockAttempts()}회`;
    }

    if (window.SorizavaRecords) {
      window.SorizavaRecords.savePracticeRecord({
        tool_type: COURSE.toolType,
        practice_title: `${courseBaseLabel()} ${roomMode === 'unlock' ? '진도 승급실' : '공부방'} ${levelLabel(currentLevel)} ${currentMaterial ? currentMaterial.title : ''} ${modeText} ${roomMode === 'unlock' ? '승급 응시' : paragraphLabel()}`.trim(),
        original_length: pureLength,
        typed_length: pureCount(rawS),
        accuracy: Number(scoreText),
        score: Number(scoreText),
        cpm,
        elapsed_seconds: elapsed,
        wrong_count: wrong,
        missing_count: missing,
        added_count: added,
        memo: JSON.stringify({ kind: COURSE.progressKind, ...progressRecord })
      }).then(saved => {
        if (saved && saved.created_at) {
          progressRecord.createdAt = saved.created_at;
          saveIntermediateProgressLog(progressRecord);
        }
      });
    }
  }

  function makeGradeMessage(score, elapsed, isParagraphMode) {
    if (!isParagraphMode) return '일반 보고치기/듣고치기 채점 결과입니다.';
    if (elapsed > 60) return `시간 초과 · ${formatClock(elapsed)} 소요 / 1분 기준을 넘었습니다.`;
    if (score === 100) return 'PERFECT · 1분 안에 정확도 100%로 완료했습니다.';
    if (score >= 98) return 'GREAT · 1분 안에 정확도 98% 이상으로 완료했습니다.';
    if (score >= 95) return 'NICE · 1분 안에 정확도 95% 이상으로 완료했습니다.';
    return '더 연습 · 1분 안에 들어왔지만 정확도가 부족합니다.';
  }

  function saveHistory(record) {
    const history = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
    history.unshift(record);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, 20)));
  }
  function loadHistory() {
    const list = $('historyList');
    const history = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
    if (!history.length) {
      list.innerHTML = '<li class="history-item" style="justify-content:center; color:#A0A7B5;">아직 기록이 없습니다.</li>';
      return;
    }
    list.innerHTML = history.map(item => `
      <li class="history-item">
        <div><span class="history-tag">${escapeHtml(item.date)}</span> ${levelLabel(item.level)} · ${escapeHtml(item.title || '자료')} · ${modeName(item.mode)} · ${escapeHtml(item.paragraph || '전체')}</div>
        <div><strong>${item.score}%</strong> · ${item.cpm}자/분</div>
      </li>
    `).join('');
  }
  function modeName(mode) { return mode === 'unlock' ? '진도 승급실' : mode === 'listen' ? '듣고 치기' : '보고 치기'; }
  function clearHistory() {
    if (!confirm(`${COURSE.title} 기록을 모두 삭제하시겠습니까?`)) return;
    localStorage.removeItem(HISTORY_KEY);
    loadHistory();
  }

  function toggleAdminPanel(force) {
    if (!isMaterialManager) return alert('자료 등록/수정 권한이 없습니다.');
    const panel = $('adminPanel');
    const shouldShow = typeof force === 'boolean' ? force : panel.style.display === 'none';
    panel.style.display = shouldShow ? 'block' : 'none';
    if (shouldShow) {
      $('adminLevel').value = String(currentLevel);
      renderAdminMaterialSelect();
      populateAdminForm($('adminMaterialSelect').value);
    }
  }
  function newMaterialForm(clearSelect = true) {
    if (clearSelect) $('adminMaterialSelect').value = '__new';
    const level = Number($('adminLevel').value || currentLevel);
    const nextNo = materialsForLevel(level).length + 1;
    $('adminTitle').value = `${levelLabel(level)} ${nextNo}번`;
    $('adminSourceText').value = '';
    adminAudioDataUrl = '';
    adminAudioName = '';
    adminAudioFile = null;
    $('adminAudioName').innerText = '오디오 없음';
  }
  function populateAdminForm(id) {
    if (!id || id === '__new') return newMaterialForm(false);
    const item = findMaterial(id);
    if (!item) return newMaterialForm(false);
    $('adminLevel').value = String(item.level);
    $('adminTitle').value = item.title;
    $('adminSourceText').value = item.sourceText || '';
    adminAudioDataUrl = item.audioDataUrl || '';
    adminAudioName = item.audioName || '';
    adminAudioFile = null;
    $('adminAudioName').innerText = item.audioName || (getMaterialAudioSrc(item) ? '등록 오디오' : '오디오 없음');
  }

  async function prepareAudioPayload(existing, level, title) {
    const keepExisting = () => ({
      audioName: adminAudioName || existing?.audioName || '',
      audioDataUrl: adminAudioDataUrl || existing?.audioDataUrl || '',
      audioUrl: existing?.audioUrl || '',
      audioPath: existing?.audioPath || '',
      audioMime: existing?.audioMime || ''
    });
    if (!adminAudioFile) return keepExisting();

    const file = adminAudioFile;
    const client = window.SORIZAVA_SUPABASE;
    if (client && client.storage && typeof client.storage.from === 'function') {
      const path = makeAudioStoragePath(level, file);
      try {
        const { error } = await withTimeout(
          client.storage.from(AUDIO_STORAGE_BUCKET).upload(path, file, {
            cacheControl: '31536000',
            upsert: false,
            contentType: file.type || 'audio/mpeg'
          }),
          AUDIO_UPLOAD_TIMEOUT_MS,
          '오디오 업로드 시간이 초과되었습니다.'
        );
        if (error) throw error;
        const { data } = client.storage.from(AUDIO_STORAGE_BUCKET).getPublicUrl(path);
        const publicUrl = data && data.publicUrl ? data.publicUrl : '';
        if (!publicUrl) throw new Error('오디오 공개 URL을 만들지 못했습니다.');
        return {
          audioName: file.name,
          audioDataUrl: '',
          audioUrl: publicUrl,
          audioPath: path,
          audioMime: file.type || 'audio/mpeg'
        };
      } catch (uploadError) {
        if (file.size > LOCAL_AUDIO_INLINE_MAX_BYTES) {
          throw new Error(`오디오 저장소 업로드 실패: ${uploadError.message || uploadError}\n파일명/Storage 버킷 설정을 확인한 뒤 다시 저장하세요.`);
        }
        console.warn('오디오 Storage 업로드 실패, 작은 파일만 임시 문자열 저장으로 대체:', uploadError);
      }
    }

    if (file.size > LOCAL_AUDIO_INLINE_MAX_BYTES) {
      throw new Error(`오디오 파일이 ${formatFileSize(file.size)}라 DB 문자열/브라우저 임시 저장 방식으로는 안전하게 저장할 수 없습니다.\n파일명/Storage 버킷 설정을 확인한 뒤 다시 저장하세요.`);
    }

    return {
      audioName: file.name,
      audioDataUrl: await readFileAsDataUrl(file),
      audioUrl: '',
      audioPath: '',
      audioMime: file.type || 'audio/mpeg'
    };
  }

  async function saveAdminMaterial() {
    if (!isMaterialManager) return alert('자료 등록/수정 권한이 없습니다.');
    setAdminSaveBusy(true);
    let payload = null;
    try {
      const level = Number($('adminLevel').value || currentLevel);
      const selectedId = $('adminMaterialSelect').value;
      const isNew = !selectedId || selectedId === '__new';
      const title = $('adminTitle').value.trim() || `${levelLabel(level)} 자료`;
      const sourceText = $('adminSourceText').value.trim();
      if (!sourceText) return alert('원문을 입력하세요.');
      if (isNew && materialsForLevel(level).length >= 10) return alert(`${levelLabel(level)} 자료는 최대 10개까지 등록할 수 있습니다.`);

      const existing = isNew ? null : findMaterial(selectedId);
      const audioPayload = await prepareAudioPayload(existing, level, title);
      payload = {
        level,
        title,
        sourceText,
        audioName: audioPayload.audioName || '',
        audioDataUrl: audioPayload.audioDataUrl || '',
        audioUrl: audioPayload.audioUrl || '',
        audioPath: audioPayload.audioPath || '',
        audioMime: audioPayload.audioMime || '',
        updatedAt: new Date().toISOString()
      };

      const client = window.SORIZAVA_SUPABASE;
      if (!client) throw new Error('Supabase client missing');
      if (existing && existing.source === 'supabase' && existing.rowId) {
        const { error } = await withTimeout(
          client
            .from('practice_materials')
            .update({ title: `${levelLabel(level)} ${title}`, content: JSON.stringify(payload), is_active: true })
            .eq('id', existing.rowId),
          DB_SAVE_TIMEOUT_MS,
          '자료 저장 시간이 초과되었습니다.'
        );
        if (error) throw error;
      } else {
        const { error } = await withTimeout(
          client
            .from('practice_materials')
            .insert({ tool_type: COURSE.toolType, title: `${levelLabel(level)} ${title}`, content: JSON.stringify(payload), is_active: true, created_by: sessionStorage.getItem('shorthand_user_id') }),
          DB_SAVE_TIMEOUT_MS,
          '자료 저장 시간이 초과되었습니다.'
        );
        if (error) throw error;
      }
      adminAudioFile = null;
      adminAudioDataUrl = payload.audioDataUrl || '';
      adminAudioName = payload.audioName || '';
      alert(`${COURSE.shortLabel} 자료를 저장했습니다.`);
      await loadMaterials();
      selectLevel(level, false);
    } catch (error) {
      console.warn(`${COURSE.shortLabel} 자료 저장 실패:`, error);
      if (isAudioStorageError(error)) {
        alert(`${error.message || error}\n\n해결: sql/intermediate_audio_storage_20260527.sql을 Supabase SQL Editor에서 한 번 실행한 뒤 다시 저장하세요.`);
        return;
      }
      try {
        const level = Number($('adminLevel').value || currentLevel);
        const selectedId = $('adminMaterialSelect').value;
        const isNew = !selectedId || selectedId === '__new';
        const title = $('adminTitle').value.trim() || `${levelLabel(level)} 자료`;
        if (!payload) {
          const existing = isNew ? null : findMaterial(selectedId);
          payload = {
            level,
            title,
            sourceText: $('adminSourceText').value.trim(),
            audioName: adminAudioName || existing?.audioName || '',
            audioDataUrl: adminAudioDataUrl || existing?.audioDataUrl || '',
            audioUrl: existing?.audioUrl || '',
            audioPath: existing?.audioPath || '',
            audioMime: existing?.audioMime || '',
            updatedAt: new Date().toISOString()
          };
        }
        saveAdminMaterialLocal(level, title, payload, selectedId, isNew);
        alert(`서버 저장에 실패해 현재 브라우저에 임시 저장했습니다.\n원인: ${error.message || error}\n\n전체 학생에게 공유하려면 Supabase 권한/테이블 설정을 확인해야 합니다.`);
        await loadMaterials();
        selectLevel(level, false);
      } catch (localError) {
        console.warn('로컬 임시 저장도 실패:', localError);
        alert(`자료 저장에 실패했습니다.\n서버 오류: ${error.message || error}\n로컬 저장 오류: ${localError.message || localError}`);
      }
    } finally {
      setAdminSaveBusy(false);
    }
  }
  function saveAdminMaterialLocal(level, title, payload, selectedId, isNew) {
    let localList = readLocalMaterials();
    if (!isNew) {
      const idx = localList.findIndex(item => item.id === selectedId);
      if (idx >= 0) localList[idx] = { ...localList[idx], level, title, sourceText: payload.sourceText, audioName: payload.audioName, audioDataUrl: payload.audioDataUrl, audioUrl: payload.audioUrl || '', audioPath: payload.audioPath || '', audioMime: payload.audioMime || '', source: 'local' };
      else localList.push(makeLocalItem(level, title, payload));
    } else {
      localList.push(makeLocalItem(level, title, payload));
    }
    writeLocalMaterials(localList);
    materials = localList;
  }
  function makeLocalItem(level, title, payload) {
    return { id: `local_${level}_${Date.now()}`, source: 'local', rowId: null, level, title, sourceText: payload.sourceText, audioName: payload.audioName, audioDataUrl: payload.audioDataUrl, audioUrl: payload.audioUrl || '', audioPath: payload.audioPath || '', audioMime: payload.audioMime || '', createdAt: new Date().toISOString() };
  }
  async function deleteAdminMaterial() {
    if (!isMaterialManager) return alert('자료 삭제 권한이 없습니다.');
    const selectedId = $('adminMaterialSelect').value;
    if (!selectedId || selectedId === '__new') return alert('삭제할 자료를 선택하세요.');
    const item = findMaterial(selectedId);
    if (!item) return alert('자료를 찾을 수 없습니다.');
    if (!confirm(`'${item.title}' 자료를 삭제하시겠습니까?`)) return;
    try {
      if (item.source === 'supabase' && item.rowId) {
        const { error } = await window.SORIZAVA_SUPABASE.from('practice_materials').update({ is_active: false }).eq('id', item.rowId);
        if (error) throw error;
      } else {
        const localList = readLocalMaterials().filter(row => row.id !== item.id);
        writeLocalMaterials(localList);
      }
      alert('자료를 삭제했습니다.');
      await loadMaterials();
      selectLevel(Number($('adminLevel').value || currentLevel), false);
      newMaterialForm();
    } catch (error) {
      console.warn(error);
      alert('자료 삭제에 실패했습니다.');
    }
  }

  function closeModal(event) {
    if (!event || event.target === $('resultModal')) $('resultModal').style.display = 'none';
  }
  function logout() {
    if (confirm('로그아웃 하시겠습니까?')) window.SorizavaAuth.signOut();
  }

  window.selectLevel = selectLevel;
  window.selectParagraph = selectParagraph;
  window.setMode = setMode;
  window.setRoomMode = setRoomMode;
  window.resetPractice = resetPractice;
  window.finishPractice = finishPractice;
  window.toggleAudio = toggleAudio;
  window.skipAudio = skipAudio;
  window.adjustSpeed = adjustSpeed;
  window.clearHistory = clearHistory;
  window.closeModal = closeModal;
  window.logout = logout;
  window.toggleAdminPanel = toggleAdminPanel;
  window.newMaterialForm = newMaterialForm;
  window.saveAdminMaterial = saveAdminMaterial;
  window.deleteAdminMaterial = deleteAdminMaterial;
  window.toggleAbbreviationDisplay = toggleAbbreviationDisplay;
  window.saveAbbreviationList = saveAbbreviationList;
  window.clearAbbreviationList = clearAbbreviationList;
  window.openStudyRoom = openStudyRoom;
  window.startPacemaker = startPacemaker;
  window.stopPacemaker = stopPacemaker;

  if (window.SorizavaAuth && window.SorizavaAuth.bootPage) {
    window.SorizavaAuth.bootPage(init);
  } else {
    document.addEventListener('DOMContentLoaded', () => init(null));
  }
})();
