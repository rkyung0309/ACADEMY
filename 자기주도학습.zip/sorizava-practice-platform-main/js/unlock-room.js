(function () {
  const COURSE_CONFIG = {
    intermediate: {
      key: 'intermediate', toolType: 'intermediate', unlockToolType: 'intermediate_unlock', icon: '🧩', label: '중급반', title: '진도 승급실',
      levels: [110, 120, 130, 140, 150, 160, 170].map(v => ({ value: v, label: `${v}자`, pace: v })),
      progressKind: 'intermediate_progress', progressKey: 'sorizava_intermediate_progress_logs_v1', localMaterialsKey: 'sorizava_intermediate_unlock_materials_v1', storageFolder: 'unlock/intermediate'
    },
    advanced: {
      key: 'advanced', toolType: 'advanced', unlockToolType: 'advanced_unlock', icon: '🚀', label: '고급반', title: '진도 승급실',
      levels: [190, 210, 230, 250].map(v => ({ value: v, label: `${v}자`, pace: v })),
      progressKind: 'advanced_progress', progressKey: 'sorizava_advanced_progress_logs_v1', localMaterialsKey: 'sorizava_advanced_unlock_materials_v1', storageFolder: 'unlock/advanced'
    },
    grade: {
      key: 'grade', toolType: 'grade', unlockToolType: 'grade_unlock', icon: '🏅', label: '급수반', title: '진도 승급실',
      levels: [{ value: 170, label: '3급', pace: 170 }, { value: 210, label: '2급', pace: 210 }, { value: 250, label: '1급', pace: 250 }],
      progressKind: 'grade_progress', progressKey: 'sorizava_grade_progress_logs_v1', localMaterialsKey: 'sorizava_grade_unlock_materials_v1', storageFolder: 'unlock/grade'
    }
  };
  const PROMOTION_ROUTE = [
    ...COURSE_CONFIG.intermediate.levels.map(meta => ({ courseKey: 'intermediate', level: Number(meta.value) })),
    ...COURSE_CONFIG.advanced.levels.map(meta => ({ courseKey: 'advanced', level: Number(meta.value) })),
    ...COURSE_CONFIG.grade.levels.map(meta => ({ courseKey: 'grade', level: Number(meta.value) }))
  ];
  const PASS_ACCURACY = 90;
  const WEEKLY_FREE_LIMIT = 3;
  const PROMOTION_SUBJECTS = [
    { key: 'speech', label: '연설', order: 1 },
    { key: 'editorial', label: '논설', order: 2 }
  ];
  const SUBJECT_BREAK_SECONDS = 60;
  const AUDIO_STORAGE_BUCKET = 'practice-audios';
  const LOCAL_AUDIO_INLINE_MAX_BYTES = 900 * 1024;
  const AUDIO_UPLOAD_TIMEOUT_MS = 60000;
  const DB_SAVE_TIMEOUT_MS = 45000;

  let ctx = null;
  let COURSE = COURSE_CONFIG.intermediate;
  let LEVELS = COURSE.levels.map(item => item.value);
  let materials = [];
  let progressLogs = [];
  let creditLedger = [];
  let isMaterialManager = false;
  let isStrictAdmin = false;
  let targetLevel = null;
  let targetStep = null;
  let assignedMaterial = null;
  let activeAttempt = null;
  let startedAt = null;
  let timer = null;
  let adminAudioFile = null;
  let adminAudioName = '';
  let adminAudioDataUrl = '';
  let adminEditorialAudioFile = null;
  let adminEditorialAudioName = '';
  let adminEditorialAudioDataUrl = '';
  let hasSubmitted = false;
  let currentSubjectIndex = 0;
  let subjectAnswers = {};
  let breakTimer = null;
  let breakRemain = SUBJECT_BREAK_SECONDS;
  let suppressAutoResume = false;

  const $ = (id) => document.getElementById(id);
  const qsa = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  function esc(value) {
    return String(value ?? '').replace(/[&<>"']/g, s => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[s]));
  }
  function normalizeRole(value) { return String(value || '').trim().toLowerCase(); }
  function collectRoles(context) {
    let cached = '';
    try { cached = JSON.parse(sessionStorage.getItem('sorizava_profile') || '{}').role || ''; } catch (error) { cached = ''; }
    return [context?.profile?.role, sessionStorage.getItem('shorthand_role'), cached].map(normalizeRole).filter(Boolean);
  }
  function hasStrictAdminAccess(context) {
    const roles = ['admin', 'administrator', 'super_admin', 'superadmin', 'owner', 'manager', 'operator', 'staff', '관리자', '운영팀'];
    return collectRoles(context).some(role => roles.includes(role));
  }
  function hasMaterialManageAccess(context) {
    const roles = ['admin', 'administrator', 'super_admin', 'superadmin', 'owner', 'manager', 'operator', 'staff', 'teacher', '강사', '선생님', '관리자', '운영팀'];
    return collectRoles(context).some(role => roles.includes(role));
  }
  function resolveCourseKeyFromQuery() {
    const raw = String(new URLSearchParams(location.search).get('course') || '').toLowerCase();
    if (['advanced', 'high', '고급', '고급반'].includes(raw)) return 'advanced';
    if (['grade', 'level', '급수', '급수반'].includes(raw)) return 'grade';
    if (['intermediate', 'middle', '중급', '중급반'].includes(raw)) return 'intermediate';
    return '';
  }
  function profileText(context = ctx) {
    const p = context?.profile || {};
    return [p.course, p.current_course, p.course_type, p.enrolled_course, p.training_course, p.class_name, p.className, p.current_class, p.currentClass, p.level, p.current_level, p.progress_level, p.study_level, p.grade, p.grade_level, p.track, p.progress, p.memo, p.note]
      .filter(v => v !== undefined && v !== null).join(' ');
  }
  function inferCourseFromProfile(context = ctx) {
    const text = profileText(context);
    if (/급수|1\s*급|2\s*급|3\s*급|시험대비|자격증|grade/i.test(text)) return 'grade';
    if (/고급|190\s*자|210\s*자|230\s*자|250\s*자|advanced/i.test(text)) return 'advanced';
    if (/중급|110\s*자|120\s*자|130\s*자|140\s*자|150\s*자|160\s*자|170\s*자|intermediate/i.test(text)) return 'intermediate';
    return '';
  }
  function inferCourseFromRecentRecords() {
    const rows = progressLogs || [];
    const found = rows.find(row => ['intermediate', 'advanced', 'grade'].includes(String(row.course || row.toolType || '')));
    return found ? String(found.course || found.toolType) : '';
  }
  function setCourse(key) {
    COURSE = COURSE_CONFIG[key] || COURSE_CONFIG.intermediate;
    LEVELS = COURSE.levels.map(item => item.value);
    document.body?.setAttribute('data-course', COURSE.key);
  }
  function courseConfig(courseKey = COURSE.key) { return COURSE_CONFIG[courseKey] || COURSE_CONFIG.intermediate; }
  function normalizeCourseKey(value, fallback = COURSE.key) {
    const raw = String(value || '').trim().toLowerCase();
    if (['advanced', 'high', '고급', '고급반', 'advanced_unlock', 'advanced_progress'].includes(raw) || /advanced|고급/.test(raw)) return 'advanced';
    if (['grade', 'level', '급수', '급수반', 'grade_unlock', 'grade_progress'].includes(raw) || /grade|급수|[123]\s*급/.test(raw)) return 'grade';
    if (['intermediate', 'middle', '중급', '중급반', 'intermediate_unlock', 'intermediate_progress'].includes(raw) || /intermediate|중급/.test(raw)) return 'intermediate';
    return COURSE_CONFIG[fallback] ? fallback : 'intermediate';
  }
  function levelMeta(level, courseKey = COURSE.key) {
    const numeric = Number(level);
    const config = courseConfig(courseKey);
    return config.levels.find(item => Number(item.value) === numeric) || { value: numeric, label: `${numeric}자`, pace: numeric };
  }
  function levelLabel(level, courseKey = COURSE.key) { return levelMeta(level, courseKey).label; }
  function levelIndex(level, courseKey = COURSE.key) { return courseConfig(courseKey).levels.map(item => Number(item.value)).indexOf(Number(level)); }
  function routeIndex(step) {
    if (!step) return -1;
    const courseKey = normalizeCourseKey(step.courseKey || step.course || COURSE.key);
    return PROMOTION_ROUTE.findIndex(item => item.courseKey === courseKey && Number(item.level) === Number(step.level));
  }
  function nextPromotionStep(step) {
    const idx = routeIndex(step);
    return idx >= 0 ? PROMOTION_ROUTE[idx + 1] || null : null;
  }
  function previousPromotionStep(step) {
    const idx = routeIndex(step);
    return idx > 0 ? PROMOTION_ROUTE[idx - 1] : null;
  }
  function nextLevel(level) {
    const next = nextPromotionStep({ courseKey: COURSE.key, level });
    return next && next.courseKey === COURSE.key ? next.level : null;
  }
  function previousLevel(level) {
    const prev = previousPromotionStep({ courseKey: COURSE.key, level });
    return prev && prev.courseKey === COURSE.key ? prev.level : null;
  }
  function stepLabel(step, includeCourse = false) {
    if (!step) return '최종 단계';
    const courseKey = normalizeCourseKey(step.courseKey || step.course || COURSE.key);
    const label = levelLabel(step.level, courseKey);
    return includeCourse ? `${courseConfig(courseKey).label} ${label}` : label;
  }
  function pureText(text) { return String(text || '').replace(/[^a-zA-Z0-9가-힣]/g, ''); }
  function pureCount(text) { return pureText(text).length; }
  function formatClock(seconds) {
    const safe = Math.max(0, Number(seconds) || 0);
    const min = Math.floor(safe / 60).toString().padStart(2, '0');
    const sec = Math.floor(safe % 60).toString().padStart(2, '0');
    return `${min}:${sec}`;
  }
  function formatTime(seconds) {
    const safe = Math.max(0, Number(seconds) || 0);
    const min = Math.floor(safe / 60);
    const sec = Math.floor(safe % 60).toString().padStart(2, '0');
    return `${min}:${sec}`;
  }
  function formatFileSize(bytes) {
    const size = Number(bytes || 0);
    if (size >= 1024 * 1024) return `${(size / 1024 / 1024).toFixed(1)}MB`;
    if (size >= 1024) return `${Math.round(size / 1024)}KB`;
    return `${size}B`;
  }
  function kstDateKey(date = new Date()) {
    try { return new Date(date).toLocaleDateString('sv-SE', { timeZone: 'Asia/Seoul' }); }
    catch (error) { return new Date(Date.now() + 9 * 60 * 60 * 1000).toISOString().slice(0, 10); }
  }
  function kstDateFromKey(key) { return new Date(`${key}T00:00:00+09:00`); }
  function weekRange() {
    const today = kstDateFromKey(kstDateKey());
    const day = today.getDay();
    const monday = new Date(today);
    monday.setDate(today.getDate() - ((day + 6) % 7));
    const sunday = new Date(monday);
    sunday.setDate(monday.getDate() + 6);
    return { start: kstDateKey(monday), end: kstDateKey(sunday) };
  }
  function displayName() { return ctx?.profile?.name || ctx?.user?.email || sessionStorage.getItem('shorthand_user') || 'User'; }
  function syncShell() {
    const name = displayName();
    qsa('#userNameSide').forEach(el => { el.textContent = name; });
    qsa('#userAvatar').forEach(el => { el.textContent = String(name || 'U').charAt(0).toUpperCase(); });
    if (isStrictAdmin && $('adminBtn')) $('adminBtn').style.display = 'block';
  }
  function materialKey(item) { return item ? String(item.rowId || item.id || item.title || '') : ''; }
  function subjectMeta(subjectKey) { return PROMOTION_SUBJECTS.find(item => item.key === subjectKey) || PROMOTION_SUBJECTS[0]; }
  function subjectLabel(subjectKey) { return subjectMeta(subjectKey).label; }
  function emptySubject() { return { sourceText: '', audioName: '', audioDataUrl: '', audioUrl: '', audioPath: '', audioMime: '' }; }
  function normalizeSubjectData(value, fallback = {}) {
    const row = value && typeof value === 'object' ? value : {};
    return {
      sourceText: row.sourceText || row.text || fallback.sourceText || '',
      audioName: row.audioName || row.audio_name || fallback.audioName || '',
      audioDataUrl: row.audioDataUrl || row.audio_data_url || fallback.audioDataUrl || '',
      audioUrl: row.audioUrl || row.audio_url || fallback.audioUrl || '',
      audioPath: row.audioPath || row.audio_path || fallback.audioPath || '',
      audioMime: row.audioMime || row.audio_mime || fallback.audioMime || ''
    };
  }
  function materialSubject(item, subjectKey) {
    const fallback = subjectKey === 'speech' ? {
      sourceText: item?.sourceText || '',
      audioName: item?.audioName || '',
      audioDataUrl: item?.audioDataUrl || '',
      audioUrl: item?.audioUrl || '',
      audioPath: item?.audioPath || '',
      audioMime: item?.audioMime || ''
    } : emptySubject();
    return normalizeSubjectData(item?.subjects?.[subjectKey], fallback);
  }
  function getSubjectAudioSrc(subject) { return subject ? (subject.audioUrl || subject.audioDataUrl || '') : ''; }
  function getMaterialAudioSrc(item) { return getSubjectAudioSrc(materialSubject(item, 'speech')); }
  function hasCompleteSubject(item, subjectKey) {
    const subject = materialSubject(item, subjectKey);
    return Boolean(subject.sourceText && getSubjectAudioSrc(subject));
  }
  function hasCompletePromotionMaterial(item) {
    return PROMOTION_SUBJECTS.every(meta => hasCompleteSubject(item, meta.key));
  }
  function stripLevelPrefix(title) {
    let value = String(title || '').trim();
    COURSE.levels.forEach(meta => {
      const escapedLabel = meta.label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      value = value.replace(new RegExp(`^\\s*${escapedLabel}\\s*`), '');
    });
    return value.replace(/^\s*\d+\s*자\s*/, '').replace(/^\s*[123]\s*급\s*/, '').trim();
  }
  function extractLevel(title) {
    const text = String(title || '');
    const byLabel = COURSE.levels.find(meta => text.includes(meta.label));
    if (byLabel) return Number(byLabel.value);
    const values = COURSE.levels.map(meta => meta.value).join('|');
    const match = text.match(new RegExp(`(${values})`));
    return match ? Number(match[1]) : null;
  }
  function normalizeLevelValue(value, title = '') {
    const raw = String(value ?? '').trim();
    if (raw) {
      const byLabel = COURSE.levels.find(meta => raw === String(meta.value) || raw === meta.label || raw.includes(meta.label));
      if (byLabel) return Number(byLabel.value);
      const num = Number(raw.replace(/[^0-9]/g, ''));
      if (Number.isFinite(num)) {
        const direct = COURSE.levels.find(meta => Number(meta.value) === num);
        if (direct) return Number(direct.value);
      }
    }
    return extractLevel(title) || LEVELS[0];
  }
  function normalizeMaterial(row, index = 0, source = 'supabase') {
    let payload = {};
    if (typeof row.content === 'string') {
      try { payload = JSON.parse(row.content); } catch (error) { payload = { sourceText: row.content }; }
    } else if (row.content && typeof row.content === 'object') {
      payload = row.content;
    }
    const level = normalizeLevelValue(payload.level || row.level, row.title || payload.title || '');
    const cleanTitle = payload.title || row.display_title || row.title || `${levelLabel(level)} 승급 ${index + 1}`;
    const legacySubject = {
      sourceText: payload.sourceText || payload.text || '',
      audioName: payload.audioName || payload.audio_name || '',
      audioDataUrl: payload.audioDataUrl || payload.audio_data_url || '',
      audioUrl: payload.audioUrl || payload.audio_url || row.audio_url || '',
      audioPath: payload.audioPath || payload.audio_path || '',
      audioMime: payload.audioMime || payload.audio_mime || ''
    };
    const subjects = {
      speech: normalizeSubjectData(payload.subjects?.speech || payload.speech, legacySubject),
      editorial: normalizeSubjectData(payload.subjects?.editorial || payload.editorial, {})
    };
    return {
      id: String(row.id || payload.id || `${source}_${level}_${index}_${Date.now()}`),
      source,
      rowId: row.id || null,
      level,
      title: stripLevelPrefix(cleanTitle) || `${levelLabel(level)} 승급 ${index + 1}`,
      subjects,
      sourceText: subjects.speech.sourceText,
      audioName: subjects.speech.audioName,
      audioDataUrl: subjects.speech.audioDataUrl,
      audioUrl: subjects.speech.audioUrl,
      audioPath: subjects.speech.audioPath,
      audioMime: subjects.speech.audioMime,
      createdAt: row.created_at || payload.createdAt || ''
    };
  }
  function readLocalMaterials() {
    try {
      const rows = JSON.parse(localStorage.getItem(COURSE.localMaterialsKey) || '[]');
      return Array.isArray(rows) ? rows.map((row, idx) => normalizeMaterial(row, idx, 'local')) : [];
    } catch (error) { return []; }
  }
  function writeLocalMaterials(list) {
    const compact = (Array.isArray(list) ? list : []).map(item => ({
      id: item.id,
      level: item.level,
      title: item.title,
      content: JSON.stringify({
        level: item.level,
        title: item.title,
        subjects: item.subjects || {
          speech: normalizeSubjectData(null, item),
          editorial: emptySubject()
        },
        sourceText: item.sourceText,
        audioName: item.audioName,
        audioDataUrl: item.audioDataUrl,
        audioUrl: item.audioUrl || '',
        audioPath: item.audioPath || '',
        audioMime: item.audioMime || '',
        createdAt: item.createdAt || new Date().toISOString()
      })
    }));
    localStorage.setItem(COURSE.localMaterialsKey, JSON.stringify(compact));
  }
  function materialsForLevel(level = targetLevel) {
    return materials.filter(item => Number(item.level) === Number(level) && hasCompletePromotionMaterial(item));
  }
  function findMaterial(id) { return materials.find(item => String(item.id) === String(id)) || null; }
  async function loadMaterials() {
    let loaded = [];
    try {
      const client = window.SORIZAVA_SUPABASE;
      if (!client) throw new Error('Supabase client missing');
      const { data, error } = await client
        .from('practice_materials')
        .select('*')
        .eq('tool_type', COURSE.unlockToolType)
        .eq('is_active', true)
        .order('created_at', { ascending: true });
      if (error) throw error;
      loaded = (data || []).map((row, idx) => normalizeMaterial(row, idx, 'supabase'));
    } catch (error) {
      console.warn(`${COURSE.title} 자료 서버 조회 실패, 로컬 자료로 대체:`, error);
      loaded = readLocalMaterials();
    }
    const localLoaded = readLocalMaterials();
    if (localLoaded.length) {
      const map = new Map();
      [...loaded, ...localLoaded].forEach(item => {
        if (!item) return;
        const key = `${item.source || 'row'}|${item.rowId || item.id || item.level + '_' + item.title}`;
        map.set(key, item);
      });
      loaded = Array.from(map.values());
    }
    materials = loaded.sort((a, b) => levelIndex(a.level) - levelIndex(b.level) || String(a.createdAt || '').localeCompare(String(b.createdAt || '')) || a.title.localeCompare(b.title, 'ko'));
  }
  function readProgressLogs(courseKey = COURSE.key) {
    try {
      const config = courseConfig(courseKey);
      const rows = JSON.parse(localStorage.getItem(config.progressKey) || '[]');
      return Array.isArray(rows) ? rows.map(row => ({ ...row, course: normalizeCourseKey(row.course || row.courseKey || config.key, config.key) })) : [];
    } catch (error) { return []; }
  }
  function writeProgressLogs(rows, courseKey = COURSE.key) {
    const config = courseConfig(courseKey);
    const clean = (Array.isArray(rows) ? rows : [])
      .filter(row => row && row.level && row.materialKey)
      .map(row => ({ ...row, course: normalizeCourseKey(row.course || row.courseKey || config.key, config.key) }))
      .sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0))
      .slice(0, 800);
    localStorage.setItem(config.progressKey, JSON.stringify(clean));
    if (config.key === COURSE.key) progressLogs = clean;
  }
  function progressLogKey(row) { return [row.course || '', row.createdAt || '', row.level || '', row.materialKey || '', row.mode || '', row.accuracy || ''].join('|'); }
  function mergeProgressLogs(...groups) {
    const map = new Map();
    groups.flat().forEach(row => {
      if (!row || !row.level || !row.materialKey) return;
      map.set(progressLogKey(row), row);
    });
    return Array.from(map.values());
  }
  function parseProgressMemo(record, courseKey = COURSE.key) {
    const memo = record && record.memo;
    if (!memo || typeof memo !== 'string') return null;
    try {
      const parsed = JSON.parse(memo);
      return parsed && parsed.kind === courseConfig(courseKey).progressKind ? parsed : null;
    } catch (error) { return null; }
  }
  async function syncRemoteProgressLogs(courseKey = COURSE.key) {
    const config = courseConfig(courseKey);
    progressLogs = readProgressLogs(config.key);
    try {
      if (!window.SorizavaRecords || !window.SorizavaRecords.getMyRecentRecords) return;
      const records = await window.SorizavaRecords.getMyRecentRecords(700);
      const remoteLogs = (records || [])
        .filter(record => record.tool_type === config.toolType || record.tool_type === config.unlockToolType)
        .map(record => {
          const meta = parseProgressMemo(record, config.key);
          if (!meta || !meta.materialKey) return null;
          return {
            id: meta.id || String(record.id || ''),
            course: normalizeCourseKey(meta.course || config.key, config.key),
            level: Number(meta.level),
            materialId: meta.materialId || '',
            materialKey: meta.materialKey || '',
            materialTitle: meta.materialTitle || meta.title || record.practice_title || '',
            title: meta.title || meta.materialTitle || record.practice_title || '',
            mode: meta.mode || (record.tool_type === config.unlockToolType ? 'unlock' : ''),
            roomMode: meta.roomMode || (record.tool_type === config.unlockToolType ? 'unlock' : ''),
            accuracy: Number(meta.accuracy ?? record.accuracy ?? record.score ?? 0),
            score: Number(meta.score ?? record.score ?? record.accuracy ?? 0),
            cpm: Number(meta.cpm ?? record.cpm ?? 0),
            elapsed: Number(meta.elapsed ?? record.elapsed_seconds ?? 0),
            createdAt: record.created_at || meta.createdAt || new Date().toISOString(),
            date: meta.date || ''
          };
        })
        .filter(Boolean);
      writeProgressLogs(mergeProgressLogs(progressLogs, remoteLogs), config.key);
    } catch (error) {
      console.warn('진도 승급실 기록 동기화 실패:', error);
    }
  }
  function bestUnlockLogForLevel(level, courseKey = COURSE.key) {
    const config = courseConfig(courseKey);
    const source = config.key === COURSE.key ? progressLogs : readProgressLogs(config.key);
    return source
      .filter(row => Number(row.level) === Number(level) && normalizeCourseKey(row.course || row.courseKey || config.key, config.key) === config.key && (row.mode === 'unlock' || row.roomMode === 'unlock'))
      .sort((a, b) => Number(b.accuracy || 0) - Number(a.accuracy || 0))[0] || null;
  }
  function isLevelPassedForUnlock(level, courseKey = COURSE.key) {
    const best = bestUnlockLogForLevel(level, courseKey);
    return Boolean(best && Number(best.accuracy || 0) >= PASS_ACCURACY);
  }
  function inferAssignedTargetStep() {
    const p = ctx?.profile || {};
    const rawValues = [
      p.promotion_level, p.promotion_target, p.unlock_target, p.unlock_level,
      p.target_level, p.next_level, p.assigned_level, p.assigned_progress,
      p.current_level, p.progress_level, p.study_level, p.level, p.speed, p.current_speed,
      profileText(ctx)
    ];
    const hinted = inferCourseFromProfile(ctx) || COURSE.key;
    const courseOrder = [hinted, ...Object.keys(COURSE_CONFIG).filter(key => key !== hinted)];
    for (const value of rawValues) {
      const raw = String(value ?? '').trim();
      if (!raw) continue;
      for (const courseKey of courseOrder) {
        const config = courseConfig(courseKey);
        const byLabel = config.levels.find(meta => raw === meta.label || raw.includes(meta.label));
        if (byLabel) return { courseKey: config.key, level: Number(byLabel.value) };
      }
      const num = Number(raw.replace(/[^0-9]/g, ''));
      if (Number.isFinite(num)) {
        for (const courseKey of courseOrder) {
          const config = courseConfig(courseKey);
          const direct = config.levels.find(meta => Number(meta.value) === num);
          if (direct) return { courseKey: config.key, level: Number(direct.value) };
        }
      }
    }
    return null;
  }
  function getNextUnlockTarget() {
    const assigned = inferAssignedTargetStep();
    if (assigned) {
      let step = assigned;
      while (step && isLevelPassedForUnlock(step.level, step.courseKey)) step = nextPromotionStep(step);
      return step || null;
    }
    return PROMOTION_ROUTE.find(step => !isLevelPassedForUnlock(step.level, step.courseKey)) || null;
  }
  function getHighestUnlockedLevel() {
    let highest = LEVELS[0];
    for (const step of LEVELS) {
      if (step === LEVELS[0] || isLevelPassedForUnlock(previousLevel(step))) highest = step;
      else break;
    }
    return highest;
  }
  function readAttempts() {
    try {
      const rows = JSON.parse(localStorage.getItem(`sorizava_${COURSE.key}_unlock_attempts_v1`) || '[]');
      return Array.isArray(rows) ? rows : [];
    } catch (error) { return []; }
  }
  function writeAttempts(rows) {
    localStorage.setItem(`sorizava_${COURSE.key}_unlock_attempts_v1`, JSON.stringify((Array.isArray(rows) ? rows : []).slice(-700)));
  }
  function weeklyAttempts() {
    const range = weekRange();
    return readAttempts().filter(row => row && row.dateKey >= range.start && row.dateKey <= range.end);
  }
  function extraChances() {
    const value = Number(localStorage.getItem(`sorizava_${COURSE.key}_unlock_extra_chances_v1`) || 0);
    return Number.isFinite(value) ? Math.max(0, value) : 0;
  }
  function weeklyLimit() { return WEEKLY_FREE_LIMIT + extraChances(); }
  function remainingAttempts() { return Math.max(0, weeklyLimit() - weeklyAttempts().length); }
  async function loadCreditLedger() {
    creditLedger = [];
    const userId = ctx?.user?.id || sessionStorage.getItem('shorthand_user_id');
    try {
      const local = JSON.parse(localStorage.getItem('credit_ledger') || '[]');
      creditLedger = Array.isArray(local) ? local : [];
    } catch (error) { creditLedger = []; }
    if (!userId || !window.SORIZAVA_SUPABASE) return;
    try {
      const { data, error } = await window.SORIZAVA_SUPABASE
        .from('credit_ledger')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(200);
      if (error) throw error;
      creditLedger = data || [];
    } catch (error) {
      console.warn('크레딧 DB 조회 실패, localStorage 기준으로 표시:', error);
    }
  }
  function creditBalance() {
    const p = ctx?.profile || {};
    const profileBalance = [p.credit_balance, p.credits, p.credit].map(Number).find(Number.isFinite);
    if (Number.isFinite(profileBalance)) return profileBalance;
    return creditLedger.reduce((sum, row) => sum + (Number(row.amount) || 0), 0);
  }
  function attemptsForMaterial(item) {
    const key = materialKey(item);
    return readAttempts().filter(row => Number(row.level) === Number(item.level) && row.materialKey === key);
  }
  function chooseNextMaterial(level) {
    const list = materialsForLevel(level);
    if (!list.length) return null;
    const neverTried = list.find(item => attemptsForMaterial(item).length === 0);
    if (neverTried) return neverTried;
    return list.slice().sort((a, b) => {
      const aLast = attemptsForMaterial(a).sort((x, y) => new Date(y.createdAt || 0) - new Date(x.createdAt || 0))[0];
      const bLast = attemptsForMaterial(b).sort((x, y) => new Date(y.createdAt || 0) - new Date(x.createdAt || 0))[0];
      return new Date(aLast?.createdAt || 0) - new Date(bLast?.createdAt || 0);
    })[0];
  }
  function updateAssignedMaterial() {
    targetStep = getNextUnlockTarget();
    if (targetStep && targetStep.courseKey !== COURSE.key) {
      setCourse(targetStep.courseKey);
      updateCourseUi();
    }
    targetLevel = targetStep ? Number(targetStep.level) : null;
    assignedMaterial = targetStep ? chooseNextMaterial(targetStep.level) : null;
  }
  async function refreshAssignedMaterial() {
    const step = getNextUnlockTarget();
    if (step && step.courseKey !== COURSE.key) {
      setCourse(step.courseKey);
      updateCourseUi();
      renderAdminLevels(step.courseKey, step.level);
      renderCourseTabs();
      await loadMaterials();
      await syncRemoteProgressLogs(step.courseKey);
    }
    targetStep = step || null;
    targetLevel = targetStep ? Number(targetStep.level) : null;
    assignedMaterial = targetStep ? chooseNextMaterial(targetStep.level) : null;
  }
  function updateCourseUi() {
    document.title = 'SHORTHAND PRO - 진도 승급실';
    if ($('unlockPageTitle')) $('unlockPageTitle').textContent = '🎯 진도 승급실';
    if ($('unlockPageSubtitle')) $('unlockPageSubtitle').textContent = '학생별 승급 기준에 따라 현재 응시해야 할 단계만 자동 배정됩니다. 한번 시작하면 멈출 수 없습니다.';
    if ($('unlockRoomNavText')) $('unlockRoomNavText').textContent = '진도 승급실';
    if ($('unlockRoomNavItem')) $('unlockRoomNavItem').href = 'unlock-room.html';
    qsa('.nav-item').forEach(item => item.classList.toggle('active', item.dataset.navKey === 'unlock-room'));
  }
  function allAdminStepOptions() {
    const labels = { intermediate: '중급반', advanced: '고급반', grade: '급수반' };
    return Object.entries(COURSE_CONFIG).map(([key, config]) => ({
      key,
      label: labels[key] || config.label,
      levels: config.levels.map(meta => ({ course: key, value: Number(meta.value), label: meta.label }))
    }));
  }
  function stepValue(courseKey, level) { return `${courseKey}:${Number(level)}`; }
  function parseStepValue(value) {
    const raw = String(value || '').trim();
    if (raw.includes(':')) {
      const [courseKey, levelRaw] = raw.split(':');
      return { courseKey: COURSE_CONFIG[courseKey] ? courseKey : COURSE.key, level: Number(levelRaw) || LEVELS[0] };
    }
    return { courseKey: COURSE.key, level: Number(raw || targetLevel || LEVELS[0]) };
  }
  function selectedAdminStep() {
    const select = $('unlockAdminLevel');
    return parseStepValue(select && select.value ? select.value : stepValue(COURSE.key, targetLevel || LEVELS[0]));
  }
  async function switchCourseForAdmin(courseKey) {
    if (!COURSE_CONFIG[courseKey] || courseKey === COURSE.key) return;
    setCourse(courseKey);
    updateCourseUi();
    renderAdminLevels();
    await loadMaterials();
    await syncRemoteProgressLogs();
  }
  function renderAdminLevels(selectedCourse = COURSE.key, selectedLevel = targetLevel || LEVELS[0]) {
    const select = $('unlockAdminLevel');
    if (!select) return;
    select.innerHTML = allAdminStepOptions().map(group => `
      <optgroup label="${esc(group.label)}">
        ${group.levels.map(meta => `<option value="${stepValue(meta.course, meta.value)}">${esc(group.label)} ${esc(meta.label)}</option>`).join('')}
      </optgroup>
    `).join('');
    select.value = stepValue(selectedCourse, selectedLevel);
    if (!select.value) select.value = stepValue(COURSE.key, LEVELS[0]);
  }
  function renderCourseTabs() {
    const box = $('unlockCourseTabs');
    if (!box) return;
    box.innerHTML = '<span class="unlock-single-route">중급·고급·급수 승급 자료를 한 화면에서 관리합니다. 학생에게는 지정된 승급 대상만 표시됩니다.</span>';
  }
  function renderAdminMaterialSelect() {
    const select = $('unlockAdminMaterialSelect');
    if (!select) return;
    const step = selectedAdminStep();
    const level = Number(step.level || targetLevel || LEVELS[0]);
    const list = materials.filter(item => Number(item.level) === Number(level));
    select.innerHTML = ['<option value="__new">새 자료 등록</option>', ...list.map((item, idx) => `<option value="${esc(item.id)}">${idx + 1}. ${esc(item.title)}</option>`)].join('');
  }
  function newUnlockMaterialForm(clearSelect = true) {
    if (clearSelect && $('unlockAdminMaterialSelect')) $('unlockAdminMaterialSelect').value = '__new';
    const step = selectedAdminStep();
    const level = Number(step.level || targetLevel || LEVELS[0]);
    const nextNo = materials.filter(item => Number(item.level) === Number(level)).length + 1;
    $('unlockAdminTitle').value = `${levelLabel(level)} 승급 ${nextNo}번`;
    $('unlockAdminSourceText').value = '';
    if ($('unlockAdminEditorialSourceText')) $('unlockAdminEditorialSourceText').value = '';
    adminAudioFile = null;
    adminAudioDataUrl = '';
    adminAudioName = '';
    adminEditorialAudioFile = null;
    adminEditorialAudioDataUrl = '';
    adminEditorialAudioName = '';
    $('unlockAdminAudioName').innerText = '연설 오디오 없음';
    if ($('unlockAdminEditorialAudioName')) $('unlockAdminEditorialAudioName').innerText = '논설 오디오 없음';
  }
  function populateUnlockAdminForm(id) {
    if (!id || id === '__new') return newUnlockMaterialForm(false);
    const item = findMaterial(id);
    if (!item) return newUnlockMaterialForm(false);
    const currentStep = selectedAdminStep();
    if (String(currentStep.courseKey) !== String(COURSE.key) || Number(currentStep.level) !== Number(item.level)) {
      $('unlockAdminLevel').value = stepValue(COURSE.key, item.level);
    }
    const speech = materialSubject(item, 'speech');
    const editorial = materialSubject(item, 'editorial');
    $('unlockAdminTitle').value = item.title;
    $('unlockAdminSourceText').value = speech.sourceText || '';
    if ($('unlockAdminEditorialSourceText')) $('unlockAdminEditorialSourceText').value = editorial.sourceText || '';
    adminAudioFile = null;
    adminAudioDataUrl = speech.audioDataUrl || '';
    adminAudioName = speech.audioName || '';
    adminEditorialAudioFile = null;
    adminEditorialAudioDataUrl = editorial.audioDataUrl || '';
    adminEditorialAudioName = editorial.audioName || '';
    $('unlockAdminAudioName').innerText = speech.audioName || (getSubjectAudioSrc(speech) ? '연설 등록 오디오' : '연설 오디오 없음');
    if ($('unlockAdminEditorialAudioName')) $('unlockAdminEditorialAudioName').innerText = editorial.audioName || (getSubjectAudioSrc(editorial) ? '논설 등록 오디오' : '논설 오디오 없음');
  }
  function renderStatus() {
    if (!activeAttempt || hasSubmitted) updateAssignedMaterial();
    const remaining = remainingAttempts();
    const used = weeklyAttempts().length;
    const credits = Math.max(0, Number(creditBalance()) || 0);
    if ($('unlockRemainCount')) $('unlockRemainCount').textContent = `${remaining}회`;
    if ($('unlockAttemptMeta')) $('unlockAttemptMeta').textContent = `주 ${WEEKLY_FREE_LIMIT}회 무료 · ${used}/${weeklyLimit()}회 사용`;
    if ($('unlockCreditCount')) $('unlockCreditCount').textContent = `${credits}개`;

    const currentStep = targetStep || (targetLevel ? { courseKey: COURSE.key, level: Number(targetLevel) } : null);
    const nextStep = currentStep ? nextPromotionStep(currentStep) : null;
    const targetLabel = currentStep ? stepLabel(currentStep, true) : '전체 승급 완료';
    const nextLabel = nextStep ? stepLabel(nextStep, true) : '최종 단계';
    if ($('unlockTargetLabel')) $('unlockTargetLabel').textContent = targetLabel;
    if ($('unlockTargetMeta')) {
      $('unlockTargetMeta').textContent = currentStep
        ? `통과 후 다음 단계: ${nextLabel}`
        : '모든 승급 단계가 열려 있습니다.';
    }
    if ($('unlockNextLabel')) $('unlockNextLabel').textContent = currentStep ? nextLabel : '완료';
    if ($('unlockNextMeta')) $('unlockNextMeta').textContent = currentStep
      ? `${stepLabel(currentStep, false)} 통과 시 ${nextLabel}로 승급합니다.`
      : '더 이상 응시할 승급 단계가 없습니다.';

    const readyTitle = $('unlockReadyTitle');
    const readyMessage = $('unlockReadyMessage');
    const startBtn = $('unlockStartBtn');
    if (!readyTitle || !readyMessage || !startBtn) return;
    startBtn.disabled = true;
    if (!targetLevel) {
      readyTitle.textContent = '모든 단계가 열려 있습니다.';
      readyMessage.textContent = '승급 기준을 모두 통과했습니다.';
      startBtn.textContent = '승급 완료';
      return;
    }
    if (!assignedMaterial) {
      readyTitle.textContent = `${targetLabel} 승급 자료 없음`;
      readyMessage.textContent = '관리자가 해당 단계의 연설·논설 원문과 오디오를 모두 등록해야 응시할 수 있습니다.';
      startBtn.textContent = '응시 불가';
      return;
    }
    if (remaining <= 0) {
      readyTitle.textContent = `${targetLabel} 응시 횟수 부족`;
      readyMessage.textContent = `이번 주 무료 ${WEEKLY_FREE_LIMIT}회를 모두 사용했습니다. 추가 응시는 크레딧 차감 구조로 연결해야 합니다.`;
      startBtn.textContent = '응시 횟수 없음';
      return;
    }
    readyTitle.textContent = `${targetLabel} 승급 평가`;
    readyMessage.textContent = `통과 후 다음 단계는 ${nextLabel}입니다. 연설 후 1분 대기 뒤 논설이 이어집니다. 배정 파일은 이전 응시와 최대한 겹치지 않게 자동 선택되며, 시작 즉시 응시 횟수 1회가 차감됩니다.`;
    startBtn.textContent = '응시 시작';
    startBtn.disabled = false;
  }
  function bindEvents() {
    const sourceFile = $('unlockAdminSourceFile');
    if (sourceFile) {
      sourceFile.addEventListener('change', event => {
        const file = event.target.files && event.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = () => { $('unlockAdminSourceText').value = String(reader.result || ''); event.target.value = ''; };
        reader.readAsText(file, 'utf-8');
      });
    }
    const editorialSourceFile = $('unlockAdminEditorialSourceFile');
    if (editorialSourceFile) {
      editorialSourceFile.addEventListener('change', event => {
        const file = event.target.files && event.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = () => { $('unlockAdminEditorialSourceText').value = String(reader.result || ''); event.target.value = ''; };
        reader.readAsText(file, 'utf-8');
      });
    }
    const audioFile = $('unlockAdminAudioFile');
    if (audioFile) {
      audioFile.addEventListener('change', event => {
        const file = event.target.files && event.target.files[0];
        if (!file) return;
        if (file.size > 30 * 1024 * 1024) alert('오디오 용량이 큽니다. 가능하면 30MB 이하 mp3 파일을 권장합니다.');
        adminAudioFile = file;
        adminAudioDataUrl = '';
        adminAudioName = file.name;
        $('unlockAdminAudioName').innerText = `${file.name} (${formatFileSize(file.size)})`;
        event.target.value = '';
      });
    }
    const editorialAudioFile = $('unlockAdminEditorialAudioFile');
    if (editorialAudioFile) {
      editorialAudioFile.addEventListener('change', event => {
        const file = event.target.files && event.target.files[0];
        if (!file) return;
        if (file.size > 30 * 1024 * 1024) alert('오디오 용량이 큽니다. 가능하면 30MB 이하 mp3 파일을 권장합니다.');
        adminEditorialAudioFile = file;
        adminEditorialAudioDataUrl = '';
        adminEditorialAudioName = file.name;
        $('unlockAdminEditorialAudioName').innerText = `${file.name} (${formatFileSize(file.size)})`;
        event.target.value = '';
      });
    }
    const adminLevel = $('unlockAdminLevel');
    if (adminLevel) {
      adminLevel.addEventListener('change', async () => {
        const step = selectedAdminStep();
        await switchCourseForAdmin(step.courseKey);
        renderAdminLevels(step.courseKey, step.level);
        renderAdminMaterialSelect();
        newUnlockMaterialForm(false);
      });
    }
    const adminSelect = $('unlockAdminMaterialSelect');
    if (adminSelect) {
      adminSelect.addEventListener('change', () => populateUnlockAdminForm(adminSelect.value));
    }
    const typing = $('unlockTypingArea');
    if (typing) {
      typing.addEventListener('input', () => {
        $('unlockTypingCount').textContent = `${pureCount(typing.value)}자 입력`;
      });
    }
    const audio = $('unlockAudioPlayer');
    if (audio) {
      audio.addEventListener('loadedmetadata', () => {
        $('unlockTotalTime').textContent = formatTime(audio.duration || 0);
      });
      audio.addEventListener('timeupdate', () => {
        const total = audio.duration || 0;
        $('unlockCurrentTime').textContent = formatTime(audio.currentTime || 0);
        if (total > 0) $('unlockAudioProgress').style.width = `${Math.min(100, (audio.currentTime / total) * 100)}%`;
      });
      audio.addEventListener('ended', () => {
        $('unlockAudioState').textContent = `${currentSubjectLabel()} 오디오 재생 완료`;
        $('unlockAudioMeta').textContent = isLastSubject() ? '입력을 마친 뒤 최종 채점을 누르세요.' : '입력을 마친 뒤 연설 입력 완료를 누르세요.';
        document.body.classList.remove('unlock-audio-playing');
      });
      audio.addEventListener('pause', () => {
        if (suppressAutoResume) return;
        if (activeAttempt && !hasSubmitted && !audio.ended) {
          audio.play().catch(() => {});
        }
      });
    }
    window.addEventListener('beforeunload', event => {
      if (!activeAttempt || hasSubmitted) return;
      event.preventDefault();
      event.returnValue = '';
    });
  }
  function startTimer() {
    startedAt = Date.now();
    if (timer) clearInterval(timer);
    timer = setInterval(() => {
      $('unlockTimer').textContent = formatClock((Date.now() - startedAt) / 1000);
    }, 500);
  }
  function stopTimer() {
    if (timer) clearInterval(timer);
    timer = null;
  }
  function pauseAudioWithoutResume(audio) {
    if (!audio) return;
    suppressAutoResume = true;
    audio.pause();
    setTimeout(() => { suppressAutoResume = false; }, 150);
  }
  function currentSubjectKey() { return PROMOTION_SUBJECTS[currentSubjectIndex]?.key || 'speech'; }
  function currentSubjectLabel() { return subjectLabel(currentSubjectKey()); }
  function isLastSubject() { return currentSubjectIndex >= PROMOTION_SUBJECTS.length - 1; }
  function clearBreakTimer() {
    if (breakTimer) clearInterval(breakTimer);
    breakTimer = null;
  }
  function setSubjectWorkVisible(visible) {
    if ($('unlockSubjectWorkPanel')) $('unlockSubjectWorkPanel').style.display = visible ? 'block' : 'none';
    if ($('unlockBreakPanel')) $('unlockBreakPanel').style.display = visible ? 'none' : 'grid';
  }
  function resetSubjectInput(subjectKey) {
    const label = subjectLabel(subjectKey);
    if ($('unlockTypingArea')) {
      $('unlockTypingArea').value = '';
      $('unlockTypingArea').disabled = false;
      $('unlockTypingArea').placeholder = `${label} 오디오가 시작되면 이 칸에 바로 입력하세요.`;
    }
    if ($('unlockTypingCount')) $('unlockTypingCount').textContent = '0자 입력';
    if ($('unlockSubmitBtn')) {
      $('unlockSubmitBtn').disabled = false;
      $('unlockSubmitBtn').textContent = isLastSubject() ? '최종 채점' : `${label} 입력 완료`;
    }
  }
  function recordAttemptStart(material) {
    const attempts = readAttempts();
    const id = `${Date.now()}_${Math.random().toString(16).slice(2)}`;
    const row = {
      id,
      dateKey: kstDateKey(),
      course: COURSE.key,
      level: Number(targetLevel),
      materialKey: materialKey(material),
      materialTitle: material.title || '',
      status: 'started',
      createdAt: new Date().toISOString()
    };
    attempts.push(row);
    writeAttempts(attempts);
    return row;
  }
  function updateAttemptFinish(attempt, result) {
    const attempts = readAttempts();
    const idx = attempts.findIndex(row => row.id === attempt.id);
    const updated = { ...attempt, ...result, status: 'submitted', submittedAt: new Date().toISOString() };
    if (idx >= 0) attempts[idx] = updated;
    else attempts.push(updated);
    writeAttempts(attempts);
    activeAttempt = updated;
  }
  async function playCurrentSubject() {
    const subjectKey = currentSubjectKey();
    const subject = materialSubject(assignedMaterial, subjectKey);
    const audioSrc = getSubjectAudioSrc(subject);
    if (!audioSrc) return alert(`${subjectLabel(subjectKey)} 오디오가 없습니다.`);

    setSubjectWorkVisible(true);
    resetSubjectInput(subjectKey);
    if ($('unlockLiveTitle')) $('unlockLiveTitle').textContent = `${stepLabel(targetStep || { courseKey: COURSE.key, level: targetLevel }, true)} ${subjectLabel(subjectKey)} 평가`;
    if ($('unlockAudioState')) $('unlockAudioState').textContent = `${subjectLabel(subjectKey)} 오디오 재생 중`;
    if ($('unlockAudioMeta')) $('unlockAudioMeta').textContent = subject.audioName || `${subjectLabel(subjectKey)} 등록 오디오`;
    if ($('unlockAudioProgress')) $('unlockAudioProgress').style.width = '0%';
    if ($('unlockCurrentTime')) $('unlockCurrentTime').textContent = '0:00';
    if ($('unlockTotalTime')) $('unlockTotalTime').textContent = '0:00';

    const audio = $('unlockAudioPlayer');
    pauseAudioWithoutResume(audio);
    audio.removeAttribute('src');
    audio.load();
    audio.src = audioSrc;
    audio.playbackRate = 1;
    audio.load();
    document.body.classList.add('unlock-active');
    try {
      await audio.play();
    } catch (error) {
      $('unlockAudioState').textContent = `${subjectLabel(subjectKey)} 재생 준비 완료`;
      $('unlockAudioMeta').textContent = '브라우저가 자동 재생을 막았습니다. 입력칸을 클릭한 뒤 재생이 시작되는지 확인하세요.';
      console.warn('오디오 재생 실패:', error);
    }
    $('unlockTypingArea').focus();
  }
  function showSubjectBreak() {
    clearBreakTimer();
    const audio = $('unlockAudioPlayer');
    if (audio) pauseAudioWithoutResume(audio);
    document.body.classList.remove('unlock-audio-playing');
    setSubjectWorkVisible(false);
    breakRemain = SUBJECT_BREAK_SECONDS;
    if ($('unlockBreakTimer')) $('unlockBreakTimer').textContent = formatClock(breakRemain);
    breakTimer = setInterval(() => {
      breakRemain -= 1;
      if ($('unlockBreakTimer')) $('unlockBreakTimer').textContent = formatClock(breakRemain);
      if (breakRemain <= 0) startNextSubjectNow();
    }, 1000);
  }
  async function startNextSubjectNow() {
    if (!activeAttempt || hasSubmitted) return;
    clearBreakTimer();
    currentSubjectIndex = Math.min(currentSubjectIndex + 1, PROMOTION_SUBJECTS.length - 1);
    await playCurrentSubject();
  }
  async function startUnlockChallenge() {
    renderStatus();
    if (!targetLevel) return alert('이미 모든 단계가 열려 있습니다.');
    if (!assignedMaterial) return alert('응시 가능한 진도 승급실 자료가 없습니다. 관리자에게 자료 등록을 요청하세요.');
    if (!hasCompletePromotionMaterial(assignedMaterial)) return alert('연설과 논설 원문·오디오가 모두 등록되어야 응시할 수 있습니다.');
    if (remainingAttempts() <= 0) return alert(`이번 주 무료 ${WEEKLY_FREE_LIMIT}회 응시를 모두 사용했습니다.`);

    activeAttempt = recordAttemptStart(assignedMaterial);
    hasSubmitted = false;
    currentSubjectIndex = 0;
    subjectAnswers = {};
    clearBreakTimer();
    $('unlockReadyPanel').style.display = 'none';
    $('unlockLivePanel').style.display = 'block';
    startTimer();
    await playCurrentSubject();
    renderStatus();
  }
  function calculateAccuracy(original, submitted) {
    let pureLength = pureCount(original);
    if (pureLength === 0) pureLength = 1;
    const oArr = String(original || '').trim().split('');
    const sArr = String(submitted || '').trim().split('');
    const n = oArr.length;
    const m = sArr.length;
    const dp = Array.from({ length: n + 1 }, () => Array(m + 1).fill(0));
    for (let i = 1; i <= n; i += 1) {
      for (let j = 1; j <= m; j += 1) {
        dp[i][j] = oArr[i - 1] === sArr[j - 1] ? dp[i - 1][j - 1] + 1 : Math.max(dp[i - 1][j], dp[i][j - 1]);
      }
    }
    let i = n;
    let j = m;
    const diffs = [];
    while (i > 0 || j > 0) {
      if (i > 0 && j > 0 && oArr[i - 1] === sArr[j - 1]) { diffs.unshift({ t: 'same', c: oArr[i - 1] }); i -= 1; j -= 1; }
      else if (j > 0 && (i === 0 || dp[i][j - 1] >= dp[i - 1][j])) { diffs.unshift({ t: 'added', c: sArr[j - 1] }); j -= 1; }
      else { diffs.unshift({ t: 'missing', c: oArr[i - 1] }); i -= 1; }
    }
    let wrong = 0;
    let missing = 0;
    let added = 0;
    let mBuffer = [];
    let aBuffer = [];
    function flushBuffer() {
      const len = Math.max(mBuffer.length, aBuffer.length);
      for (let k = 0; k < len; k += 1) {
        const mChar = mBuffer[k];
        const aChar = aBuffer[k];
        if (mChar !== undefined && aChar !== undefined) wrong += 1;
        else if (mChar !== undefined) missing += 1;
        else if (aChar !== undefined) added += 1;
      }
      mBuffer = [];
      aBuffer = [];
    }
    diffs.forEach(item => {
      if (item.t === 'same') { flushBuffer(); }
      else if (item.t === 'missing') mBuffer.push(item.c);
      else if (item.t === 'added') aBuffer.push(item.c);
    });
    flushBuffer();
    const addedPenalty = Math.floor(added / 3);
    const scoreValue = Math.max(0, 100 - ((wrong + missing + addedPenalty) / pureLength * 100));
    return { score: Number(scoreValue.toFixed(1)), wrong, missing, added, originalLength: pureLength };
  }
  function calculateFinalAccuracy(material, answers) {
    let originalLength = 0;
    let typedLength = 0;
    let wrong = 0;
    let missing = 0;
    let added = 0;
    const bySubject = {};
    PROMOTION_SUBJECTS.forEach(meta => {
      const subject = materialSubject(material, meta.key);
      const typed = String(answers?.[meta.key] || '');
      const result = calculateAccuracy(subject.sourceText || '', typed);
      bySubject[meta.key] = result;
      originalLength += pureCount(subject.sourceText || '');
      typedLength += pureCount(typed);
      wrong += result.wrong;
      missing += result.missing;
      added += result.added;
    });
    const baseLength = Math.max(1, originalLength);
    const scoreValue = Math.max(0, 100 - ((wrong + missing + Math.floor(added / 3)) / baseLength * 100));
    return { score: Number(scoreValue.toFixed(1)), wrong, missing, added, originalLength: baseLength, typedLength, bySubject };
  }
  async function finishUnlockChallenge() {
    if (!activeAttempt || !assignedMaterial) return alert('진행 중인 승급 평가가 없습니다.');
    if (hasSubmitted) return alert('이미 제출한 응시입니다.');
    const subjectKey = currentSubjectKey();
    const typed = $('unlockTypingArea').value;
    if (!typed.trim()) return alert('입력된 내용이 없습니다.');
    subjectAnswers[subjectKey] = typed;

    if (!isLastSubject()) {
      $('unlockTypingArea').disabled = true;
      $('unlockSubmitBtn').disabled = true;
      showSubjectBreak();
      return;
    }

    hasSubmitted = true;
    clearBreakTimer();
    stopTimer();
    const audio = $('unlockAudioPlayer');
    if (audio) pauseAudioWithoutResume(audio);
    document.body.classList.remove('unlock-active');
    $('unlockTypingArea').disabled = true;
    $('unlockSubmitBtn').disabled = true;

    const elapsed = startedAt ? Math.floor((Date.now() - startedAt) / 1000) : 0;
    const result = calculateFinalAccuracy(assignedMaterial, subjectAnswers);
    const passed = result.score >= PASS_ACCURACY;
    const cpm = elapsed > 0 ? Math.floor(result.typedLength / (elapsed / 60)) : 0;
    const record = {
      kind: COURSE.progressKind,
      id: activeAttempt.id,
      course: COURSE.key,
      level: Number(targetLevel),
      materialId: assignedMaterial.id || '',
      materialKey: materialKey(assignedMaterial),
      materialTitle: assignedMaterial.title || '',
      title: assignedMaterial.title || '',
      mode: 'unlock',
      roomMode: 'unlock',
      paragraph: '진도 승급실',
      subjects: PROMOTION_SUBJECTS.map(meta => ({ key: meta.key, label: meta.label, score: result.bySubject?.[meta.key]?.score || 0 })),
      accuracy: result.score,
      score: result.score,
      cpm,
      chars: result.typedLength,
      originalLength: result.originalLength,
      elapsed,
      wrong: result.wrong,
      missing: result.missing,
      added: result.added,
      passed,
      createdAt: new Date().toISOString(),
      date: new Date().toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })
    };
    updateAttemptFinish(activeAttempt, { accuracy: result.score, passed, elapsed, cpm, wrong: result.wrong, missing: result.missing, added: result.added });
    writeProgressLogs([record, ...progressLogs], record.course);

    if (window.SorizavaRecords) {
      window.SorizavaRecords.savePracticeRecord({
        tool_type: COURSE.unlockToolType,
        practice_title: `${COURSE.label} 진도 승급실 ${levelLabel(targetLevel)} 연설+논설 ${assignedMaterial.title || ''}`.trim(),
        original_length: result.originalLength,
        typed_length: result.typedLength,
        accuracy: result.score,
        score: result.score,
        cpm,
        elapsed_seconds: elapsed,
        wrong_count: result.wrong,
        missing_count: result.missing,
        added_count: result.added,
        memo: JSON.stringify(record)
      }).then(saved => {
        if (saved && saved.created_at) {
          record.createdAt = saved.created_at;
          writeProgressLogs([record, ...readProgressLogs(record.course)], record.course);
        }
      }).catch(error => console.warn('진도 승급실 기록 서버 저장 실패:', error));
    }
    showResult(result, passed, { courseKey: record.course, level: record.level });
    if (passed) await refreshAssignedMaterial();
    renderStatus();
  }
  function showResult(result, passed, completedStep = null) {
    const scoreValue = typeof result === 'number' ? result : Number(result?.score || 0);
    const step = completedStep || targetStep || (targetLevel ? { courseKey: COURSE.key, level: targetLevel } : null);
    const next = step ? nextPromotionStep(step) : null;
    const completedLabel = step ? stepLabel(step, true) : '현재 단계';
    const nextLabel = next ? stepLabel(next, true) : '';
    $('unlockResultMark').textContent = passed ? '✅' : '🔒';
    $('unlockResultTitle').textContent = passed ? '승급 통과' : '승급 미통과';
    $('unlockResultScore').textContent = `${Number(scoreValue).toFixed(1)}%`;
    if ($('unlockResultWrong')) $('unlockResultWrong').textContent = `${Number(result?.wrong || 0)}개`;
    if ($('unlockResultMissing')) $('unlockResultMissing').textContent = `${Number(result?.missing || 0)}개`;
    if ($('unlockResultAdded')) $('unlockResultAdded').textContent = `${Number(result?.added || 0)}개`;
    if (passed && next) $('unlockResultMessage').textContent = `${completedLabel} 통과 완료. 다음 단계는 ${nextLabel}입니다.`;
    else if (passed) $('unlockResultMessage').textContent = '마지막 단계까지 승급 완료되었습니다.';
    else $('unlockResultMessage').textContent = `${PASS_ACCURACY}% 이상이어야 통과입니다. 통과 후 다음 단계는 ${nextLabel || '최종 단계'}입니다.`;
    $('unlockResultModal').style.display = 'flex';
  }
  function closeUnlockResult(event) {
    if (event && event.target !== $('unlockResultModal')) return;
    $('unlockResultModal').style.display = 'none';
    resetAfterSubmit();
  }
  function resetAfterSubmit() {
    if (!hasSubmitted) return;
    clearBreakTimer();
    activeAttempt = null;
    assignedMaterial = null;
    startedAt = null;
    hasSubmitted = false;
    currentSubjectIndex = 0;
    subjectAnswers = {};
    setSubjectWorkVisible(true);
    $('unlockLivePanel').style.display = 'none';
    $('unlockReadyPanel').style.display = 'grid';
    const audio = $('unlockAudioPlayer');
    if (audio) { pauseAudioWithoutResume(audio); audio.removeAttribute('src'); audio.load(); }
    refreshAssignedMaterial().then(renderStatus).catch(() => renderStatus());
  }
  function safeFileName(name) {
    const original = String(name || 'audio.mp3').normalize('NFKD');
    const extMatch = original.match(/\.([a-zA-Z0-9]{1,8})$/);
    const ext = extMatch ? extMatch[1].toLowerCase() : 'mp3';
    const stem = original.replace(/\.[^/.]+$/, '').replace(/[^a-zA-Z0-9_-]+/g, '_').replace(/_+/g, '_').replace(/^_+|_+$/g, '').slice(0, 60);
    return `${stem || 'audio'}_${Date.now()}.${ext || 'mp3'}`;
  }
  function makeAudioStoragePath(level, file, subjectKey = 'speech') {
    const random = Math.random().toString(36).slice(2, 8);
    return `${COURSE.storageFolder}/${level}/${subjectKey}/${Date.now()}_${random}_${safeFileName(file?.name)}`;
  }
  function readFileAsDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = () => reject(reader.error || new Error('오디오 파일을 읽지 못했습니다.'));
      reader.readAsDataURL(file);
    });
  }
  function withTimeout(promise, ms, label) {
    let timeoutId;
    const timeout = new Promise((_, reject) => { timeoutId = setTimeout(() => reject(new Error(label || '요청 시간이 초과되었습니다.')), ms); });
    return Promise.race([promise, timeout]).finally(() => clearTimeout(timeoutId));
  }
  function adminAudioState(subjectKey) {
    if (subjectKey === 'editorial') {
      return {
        file: adminEditorialAudioFile,
        name: adminEditorialAudioName,
        dataUrl: adminEditorialAudioDataUrl
      };
    }
    return { file: adminAudioFile, name: adminAudioName, dataUrl: adminAudioDataUrl };
  }
  async function prepareAudioPayload(existing, level, subjectKey = 'speech') {
    const state = adminAudioState(subjectKey);
    const keepExisting = () => ({
      audioName: state.name || existing?.audioName || '',
      audioDataUrl: state.dataUrl || existing?.audioDataUrl || '',
      audioUrl: existing?.audioUrl || '',
      audioPath: existing?.audioPath || '',
      audioMime: existing?.audioMime || ''
    });
    if (!state.file) return keepExisting();
    const file = state.file;
    const client = window.SORIZAVA_SUPABASE;
    if (client && client.storage && typeof client.storage.from === 'function') {
      const path = makeAudioStoragePath(level, file, subjectKey);
      try {
        const { error } = await withTimeout(
          client.storage.from(AUDIO_STORAGE_BUCKET).upload(path, file, { cacheControl: '31536000', upsert: false, contentType: file.type || 'audio/mpeg' }),
          AUDIO_UPLOAD_TIMEOUT_MS,
          '오디오 업로드 시간이 초과되었습니다.'
        );
        if (error) throw error;
        const { data } = client.storage.from(AUDIO_STORAGE_BUCKET).getPublicUrl(path);
        const publicUrl = data && data.publicUrl ? data.publicUrl : '';
        if (!publicUrl) throw new Error('오디오 공개 URL을 만들지 못했습니다.');
        return { audioName: file.name, audioDataUrl: '', audioUrl: publicUrl, audioPath: path, audioMime: file.type || 'audio/mpeg' };
      } catch (uploadError) {
        if (file.size > LOCAL_AUDIO_INLINE_MAX_BYTES) throw new Error(`오디오 저장소 업로드 실패: ${uploadError.message || uploadError}`);
        console.warn('오디오 Storage 업로드 실패, 작은 파일만 임시 문자열 저장으로 대체:', uploadError);
      }
    }
    if (file.size > LOCAL_AUDIO_INLINE_MAX_BYTES) throw new Error(`오디오 파일이 ${formatFileSize(file.size)}라 브라우저 임시 저장 방식으로는 안전하게 저장할 수 없습니다.`);
    return { audioName: file.name, audioDataUrl: await readFileAsDataUrl(file), audioUrl: '', audioPath: '', audioMime: file.type || 'audio/mpeg' };
  }
  function makeLocalItem(level, title, payload) {
    const speech = normalizeSubjectData(payload.subjects?.speech, {});
    return { id: `local_unlock_${COURSE.key}_${level}_${Date.now()}`, source: 'local', rowId: null, level, title, subjects: payload.subjects, sourceText: speech.sourceText, audioName: speech.audioName, audioDataUrl: speech.audioDataUrl, audioUrl: speech.audioUrl || '', audioPath: speech.audioPath || '', audioMime: speech.audioMime || '', createdAt: new Date().toISOString() };
  }
  function saveUnlockMaterialLocal(level, title, payload, selectedId, isNew) {
    let list = readLocalMaterials();
    const speech = normalizeSubjectData(payload.subjects?.speech, {});
    const nextItem = { level, title, subjects: payload.subjects, sourceText: speech.sourceText, audioName: speech.audioName, audioDataUrl: speech.audioDataUrl, audioUrl: speech.audioUrl || '', audioPath: speech.audioPath || '', audioMime: speech.audioMime || '', source: 'local' };
    if (!isNew) {
      const idx = list.findIndex(item => item.id === selectedId);
      if (idx >= 0) list[idx] = { ...list[idx], ...nextItem };
      else list.push(makeLocalItem(level, title, payload));
    } else {
      list.push(makeLocalItem(level, title, payload));
    }
    writeLocalMaterials(list);
    materials = list;
  }
  function buildSubjectPayload(subjectKey, sourceText, audioPayload) {
    return {
      sourceText: String(sourceText || '').trim(),
      audioName: audioPayload.audioName || '',
      audioDataUrl: audioPayload.audioDataUrl || '',
      audioUrl: audioPayload.audioUrl || '',
      audioPath: audioPayload.audioPath || '',
      audioMime: audioPayload.audioMime || ''
    };
  }
  function validateSubjectPayload(subjects) {
    for (const meta of PROMOTION_SUBJECTS) {
      const subject = subjects[meta.key] || emptySubject();
      if (!subject.sourceText) return `${meta.label} 채점 기준 원문을 입력하세요.`;
      if (!getSubjectAudioSrc(subject)) return `${meta.label} 오디오를 등록하세요.`;
    }
    return '';
  }
  async function saveUnlockMaterial() {
    if (!isMaterialManager) return alert('진도 승급실 자료 등록/수정 권한이 없습니다.');
    const saveBtn = document.querySelector('button[onclick="saveUnlockMaterial()"]');
    if (saveBtn) { saveBtn.disabled = true; saveBtn.textContent = '저장 중...'; }
    let payload = null;
    try {
      const step = selectedAdminStep();
      await switchCourseForAdmin(step.courseKey);
      const level = Number(step.level || targetLevel || LEVELS[0]);
      renderAdminLevels(step.courseKey, level);
      const selectedId = $('unlockAdminMaterialSelect').value;
      const isNew = !selectedId || selectedId === '__new';
      const title = $('unlockAdminTitle').value.trim() || `${levelLabel(level)} 승급 자료`;
      const speechSourceText = $('unlockAdminSourceText').value.trim();
      const editorialSourceText = $('unlockAdminEditorialSourceText') ? $('unlockAdminEditorialSourceText').value.trim() : '';
      const existing = isNew ? null : findMaterial(selectedId);
      const speechAudio = await prepareAudioPayload(materialSubject(existing, 'speech'), level, 'speech');
      const editorialAudio = await prepareAudioPayload(materialSubject(existing, 'editorial'), level, 'editorial');
      const subjects = {
        speech: buildSubjectPayload('speech', speechSourceText, speechAudio),
        editorial: buildSubjectPayload('editorial', editorialSourceText, editorialAudio)
      };
      const validationMessage = validateSubjectPayload(subjects);
      if (validationMessage) return alert(validationMessage);
      payload = { level, title, subjects, sourceText: subjects.speech.sourceText, audioName: subjects.speech.audioName, audioDataUrl: subjects.speech.audioDataUrl, audioUrl: subjects.speech.audioUrl, audioPath: subjects.speech.audioPath, audioMime: subjects.speech.audioMime, updatedAt: new Date().toISOString() };
      const client = window.SORIZAVA_SUPABASE;
      if (!client) throw new Error('Supabase client missing');
      if (existing && existing.source === 'supabase' && existing.rowId) {
        const { error } = await withTimeout(client.from('practice_materials').update({ title: `${levelLabel(level)} ${title}`, content: JSON.stringify(payload), is_active: true }).eq('id', existing.rowId), DB_SAVE_TIMEOUT_MS, '자료 저장 시간이 초과되었습니다.');
        if (error) throw error;
      } else {
        const { error } = await withTimeout(client.from('practice_materials').insert({ tool_type: COURSE.unlockToolType, title: `${levelLabel(level)} ${title}`, content: JSON.stringify(payload), is_active: true, created_by: sessionStorage.getItem('shorthand_user_id') }), DB_SAVE_TIMEOUT_MS, '자료 저장 시간이 초과되었습니다.');
        if (error) throw error;
      }
      adminAudioFile = null;
      adminAudioDataUrl = subjects.speech.audioDataUrl || '';
      adminAudioName = subjects.speech.audioName || '';
      adminEditorialAudioFile = null;
      adminEditorialAudioDataUrl = subjects.editorial.audioDataUrl || '';
      adminEditorialAudioName = subjects.editorial.audioName || '';
      alert('진도 승급실 자료를 저장했습니다.');
      await loadMaterials();
      renderAdminMaterialSelect();
      renderStatus();
    } catch (error) {
      console.warn('진도 승급실 자료 서버 저장 실패:', error);
      try {
        const step = selectedAdminStep();
        await switchCourseForAdmin(step.courseKey);
        const level = Number(step.level || targetLevel || LEVELS[0]);
        renderAdminLevels(step.courseKey, level);
        const selectedId = $('unlockAdminMaterialSelect').value;
        const isNew = !selectedId || selectedId === '__new';
        const title = $('unlockAdminTitle').value.trim() || `${levelLabel(level)} 승급 자료`;
        if (!payload) {
          const existing = isNew ? null : findMaterial(selectedId);
          const speechExisting = materialSubject(existing, 'speech');
          const editorialExisting = materialSubject(existing, 'editorial');
          const subjects = {
            speech: buildSubjectPayload('speech', $('unlockAdminSourceText').value.trim(), { audioName: adminAudioName || speechExisting.audioName || '', audioDataUrl: adminAudioDataUrl || speechExisting.audioDataUrl || '', audioUrl: speechExisting.audioUrl || '', audioPath: speechExisting.audioPath || '', audioMime: speechExisting.audioMime || '' }),
            editorial: buildSubjectPayload('editorial', $('unlockAdminEditorialSourceText') ? $('unlockAdminEditorialSourceText').value.trim() : '', { audioName: adminEditorialAudioName || editorialExisting.audioName || '', audioDataUrl: adminEditorialAudioDataUrl || editorialExisting.audioDataUrl || '', audioUrl: editorialExisting.audioUrl || '', audioPath: editorialExisting.audioPath || '', audioMime: editorialExisting.audioMime || '' })
          };
          payload = { level, title, subjects, sourceText: subjects.speech.sourceText, audioName: subjects.speech.audioName, audioDataUrl: subjects.speech.audioDataUrl, audioUrl: subjects.speech.audioUrl, audioPath: subjects.speech.audioPath, audioMime: subjects.speech.audioMime, updatedAt: new Date().toISOString() };
        }
        const validationMessage = validateSubjectPayload(payload.subjects || {});
        if (validationMessage) return alert(validationMessage);
        saveUnlockMaterialLocal(level, title, payload, selectedId, isNew);
        alert(`서버 저장에 실패해 현재 브라우저에 임시 저장했습니다.
원인: ${error.message || error}`);
        await loadMaterials();
        renderAdminMaterialSelect();
        renderStatus();
      } catch (localError) {
        console.warn('진도 승급실 로컬 저장 실패:', localError);
        alert(`자료 저장에 실패했습니다.
${localError.message || localError}`);
      }
    } finally {
      if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = '저장/수정'; }
    }
  }
  async function deleteUnlockMaterial() {
    if (!isMaterialManager) return alert('진도 승급실 자료 삭제 권한이 없습니다.');
    const selectedId = $('unlockAdminMaterialSelect').value;
    if (!selectedId || selectedId === '__new') return alert('삭제할 자료를 선택하세요.');
    const item = findMaterial(selectedId);
    if (!item) return alert('자료를 찾을 수 없습니다.');
    if (!confirm(`'${item.title}' 진도 승급실 자료를 삭제하시겠습니까?`)) return;
    try {
      if (item.source === 'supabase' && item.rowId && window.SORIZAVA_SUPABASE) {
        const { error } = await window.SORIZAVA_SUPABASE.from('practice_materials').update({ is_active: false }).eq('id', item.rowId);
        if (error) throw error;
      } else {
        writeLocalMaterials(readLocalMaterials().filter(row => row.id !== item.id));
      }
      alert('진도 승급실 자료를 삭제했습니다.');
      await loadMaterials();
      renderAdminMaterialSelect();
      newUnlockMaterialForm();
      renderStatus();
    } catch (error) {
      console.warn(error);
      alert('자료 삭제에 실패했습니다.');
    }
  }
  function toggleUnlockAdminPanel(force) {
    if (!isMaterialManager) return alert('진도 승급실 자료 관리 권한이 없습니다.');
    const panel = $('unlockAdminPanel');
    const shouldShow = typeof force === 'boolean' ? force : panel.style.display === 'none';
    panel.style.display = shouldShow ? 'block' : 'none';
    if (shouldShow) {
      renderAdminLevels(COURSE.key, targetLevel || LEVELS[0]);
      renderAdminMaterialSelect();
      populateUnlockAdminForm($('unlockAdminMaterialSelect').value);
    }
  }
  async function init(context) {
    ctx = context || null;
    isStrictAdmin = hasStrictAdminAccess(ctx);
    isMaterialManager = hasMaterialManageAccess(ctx) || isStrictAdmin;
    syncShell();
    const queryCourse = isMaterialManager ? resolveCourseKeyFromQuery() : '';
    const profileCourse = inferCourseFromProfile(ctx);
    setCourse(profileCourse || queryCourse || 'intermediate');
    updateCourseUi();
    renderAdminLevels();
    renderCourseTabs();
    bindEvents();
    if (isMaterialManager && $('adminUnlockPanelToggle')) $('adminUnlockPanelToggle').style.display = 'inline-flex';
    await loadCreditLedger();
    await loadMaterials();
    await syncRemoteProgressLogs();
    if (!profileCourse && !queryCourse) {
      const recordCourse = inferCourseFromRecentRecords();
      if (recordCourse && recordCourse !== COURSE.key) {
        setCourse(recordCourse);
        updateCourseUi();
        renderAdminLevels();
        renderCourseTabs();
        await loadMaterials();
        await syncRemoteProgressLogs();
      }
    }
    await refreshAssignedMaterial();
    renderAdminMaterialSelect();
    newUnlockMaterialForm(false);
    renderStatus();
    const loading = $('loading-overlay');
    if (loading) loading.style.display = 'none';
  }
  function logout() {
    if (confirm('로그아웃 하시겠습니까?')) window.SorizavaAuth.signOut();
  }

  window.SorizavaUnlockRoom = { init };
  window.startUnlockChallenge = startUnlockChallenge;
  window.finishUnlockChallenge = finishUnlockChallenge;
  window.startNextSubjectNow = startNextSubjectNow;
  window.closeUnlockResult = closeUnlockResult;
  window.toggleUnlockAdminPanel = toggleUnlockAdminPanel;
  window.newUnlockMaterialForm = newUnlockMaterialForm;
  window.saveUnlockMaterial = saveUnlockMaterial;
  window.deleteUnlockMaterial = deleteUnlockMaterial;
  window.logout = logout;

  if (window.SorizavaAuth && window.SorizavaAuth.bootPage) {
    window.SorizavaAuth.bootPage(init);
  } else {
    document.addEventListener('DOMContentLoaded', () => init(null));
  }
})();
