function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.querySelector('.sidebar-overlay');
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
}

// [신규] 모드 전환 기능
function toggleMode() {
    const isChecked = document.getElementById('modeToggle').checked;
    const postSection = document.getElementById('postEditSection');
    const lblPre = document.getElementById('lblPre');
    
    if (isChecked) {
        postSection.classList.add('active');
        lblPre.innerText = "✍️ 내 입력 (초안)"; // 번문 모드 시 '초안'으로 명시
    } else {
        postSection.classList.remove('active');
        lblPre.innerText = "✍️ 내 입력"; // 일반 모드 시 그냥 '내 입력'
        document.getElementById('studentPost').value = ""; // 끄면 내용 초기화 (선택사항)
    }
}

let currentUser = sessionStorage.getItem('shorthand_user');
let scoreHistory = [];
let fullHistoryRaw = [];
let myChart = null;
let currentErrorItems = []; 
let currentTypoOnlyItems = []; 

function escapeHtml(str) {
    return String(str ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

function toHtmlChar(ch) {
    if (ch === " ") return "&nbsp;";
    return escapeHtml(ch);
}


function updateToksoriTextCounts() {
    const targets = [
        ['original', 'originalCount'],
        ['studentPre', 'studentPreCount'],
        ['studentPost', 'studentPostCount']
    ];

    targets.forEach(([textareaId, counterId]) => {
        const textarea = document.getElementById(textareaId);
        const counter = document.getElementById(counterId);
        if (!textarea || !counter) return;
        counter.textContent = `${textarea.value.length.toLocaleString()}자`;
    });
}

function setupToksoriTextCounters() {
    ['original', 'studentPre', 'studentPost'].forEach((textareaId) => {
        const textarea = document.getElementById(textareaId);
        if (!textarea) return;
        textarea.addEventListener('input', updateToksoriTextCounts);
    });
    updateToksoriTextCounts();
}

function initApp() {
    currentUser = sessionStorage.getItem('shorthand_user');
    if (!currentUser) {
        alert("로그인을 먼저 해주세요! 🙅‍♀️");
        location.href = 'index.html'; 
        return;
    }
    const welcomeHTML = `👋 <b>${escapeHtml(currentUser)}</b>님 환영합니다!`;
    document.getElementById('welcomeMsg').innerHTML = welcomeHTML;
    if(document.getElementById('sideUserName')) document.getElementById('sideUserName').innerText = currentUser;
    
    setupDragAndDrop('original');
    setupDragAndDrop('studentPre');
    setupDragAndDrop('studentPost');
    setupToksoriTextCounters();
    initAudioPlayer();
    fetchData();
}

// 오디오 플레이어 로직
const audio = document.getElementById('audioPlayer');
const playBtn = document.getElementById('playBtn');
const progressBar = document.getElementById('audioProgress');
const timeDisplay = document.getElementById('timeDisplay');
function initAudioPlayer() {
    setAudioSpeed(document.getElementById('speedRate')?.value || 1.0);
    audio.addEventListener('timeupdate', () => {
        if (!isNaN(audio.duration)) {
            progressBar.value = (audio.currentTime / audio.duration) * 100;
            updateTimeDisplay();
        }
    });
    audio.addEventListener('loadedmetadata', () => { updateTimeDisplay(); playBtn.disabled = false; });
    audio.addEventListener('ended', () => { playBtn.innerText = "▶"; progressBar.value = 0; });
}

function loadAudioFile(input) {
    const file = input.files[0];
    if (file) {
        const fileURL = URL.createObjectURL(file);
        audio.src = fileURL;
        playBtn.innerText = "▶";
        playBtn.disabled = false;
    }
}

function toggleAudio() {
    if (audio.paused) { audio.play(); playBtn.innerText = "⏸"; } 
    else { audio.pause(); playBtn.innerText = "▶"; }
}

const MIN_AUDIO_RATE = 0.5;
const MAX_AUDIO_RATE = 2.0;

function normalizeAudioRate(value) {
    const numeric = Number.parseFloat(value);
    const safeValue = Number.isFinite(numeric) ? numeric : 1.0;
    const steppedValue = Math.round(safeValue * 10) / 10;
    return Math.min(MAX_AUDIO_RATE, Math.max(MIN_AUDIO_RATE, steppedValue));
}

function setAudioSpeed(value) {
    const speedInput = document.getElementById('speedRate');
    const normalizedRate = normalizeAudioRate(value);
    if (speedInput) speedInput.value = normalizedRate.toFixed(1);
    if (audio) audio.playbackRate = normalizedRate;
}

function changeSpeed() {
    const speedInput = document.getElementById('speedRate');
    setAudioSpeed(speedInput ? speedInput.value : 1.0);
}

function adjustAudioSpeed(delta) {
    const speedInput = document.getElementById('speedRate');
    const currentRate = speedInput ? Number.parseFloat(speedInput.value) : 1.0;
    setAudioSpeed((Number.isFinite(currentRate) ? currentRate : 1.0) + delta);
}
function seekAudio() { audio.currentTime = (progressBar.value / 100) * audio.duration; }
function updateTimeDisplay() {
    const format = (t) => {
        const m = Math.floor(t / 60).toString().padStart(2, '0');
        const s = Math.floor(t % 60).toString().padStart(2, '0');
        return `${m}:${s}`;
    };
    timeDisplay.innerText = `${format(audio.currentTime)} / ${format(audio.duration || 0)}`;
}

async function fetchData() {
    try {
        const { data, error } = await window.SORIZAVA_SUPABASE
            .from('practice_records')
            .select('*')
            .eq('tool_type', 'toksori2')
            .order('created_at', { ascending: true })
            .limit(500);
        if (error) throw error;
        fullHistoryRaw = (data || []).map(r => ({
            date: new Date(r.created_at).toISOString().slice(0,10),
            title: r.practice_title || '-',
            score: Number(r.score ?? r.accuracy ?? 0),
            w: r.wrong_count || 0,
            mi: r.missing_count || 0,
            ad: r.added_count || 0,
            n: r.original_length || 0
        }));
        const ignoredCount = parseInt(localStorage.getItem('ignoredHistoryCount') || '0');
        scoreHistory = fullHistoryRaw.slice(ignoredCount);
        updateHistoryUI();
        updateChart();
        checkAttendance(scoreHistory);
    } catch(e) { console.log('기록 로딩 실패', e); }
}


function updateKingRanking(allHistory) {
    const kingListEl = document.getElementById('kingList');
    if (!allHistory || allHistory.length === 0) { kingListEl.innerHTML = "연습을 시작해 1등이 되어보세요! 🏆"; return; }
    const totals = {};
    allHistory.forEach(h => { totals[h.name] = (totals[h.name] || 0) + Number(h.charCount || 0); });
    const sorted = Object.entries(totals).sort((a, b) => b[1] - a[1]).slice(0, 3);
    kingListEl.innerHTML = sorted.map((s, idx) => {
        let style = (idx === 0) ? "background:var(--gold); border:1px solid white;" : "";
        return `<div class="ranking-item" style="${style}">${idx+1}등 ${escapeHtml(s[0])}</div>`;
    }).join('');
}


function isScorableToksoriChar(char) {
    // 한글 음절뿐 아니라 ㄱ, ㄴ, ㄷ 같은 한글 자모도 실제 입력 문자로 보아 채점에 포함합니다.
    // 공백·문장부호는 채점 기준에서 제외합니다.
    return /[0-9a-zA-Z\uAC00-\uD7A3\u3130-\u318F\u1100-\u11FF]/.test(char);
}

function countScorableToksoriChars(text) {
    return Array.from(String(text || '')).filter(isScorableToksoriChar).length;
}

function isToksoriSpecialChar(char) {
    return !isScorableToksoriChar(char);
}

function getToksoriEojeolContext(text, charIndex, radius = 1) {
    const source = String(text || '');
    const tokens = [];
    const regex = /\S+/g;
    let match;

    while ((match = regex.exec(source)) !== null) {
        tokens.push({
            text: match[0],
            start: match.index,
            end: match.index + match[0].length
        });
    }

    if (tokens.length === 0) return '';

    let tokenIndex = tokens.findIndex(token => charIndex >= token.start && charIndex < token.end);

    if (tokenIndex < 0) {
        tokenIndex = tokens.findIndex(token => token.start > charIndex);
        if (tokenIndex < 0) tokenIndex = tokens.length - 1;
    }

    const start = Math.max(0, tokenIndex - radius);
    const end = Math.min(tokens.length, tokenIndex + radius + 1);
    return tokens.slice(start, end).map(token => token.text).join(' ');
}

function buildToksoriTypoContextItems(diffs, rawOriginal, rawStudent) {
    const typoItems = [];
    let originalIndex = 0;
    let studentIndex = 0;
    let missingBuffer = [];
    let addedBuffer = [];

    function flushTypoBuffer() {
        let missingIndex = 0;
        let addedIndex = 0;

        while (missingIndex < missingBuffer.length || addedIndex < addedBuffer.length) {
            const missingItem = missingBuffer[missingIndex];
            const addedItem = addedBuffer[addedIndex];

            if (missingItem && isToksoriSpecialChar(missingItem.c)) {
                missingIndex++;
                continue;
            }

            if (addedItem && isToksoriSpecialChar(addedItem.c)) {
                addedIndex++;
                continue;
            }

            // 원문 글자 1개와 입력 글자 1개가 서로 대체된 경우만 오자로 기록합니다.
            // 탈자만 있거나 첨자만 있는 경우는 오답노트에서 제외합니다.
            if (missingItem && addedItem) {
                typoItems.push({
                    type: 'wrong',
                    correct: missingItem.c,
                    wrong: addedItem.c,
                    correctContext: getToksoriEojeolContext(rawOriginal, missingItem.index, 1),
                    wrongContext: getToksoriEojeolContext(rawStudent, addedItem.index, 1)
                });
                missingIndex++;
                addedIndex++;
                continue;
            }

            if (missingItem) {
                missingIndex++;
                continue;
            }

            if (addedItem) {
                addedIndex++;
                continue;
            }
        }

        missingBuffer = [];
        addedBuffer = [];
    }

    diffs.forEach(item => {
        if (item.t === 'same') {
            flushTypoBuffer();
            originalIndex++;
            studentIndex++;
            return;
        }

        if (item.t === 'missing') {
            missingBuffer.push({ c: item.c, index: originalIndex });
            originalIndex++;
            return;
        }

        if (item.t === 'added') {
            addedBuffer.push({ c: item.c, index: studentIndex });
            studentIndex++;
        }
    });

    flushTypoBuffer();

    return typoItems;
}

function clearAllInputs() {
    if(confirm("작성 중인 내용을 모두 지울까요?")) {
        document.getElementById('original').value = "";
        document.getElementById('studentPre').value = "";
        document.getElementById('studentPost').value = "";
        updateToksoriTextCounts();
    }
}

// [신규] '번문 후' 정밀 채점 함수 (점수 계산용)
function getExactStats(rawO, rawS) {
    const isSpecial = isToksoriSpecialChar;
    let pureLength = countScorableToksoriChars(rawO);
    if (pureLength === 0) pureLength = 1;

    let oArr = rawO.trim().split('');
    let sArr = rawS.trim().split('');
    let n = oArr.length, m = sArr.length;
    let dp = Array.from(Array(n + 1), () => Array(m + 1).fill(0));
    for (let i = 1; i <= n; i++) {
        for (let j = 1; j <= m; j++) {
            if (oArr[i-1] === sArr[j-1]) dp[i][j] = dp[i-1][j-1] + 1;
            else dp[i][j] = Math.max(dp[i-1][j], dp[i][j-1]);
        }
    }
    let i = n, j = m, diffs = [];
    while (i > 0 || j > 0) {
        if (i > 0 && j > 0 && oArr[i-1] === sArr[j-1]) { diffs.push({ t: 'same', c: oArr[i-1] }); i--; j--; } 
        else if (j > 0 && (i === 0 || dp[i][j-1] >= dp[i-1][j])) { diffs.push({ t: 'added', c: sArr[j-1] }); j--; } 
        else { diffs.push({ t: 'missing', c: oArr[i-1] }); i--; }
    }
    diffs.reverse();

    let w=0, mi=0, ad=0;
    let mBuffer = [], aBuffer = []; 
    
    function flush() {
        let mIdx = 0, aIdx = 0;
        while (mIdx < mBuffer.length || aIdx < aBuffer.length) {
            let mChar = mBuffer[mIdx], aChar = aBuffer[aIdx];
            if (mIdx < mBuffer.length && isSpecial(mChar)) { mIdx++; continue; }
            if (aIdx < aBuffer.length && isSpecial(aChar)) { aIdx++; continue; }
            if (mIdx < mBuffer.length && aIdx < aBuffer.length) { w++; mIdx++; aIdx++; continue; }
            if (mIdx < mBuffer.length) { mi++; mIdx++; continue; }
            if (aIdx < aBuffer.length) { ad++; aIdx++; continue; }
        }
        mBuffer = []; aBuffer = [];
    }

    for (let k = 0; k < diffs.length; k++) {
        if (diffs[k].t === 'same') { flush(); }
        else if (diffs[k].t === 'missing') { mBuffer.push(diffs[k].c); }
        else if (diffs[k].t === 'added') { aBuffer.push(diffs[k].c); }
    }
    flush();

    let adPenalty = Math.floor(ad / 3);
    let score = Math.max(0, 100 - ((w + mi + adPenalty) / pureLength * 100)).toFixed(1);
    return { score, w, mi, ad, totalErr: w + mi + ad };
}

// [핵심 로직] 통합 분석 함수 (수정됨: 번문 비교 결과 UI 추가)
function analyzeAndGrade() {
    let rawO = document.getElementById('original').value;
    let rawS = document.getElementById('studentPre').value; 
    let rawPost = document.getElementById('studentPost').value;
    const isModeOn = document.getElementById('modeToggle').checked;

    if(!rawO.trim()) { alert("정답(원본)을 입력해주세요."); return; }
    if(!rawS.trim()) { alert("내 입력 내용을 입력해주세요."); return; }

    const isSpecial = isToksoriSpecialChar;
    let pureLength = countScorableToksoriChars(rawO);
    if(pureLength === 0) pureLength = 1;

    // 1. 기본 채점 (초안 기준) - 기존 로직 유지 (시각화용)
    let oArr = rawO.trim().split('');
    let sArr = rawS.trim().split('');
    let n = oArr.length;
    let m = sArr.length;
    
    let dp = Array.from(Array(n + 1), () => Array(m + 1).fill(0));
    for (let i = 1; i <= n; i++) {
        for (let j = 1; j <= m; j++) {
            if (oArr[i-1] === sArr[j-1]) dp[i][j] = dp[i-1][j-1] + 1;
            else dp[i][j] = Math.max(dp[i-1][j], dp[i][j-1]);
        }
    }

    let i = n, j = m, diffs = [];
    while (i > 0 || j > 0) {
        if (i > 0 && j > 0 && oArr[i-1] === sArr[j-1]) { diffs.push({ t: 'same', c: oArr[i-1] }); i--; j--; } 
        else if (j > 0 && (i === 0 || dp[i][j-1] >= dp[i-1][j])) { diffs.push({ t: 'added', c: sArr[j-1] }); j--; } 
        else { diffs.push({ t: 'missing', c: oArr[i-1] }); i--; }
    }
    diffs.reverse();
    currentTypoOnlyItems = buildToksoriTypoContextItems(diffs, rawO.trim(), rawS.trim());

    let html = "", w=0, mi=0, ad=0;
    let mBuffer = [], aBuffer = []; 
    currentErrorItems = [];
    let wordO = "", wordS = "", isWordDirty = false;

    function commitWord() {
        if (isWordDirty && (wordO.trim() || wordS.trim())) {
            currentErrorItems.push({ type: (wordS.trim() === "") ? 'missing' : 'wrong', correct: wordO, wrong: wordS });
        }
        wordO = ""; wordS = ""; isWordDirty = false;
    }

    function flushBuffer() {
        let mIdx = 0, aIdx = 0;
        while (mIdx < mBuffer.length || aIdx < aBuffer.length) {
            let mChar = mBuffer[mIdx];
            let aChar = aBuffer[aIdx];

            if (mIdx < mBuffer.length && isSpecial(mChar)) { 
                html += `<span>${toHtmlChar(mChar)}</span>`;
                wordO += mChar; wordS += mChar; mIdx++; continue;
            }
            if (aIdx < aBuffer.length && isSpecial(aChar)) { 
                html += `<span style=\"color:#ccc;\">${toHtmlChar(aChar)}</span>`;
                wordS += aChar; aIdx++; continue; 
            }
            if (mIdx < mBuffer.length && aIdx < aBuffer.length) { 
                html += `<span class=\"d-wrong\">${toHtmlChar(aChar)}<span class=\"correction\">${toHtmlChar(mChar)}</span></span>`;
                wordO += mChar; wordS += aChar; isWordDirty = true; w++; mIdx++; aIdx++; continue;
            }
            if (mIdx < mBuffer.length) { 
                html += `<span class=\"d-missing\">${toHtmlChar(mChar)}</span>`;
                wordO += mChar; isWordDirty = true; mi++; mIdx++; continue;
            }
            if (aIdx < aBuffer.length) { 
                html += `<span class=\"d-added\">${toHtmlChar(aChar)}</span>`;
                wordS += aChar; isWordDirty = true; ad++; aIdx++; continue;
            }
        }
        mBuffer = []; aBuffer = [];
    }

    for (let k = 0; k < diffs.length; k++) {
        let item = diffs[k];
        if (item.t === 'same') { 
            flushBuffer();
            if (item.c === ' ' || item.c === '\n') {
                commitWord();
                html += (item.c === ' ') ? '<span>&nbsp;</span>' : '<br>';
            } else {
                html += `<span>${toHtmlChar(item.c)}</span>`;
                wordO += item.c; wordS += item.c;
            }
        } 
        else if (item.t === 'missing') { mBuffer.push(item.c); } 
        else if (item.t === 'added') { aBuffer.push(item.c); }
    }
    flushBuffer(); commitWord(); 

    let adPenalty = Math.floor(ad / 3);
    let calcN = pureLength > 0 ? pureLength : 1;
    let scorePre = Math.max(0, 100 - ((w + mi + adPenalty) / calcN * 100)).toFixed(1);
    const fName = document.getElementById('fileName').value.trim() || "미지정";

    // 2. 결과 표시 UI 제어 (번문 모드 여부에 따라 분기)
    const scoreBox = document.getElementById('finalScore').parentElement;
    
    // 번문 모드이고, 번문 내용이 있다면 '비교 뷰' 생성
    if (isModeOn && rawPost.trim()) {
        const postStats = getExactStats(rawO, rawPost); // 번문 후 정밀 계산
        const scorePost = postStats.score;
        const scoreDiff = (scorePost - scorePre).toFixed(1);
        
        // 상세 증감 계산
        const wDiff = postStats.w - w;
        const miDiff = postStats.mi - mi;
        const adDiff = postStats.ad - ad;
        const getSign = (n) => n > 0 ? `+${n}` : `${n}`;
        const getColor = (n) => n < 0 ? '#00B894' : (n > 0 ? '#FF7675' : '#888'); // 에러는 줄어야(-) 초록색

        // UI 덮어쓰기 (비교 모드)
        scoreBox.innerHTML = `
            <div style="display:flex; justify-content:center; align-items:center; gap:15px; margin-bottom:15px;">
                <div style="text-align:center; opacity:0.6;">
                    <div style="font-size:0.9rem; margin-bottom:5px;">초안</div>
                    <div style="font-size:2.2rem; font-weight:bold; color:#555;">${scorePre}</div>
                </div>
                <div style="font-size:1.5rem; color:#ccc;">▶</div>
                <div style="text-align:center;">
                    <div style="font-size:0.9rem; margin-bottom:5px; color:var(--primary); font-weight:bold;">번문 후</div>
                    <div style="font-size:3rem; font-weight:900; color:var(--primary);">${scorePost}</div>
                </div>
            </div>
            <div style="background:white; border:1px solid #eee; border-radius:12px; padding:15px; font-size:0.9rem; text-align:left;">
                <div style="display:flex; justify-content:space-between; margin-bottom:8px; border-bottom:1px dashed #eee; padding-bottom:8px;">
                    <span style="font-weight:bold;">📈 점수 변화</span>
                    <span style="font-weight:bold; color:${scoreDiff >= 0 ? '#00B894' : '#FF7675'}">
                        ${scoreDiff > 0 ? '+' : ''}${scoreDiff}점
                    </span>
                </div>
                <div style="display:flex; justify-content:space-between; margin-bottom:5px;">
                    <span>❌ 오자</span>
                    <span>${w}개 ➡ <b>${postStats.w}개</b> <span style="font-size:0.8em; color:${getColor(wDiff)}">(${getSign(wDiff)})</span></span>
                </div>
                <div style="display:flex; justify-content:space-between; margin-bottom:5px;">
                    <span>🕳️ 탈자</span>
                    <span>${mi}개 ➡ <b>${postStats.mi}개</b> <span style="font-size:0.8em; color:${getColor(miDiff)}">(${getSign(miDiff)})</span></span>
                </div>
                <div style="display:flex; justify-content:space-between;">
                    <span>➕ 첨자</span>
                    <span>${ad}개 ➡ <b>${postStats.ad}개</b> <span style="font-size:0.8em; color:${getColor(adDiff)}">(${getSign(adDiff)})</span></span>
                </div>
            </div>
        `;
    } else {
        // 일반 모드 (기존 UI 복원)
        scoreBox.innerHTML = `
            <div style="color:#888; margin-bottom:5px;">정확도 (초안)</div>
            <div id="finalScore" style="font-size:4rem; font-weight:900; color:var(--primary);">${scorePre}</div>
            <div id="scoreDesc" style="font-weight:600; color:#555;">총 글자: ${pureLength} / 오자: ${w} / 탈자: ${mi} / 첨자: ${ad}</div>
        `;
        analyzeGrowth(scorePre, w + mi + ad, fName);
    }

    document.getElementById('diffOutput').innerHTML = html;
    const detailPanel = document.querySelector('.result-detail-panel');
    if (detailPanel) detailPanel.setAttribute('open', 'open');

    // 오답노트 등 나머지 기능 실행
    renderErrorNote();
    document.getElementById('result').style.display = 'block';

    // 서버 전송 (초안 점수 기준 기록 유지 - 히스토리 관리용)
    sendDataToServer(scorePre, w, mi, ad, fName, pureLength, rawO, rawS);

    // 3. 번문 정밀 분석 시각화 (하이라이트)
    if (isModeOn && rawPost.trim()) {
        document.getElementById('review-box').style.display = 'block';
        generateCorrectionHighlight(rawO, rawS, rawPost);
        // 성장 분석 박스는 비교 뷰가 있으므로 숨김 처리 (중복 정보 방지)
        document.getElementById('growthBox').style.display = 'none';
    } else {
        document.getElementById('review-box').style.display = 'none';
    }
}

// [신규] 번문 정밀 분석 로직 함수
function generateCorrectionHighlight(txtOriginal, txtPre, txtPost) {
    const cleanO = txtOriginal.replace(/\s+/g, ' ').trim();
    const sOrigin = txtOriginal.trim().split('');
    const sPre = txtPre.trim().split('');
    const sPost = txtPost.trim().split('');
    const getDiff = (arr1, arr2) => {
        let dp = Array.from(Array(arr1.length + 1), () => Array(arr2.length + 1).fill(0));
        for (let i = 1; i <= arr1.length; i++) {
            for (let j = 1; j <= arr2.length; j++) {
                if (arr1[i-1] === arr2[j-1]) dp[i][j] = dp[i-1][j-1] + 1;
                else dp[i][j] = Math.max(dp[i-1][j], dp[i][j-1]);
            }
        }
        let i = arr1.length, j = arr2.length;
        let diff = [];
        while (i > 0 || j > 0) {
            if (i > 0 && j > 0 && arr1[i-1] === arr2[j-1]) { diff.push({ t: 'same', c: arr1[i-1] }); i--; j--; }
            else if (j > 0 && (i === 0 || dp[i][j-1] >= dp[i-1][j])) { diff.push({ t: 'added', c: arr2[j-1] }); j--; }
            else { diff.push({ t: 'missing', c: arr1[i-1] }); i--; }
        }
        return diff.reverse();
    };

    const diffPrePost = getDiff(sPre, sPost);
    let postMeta = [];
    let delQueue = [];
    diffPrePost.forEach(ch => {
        if (ch.t === 'same') { delQueue = []; postMeta.push({ isNew: false, deletedFromPre: "" }); }
        else if (ch.t === 'missing') { delQueue.push(ch.c); }
        else if (ch.t === 'added') { let matchedDel = delQueue.shift() || ""; postMeta.push({ isNew: true, deletedFromPre: matchedDel }); }
    });

    const diffOrigPost = getDiff(sOrigin, sPost);
    let html = "";
    let postIdx = 0; let missingBuffer = "";

    const flushMissing = () => {
        if (!missingBuffer) return;
        for (let char of missingBuffer) {
            if (char === '\n') html += '<br>';
            else if (char === ' ') html += '<span>&nbsp;</span>'; 
            else html += `<span class="hl-omitted">${escapeHtml(char)}</span>`;
        }
        missingBuffer = "";
    };
    diffOrigPost.forEach(ch => {
        if (ch.t === 'same') {
            flushMissing();
            let displayChar = (ch.c === '\n') ? '<br>' : `<span>${toHtmlChar(ch.c)}</span>`;
            let meta = postMeta[postIdx] || { isNew: false };
            if (meta.isNew) {
                if (!/^\s$/.test(ch.c)) html += `<span class="hl-success">${toHtmlChar(ch.c)}</span>`;
                else html += displayChar;
            } else {
                html += displayChar;
            }
            postIdx++;
        } else if (ch.t === 'missing') {
            missingBuffer += ch.c;
        } else if (ch.t === 'added') {
            let targetChar = ch.c;
            let displayChar = toHtmlChar(targetChar);
            if (targetChar === '\n') displayChar = '<br>';
            if (/^\s$/.test(targetChar)) {
                html += displayChar;
            } else {
                let meta = postMeta[postIdx] || { isNew: true, deletedFromPre: "" };
                if (meta.isNew) {
                    let deletedText = meta.deletedFromPre.trim();
                    if (deletedText.length > 0 && cleanO.includes(deletedText)) { html += `<span class="hl-bad">${displayChar}</span>`; } 
                    else if (deletedText.length === 0) { html += `<span class="hl-bad">${displayChar}</span>`; }
                    else { html += `<span class="hl-warning">${displayChar}</span>`; }
                } else {
                    html += `<span class="hl-missed">${displayChar}</span>`;
                }
            }
            missingBuffer = "";
            postIdx++;
        }
    });
    flushMissing();
    document.getElementById('reviewContent').innerHTML = html;
}

function getWrongOnlyErrorItems() {
    // 오답노트는 '오자'만 표시합니다.
    // 표시는 오자가 난 글자만 단독으로 보여주지 않고, 오자 어절 기준 앞뒤 1어절까지 함께 보여줍니다.
    const seen = new Set();
    const result = [];

    currentTypoOnlyItems.forEach(e => {
        if (
            e.type !== 'wrong' ||
            String(e.correct || '').trim().length === 0 ||
            String(e.wrong || '').trim().length === 0
        ) return;

        const item = {
            ...e,
            correctContext: String(e.correctContext || e.correct || '').trim(),
            wrongContext: String(e.wrongContext || e.wrong || '').trim()
        };

        const key = `${item.correctContext}::${item.wrongContext}`;
        if (seen.has(key)) return;
        seen.add(key);
        result.push(item);
    });

    return result;
}

function renderErrorNote() {
    const area = document.getElementById('errorNoteArea');
    const list = document.getElementById('errorList');
    const icon = document.getElementById('errorToggleIcon');
    const validErrors = getWrongOnlyErrorItems();

    // 오답노트는 오자만 노출합니다. 탈자·첨자는 채점 결과에는 반영하되 오답노트에서는 제외합니다.
    if (validErrors.length === 0) {
        area.style.display = 'none';
        list.innerHTML = '';
        return;
    }

    list.innerHTML = validErrors.map(e => `
        <div class="error-item-row">
            <span style="background:#FF7675; color:white; padding:2px 6px; border-radius:4px; font-size:0.8rem; margin-right:5px;">오자</span>
            <span style="color:#FF7675; text-decoration:line-through; margin-right:5px;">${escapeHtml(e.wrongContext)}</span>
            <span style="color:#6C5CE7; font-weight:bold;">➡ ${escapeHtml(e.correctContext)}</span>
        </div>
    `).join('');

    area.style.display = 'block';
    list.style.display = 'none';
    icon.innerText = `▼ (오자 ${validErrors.length}개 - 클릭해서 펼치기)`;
}

function toggleErrorList() {
    const list = document.getElementById('errorList');
    const icon = document.getElementById('errorToggleIcon');
    if (list.style.display === 'none') {
        list.style.display = 'block';
        icon.innerText = '▲ (접기)';
    } else {
        list.style.display = 'none';
        const count = getWrongOnlyErrorItems().length;
        icon.innerText = `▼ (오자 ${count}개 - 클릭해서 펼치기)`;
    }
}

function saveErrorNote() {
    const wrongOnlyItems = getWrongOnlyErrorItems();
    if (wrongOnlyItems.length === 0) {
        alert("저장할 오자가 없습니다.");
        return;
    }

    const fName = document.getElementById('fileName').value.trim() || "연습";
    const today = new Date().toISOString().slice(0, 10);
    let content = `[${today}] ${fName} - 오답 노트 (오자만)\n\n`;
    content += wrongOnlyItems.map((e, i) =>
        `${i+1}. [오자] 입력: '${e.wrongContext}' -> 정답: '${e.correctContext}'`
    ).join('\n');

    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `${fName}_오답노트_${today}.txt`;
    link.click();
}

function analyzeGrowth(currentScore, currentErrors, fileName) {
    const box = document.getElementById('growthBox');
    if (!fileName || fileName === "미지정") { box.style.display = 'none'; return; }
    const prevRecords = fullHistoryRaw.filter(h => h.title === fileName);
    if (prevRecords.length === 0) {
        box.innerHTML = `<div class="growth-title">🌱 첫 응시네요!</div><div>'${escapeHtml(fileName)}' 파일의 첫 기록이 생성됩니다. 기준 기록을 잘 만들어보세요!</div>`;
        box.style.display = 'block';
    } else {
        const last = prevRecords[prevRecords.length - 1];
        const lastScore = parseFloat(last.score);
        const lastErrors = parseInt(last.w) + parseInt(last.mi) + parseInt(last.ad);
        const cScore = parseFloat(currentScore);
        const scoreDiff = (cScore - lastScore).toFixed(1);
        const errDiff = lastErrors - currentErrors;
        let msg = `<div class="growth-title">🆚 '${escapeHtml(fileName)}' 성장 분석</div>`;
        if (cScore > lastScore) msg += `<div style="margin-bottom:5px;">🚀 점수가 <span style="color:#00B894; font-weight:bold;">+${scoreDiff}점</span> 올랐어요! (직전: ${lastScore}점)</div>`;
        else if (cScore < lastScore) msg += `<div style="margin-bottom:5px;">📉 점수가 <span style="color:#FF7675; font-weight:bold;">${scoreDiff}점</span> 떨어졌어요. 다시 집중해봐요! (직전: ${lastScore}점)</div>`;
        else msg += `<div style="margin-bottom:5px;">⚖️ 지난번과 점수가 똑같아요. (${lastScore}점)</div>`;
        
        if (errDiff > 0) msg += `<div>✨ 와우! 전체 실수(오/탈/첨)가 <span style="color:#00B894; font-weight:bold;">${errDiff}개</span> 줄었어요!</div>`;
        else if (errDiff < 0) msg += `<div>⚠️ 실수가 지난번보다 <span style="color:#FF7675; font-weight:bold;">${Math.abs(errDiff)}개</span> 늘어났어요.</div>`;
        box.innerHTML = msg; box.style.display = 'block';
    }
}

async function sendDataToServer(score, w, mi, ad, title, n, sourceText = "", typedText = "") {
    const scoreNum = parseFloat(score);
    const today = new Date().toISOString().split('T')[0];
    const prevMax = Math.max(0, ...scoreHistory.map(h => parseFloat(h.score) || 0));
    scoreHistory.push({ date: today, title: title, score: scoreNum, w: w, mi: mi, ad: ad, n: n });
    fullHistoryRaw.push({ date: today, title: title, score: scoreNum, w: w, mi: mi, ad: ad, n: n });

    const recordMsg = document.getElementById("recordMsg");
    if (recordMsg && scoreNum > prevMax) {
        recordMsg.innerHTML = `🏅 <b>신기록!</b> 최고 정확도 ${scoreNum}% 달성`;
        recordMsg.style.display = "block";
        clearTimeout(window.__toksoriRecordToastTimer);
        window.__toksoriRecordToastTimer = setTimeout(() => {
            recordMsg.style.display = "none";
            recordMsg.innerHTML = "";
        }, 2500);
    }
    const streakMsg = document.getElementById("streakMsg");
    if (streakMsg) {
        const target = 95;
        streakMsg.innerHTML = (scoreNum >= target) ?
        `✅ <b>목표 달성</b> (${target}%)` : `📌 목표 ${target}%까지 ${Math.max(0, (target - scoreNum)).toFixed(1)}% 남음`;
        streakMsg.style.display = "block";
        clearTimeout(window.__toksoriStreakToastTimer);
        window.__toksoriStreakToastTimer = setTimeout(() => {
            streakMsg.style.display = "none";
            streakMsg.innerHTML = "";
        }, 2500);
    }
    await window.SorizavaRecords.savePracticeRecord({
        tool_type: 'toksori2',
        practice_title: title,
        original_length: n,
        typed_length: n,
        accuracy: scoreNum,
        score: scoreNum,
        wrong_count: w,
        missing_count: mi,
        added_count: ad,
        source_text_snapshot: String(sourceText || '').slice(0, 12000),
        typed_text_snapshot: String(typedText || '').slice(0, 12000),
        diff_summary: (currentErrorItems || []).slice(0, 20).map(item => `${item.type || 'wrong'}:${item.correct || ''}->${item.wrong || ''}`).join(' / '),
        memo: '똑소리2 자동 저장'
    });
    updateHistoryUI();
    updateChart();
}


function updateHistoryUI() {
    const list = document.getElementById('historyList');
    list.innerHTML = scoreHistory.slice(-10).reverse().map(item => `
        <div style="padding:15px; border-bottom:1px solid #eee;">
            <div style="display:flex; justify-content:space-between; font-weight:bold; margin-bottom:5px;">
                <span>📅 ${item.date} [${escapeHtml(item.title)}]</span>
                <span style="color:var(--primary);">${item.score}%</span>
            </div>
            <div style="font-size:0.8rem; color:#888;">
                📍 글자: ${item.n} | ❌ 오자: ${item.w} | 🕳️ 탈자: ${item.mi} | ➕ 첨자: ${item.ad}
            </div>
        </div>
    `).join('');
}

function updateChart() {
    const ctx = document.getElementById('scoreChart').getContext('2d');
    if(myChart) myChart.destroy();
    myChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: scoreHistory.slice(-15).map((_, i) => (i+1) + "회"),
            datasets: [{ 
                label: '정확도 (%)', 
                data: scoreHistory.slice(-15).map(i => parseFloat(i.score)), 
                borderColor: '#6C5CE7', tension: 0.3, fill: true, backgroundColor: 'rgba(108, 92, 231, 0.1)' 
            }]
        },
        options: { responsive: true, maintainAspectRatio: false }
    });
}

function hideToksoriToast(elementId, timerKey, delay = 2500) {
    const el = document.getElementById(elementId);
    if (!el) return;
    clearTimeout(window[timerKey]);
    window[timerKey] = setTimeout(() => {
        el.style.display = 'none';
        el.innerHTML = '';
    }, delay);
}

function checkAttendance(history) {
    if(!history || history.length === 0) return;
    const dates = [...new Set(history.map(h => h.date))].sort().reverse();
    if(dates.length > 1) {
        const msg = document.getElementById('streakMsg');
        if (!msg) return;
        msg.innerHTML = `🔥 <b>꾸준함의 승리!</b> 연속으로 연습을 이어가고 있습니다!`;
        msg.style.display = 'block';
        hideToksoriToast('streakMsg', '__toksoriAttendanceToastTimer', 2500);
    }
}

function logout() { if(confirm("로그아웃 하시겠습니까?")) window.SorizavaAuth.signOut(); }

function clearHistoryView() {
    if(confirm("기록을 초기화하시겠습니까?")) {
        localStorage.setItem('ignoredHistoryCount', fullHistoryRaw.length);
        scoreHistory = []; updateHistoryUI(); updateChart(); alert("초기화되었습니다! ✨");
    }
}

function closeReport() { document.getElementById('overlay').style.display = 'none'; document.getElementById('report-modal').style.display = 'none'; }
function generateReport() {
    if (!scoreHistory || scoreHistory.length === 0) { alert("분석할 연습 기록이 없습니다. 먼저 연습을 진행해 주세요!"); return; }
    const now = new Date();
    const thisMonth = now.getMonth(); const thisYear = now.getFullYear();
    const monthlyData = scoreHistory.filter(h => { const hDate = new Date(h.date); return hDate.getMonth() === thisMonth && hDate.getFullYear() === thisYear; });
    if (monthlyData.length === 0) { alert("이번 달 기록된 데이터가 없습니다."); return; }

    const totalSessions = monthlyData.length;
    const avgScore = (monthlyData.reduce((acc, cur) => acc + parseFloat(cur.score), 0) / totalSessions).toFixed(1);
    const totalChars = monthlyData.reduce((acc, cur) => acc + parseInt(cur.n || 0), 0);
    const maxScore = Math.max(...monthlyData.map(h => parseFloat(h.score)));
    const reportHtml = `
        <div style="background:#F0F4F8; padding:15px; border-radius:10px; border-left:5px solid var(--primary); margin-bottom:15px;">
            <p style="margin:5px 0;">📊 <b>총 연습 횟수:</b> ${totalSessions}회</p>
            <p style="margin:5px 0;">🎯 <b>평균 정확도:</b> <span style="color:var(--primary); font-weight:bold;">${avgScore}%</span></p>
            <p style="margin:5px 0;">🏆 <b>최고 정확도:</b> ${maxScore}%</p>
            <p style="margin:5px 0;">⌨️ <b>누적 연습량:</b> ${totalChars.toLocaleString()}자</p>
        </div>
        <p style="text-align:center; font-size:14px; color:#666;">
            ${avgScore >= 98 ? "🌟 전문가 수준의 정확도입니다!" : "📈 꾸준히 연습하면 더 좋아질 거예요!"}
        </p>
    `;
    document.getElementById('report-content').innerHTML = reportHtml;
    document.getElementById('overlay').style.display = 'block'; document.getElementById('report-modal').style.display = 'block';
}

function loadFile(input, targetId) {
    const file = input.files[0];
    if (file) readFile(file, targetId);
}

function readFile(file, targetId) {
    if (file.name.split('.').pop().toLowerCase() !== 'txt') { alert("txt 파일만 불러올 수 있어요! 😅"); return; }
    const reader = new FileReader();
    reader.onload = function(e) { document.getElementById(targetId).value = e.target.result; updateToksoriTextCounts(); };
    reader.readAsText(file, "UTF-8");
}

function setupDragAndDrop(areaId) {
    const area = document.getElementById(areaId);
    area.addEventListener("dragover", (e) => { e.preventDefault(); area.style.borderColor = "var(--primary)"; });
    area.addEventListener("dragleave", (e) => { e.preventDefault(); area.style.borderColor = "#F0F4F8"; });
    area.addEventListener("drop", (e) => { e.preventDefault(); area.style.borderColor = "#F0F4F8"; const file = e.dataTransfer.files[0]; if (file) readFile(file, areaId); });
}

function saveScreenshot() {
    const element = document.getElementById("result-card-box");
    if (!element) { alert("저장할 결과 화면이 없습니다."); return; }
    html2canvas(element, { scale: 2, backgroundColor: "#ffffff", useCORS: true }).then(canvas => {
        const link = document.createElement("a");
        const today = new Date().toISOString().slice(0, 10);
        const fName = document.getElementById('fileName').value.trim() || "연습";
        link.download = `똑소리_${fName}_결과_${today}.png`;
        link.href = canvas.toDataURL("image/png");
        link.click();
    });
}
