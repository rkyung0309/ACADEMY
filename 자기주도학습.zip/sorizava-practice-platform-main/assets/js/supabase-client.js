// Supabase browser client for Sorizava Practice Platform
// publishable key is safe to use in browser. Never place service_role/secret keys here.
(function () {
  const SUPABASE_URL = "https://frqcxmkwcecqvpmbxori.supabase.co";
  const SUPABASE_PUBLISHABLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZycWN4bWt3Y2VjcXZwbWJ4b3JpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzcwNDAxMjUsImV4cCI6MjA5MjYxNjEyNX0.OLcoaCMc69lAqtYoZ8zPRx6k267B2AHv-7w9yMogMhA";
  if (!window.supabase || !window.supabase.createClient) {
    console.error("Supabase JS SDK가 로드되지 않았습니다.");
    return;
  }
  window.SORIZAVA_SUPABASE_URL = SUPABASE_URL;
  window.SORIZAVA_SUPABASE = window.supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true
    }
  });
})();
