// 자수 측정 페이지 스크립트

// 사이드바 토글
function toggleSidebar(forceOpen) {
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.querySelector('.sidebar-overlay');
    if (!sidebar || !overlay) return;

    const shouldOpen = typeof forceOpen === 'boolean' ? forceOpen : !sidebar.classList.contains('active');
    sidebar.classList.toggle('active', shouldOpen);
    overlay.classList.toggle('active', shouldOpen);
}

// 기본 요소 참조
const typingArea = document.getElementById('typingArea');
const timeVal = document.getElementById('timeVal');
const charVal = document.getElementById('charVal');
const speedVal = document.getElementById('speedVal');
const audioVal = document.getElementById('audioVal');
const audioPlayer = document.getElementById('audioPlayer');
const seekBar = document.getElementById('seekBar');
const currentTimeText = document.getElementById('currentTime');
const totalTimeText = document.getElementById('totalTime');
const resultLayer = document.getElementById('resultLayer');
const summaryDisplay = document.getElementById('summaryDisplay');
const playBtn = document.getElementById('playBtn');
const miniPlayBtn = document.getElementById('miniPlayBtn');
const speedDisplay = document.getElementById('speedDisplay');

// 스마트 일시정지 관련 요소
const smartPauseToggle = document.getElementById('smartPauseToggle');
const smartPauseTimeInput = document.getElementById('smartPauseTime');

const historyList = document.getElementById('historyList');
const SKIP_SECONDS = 3;

let currentUser = sessionStorage.getItem('shorthand_user');
const sidebarNameEl = document.getElementById('userNameSide') || document.getElementById('sideUserName');
if (currentUser && sidebarNameEl) {
    sidebarNameEl.innerText = currentUser;
}

// 상태 변수
let startTime = null;
let timerLoop = null;
let isStarted = false;
let currentSpeed = 1.0;
let smartPauseTimer = null;
let isSmartPausing = false;

// 초기화
loadHistory();
updatePlayButtons(false);

// 키보드 이벤트: ESC 종료, F6/F7 3초 이동
window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && isStarted) {
        e.preventDefault();
        finish();
        return;
    }

    if (e.key === 'F6') {
        e.preventDefault();
        skipAudio(SKIP_SECONDS);
        return;
    }

    if (e.key === 'F7') {
        e.preventDefault();
        skipAudio(-SKIP_SECONDS);
    }
});

// 타이핑 이벤트: 측정 시작 및 스마트 일시정지
typingArea.addEventListener('input', () => {
    const hasText = typingArea.value.length > 0;

    // 1. 자동 시작 로직
    if (!isStarted && hasText) {
        isStarted = true;
        startTime = Date.now();
        timerLoop = setInterval(updateStats, 1000);

        if (audioPlayer.src && audioPlayer.paused) {
            audioPlayer.play().catch(() => {});
        }
    }
    updateStats();

    // 2. 스마트 일시정지 로직
    if (smartPauseToggle && smartPauseToggle.checked && isStarted && audioPlayer.src) {
        clearTimeout(smartPauseTimer);
        typingArea.classList.remove('paused-warning');

        // 스마트 일시정지로 멈춰 있었다면 다시 재생
        if (audioPlayer.paused && isSmartPausing) {
            audioPlayer.play().catch(() => {});
            isSmartPausing = false;
        }

        const pauseDelay = getSmartPauseDelayMs();
        smartPauseTimer = setTimeout(() => {
            if (!audioPlayer.paused) {
                audioPlayer.pause();
                isSmartPausing = true;
                typingArea.classList.add('paused-warning');
            }
        }, pauseDelay);
    }
});

// 측정 종료
function finish() {
    clearInterval(timerLoop);
    clearTimeout(smartPauseTimer);
    typingArea.classList.remove('paused-warning');
    typingArea.disabled = true;
    audioPlayer.pause();

    const text = typingArea.value.replace(/[^a-zA-Z0-9가-힣]/g, '');
    const elapsed = startTime ? (Date.now() - startTime) / 1000 : 0;
    const finalSpeed = text.length > 0 && elapsed > 0 ? Math.floor(text.length / (elapsed / 60)) : 0;

    resultLayer.style.display = 'flex';
    summaryDisplay.innerHTML = `
        <div>🚀 최종 타수: <strong style="color:#6C5CE7; font-size:1.4rem;">${finalSpeed}</strong> CPM</div>
        <div style="font-size:0.95rem; margin-top:10px;">
            🔤 입력 글자 수: ${text.length}자 &nbsp;|&nbsp; ⏱️ 측정 시간: ${Math.floor(elapsed)}초
        </div>`;

    saveHistory(finalSpeed, text.length, Math.floor(elapsed));
    if (window.SorizavaRecords) {
        window.SorizavaRecords.savePracticeRecord({
            tool_type: 'measure',
            practice_title: '자수측정',
            typed_length: text.length,
            cpm: finalSpeed,
            elapsed_seconds: Math.floor(elapsed),
            memo: '자수측정 자동 저장'
        });
    }
}

// 통계 업데이트
function updateStats() {
    if (startTime) {
        const elapsed = (Date.now() - startTime) / 1000;
        timeVal.innerText = formatClock(elapsed);

        const text = typingArea.value.replace(/[^a-zA-Z0-9가-힣]/g, '');
        charVal.innerText = text.length;
        speedVal.innerText = elapsed > 1 ? Math.floor(text.length / (elapsed / 60)) : 0;
    }
}

function getSmartPauseDelayMs() {
    const rawValue = smartPauseTimeInput ? parseFloat(smartPauseTimeInput.value) : 1.0;
    const seconds = Number.isFinite(rawValue) ? Math.min(Math.max(rawValue, 0.5), 5.0) : 1.0;
    if (smartPauseTimeInput && smartPauseTimeInput.value !== seconds.toFixed(1)) {
        smartPauseTimeInput.value = seconds.toFixed(1);
    }
    return seconds * 1000;
}

// 시간 포맷
function formatTime(seconds) {
    const safeSeconds = Number.isFinite(seconds) ? Math.max(0, seconds) : 0;
    const min = Math.floor(safeSeconds / 60);
    const sec = Math.floor(safeSeconds % 60);
    return `${min}:${sec < 10 ? '0' : ''}${sec}`;
}

function formatClock(seconds) {
    const safeSeconds = Number.isFinite(seconds) ? Math.max(0, seconds) : 0;
    const min = Math.floor(safeSeconds / 60);
    const sec = Math.floor(safeSeconds % 60);
    return `${String(min).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
}

function updatePlayButtons(isPlaying) {
    if (playBtn) {
        playBtn.innerHTML = isPlaying
            ? '<span class="control-icon">⏸</span><strong>일시정지</strong>'
            : '<span class="control-icon">▶</span><strong>재생 시작</strong>';
        playBtn.classList.toggle('is-playing', isPlaying);
    }
    if (miniPlayBtn) {
        miniPlayBtn.innerText = isPlaying ? '⏸' : '▶';
        miniPlayBtn.classList.toggle('is-playing', isPlaying);
    }
}

// 오디오 UI 업데이트
audioPlayer.addEventListener('timeupdate', () => {
    if (!audioPlayer.duration) return;
    const percent = (audioPlayer.currentTime / audioPlayer.duration) * 100;
    seekBar.value = percent;
    currentTimeText.innerText = formatTime(audioPlayer.currentTime);
    audioVal.innerText = formatClock(audioPlayer.duration - audioPlayer.currentTime);
});

audioPlayer.addEventListener('loadedmetadata', () => {
    totalTimeText.innerText = formatTime(audioPlayer.duration);
    audioVal.innerText = formatClock(audioPlayer.duration);
    seekBar.max = 100;
    seekBar.value = 0;
    currentTimeText.innerText = '0:00';
});

audioPlayer.addEventListener('play', () => updatePlayButtons(true));
audioPlayer.addEventListener('pause', () => updatePlayButtons(false));
audioPlayer.addEventListener('ended', () => updatePlayButtons(false));

// Seek Bar 조작
seekBar.addEventListener('input', () => {
    if (audioPlayer.duration) {
        const seekTime = (seekBar.value / 100) * audioPlayer.duration;
        audioPlayer.currentTime = seekTime;
    }
});

// 파일 열기
document.getElementById('audioFile').addEventListener('change', function() {
    const file = this.files[0];
    if (file) {
        if (audioPlayer.src && audioPlayer.src.startsWith('blob:')) {
            URL.revokeObjectURL(audioPlayer.src);
        }
        audioPlayer.src = URL.createObjectURL(file);
        audioPlayer.load();
        typingArea.focus();
    }
});

// 오디오 컨트롤
function toggleAudio() {
    if (!audioPlayer.src) {
        document.getElementById('audioFile').click();
        return;
    }
    if (audioPlayer.paused) {
        audioPlayer.play().catch(() => {});
    } else {
        audioPlayer.pause();
    }
}

function skipAudio(seconds) {
    if (audioPlayer.duration) {
        audioPlayer.currentTime = Math.min(Math.max(audioPlayer.currentTime + seconds, 0), audioPlayer.duration);
    }
}

function adjustSpeed(amount) {
    let newSpeed = Math.round((currentSpeed + amount) * 10) / 10;
    if (newSpeed < 0.5) newSpeed = 0.5;
    if (newSpeed > 2.0) newSpeed = 2.0;

    currentSpeed = newSpeed;
    audioPlayer.playbackRate = currentSpeed;
    speedDisplay.innerText = `${currentSpeed.toFixed(1)}x`;
}

function resetAll() {
    clearInterval(timerLoop);
    clearTimeout(smartPauseTimer);
    isStarted = false;
    startTime = null;
    isSmartPausing = false;

    typingArea.disabled = false;
    typingArea.value = '';
    typingArea.classList.remove('paused-warning');
    typingArea.focus();

    timeVal.innerText = '00:00';
    charVal.innerText = '0';
    speedVal.innerText = '0';

    if (audioPlayer.src) {
        audioPlayer.pause();
        audioPlayer.currentTime = 0;
        seekBar.value = 0;
        currentTimeText.innerText = '0:00';
        if (audioPlayer.duration) {
            audioVal.innerText = formatClock(audioPlayer.duration);
        }
    } else {
        audioVal.innerText = '00:00';
    }
    updatePlayButtons(false);
    resultLayer.style.display = 'none';
}

function closeResult() {
    resultLayer.style.display = 'none';
    loadHistory();
}

// 히스토리 관리
function saveHistory(speed, chars, time) {
    const now = new Date();
    const dateStr = `${now.getMonth()+1}/${now.getDate()} ${now.getHours()}:${now.getMinutes() < 10 ? '0'+now.getMinutes() : now.getMinutes()}`;

    const record = {
        date: dateStr,
        speed: speed,
        chars: chars,
        time: time
    };

    let history = JSON.parse(localStorage.getItem('shorthand_history') || '[]');
    history.unshift(record);
    if (history.length > 5) history.pop();
    localStorage.setItem('shorthand_history', JSON.stringify(history));
}

function loadHistory() {
    let history = JSON.parse(localStorage.getItem('shorthand_history') || '[]');
    historyList.innerHTML = '';

    if (history.length === 0) {
        historyList.innerHTML = '<li class="history-empty">아직 저장된 기록이 없습니다.<br><small>측정을 완료하면 기록이 여기에 표시됩니다.</small></li>';
        return;
    }

    history.forEach(rec => {
        const li = document.createElement('li');
        li.className = 'history-item';
        li.innerHTML = `
            <div>
                <span class="history-tag">${rec.date}</span>
                <span style="font-weight:800;">${rec.speed} CPM</span>
            </div>
            <div style="color:#64748B; font-size:0.9rem;">
                ${rec.chars}자 입력 · ${formatClock(rec.time)}
            </div>
        `;
        historyList.appendChild(li);
    });
}

function clearHistory() {
    if(confirm('최근 측정 기록을 모두 삭제하시겠습니까?')) {
        localStorage.removeItem('shorthand_history');
        loadHistory();
    }
}

function logout() {
    if(confirm('로그아웃 하시겠습니까?')) window.SorizavaAuth.signOut();
}
