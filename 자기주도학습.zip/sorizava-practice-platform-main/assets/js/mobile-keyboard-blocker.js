// Mobile keyboard blocker rollback / input restore version
// This file intentionally does NOT block focus, touch, or hardware keyboard input.
// It also removes attributes left by earlier keyboard-blocking patches.
(function () {
  'use strict';

  var EDITABLE_SELECTOR = [
    'textarea',
    'input:not([type])',
    'input[type="text"]',
    'input[type="search"]',
    'input[type="email"]',
    'input[type="password"]',
    'input[type="tel"]',
    'input[type="url"]',
    'input[type="number"]',
    '[contenteditable="true"]'
  ].join(',');

  function isEditable(el) {
    return !!(el && el.nodeType === 1 && el.matches && el.matches(EDITABLE_SELECTOR));
  }

  function restoreInput(el) {
    if (!isEditable(el) || el.disabled) return;
    // 이전 패치에서 남은 차단 속성 제거
    if (el.getAttribute('data-mobile-keyboard-blocked')) {
      el.removeAttribute('data-mobile-keyboard-blocked');
    }
    if (el.getAttribute('inputmode') === 'none') {
      el.removeAttribute('inputmode');
    }
    if (el.getAttribute('virtualkeyboardpolicy')) {
      el.removeAttribute('virtualkeyboardpolicy');
    }
    try { if (el.virtualKeyboardPolicy) el.virtualKeyboardPolicy = ''; } catch (e) {}
    if (el.readOnly && !el.hasAttribute('data-original-readonly')) {
      el.readOnly = false;
      el.removeAttribute('readonly');
    }
    el.setAttribute('autocomplete', 'off');
    el.setAttribute('spellcheck', 'false');
  }

  function applyTo(root) {
    if (!root) return;
    if (isEditable(root)) restoreInput(root);
    if (!root.querySelectorAll) return;
    root.querySelectorAll(EDITABLE_SELECTOR).forEach(restoreInput);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { applyTo(document); }, { once: true });
  } else {
    applyTo(document);
  }

  document.addEventListener('focusin', function (event) { restoreInput(event.target); }, true);
  document.addEventListener('keydown', function (event) { restoreInput(event.target); }, true);
  document.addEventListener('input', function (event) { restoreInput(event.target); }, true);

  if ('MutationObserver' in window) {
    new MutationObserver(function (mutations) {
      mutations.forEach(function (mutation) {
        mutation.addedNodes && mutation.addedNodes.forEach(function (node) {
          if (node && node.nodeType === 1) applyTo(node);
        });
      });
    }).observe(document.documentElement, { childList: true, subtree: true });
  }
})();
