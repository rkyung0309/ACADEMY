
// Learning Portal Final Integration - no sample user data, actual auth/records driven.
(function(){
  const $ = (id) => document.getElementById(id);
  const qs = (sel, root=document) => root.querySelector(sel);
  const qsa = (sel, root=document) => Array.from(root.querySelectorAll(sel));
  const state = { ctx:null, profile:null, user:null, records:[], summary:null, feedback:[], aiFeedback:[], creditLedger:[], unlockChanceLedger:[], materials:[], currentMode:'audio', selectedMaterial:null, timer:null, startedAt:null, elapsed:0, myFilter:'all' };
  const MODE_LABEL = { audio:'듣고치기', reading:'보고치기', quest:'퀘스트' };
  const MODE_TOOL = { audio:'practice_room_audio', reading:'practice_room_reading', quest:'quest' };
  const LEVELS = [110,120,130,140,150,160,170,190,210,230,250];

  function esc(v){return String(v ?? '').replace(/[&<>"']/g, s=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s]));}
  function n(v,f=0){const x=Number(v);return Number.isFinite(x)?x:f;}
  function round1(v){const x=Number(v);return Number.isFinite(x)?Math.round(x*10)/10:0;}
  function score(r){const a=Number(r?.accuracy); if(Number.isFinite(a)) return a; const s=Number(r?.score); return Number.isFinite(s)?s:null;}
  function kstKey(value){try{return new Date(value).toLocaleDateString('sv-SE',{timeZone:'Asia/Seoul'});}catch(e){return '';}}
  function fmtDate(value){if(!value) return '-'; try{return new Date(value).toLocaleString('ko-KR',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'});}catch(e){return '-';}}
  function todayKey(){return window.SorizavaRecords?.todayKstDateString ? window.SorizavaRecords.todayKstDateString() : new Date(Date.now()+9*3600000).toISOString().slice(0,10);}
  function displayName(){return state.profile?.name || state.user?.email || sessionStorage.getItem('shorthand_user') || '사용자';}
  function roleLabel(role){return {admin:'관리자',operator:'운영팀',teacher:'강사',student:'학생'}[String(role||'').toLowerCase()] || (role || '학생');}
  function toolLabel(type){return window.SorizavaRecords?.getToolLabel?.(type) || ({intermediate:'중급반 공부방',advanced:'고급반 공부방',grade:'급수반 공부방',practice_room_audio:'기존 듣고치기',practice_room_reading:'기존 보고치기',quest:'퀘스트',intermediate_unlock:'진도 승급실',advanced_unlock:'진도 승급실',grade_unlock:'진도 승급실'}[type]) || type || '기타';}
  function setLoading(show){const el=$('loading-overlay'); if(el) el.style.display=show?'flex':'none';}
  function firstChar(name){return String(name||'U').trim().charAt(0).toUpperCase() || 'U';}
  function syncShell(){
    const name=displayName();
    qsa('#userNameSide,#sideUserName').forEach(el=>el.textContent=name);
    qsa('#userAvatar').forEach(el=>el.textContent=firstChar(name));
    const adminBtn=$('adminBtn');
    if(adminBtn && ['admin','operator','teacher'].includes(String(state.profile?.role||'').toLowerCase())) adminBtn.style.display='block';
  }
  async function requirePage(){
    const ctx = await window.SorizavaAuth.requireApproved({redirect:true});
    if(!ctx || !ctx.approved) return null;
    state.ctx=ctx; state.user=ctx.user; state.profile=ctx.profile; syncShell(); return ctx;
  }
  async function loadRecords(){
    try{ state.summary = await window.SorizavaRecords.getMyStudyInsight(); state.records = state.summary.records || []; }
    catch(e){ console.error('기록 조회 실패', e); state.summary={records:[],avgAcc:0,maxCPM:0,streak:0,graphData:[],insight:{}}; state.records=[]; }
  }
  function todayRecords(){const t=todayKey(); return state.records.filter(r=>kstKey(r.created_at)===t);}
  function weekRecords(){const now=new Date(`${todayKey()}T23:59:59+09:00`).getTime(); const start=now-6*86400000; return state.records.filter(r=>{const time=new Date(r.created_at).getTime(); return Number.isFinite(time)&&time>=start&&time<=now;});}

  function parseRecordMemo(record){
    const memo=record&&record.memo;
    if(!memo || typeof memo!=='string') return null;
    try{return JSON.parse(memo);}catch(e){return null;}
  }
  function recordSeconds(record){
    const direct=Number(record?.elapsed_seconds);
    if(Number.isFinite(direct)&&direct>0) return direct;
    const memo=parseRecordMemo(record);
    const fromMemo=Number(memo?.elapsed ?? memo?.elapsed_seconds ?? memo?.duration ?? 0);
    return Number.isFinite(fromMemo)&&fromMemo>0?fromMemo:0;
  }
  function sumSeconds(records=[]){return records.reduce((sum,row)=>sum+recordSeconds(row),0);}
  function formatStudyDuration(seconds){
    const safe=Math.max(0,Math.round(Number(seconds)||0));
    const hours=Math.floor(safe/3600);
    const minutes=Math.floor((safe%3600)/60);
    if(hours>0) return `${hours}시간 ${minutes}분`;
    if(minutes>0) return `${minutes}분`;
    return safe>0?'1분 미만':'0분';
  }
  function inferLevelFromText(text){
    const match=String(text||'').match(/(110|120|130|140|150|160|170|190|210|230|250)\s*자/);
    return match?Number(match[1]):null;
  }
  function profileText(){
    const p=state.profile||{};
    return [
      p.course_track,p.assigned_course,p.course,p.current_course,p.course_type,p.enrolled_course,p.training_course,p.class_name,p.className,p.current_class,p.currentClass,
      p.level,p.current_level,p.progress_level,p.study_level,p.grade,p.grade_level,p.track,p.progress,p.memo,p.note
    ].filter(v=>v!==undefined&&v!==null).join(' ');
  }
  function dashboardPromotionRoute(){
    const text=profileText();
    if(/급수|1\s*급|2\s*급|3\s*급|시험대비|자격증|grade/i.test(text)) return [170,210,250];
    return LEVELS;
  }
  function dashboardAllUnlockLogs(){
    return ['intermediate','advanced','grade'].flatMap(course => dashboardUnlockLogs(course));
  }
  function promotedDashboardLevel(level){
    let current=Number(level);
    const route=dashboardPromotionRoute();
    if(!Number.isFinite(current) || !route.includes(current)) return level;
    const logs=dashboardAllUnlockLogs();
    let guard=0;
    while(route.includes(current) && guard < route.length){
      const passed=logs.some(row=>Number(row.level)===current && Number(row.accuracy||row.score||0)>=90);
      if(!passed) break;
      const idx=route.indexOf(current);
      if(idx<0 || idx>=route.length-1) break;
      current=route[idx+1];
      guard += 1;
    }
    return current;
  }

  function assignedDashboardCourse(){
    if(window.SorizavaCourseAccess?.hasManagerAccess?.(state.profile)) return '';
    return window.SorizavaCourseAccess?.profileCourseTrack?.(state.profile) || '';
  }
  function inferCurrentLevel(){
    const p=state.profile||{};
    const profileLevel=[p.current_level,p.progress_level,p.study_level,p.level,p.speed,p.current_speed]
      .map(v=>Number(String(v||'').replace(/[^0-9]/g,'')))
      .find(v=>Number.isFinite(v)&&v>=90&&v<=280);
    if(profileLevel) return promotedDashboardLevel(profileLevel);
    const profileParsed=inferLevelFromText(profileText());
    if(profileParsed) return promotedDashboardLevel(profileParsed);
    const progressLevel=Number(state.summary?.insight?.progressStatus?.currentLevel);
    if(Number.isFinite(progressLevel)&&progressLevel>0) return promotedDashboardLevel(progressLevel);
    const latestWithLevel=(state.records||[]).find(row=>inferLevelFromText(row.practice_title)||Number(row.cpm));
    if(latestWithLevel){
      const titleLevel=inferLevelFromText(latestWithLevel.practice_title);
      if(titleLevel) return promotedDashboardLevel(titleLevel);
      const cpm=Number(latestWithLevel.cpm);
      if(Number.isFinite(cpm)&&cpm>=90&&cpm<=280){
        const nearest=LEVELS.reduce((best,step)=>Math.abs(step-cpm)<Math.abs(best-cpm)?step:best,LEVELS[0]);
        return promotedDashboardLevel(nearest);
      }
    }
    return null;
  }
  function inferDashboardCourse(){
    const assigned=assignedDashboardCourse();
    if(assigned) return assigned;
    const text=profileText();
    if(/급수|1\s*급|2\s*급|3\s*급|시험대비|자격증|grade/i.test(text)) return 'grade';
    if(/고급|190\s*자|210\s*자|230\s*자|250\s*자|advanced/i.test(text)) return 'advanced';
    if(/중급|110\s*자|120\s*자|130\s*자|140\s*자|150\s*자|160\s*자|170\s*자|intermediate/i.test(text)) return 'intermediate';
    const latestCourse=(state.records||[]).find(row=>['intermediate','advanced','grade'].includes(String(row.tool_type||'')));
    if(latestCourse?.tool_type==='grade') return 'grade';
    if(latestCourse?.tool_type==='advanced') return 'advanced';
    if(latestCourse?.tool_type==='intermediate') return 'intermediate';
    const level=inferCurrentLevel();
    if(level&&level>=190) return 'advanced';
    return 'intermediate';
  }
  function dashboardCourseMeta(course){
    return {
      intermediate:{label:'중급반 공부방',icon:'🧩',href:'intermediate.html',summary:'110~170자 진도 훈련'},
      advanced:{label:'고급반 공부방',icon:'🚀',href:'intermediate.html?course=advanced',summary:'190자 이상 고속 훈련'},
      grade:{label:'급수반 공부방',icon:'🏅',href:'intermediate.html?course=grade',summary:'시험 대비 실전 훈련'}
    }[course] || {label:'내 공부방',icon:'🧩',href:'intermediate.html',summary:'현재 진도 훈련'};
  }
  function dashboardProgressLabel(course){
    const text=profileText();
    const gradeMatch=String(text).match(/([123])\s*급/);
    if(course==='grade' && gradeMatch) return `${gradeMatch[1]}급 준비`;
    const level=inferCurrentLevel();
    if(level) return `${level}자`;
    if(course==='advanced') return '고급반';
    if(course==='grade') return '급수반';
    return '중급반';
  }
  const DASHBOARD_UNLOCK_LEVELS = {
    intermediate: [110,120,130,140,150,160,170].map(value=>({value,label:`${value}자`})),
    advanced: [190,210,230,250].map(value=>({value,label:`${value}자`})),
    grade: [{value:170,label:'3급'},{value:210,label:'2급'},{value:250,label:'1급'}]
  };
  function courseBaseFromMeta(course){
    const meta=dashboardCourseMeta(course);
    return String(meta.label||'내 진도 공부방').replace(/\s*공부방$/,'');
  }
  function dashboardUnlockHref(course=inferDashboardCourse()){
    return 'unlock-room.html';
  }
  function rawLocalList(key){
    try{const rows=JSON.parse(localStorage.getItem(key)||'[]'); return Array.isArray(rows)?rows:[];}catch(e){return [];}
  }
  function rawLocalNumber(key, fallback=0){
    const value=Number(localStorage.getItem(key));
    return Number.isFinite(value)?value:fallback;
  }
  function rawLocalAdjustment(course){
    const value=Number(localStorage.getItem(`sorizava_${course}_unlock_extra_adjustment_v1`)||0);
    return Number.isFinite(value)?value:0;
  }
  function unlockChanceBalance(course){
    const ledger=(state.unlockChanceLedger||[]).filter(row=>String(row.course_key||row.course||row.courseKey||course)===String(course));
    const ledgerBalance=ledger.reduce((sum,row)=>sum+n(row.amount),0);
    const legacy=rawLocalNumber(`sorizava_${course}_unlock_extra_chances_v1`,0);
    return Math.max(0, ledgerBalance+legacy+rawLocalAdjustment(course));
  }
  function dashboardUnlockLogs(course=inferDashboardCourse()){
    const localRows=rawLocalList(`sorizava_${course}_progress_logs_v1`);
    const recordRows=(state.records||[]).map(row=>{
      const memo=parseRecordMemo(row)||{};
      const title=String(row.practice_title||'');
      const mode=String(memo.mode||memo.roomMode||'');
      const kind=String(memo.kind||'');
      const rowCourse = String(row.tool_type||'').includes(course) || kind.includes(course) || (course==='intermediate' && row.tool_type==='intermediate');
      const isUnlock = mode==='unlock' || memo.roomMode==='unlock' || /진도 승급실|해금방|승급/.test(title);
      if(!isUnlock || !rowCourse) return null;
      return {
        level: Number(memo.level || inferLevelFromText(title) || row.cpm || 0),
        accuracy: Number(memo.accuracy ?? memo.score ?? score(row) ?? 0),
        mode:'unlock',
        createdAt: row.created_at || memo.createdAt
      };
    }).filter(Boolean);
    return [...localRows,...recordRows];
  }
  function dashboardUnlockWeekRange(){
    const today=kstDateFromKey(todayKey());
    const day=today.getDay();
    const monday=new Date(today);
    monday.setDate(today.getDate()-((day+6)%7));
    const sunday=new Date(monday);
    sunday.setDate(monday.getDate()+6);
    return {start:formatIsoDateKey(monday),end:formatIsoDateKey(sunday)};
  }
  function dashboardUnlockState(course=inferDashboardCourse()){
    const levels=DASHBOARD_UNLOCK_LEVELS[course] || DASHBOARD_UNLOCK_LEVELS.intermediate;
    const logs=dashboardUnlockLogs(course);
    const passedLevels=levels.filter(level=>logs.some(row=>Number(row.level)===Number(level.value) && Number(row.accuracy||row.score||0)>=90));
    const nextTarget=levels.find(level=>!passedLevels.some(p=>Number(p.value)===Number(level.value))) || null;
    const attemptRows=rawLocalList(`sorizava_${course}_unlock_attempts_v1`);
    const weekRange=dashboardUnlockWeekRange();
    const usedThisWeek=attemptRows.filter(row=>row&&row.dateKey>=weekRange.start&&row.dateKey<=weekRange.end).length;
    const extra=unlockChanceBalance(course);
    const freeLimit=3;
    const weeklyLimit=freeLimit+extra;
    const remaining=Math.max(0,freeLimit-usedThisWeek)+extra;
    const credit=creditState();
    const courseLabel=courseBaseFromMeta(course);
    return {course,courseLabel,levels,passedLevels,nextTarget,freeLimit,extra,weeklyLimit,usedThisWeek,remaining,credit,weekRange,href:dashboardUnlockHref(course)};
  }
  function renderDashboardUnlockSummary(){
    const data=dashboardUnlockState();
    const chip=$('dashboardHomeUnlockChip');
    if(chip) chip.textContent=`${data.remaining}회`;
    const nav=$('unlockRoomNavItem');
    if(nav) nav.href=data.href;
    const navText=$('unlockRoomNavText');
    if(navText) navText.textContent='진도 승급실';
    const summary=$('dashboardUnlockSummary');
    if(summary){
      const targetText=data.nextTarget?`${data.nextTarget.label} 승급`:'전체 승급 완료';
      const creditText=`크레딧 ${Math.max(0,Number(data.credit.balance)||0)}개`;
      summary.innerHTML=`
        <div class="dashboard-unlock-count"><span>남은 응시</span><b>${data.remaining}회</b></div>
        <div class="dashboard-unlock-copy"><strong>${esc(targetText)}</strong><small>주 ${data.freeLimit}회 중 ${data.usedThisWeek}회 사용 · ${data.extra?`추가 ${data.extra}회 포함 · `:''}${esc(creditText)}</small></div>
      `;
    }
    return data;
  }
  function formatIsoDateKey(date){return date.toLocaleDateString('sv-SE',{timeZone:'Asia/Seoul'});}
  function kstDateFromKey(key){return new Date(`${key}T00:00:00+09:00`);}
  function dashboardWeekdaySeries(){
    const today=kstDateFromKey(todayKey());
    const day=today.getDay();
    const monday=new Date(today);
    monday.setDate(today.getDate()-((day+6)%7));
    const labels=['월','화','수','목','금','토','일'];
    const map={};
    for(let i=0;i<7;i++){
      const d=new Date(monday); d.setDate(monday.getDate()+i);
      const key=formatIsoDateKey(d);
      map[key]={key,label:labels[i],date:`${d.getMonth()+1}/${d.getDate()}`,count:0,seconds:0,isToday:key===todayKey()};
    }
    (state.records||[]).forEach(row=>{
      const key=kstKey(row.created_at);
      if(map[key]){map[key].count+=1; map[key].seconds+=recordSeconds(row);}
    });
    return Object.values(map);
  }
  function renderDashboardStats(){
    const week=weekRecords();
    const weekday=dashboardWeekdaySeries();
    const activeDays=weekday.filter(row=>row.count>0 || row.seconds>0).length;
    const weekSeconds=sumSeconds(week);
    const totalSeconds=sumSeconds(state.records);
    const course=inferDashboardCourse();
    const meta=dashboardCourseMeta(course);
    const progress=dashboardProgressLabel(course);
    const progressMeta=state.records.length?`${meta.label} · 최근 기록 기준`:`${meta.label} · 첫 기록 대기`;
    const setText=(id,value)=>{const el=$(id); if(el) el.textContent=value;};
    setText('dashboardCurrentProgress',progress);
    setText('dashboardCurrentProgressMeta',progressMeta);
    setText('dashboardWeekTime',formatStudyDuration(weekSeconds));
    setText('dashboardWeekTimeMeta',`${week.length}회 연습 · 최근 7일`);
    setText('dashboardTotalTime',formatStudyDuration(totalSeconds));
    setText('dashboardTotalTimeMeta',`${state.records.length}개 기록 기준`);
    setText('dashboardConsistencyRate',`${activeDays}/7일`);
    setText('dashboardConsistencyMeta',activeDays>=5?'요일 분산이 좋습니다':activeDays>=3?'조금 더 고르게 분산 필요':'연습 요일을 더 확보하세요');
    setText('dashboardHomeConsistencyChip',`${activeDays}/7일`);
    const icon=$('dashboardCourseIcon'); if(icon) icon.textContent=meta.icon;
    const link=$('dashboardCourseLink'); if(link){link.href=meta.href; link.textContent=`${meta.label} 바로 시작`;}
    renderDashboardUnlockSummary();
  }
  function renderDashboardWeekdayChart(id){
    const root=$(id); if(!root) return;
    const data=dashboardWeekdaySeries();
    const hasSeconds=data.some(row=>row.seconds>0);
    const max=Math.max(1,...data.map(row=>hasSeconds?Math.ceil(row.seconds/60):row.count));
    const unit=hasSeconds?'분':'회';
    const activeDays=data.filter(row=>row.count>0 || row.seconds>0).length;
    const totalValue=data.reduce((sum,row)=>sum+(hasSeconds?Math.ceil(row.seconds/60):row.count),0);
    const peak=totalValue?Math.max(...data.map(row=>hasSeconds?Math.ceil(row.seconds/60):row.count)):0;
    const balance=totalValue && peak/totalValue<=0.38 && activeDays>=4;
    const note=$('dashboardWeekdayNote');
    if(note){
      if(!totalValue) note.textContent='이번 주 저장된 연습 기록이 없습니다. 기록이 생기면 월~일 균형이 표시됩니다.';
      else note.textContent=`이번 주 ${activeDays}/7일 학습 · ${balance?'특정 요일 쏠림이 적습니다':'특정 요일에 몰리지 않게 나눠 연습하세요'}`;
    }
    root.innerHTML=data.map(row=>{
      const value=hasSeconds?Math.ceil(row.seconds/60):row.count;
      const height=value?Math.max(14,value/max*100):6;
      const cls=[value?'active':'','isToday' in row && row.isToday?'today':''].filter(Boolean).join(' ');
      return `<div class="portal-bar dashboard-weekday-bar ${cls}"><div class="portal-bar-value">${value}${unit}</div><div class="portal-bar-track"><div class="portal-bar-fill" style="height:${height}%"></div></div><div class="portal-bar-label">${esc(row.label)}<small>${esc(row.date)}</small></div></div>`;
    }).join('');
  }
  const DEFAULT_STUDY_GOALS = [
    {id:'listen', icon:'🎧', label:'듣고치기', target:3, unit:'개'},
    {id:'abbr', icon:'📚', label:'약어장', target:2, unit:'바퀴'},
    {id:'typing', icon:'⌨️', label:'단타장', target:1, unit:'바퀴'},
    {id:'wrong', icon:'🧾', label:'오타장', target:1, unit:'바퀴'},
    {id:'editorial', icon:'📰', label:'사설치기', target:10, unit:'개'}
  ];
  function normalizeStudyGoals(list){
    const saved=Array.isArray(list)?list:[];
    return DEFAULT_STUDY_GOALS.map(base=>{
      const found=saved.find(item=>item&&item.id===base.id) || {};
      const target=Number(found.target);
      return {...base,target:Number.isFinite(target)&&target>=0?Math.round(target):base.target};
    });
  }
  function readStudyGoals(){return normalizeStudyGoals(readLocal('daily_study_goals', DEFAULT_STUDY_GOALS));}
  function writeStudyGoals(goals){writeLocal('daily_study_goals', normalizeStudyGoals(goals));}
  function isListenRecord(row){
    const tool=String(row?.tool_type||'');
    const title=String(row?.practice_title||'');
    const memo=parseRecordMemo(row)||{};
    if(tool==='practice_room_audio') return true;
    if(['intermediate','advanced','grade'].includes(tool)) return /듣고|listen|audio/i.test(String(memo.mode||'')) || /듣고/.test(title);
    return /듣고/.test(title) && !/보고/.test(title);
  }
  function goalProgressValue(goal, rows){
    const id=goal.id;
    if(id==='listen') return rows.filter(isListenRecord).length;
    if(id==='abbr') return rows.filter(row=>['random','random_dictionary','random_voice_dictionary','random_abbr_wrong_visual','random_abbr_wrong_voice'].includes(String(row.tool_type||'')) || /약어|약어장/.test(String(row.practice_title||''))).length;
    if(id==='typing') return rows.filter(row=>['king','toksori2'].includes(String(row.tool_type||'')) || /단타|타자/.test(String(row.practice_title||''))).length;
    if(id==='wrong') return rows.filter(row=>/wrong|오타|오답/.test(`${row.tool_type||''} ${row.practice_title||''}`)).length;
    if(id==='editorial') return rows.filter(row=>String(row.tool_type||'')==='editorial' || /사설/.test(String(row.practice_title||''))).length;
    return 0;
  }
  function setGoalTarget(goalId, delta){
    const goals=readStudyGoals().map(goal=>goal.id===goalId?{...goal,target:Math.max(0,Number(goal.target||0)+delta)}:goal);
    writeStudyGoals(goals);
    renderDashboardGoals();
  }
  function resetStudyGoals(){
    if(!confirm('오늘 공부 목표를 기본값으로 되돌릴까요?')) return;
    writeStudyGoals(DEFAULT_STUDY_GOALS);
    renderDashboardGoals();
  }
  function renderDashboardGoals(){
    const root=$('dashboardGoalList');
    const summary=$('dashboardGoalSummary');
    if(!root) return;
    const goals=readStudyGoals();
    const today=todayRecords();
    const rows=goals.map(goal=>{
      const done=goalProgressValue(goal,today);
      const target=Math.max(0,Number(goal.target||0));
      const rate=target>0?Math.min(100,Math.round(done/target*100)):(done>0?100:0);
      const achieved=target>0 && done>=target;
      return {...goal,done,target,rate,achieved};
    });
    const achievedCount=rows.filter(row=>row.achieved).length;
    if(summary){
      summary.innerHTML=`<b>${achievedCount}/${rows.length}개 목표 달성</b><span>목표 숫자는 + / - 버튼으로 바로 조정됩니다.</span>`;
    }
    const homeGoalChip=$('dashboardHomeGoalChip');
    if(homeGoalChip) homeGoalChip.textContent=`${achievedCount}/${rows.length}`;
    root.innerHTML=rows.map(row=>`
      <article class="dashboard-goal-item ${row.achieved?'done':''}">
        <div class="dashboard-goal-top">
          <span class="dashboard-goal-icon">${esc(row.icon)}</span>
          <div><b>${esc(row.label)}</b><small>${row.done}/${row.target}${esc(row.unit)}</small></div>
          <span class="dashboard-goal-state">${row.achieved?'달성':'진행'}</span>
        </div>
        <div class="dashboard-goal-bar"><i style="width:${row.rate}%"></i></div>
        <div class="dashboard-goal-controls" aria-label="${esc(row.label)} 목표 조정">
          <button type="button" data-goal-step="${esc(row.id)}" data-goal-delta="-1">−</button>
          <span>목표 ${row.target}${esc(row.unit)}</span>
          <button type="button" data-goal-step="${esc(row.id)}" data-goal-delta="1">＋</button>
        </div>
      </article>`).join('');
    qsa('[data-goal-step]', root).forEach(btn=>{
      btn.addEventListener('click',()=>setGoalTarget(btn.dataset.goalStep, Number(btn.dataset.goalDelta||0)));
    });
    const reset=$('dashboardGoalResetBtn');
    if(reset && !reset.dataset.bound){reset.dataset.bound='1'; reset.addEventListener('click',resetStudyGoals);}
    renderDashboardRoutine(rows);
  }
  function renderDashboardRoutine(){
    const root=$('dashboardRoutineList');
    if(!root) return;
    const unlock=renderDashboardUnlockSummary();
    const hasRemain=unlock.nextTarget && unlock.remaining>0;
    const item=unlock.nextTarget
      ? {
          title:'진도 승급실 입장',
          detail:hasRemain
            ? `${unlock.nextTarget.label} 응시 가능 · 이번 주 ${unlock.remaining}회 남음`
            : `이번 주 무료 ${unlock.freeLimit}회 사용 완료 · 크레딧으로 추가 응시 필요`,
          href:unlock.href,
          done:false,
          cta:hasRemain?'응시하기':'횟수 확인'
        }
      : {
          title:'승급 완료',
          detail:'모든 승급 단계가 열려 있습니다.',
          href:unlock.href,
          done:true,
          cta:'확인'
        };
    root.innerHTML=`
      <li class="${item.done?'done':''} unlock-first" data-routine-href="${esc(item.href)}" role="link" tabindex="0">
        <span>🎯</span>
        <b>${esc(item.title)}</b>
        <small>${esc(item.detail)}</small>
        <em>${esc(item.cta)}</em>
      </li>`;
    qsa('[data-routine-href]', root).forEach(item=>{
      const go=()=>{location.href=item.dataset.routineHref;};
      item.addEventListener('click',go);
      item.addEventListener('keydown',(event)=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();go();}});
    });
    const note=$('dashboardRoutineNote');
    if(note){
      if(unlock.nextTarget && unlock.remaining>0) note.textContent=`진도 승급실은 주 ${unlock.freeLimit}회 무료 응시입니다. 이번 주 ${unlock.remaining}회 남아 있습니다.`;
      else if(unlock.nextTarget) note.textContent=`이번 주 무료 응시는 모두 사용했습니다. 추가 응시는 크레딧 차감 구조로 연결하면 됩니다.`;
      else note.textContent='현재 모든 승급 단계가 열려 있습니다.';
    }
  }
  function errorTotals(records=state.records){return records.reduce((acc,r)=>{acc.wrong+=n(r.wrong_count);acc.missing+=n(r.missing_count);acc.added+=n(r.added_count);acc.spacing+=n(r.spacing_error_count);return acc;},{wrong:0,missing:0,added:0,spacing:0});}
  function profileRows(){
    const p=state.profile||{}; const u=state.user||{};
    const rows=[['이메일',u.email||p.email||'-'],['권한',roleLabel(p.role)],['승인상태',p.status==='approved'?'승인완료':(p.status||'-')]];
    if(p.academy_id) rows.push(['아카데미 ID',p.academy_id]);
    if(p.phone) rows.push(['연락처',p.phone]);
    return rows.map(([k,v])=>`<div><span>${esc(k)}</span><b>${esc(v)}</b></div>`).join('');
  }
  function renderMetrics(rootId){
    const root=$(rootId); if(!root) return;
    const scoreRows=state.records.map(score).filter(v=>v!==null);
    const avg=scoreRows.length?round1(scoreRows.reduce((a,b)=>a+b,0)/scoreRows.length):0;
    const maxCpm=state.records.reduce((m,r)=>Math.max(m,n(r.cpm)),0);
    root.innerHTML=`
      <article class="portal-metric"><span>누적 연습</span><b>${state.records.length}회</b><small>저장된 전체 기록</small></article>
      <article class="portal-metric"><span>평균 정확도</span><b>${avg}%</b><small>${scoreRows.length}건 기준</small></article>
      <article class="portal-metric"><span>최고 속도</span><b>${maxCpm}자</b><small>CPM 기록 기준</small></article>
      <article class="portal-metric"><span>연속 학습</span><b>${n(state.summary?.streak)}일</b><small>KST 날짜 기준</small></article>`;
  }
  function renderWeekChart(id){
    const root=$(id); if(!root) return;
    const data=state.summary?.graphData || [];
    const max=Math.max(1,...data.map(d=>n(d.value)));
    root.innerHTML=data.length?data.map(d=>`<div class="portal-bar"><div class="portal-bar-value">${n(d.value)}</div><div class="portal-bar-track"><div class="portal-bar-fill" style="height:${Math.max(4,n(d.value)/max*100)}%"></div></div><div class="portal-bar-label">${esc(d.label)}</div></div>`).join(''):'<div class="portal-empty"><b>그래프 데이터 없음</b>연습 기록이 저장되면 최근 7일 흐름이 표시됩니다.</div>';
  }
  function recordItem(r, withFeedback=false){
    const s=score(r); const errors=n(r.wrong_count)+n(r.missing_count)+n(r.added_count)+n(r.spacing_error_count);
    const cls=s===null?'':s>=95?'good':s>=85?'warn':'bad';
    return `<article class="portal-record-item">
      <div><div class="portal-record-title">${esc(r.practice_title || toolLabel(r.tool_type))}</div><div class="portal-record-meta">${fmtDate(r.created_at)} · ${esc(toolLabel(r.tool_type))} · 오/탈/첨 ${n(r.wrong_count)}/${n(r.missing_count)}/${n(r.added_count)}</div></div>
      <div class="portal-record-score">${s!==null?`<span class="portal-badge ${cls}">${round1(s)}%</span>`:'<span class="portal-badge">기록</span>'}${r.cpm?`<span class="portal-badge">${n(r.cpm)}자</span>`:''}${withFeedback?`<button class="portal-btn primary" type="button" data-ai-feedback-record="${esc(r.id||'')}">AI 피드백</button><button class="portal-btn secondary" type="button" data-feedback-record="${esc(r.id||'')}">강사 신청</button>`:''}</div>
    </article>`;
  }
  function renderRecordList(id, records, opts={}){const root=$(id); if(!root) return; root.innerHTML=records.length?records.map(r=>recordItem(r, opts.feedback)).join(''):`<div class="portal-empty"><b>저장된 기록이 없습니다</b>중급반 공부방/고급반 공부방/급수반 공부방에서 채점/저장을 완료하면 이 영역에 표시됩니다.</div>`;}

  function averageScore(rows=[]){
    const values=rows.map(score).filter(v=>v!==null);
    return values.length?round1(values.reduce((sum,value)=>sum+value,0)/values.length):null;
  }
  function passRate(rows=[], target=90){
    const values=rows.map(score).filter(v=>v!==null);
    if(!values.length) return null;
    return Math.round(values.filter(value=>value>=target).length/values.length*100);
  }
  function summaryGradeClass(value){
    if(value===null || value===undefined) return '';
    if(Number(value)>=90) return 'good';
    if(Number(value)>=80) return 'warn';
    return 'bad';
  }
  function errorFocus(records=[]){
    const totals=errorTotals(records);
    const items=[
      {key:'wrong',label:'오자',value:n(totals.wrong),advice:'글자 선택 오류가 많습니다. 비슷한 자음·모음 조합을 따로 분리해 반복하세요.'},
      {key:'missing',label:'탈자',value:n(totals.missing),advice:'누락이 많습니다. 속도를 올리기보다 문장 끝까지 밀고 가는 안정성이 우선입니다.'},
      {key:'added',label:'첨자',value:n(totals.added),advice:'불필요한 입력이 많습니다. 손이 먼저 나가는 약어와 반복어를 점검하세요.'},
      {key:'spacing',label:'띄어쓰기',value:n(totals.spacing),advice:'띄어쓰기 오류가 보입니다. 채점 기준상 감점되는 유형부터 우선 정리하세요.'}
    ];
    const total=items.reduce((sum,item)=>sum+item.value,0);
    const top=items.slice().sort((a,b)=>b.value-a.value)[0] || items[0];
    return {totals,items,total,top};
  }
  function summaryCourseStatus(){
    const course=inferDashboardCourse();
    const meta=dashboardCourseMeta(course);
    const level=inferCurrentLevel();
    const progress=dashboardProgressLabel(course);
    const unlock=dashboardUnlockState(course);
    return {course,meta,level,progress,unlock};
  }
  function renderMyLearningSummary(){
    const today=todayRecords();
    const week=weekRecords();
    const courseStatus=summaryCourseStatus();
    const allAvg=averageScore(state.records);
    const todayAvg=averageScore(today);
    const weekAvg=averageScore(week);
    const rate=passRate(week.length?week:state.records,90);
    const weekSeconds=sumSeconds(week);
    const todaySeconds=sumSeconds(today);
    const error=errorFocus(week.length?week:state.records);
    const title=$('mySummaryMainTitle');
    const desc=$('mySummaryMainDesc');
    if(title){
      if(!state.records.length) title.textContent='아직 저장된 학습 기록이 없습니다.';
      else if(today.length) title.textContent=`오늘 ${today.length}회 학습 · ${todayAvg!==null?`평균 ${todayAvg}%`:'정확도 기록 대기'}`;
      else title.textContent=`현재 ${courseStatus.progress} 기준으로 학습 중입니다.`;
    }
    if(desc){
      if(!state.records.length) desc.textContent=`${courseStatus.meta.label}에서 채점/저장을 완료하면 오늘 학습, 최근 7일 흐름, 오류 포인트가 자동으로 정리됩니다.`;
      else if(today.length) desc.textContent=`최근 7일 ${week.length}회 · ${formatStudyDuration(weekSeconds)} 학습했습니다. 오늘 기록은 누적 관리되고 있습니다.`;
      else desc.textContent=`오늘 저장된 기록은 없습니다. 최근 7일 기준 ${week.length}회 학습했고, 다음 기록은 ${courseStatus.meta.label}에서 이어가면 됩니다.`;
    }
    const hero=$('mySummaryHeroStats');
    if(hero){
      hero.innerHTML=`
        <div class="my-summary-hero-stat"><span>현재 진도</span><b>${esc(courseStatus.progress)}</b></div>
        <div class="my-summary-hero-stat"><span>오늘 학습</span><b>${today.length}회</b></div>
        <div class="my-summary-hero-stat"><span>최근 7일</span><b>${week.length}회</b></div>
        <div class="my-summary-hero-stat"><span>평균 정확도</span><b>${allAvg!==null?allAvg+'%':'-'}</b></div>`;
    }
    const todayBox=$('myTodaySummary');
    if(todayBox){
      const calloutClass=today.length?(todayAvg!==null?summaryGradeClass(todayAvg):'good'):'warn';
      const calloutTitle=today.length?'오늘 학습 기록 저장 완료':'오늘 학습 기록 없음';
      const calloutDesc=today.length
        ? `오늘은 ${today.length}개 기록이 저장됐습니다. ${todayAvg!==null?`평균 정확도는 ${todayAvg}%입니다.`:'정확도 산출 기록은 아직 없습니다.'}`
        : `${courseStatus.meta.label}에서 1개 이상 채점/저장하면 오늘 학습으로 집계됩니다.`;
      todayBox.innerHTML=`
        <div class="my-summary-mini-grid">
          <div class="my-summary-mini"><span>오늘 시간</span><b>${esc(formatStudyDuration(todaySeconds))}</b></div>
          <div class="my-summary-mini"><span>오늘 평균</span><b>${todayAvg!==null?todayAvg+'%':'-'}</b></div>
          <div class="my-summary-mini"><span>최근 7일 시간</span><b>${esc(formatStudyDuration(weekSeconds))}</b></div>
          <div class="my-summary-mini"><span>90% 이상 비율</span><b>${rate!==null?rate+'%':'-'}</b></div>
        </div>
        <div class="my-summary-callout ${calloutClass}"><b>${esc(calloutTitle)}</b><p>${esc(calloutDesc)}</p></div>`;
    }
    const errorBox=$('myErrorSummary');
    if(errorBox){
      const max=Math.max(1,...error.items.map(item=>item.value));
      const bars=error.items.map(item=>`<div class="my-error-bar-row"><span>${esc(item.label)}</span><div class="my-error-bar-track"><div class="my-error-bar-fill" style="width:${Math.max(0,item.value/max*100)}%"></div></div><b>${item.value}</b></div>`).join('');
      if(!error.total){
        errorBox.innerHTML='<div class="portal-empty"><b>오류 데이터 없음</b>오자·탈자·첨자가 저장된 기록이 생기면 집중 관리 항목을 표시합니다.</div>';
      }else{
        errorBox.innerHTML=`
          <div class="my-summary-callout ${error.top.value>=10?'bad':'warn'}"><b>최우선 점검: ${esc(error.top.label)} ${error.top.value}개</b><p>${esc(error.top.advice)}</p></div>
          <div class="my-error-bars">${bars}</div>`;
      }
    }
    const insight=$('myInsightBox');
    if(insight){
      const unlock=courseStatus.unlock;
      const target=unlock.nextTarget?`${unlock.nextTarget.label} 승급`:'전체 승급 완료';
      const progressPercent=unlock.levels.length?Math.round(unlock.passedLevels.length/unlock.levels.length*100):0;
      const weekly=unlock.nextTarget?`이번 주 남은 응시 ${unlock.remaining}회 / 총 ${unlock.weeklyLimit}회`:'현재 열린 단계 기준으로 모든 승급 조건이 완료되었습니다.';
      const extraCards=insight.innerHTML;
      insight.innerHTML=`
        <div class="my-progress-line">
          <span>${esc(courseStatus.meta.label)}</span>
          <strong>${esc(target)}</strong>
          <div class="my-progress-track"><div class="my-progress-fill" style="width:${progressPercent}%"></div></div>
          <span>${esc(weekly)}</span>
        </div>
        ${extraCards}`;
    }
  }

  function storeKey(name){return `sorizava_${name}_${state.user?.id || sessionStorage.getItem('shorthand_user_id') || 'guest'}_v2`;}
  function readLocal(name, fallback){try{const raw=localStorage.getItem(storeKey(name)); return raw?JSON.parse(raw):fallback;}catch(e){return fallback;}}
  function writeLocal(name, value){try{localStorage.setItem(storeKey(name), JSON.stringify(value));}catch(e){console.warn('local save failed',e);}}
  function normalizeFeedbackRow(row){
    return {
      id: row.id || `fb_${Date.now()}`,
      recordId: String(row.record_id || row.recordId || ''),
      title: row.title || row.practice_title || '피드백 요청',
      toolType: row.tool_type || row.toolType || '',
      status: row.status || 'requested',
      request: row.request || row.request_text || '',
      teacherComment: row.teacher_comment || row.teacherComment || '',
      createdAt: row.created_at || row.createdAt || new Date().toISOString(),
      updatedAt: row.updated_at || row.updatedAt || new Date().toISOString()
    };
  }
  async function loadFeedback(){
    const fallback=readLocal('feedback_requests', []);
    state.feedback=fallback;
    const userId=state.user?.id || sessionStorage.getItem('shorthand_user_id');
    if(!userId || !window.SORIZAVA_SUPABASE) return;
    try{
      const {data,error}=await window.SORIZAVA_SUPABASE
        .from('feedback_requests')
        .select('*')
        .eq('user_id',userId)
        .order('created_at',{ascending:false})
        .limit(200);
      if(error) throw error;
      state.feedback=(data||[]).map(normalizeFeedbackRow);
    }catch(e){
      console.warn('feedback_requests DB 조회 실패, localStorage 기준으로 표시:', e);
      state.feedback=fallback;
    }
  }
  function saveFeedback(){writeLocal('feedback_requests', state.feedback.slice(0,200));}
  async function persistFeedback(item){
    const userId=state.user?.id || sessionStorage.getItem('shorthand_user_id');
    if(!userId || !window.SORIZAVA_SUPABASE) return null;
    try{
      const row={user_id:userId,record_id:item.recordId||null,title:item.title||null,tool_type:item.toolType||null,status:item.status||'requested',request:item.request||'',teacher_comment:item.teacherComment||'',created_at:item.createdAt,updated_at:item.updatedAt};
      const {data,error}=await window.SORIZAVA_SUPABASE.from('feedback_requests').insert(row).select().single();
      if(error) throw error;
      return normalizeFeedbackRow(data);
    }catch(e){
      console.warn('feedback_requests DB 저장 실패, localStorage에 임시 저장:', e);
      return null;
    }
  }

  function normalizeAiFeedbackRow(row){
    const meta = row.meta && typeof row.meta === 'object' ? row.meta : {};
    return {
      id: row.id || `ai_${Date.now()}`,
      recordId: String(row.record_id || ''),
      title: row.title || row.practice_title || 'AI 선생님 피드백',
      status: row.status || 'draft',
      feedbackText: row.feedback_text || row.ai_feedback_text || '',
      model: row.model || '',
      sourceMode: row.source_mode || '',
      meta,
      feedbackType: meta.feedback_type || (row.record_id ? 'single_record' : 'general'),
      createdAt: row.created_at || new Date().toISOString(),
      updatedAt: row.updated_at || row.created_at || new Date().toISOString()
    };
  }
  async function loadAiFeedback(){
    state.aiFeedback=[];
    const userId=state.user?.id || sessionStorage.getItem('shorthand_user_id');
    if(!userId || !window.SORIZAVA_SUPABASE) return;
    try{
      const {data,error}=await window.SORIZAVA_SUPABASE
        .from('ai_feedbacks')
        .select('*')
        .eq('user_id',userId)
        .order('created_at',{ascending:false})
        .limit(200);
      if(error) throw error;
      state.aiFeedback=(data||[]).map(normalizeAiFeedbackRow);
    }catch(e){
      console.warn('ai_feedbacks DB 조회 실패:', e);
      state.aiFeedback=[];
    }
  }
  async function createAiFeedbackForRecord(recordId){
    const r = state.records.find(x=>String(x.id||'')===String(recordId));
    if(!r){alert('AI 피드백을 생성할 기록을 찾지 못했습니다.'); return;}
    const existing = state.aiFeedback.find(f=>String(f.recordId)===String(recordId));
    if(existing && !confirm('이미 이 기록의 AI 피드백이 있습니다. 새로 생성하면 최신 기준으로 하나 더 생성됩니다. 계속할까요?')) return;
    const session = (await window.SORIZAVA_SUPABASE.auth.getSession())?.data?.session;
    if(!session?.access_token){alert('로그인 정보가 만료되었습니다. 다시 로그인 후 이용해 주세요.'); return;}
    const btn = document.querySelector(`[data-ai-feedback-record="${CSS.escape(String(recordId))}"]`);
    const prev = btn ? btn.textContent : '';
    if(btn){btn.disabled=true; btn.textContent='생성 중...';}
    try{
      const response = await fetch('/api/ai-feedback', {
        method:'POST',
        headers:{'Content-Type':'application/json','Authorization':`Bearer ${session.access_token}`},
        body:JSON.stringify({record_id:recordId})
      });
      const result = await response.json().catch(()=>({}));
      if(!response.ok || !result.ok) throw new Error(result.error || 'AI 피드백 생성 실패');
      await loadAiFeedback();
      renderFeedbackAll();
      renderAiFeedbackRoomList();
      alert('AI 피드백 초안이 생성되었습니다. AI 선생님 피드백방 또는 마이페이지 > 피드백 탭에서 확인할 수 있습니다.');
      if(location.pathname.toLowerCase().endsWith('mypage.html')) switchMyTab('feedback');
    }catch(e){
      console.error(e);
      alert(e.message || 'AI 피드백 생성 중 오류가 발생했습니다.');
    }finally{
      if(btn){btn.disabled=false; btn.textContent=prev || 'AI 피드백';}
    }
  }
  function todayIsoKey(){return new Date().toLocaleDateString('sv-SE',{timeZone:'Asia/Seoul'});}
  async function createScopedAiFeedback({endpoint, button, confirmMessage, successMessage, body={}}){
    if(confirmMessage && !confirm(confirmMessage)) return;
    const session = (await window.SORIZAVA_SUPABASE.auth.getSession())?.data?.session;
    if(!session?.access_token){alert('로그인 정보가 만료되었습니다. 다시 로그인 후 이용해 주세요.'); return;}
    const btn = button || null;
    const prev = btn ? btn.textContent : '';
    if(btn){btn.disabled=true; btn.textContent='생성 중...';}
    try{
      const response = await fetch(endpoint, {
        method:'POST',
        headers:{'Content-Type':'application/json','Authorization':`Bearer ${session.access_token}`},
        body:JSON.stringify(body)
      });
      const result = await response.json().catch(()=>({}));
      if(!response.ok || !result.ok) throw new Error(result.error || 'AI 피드백 생성 실패');
      await loadAiFeedback();
      renderFeedbackAll();
      renderAiFeedbackRoomList();
      renderDashboardAiTeacherSummary();
      alert(successMessage || 'AI 피드백이 생성되었습니다. 피드백 현황에서 확인할 수 있습니다.');
      if(location.pathname.toLowerCase().endsWith('mypage.html')) switchMyTab('feedback');
    }catch(e){
      console.error(e);
      alert(e.message || 'AI 피드백 생성 중 오류가 발생했습니다.');
    }finally{
      if(btn){btn.disabled=false; btn.textContent=prev;}
    }
  }
  async function createDailyAiFeedback(button){
    const todayCount=todayRecords().length;
    if(!todayCount){alert('오늘 저장된 학습 기록이 없습니다. 먼저 공부방에서 채점/저장을 완료해 주세요.'); return;}
    const existing=state.aiFeedback.find(item=>item.feedbackType==='daily' && item.meta?.date===todayIsoKey());
    await createScopedAiFeedback({
      endpoint:'/api/ai-daily-feedback',
      button,
      body:{date:todayIsoKey()},
      confirmMessage: existing?'오늘 전체 AI 피드백이 이미 있습니다. 최신 기준으로 하나 더 생성할까요?':null,
      successMessage:'오늘 전체 AI 피드백이 생성되었습니다. 피드백 현황에서 확인할 수 있습니다.'
    });
  }
  async function createGrowthAiFeedback(button){
    const weekCount=weekRecords().length;
    if(!weekCount){alert('최근 7일 저장된 학습 기록이 없습니다. 먼저 학습 기록을 저장해 주세요.'); return;}
    await createScopedAiFeedback({
      endpoint:'/api/ai-growth-feedback',
      button,
      body:{date:todayIsoKey()},
      confirmMessage:'최근 7일 기록과 이전 기록을 비교해 성장 분석 피드백을 생성할까요?',
      successMessage:'최근 7일 성장 분석 피드백이 생성되었습니다. 피드백 현황에서 확인할 수 있습니다.'
    });
  }

  function latestAiFeedback(type){
    const list=(state.aiFeedback||[]).filter(item=>String(item.feedbackType||'')===String(type||''));
    return list.sort((a,b)=>new Date(b.createdAt||0)-new Date(a.createdAt||0))[0] || null;
  }
  function renderDashboardAiTeacherSummary(){
    const status=$('dashboardAiTeacherStatus');
    const stats=$('dashboardAiTeacherStats');
    if(!status && !stats) return;
    const today=todayRecords();
    const week=weekRecords();
    const daily=latestAiFeedback('daily');
    const growth=latestAiFeedback('growth_7_days');
    const aiTotal=(state.aiFeedback||[]).length;
    const dailyToday=(state.aiFeedback||[]).find(item=>item.feedbackType==='daily' && item.meta?.date===todayIsoKey());
    if(status){
      if(!state.records.length){
        status.innerHTML='아직 저장된 기록이 없습니다. 공부방에서 첫 기록을 저장하면 <b>AI 선생님 피드백방</b>에서 분석을 받을 수 있습니다.';
      }else if(today.length && !dailyToday){
        status.innerHTML=`오늘 <b>${today.length}회</b> 기록이 있습니다. 일일 종합 피드백으로 오늘 약점과 다음 과제를 확인할 수 있습니다.`;
      }else if(dailyToday){
        status.innerHTML=`오늘 일일 분석이 준비됐습니다. 최근 생성: <b>${esc(fmtDate(dailyToday.createdAt))}</b>`;
      }else if(week.length){
        status.innerHTML=`최근 7일 <b>${week.length}회</b> 기록이 있습니다. 성장 분석으로 상승/하락 흐름을 확인할 수 있습니다.`;
      }else{
        status.innerHTML='최근 기록이 부족합니다. 오늘 기록을 저장한 뒤 AI 분석을 생성하세요.';
      }
    }
    if(stats){
      stats.innerHTML=`
        <div><span>오늘 기록</span><b>${today.length}회</b></div>
        <div><span>최근 7일</span><b>${week.length}회</b></div>
        <div><span>AI 분석</span><b>${aiTotal}건</b></div>
      `;
    }
    const dailyBtn=$('dashboardDailyAiFeedbackBtn');
    if(dailyBtn){
      dailyBtn.textContent=dailyToday?'오늘 AI 피드백 다시 생성':'오늘 전체 AI 피드백 받기';
      dailyBtn.disabled=!today.length;
      dailyBtn.title=today.length?'오늘 저장된 기록 전체를 분석합니다.':'오늘 저장된 학습 기록이 있어야 생성할 수 있습니다.';
    }
    const growthBtn=$('dashboardGrowthAiFeedbackBtn');
    if(growthBtn){
      growthBtn.disabled=!week.length;
      growthBtn.title=week.length?'최근 7일 기록과 이전 기록을 비교합니다.':'최근 7일 저장된 학습 기록이 있어야 생성할 수 있습니다.';
    }
  }
  function recentScoredRecords(limit=10){
    return (state.records||[])
      .filter(row=>score(row)!==null)
      .sort((a,b)=>new Date(a.created_at||0)-new Date(b.created_at||0))
      .slice(-limit);
  }
  function avgCpm(rows=[]){
    const values=rows.map(row=>Number(row.cpm)).filter(Number.isFinite);
    return values.length?Math.round(values.reduce((sum,value)=>sum+value,0)/values.length):null;
  }
  function bestScore(rows=[]){
    const values=rows.map(score).filter(v=>v!==null);
    return values.length?round1(Math.max(...values)):null;
  }
  function aiTeacherStatCard(label,value,meta,cls=''){
    return `<div class="ai-learning-stat ${esc(cls)}"><span>${esc(label)}</span><b>${esc(value)}</b><small>${esc(meta||'')}</small></div>`;
  }
  function renderAiTeacherWeekBars(){
    const root=$('aiTeacherWeekBars');
    if(!root) return;
    const data=dashboardWeekdaySeries();
    const hasSeconds=data.some(row=>row.seconds>0);
    const values=data.map(row=>hasSeconds?Math.ceil(row.seconds/60):row.count);
    const max=Math.max(1,...values);
    const unit=hasSeconds?'분':'회';
    root.innerHTML=data.map((row,idx)=>{
      const value=values[idx];
      const height=value?Math.max(12,value/max*100):5;
      const cls=[value?'active':'',row.isToday?'today':''].filter(Boolean).join(' ');
      return `<div class="ai-week-bar ${cls}">
        <div class="ai-week-value">${value}${unit}</div>
        <div class="ai-week-track"><div class="ai-week-fill" style="height:${height}%"></div></div>
        <div class="ai-week-label">${esc(row.label)}<small>${esc(row.date)}</small></div>
      </div>`;
    }).join('');
  }
  function renderAiTeacherAccuracyTrend(){
    const root=$('aiTeacherAccuracyTrend');
    if(!root) return;
    const rows=recentScoredRecords(10);
    if(rows.length<2){
      root.innerHTML='<div class="portal-empty compact"><b>정확도 흐름 대기</b>정확도 기록이 2개 이상 쌓이면 추세선이 표시됩니다.</div>';
      return;
    }
    const values=rows.map(row=>score(row));
    const min=Math.min(70,...values)-2;
    const max=Math.max(100,...values)+1;
    const width=460, height=150, padX=28, padY=18;
    const range=Math.max(1,max-min);
    const points=values.map((value,index)=>{
      const x=padX+(rows.length===1?0:index*(width-padX*2)/(rows.length-1));
      const y=height-padY-((value-min)/range)*(height-padY*2);
      return {x,y,value,row:rows[index]};
    });
    const poly=points.map(p=>`${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');
    const first=values[0];
    const last=values[values.length-1];
    const delta=round1(last-first);
    const cls=delta>0?'good':delta<0?'bad':'neutral';
    root.innerHTML=`<div class="ai-trend-top"><b>${round1(last)}%</b><span class="${cls}">${delta>0?'+':''}${delta}%</span></div>
      <svg class="ai-trend-svg" viewBox="0 0 ${width} ${height}" role="img" aria-label="최근 정확도 추세">
        <line x1="${padX}" y1="${height-padY}" x2="${width-padX}" y2="${height-padY}" />
        <line x1="${padX}" y1="${padY}" x2="${padX}" y2="${height-padY}" />
        <polyline points="${poly}" fill="none" />
        ${points.map(p=>`<circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="4"><title>${esc(fmtDate(p.row.created_at))} · ${round1(p.value)}%</title></circle>`).join('')}
      </svg>
      <div class="ai-trend-foot"><span>최초 ${round1(first)}%</span><span>최근 ${round1(last)}%</span></div>`;
  }
  function renderAiTeacherErrorBars(){
    const root=$('aiTeacherErrorBars');
    if(!root) return;
    const basis=weekRecords().length?weekRecords():state.records;
    const error=errorFocus(basis);
    if(!error.total){
      root.innerHTML='<div class="portal-empty compact"><b>오류 데이터 없음</b>오자·탈자·첨자 기록이 쌓이면 비중이 표시됩니다.</div>';
      return;
    }
    const rows=error.items.filter(item=>item.key!=='spacing' || item.value>0);
    const max=Math.max(1,...rows.map(item=>item.value));
    root.innerHTML=`<div class="ai-error-total"><b>${error.total}개</b><span>최근 기준 누적 오류</span></div>
      <div class="ai-error-bar-list">${rows.map(item=>{
        const pct=Math.round(item.value/error.total*100);
        return `<div class="ai-error-row"><div class="ai-error-label"><span>${esc(item.label)}</span><b>${item.value}개 · ${pct}%</b></div><div class="ai-error-track"><div class="ai-error-fill ${esc(item.key)}" style="width:${Math.max(4,item.value/max*100)}%"></div></div></div>`;
      }).join('')}</div>`;
  }
  function renderAiTeacherWeakPoint(){
    const root=$('aiTeacherWeakPoint');
    if(!root) return;
    const today=todayRecords();
    const week=weekRecords();
    const basis=week.length?week:state.records;
    const error=errorFocus(basis);
    const courseStatus=summaryCourseStatus();
    const weekAvg=averageScore(week);
    const todayAvg=averageScore(today);
    const cpm=avgCpm(basis);
    let title='기록을 먼저 쌓아야 합니다';
    let desc=`${courseStatus.meta.label}에서 채점/저장한 기록이 있어야 AI가 입력 흐름과 오류 패턴을 함께 분석합니다.`;
    let tag='기록 대기';
    if(basis.length){
      if(error.total>0){
        title=`${error.top.label} 우선 점검`;
        desc=error.top.advice;
        tag=`${error.top.value}개`;
      }else if(weekAvg!==null && weekAvg>=90){
        title='정확도 안정 구간';
        desc='최근 기록 기준 오류가 크지 않습니다. 다음 분석에서는 약어 자동화와 후반부 속도 유지 여부를 우선 확인합니다.';
        tag='90% 이상';
      }else{
        title='정확도 데이터 보강 필요';
        desc='정확도와 오류 위치가 함께 저장될수록 AI 피드백의 구간 분석 품질이 올라갑니다.';
        tag='분석 보강';
      }
    }
    const lines=[];
    if(today.length) lines.push(`오늘 ${today.length}회${todayAvg!==null?` · 평균 ${todayAvg}%`:''}`);
    if(week.length) lines.push(`최근 7일 ${week.length}회${weekAvg!==null?` · 평균 ${weekAvg}%`:''}`);
    if(cpm!==null) lines.push(`평균 속도 ${cpm}자`);
    root.innerHTML=`<div class="ai-weak-tag">${esc(tag)}</div><strong>${esc(title)}</strong><p>${esc(desc)}</p><div class="ai-weak-meta">${lines.length?lines.map(esc).join('<br>'):'기록 저장 후 자동 분석됩니다.'}</div>`;
  }
  function renderAiTeacherLearningReport(){
    const stats=$('aiTeacherLearningStats');
    const headline=$('aiTeacherLearningHeadline');
    const desc=$('aiTeacherLearningDesc');
    if(!stats && !headline && !desc && !$('aiTeacherWeekBars')) return;
    const today=todayRecords();
    const week=weekRecords();
    const courseStatus=summaryCourseStatus();
    const todayAvg=averageScore(today);
    const weekAvg=averageScore(week);
    const allAvg=averageScore(state.records);
    const weekSeconds=sumSeconds(week);
    const rate=passRate(week.length?week:state.records,90);
    const cpm=avgCpm(week.length?week:state.records);
    const best=bestScore(week.length?week:state.records);
    const error=errorFocus(week.length?week:state.records);
    if(headline){
      if(!state.records.length) headline.textContent='아직 저장된 학습 기록이 없습니다. 기록이 쌓이면 AI 피드백방에서 학습 흐름과 약점 그래프를 함께 확인할 수 있습니다.';
      else if(today.length) headline.textContent=`오늘 ${today.length}회 학습했습니다. ${todayAvg!==null?`오늘 평균 정확도는 ${todayAvg}%입니다.`:'정확도 기록이 있는 파일을 더 저장하면 분석이 정교해집니다.'}`;
      else headline.textContent=`현재 ${courseStatus.progress} 기준입니다. 최근 7일 ${week.length}회 기록을 바탕으로 학습 흐름을 정리합니다.`;
    }
    if(desc){
      desc.textContent=state.records.length
        ? 'AI 피드백은 아래 학습 기록, 정확도 흐름, 오류 비중을 함께 참고해 생성됩니다.'
        : `${courseStatus.meta.label}에서 채점/저장을 완료하면 그래프와 약점 리포트가 자동으로 채워집니다.`;
    }
    if(stats){
      stats.innerHTML=[
        aiTeacherStatCard('현재 진도',courseStatus.progress,courseStatus.meta.label),
        aiTeacherStatCard('최근 7일',`${week.length}회`,formatStudyDuration(weekSeconds)),
        aiTeacherStatCard('평균 정확도',allAvg!==null?`${allAvg}%`:'-',weekAvg!==null?`7일 평균 ${weekAvg}%`:'정확도 대기',summaryGradeClass(allAvg)),
        aiTeacherStatCard('90% 이상',rate!==null?`${rate}%`:'-',best!==null?`최고 ${best}%`:'기록 대기',rate!==null&&rate>=70?'good':rate!==null&&rate<40?'bad':''),
        aiTeacherStatCard('평균 속도',cpm!==null?`${cpm}자`:'-',cpm!==null?'최근 기록 기준':'속도 기록 대기'),
        aiTeacherStatCard('최우선 오류',error.total?`${error.top.label} ${error.top.value}개`:'없음',error.total?'AI 피드백 우선 반영':'오류 데이터 대기',error.total&&error.top.value>=10?'bad':error.total?'warn':'good')
      ].join('');
    }
    const range=$('aiTeacherLearningRange');
    if(range) range.textContent=week.length?`최근 7일 ${week.length}회`:`전체 ${state.records.length}회`;
    renderAiTeacherWeekBars();
    renderAiTeacherAccuracyTrend();
    renderAiTeacherErrorBars();
    renderAiTeacherWeakPoint();
    renderAiTeacherCoachingBoard();
  }

  function clampScore(value,min=0,max=100){
    const x=Number(value);
    if(!Number.isFinite(x)) return min;
    return Math.max(min,Math.min(max,x));
  }
  function scoreTone(value){
    if(value===null || value===undefined || value==='-') return '';
    const x=Number(value);
    if(!Number.isFinite(x)) return '';
    if(x>=80) return 'good';
    if(x>=55) return 'warn';
    return 'bad';
  }
  function recentScoreStability(rows=[]){
    const values=rows.map(score).filter(v=>v!==null);
    if(values.length<2) return 55;
    const avg=values.reduce((sum,value)=>sum+value,0)/values.length;
    const variance=values.reduce((sum,value)=>sum+Math.pow(value-avg,2),0)/values.length;
    const sd=Math.sqrt(variance);
    return clampScore(100-(sd*8),30,100);
  }
  function latestAiFeedbackText(){
    const list=(state.aiFeedback||[]).slice().sort((a,b)=>new Date(b.createdAt||0)-new Date(a.createdAt||0));
    return String(list[0]?.feedbackText || '');
  }
  function estimateAbbrevScore(records=[], error){
    if(!records.length) return null;
    const abbrRows=records.filter(row=>['random','random_dictionary','random_voice_dictionary','random_abbr_wrong_visual','random_abbr_wrong_voice'].includes(String(row.tool_type||'')) || /약어|약어장|abbrev/i.test(String(row.practice_title||'')));
    const latestText=latestAiFeedbackText();
    let base=abbrRows.length?62:50;
    if(abbrRows.length>=3) base+=12;
    if(abbrRows.length>=6) base+=8;
    if(/약어/.test(latestText)) base+=5;
    if(/약어[^\n]{0,30}(지연|오류|미숙|부족|놓친|탈자)/.test(latestText)) base-=15;
    if(error?.top?.key==='added') base-=8;
    if(error?.top?.key==='missing') base-=6;
    return Math.round(clampScore(base,35,92));
  }
  function coachingScoreCard(icon,label,value,meta,cls=''){
    return `<div class="ai-coaching-score-card ${esc(cls)}"><div class="ai-coaching-score-icon">${esc(icon)}</div><div class="ai-coaching-score-main"><span>${esc(label)}</span><b>${esc(value)}</b><small>${esc(meta||'')}</small></div></div>`;
  }
  function aiTeacherCoachingData(){
    const today=todayRecords();
    const week=weekRecords();
    const basis=week.length?week:state.records;
    const recent=recentScoredRecords(5);
    const recentAvg=averageScore(recent);
    const basisAvg=averageScore(basis);
    const rate=passRate(basis,90);
    const error=errorFocus(basis);
    const courseStatus=summaryCourseStatus();
    const stability=recentScoreStability(recent);
    const frequency=clampScore((week.length/5)*100,0,100);
    const acc=recentAvg!==null?recentAvg:(basisAvg!==null?basisAvg:0);
    const errorPerRecord=basis.length&&error.total?error.total/basis.length:0;
    const errorPenalty=clampScore(errorPerRecord*5,0,25);
    const readiness=state.records.length?Math.round(clampScore(acc*.48 + (rate??0)*.22 + stability*.18 + frequency*.12 - errorPenalty,20,100)):null;
    const promoBase=state.records.length?clampScore((recentAvg??basisAvg??0)*.55 + (rate??0)*.30 + Math.min(100,recent.length*20)*.15 - errorPenalty,10,98):null;
    const abbrev=estimateAbbrevScore(basis,error);
    const credit=creditState();
    return {today,week,basis,recent,recentAvg,basisAvg,rate,error,courseStatus,readiness,promoBase,abbrev,credit};
  }
  function renderAiTeacherCoachingScores(data){
    const root=$('aiTeacherCoachingScores');
    if(!root) return;
    if(!state.records.length){
      root.innerHTML=[
        coachingScoreCard('●','AI 진단 점수','-','첫 기록 저장 후 계산'),
        coachingScoreCard('↑','승급 가능성','-','정확도 기록 필요'),
        coachingScoreCard('⌁','약어 숙련도','-','약어 분석 대기'),
        coachingScoreCard('◇','AI 이용권',`${data.credit.balance}개`,data.credit.source==='profile'?'프로필 기준':'사용 내역 기준')
      ].join('');
      return;
    }
    const promotionLabel=data.promoBase!==null?`${Math.round(data.promoBase)}%`:'-';
    const abbrevLabel=data.abbrev!==null?`${data.abbrev}점`:'-';
    const readyMeta=data.readiness>=80?'실전 대비권':data.readiness>=60?'약점 보완 단계':'기록 보강 필요';
    const promoMeta=data.promoBase>=75?'승급 도전 검토':data.promoBase>=55?'최근 기록 보완': '승급 전 안정화';
    const abbrevMeta=data.abbrev>=80?'자동화 양호':data.abbrev>=60?'문장 적용 보완':'약어 훈련 우선';
    root.innerHTML=[
      coachingScoreCard('●','AI 진단 점수',`${data.readiness}점`,readyMeta,scoreTone(data.readiness)),
      coachingScoreCard('↑','승급 가능성',promotionLabel,promoMeta,scoreTone(data.promoBase)),
      coachingScoreCard('⌁','약어 숙련도',abbrevLabel,abbrevMeta,scoreTone(data.abbrev)),
      coachingScoreCard('◇','AI 이용권',`${data.credit.balance}개`,data.credit.source==='profile'?'프로필 기준':'사용 내역 기준',data.credit.balance>0?'good':'warn')
    ].join('');
  }
  function prescriptionForWeakness(error){
    const key=error?.top?.key;
    if(key==='wrong') return ['오자 교정','비슷한 음절·단어를 잘못 치는 구간을 묶어서 10문장 반복하세요.'];
    if(key==='missing') return ['탈자 교정','문장 끝 조사·어미를 끝까지 입력하는 짧은 문장 훈련을 먼저 진행하세요.'];
    if(key==='added') return ['첨자 교정','확실히 들은 글자만 입력하는 훈련이 필요합니다. 예측 입력을 줄이세요.'];
    if(key==='spacing') return ['띄어쓰기 정리','채점 기준상 감점되는 띄어쓰기 패턴부터 우선 정리하세요.'];
    return ['기록 누적','오류 데이터가 쌓이면 약점별 처방이 자동으로 구체화됩니다.'];
  }
  function renderAiTeacherWeeklyPrescription(data){
    const root=$('aiTeacherWeeklyPrescription');
    if(!root) return;
    if(!state.records.length){
      root.innerHTML=`<div class="ai-prescription-lead"><span class="ai-prescription-mark">1</span><div><strong>첫 기록부터 저장하세요</strong><p>${esc(data.courseStatus.meta.label)}에서 채점/저장을 완료하면 AI가 정확도·오류·입력 흐름을 함께 읽기 시작합니다.</p></div></div>
      <ul class="ai-prescription-list"><li><b>1</b><span>공부방에서 듣고치기 1개를 완료하고 기록을 저장하세요.</span></li><li><b>2</b><span>저장 후 오늘 전체 AI 피드백을 생성하면 일일 처방전이 열립니다.</span></li><li><b>3</b><span>기록이 3개 이상 쌓이면 정확도 흐름과 승급 가능성이 의미 있게 계산됩니다.</span></li></ul>`;
      return;
    }
    const [weakTitle,weakDesc]=prescriptionForWeakness(data.error);
    const leadTitle=data.rate!==null&&data.rate>=70?'승급 대비 실전 안정화':'이번 주는 약점 보완 우선';
    const leadDesc=data.error.total?`${weakTitle}이 현재 가장 큰 점검 항목입니다. 새 파일을 늘리기보다 약점 유형을 먼저 줄이는 방향이 좋습니다.`:'최근 오류가 크지 않습니다. 난도 유지 상태에서 기록 편차와 약어 자동화를 확인하세요.';
    const items=[];
    items.push(weakDesc);
    if((data.recentAvg??data.basisAvg??0)<90) items.push('90% 미만으로 나온 파일 1개를 다시 치고, 재채점 결과를 저장하세요.');
    else items.push('90% 이상 기록이 유지되고 있으니 같은 자수에서 연설·논설을 번갈아 점검하세요.');
    if(data.abbrev!==null && data.abbrev<70) items.push('약어 표시를 켠 상태에서 놓친 약어를 확인한 뒤, 같은 문장을 약어 표시 OFF로 한 번 더 치세요.');
    else items.push('약어 구간은 속도보다 자동화 확인이 우선입니다. 약어 표시 OFF 기록을 1개 이상 남기세요.');
    items.push('오늘 전체 AI 피드백을 생성해 입력 지연 구간과 실제 오류 위치가 겹치는지 확인하세요.');
    root.innerHTML=`<div class="ai-prescription-lead"><span class="ai-prescription-mark">✓</span><div><strong>${esc(leadTitle)}</strong><p>${esc(leadDesc)}</p></div></div>
      <ul class="ai-prescription-list">${items.map((item,idx)=>`<li><b>${idx+1}</b><span>${esc(item)}</span></li>`).join('')}</ul>`;
  }
  function renderAiTeacherCoachingActions(data){
    const root=$('aiTeacherCoachingActions');
    if(!root) return;
    const hasToday=data.today.length>0;
    const hasWeek=data.week.length>0;
    const actions=[
      {title:hasToday?'오늘 전체 분석 생성':'오늘 기록 먼저 저장',desc:hasToday?'오늘 기록을 묶어 공통 약점과 다음 과제를 생성합니다.':`${data.courseStatus.meta.label}에서 1개 이상 저장해야 일일 분석이 가능합니다.`,badge:hasToday?'가능':'대기',cls:hasToday?'good':'warn',href:hasToday?'#':data.courseStatus.meta.href,daily:hasToday},
      {title:'내 약점 전용 연습',desc:data.error.total?`${data.error.top.label} 중심으로 오답노트와 복습 파일을 확인하세요.`:'오류가 쌓이면 약점별 복습 경로를 안내합니다.',badge:'복습',cls:'',href:'wrong-note.html'},
      {title:hasWeek?'최근 7일 성장 분석':'성장 분석 기록 부족',desc:hasWeek?'최근 기록과 이전 흐름을 비교해 상승·하락 포인트를 봅니다.':'최근 7일 기록이 있어야 성장 분석이 가능합니다.',badge:hasWeek?'가능':'대기',cls:hasWeek?'good':'warn',href:'#',growth:hasWeek},
      {title:'선생님 확인용 요약',desc:'AI 분석 결과를 수업 지도 포인트로 연결할 수 있게 정리합니다.',badge:'공유',cls:'',href:'teacher-check.html'}
    ];
    root.innerHTML=`<div class="ai-action-stack">${actions.map(action=>{
      const attr=action.daily?' data-ai-daily-feedback':(action.growth?' data-ai-growth-feedback':'');
      const href=action.href || '#';
      return `<div class="ai-action-item"><div><strong>${esc(action.title)}</strong><p>${esc(action.desc)}</p></div><a href="${esc(href)}"${attr}><span class="portal-badge ${esc(action.cls)}">${esc(action.badge)}</span></a></div>`;
    }).join('')}</div>`;
  }
  function renderAiTeacherCoachingBoard(){
    if(!$('aiTeacherCoachingScores') && !$('aiTeacherWeeklyPrescription') && !$('aiTeacherCoachingActions')) return;
    const data=aiTeacherCoachingData();
    const status=$('aiTeacherCoachingStatus');
    if(status){
      if(!state.records.length) status.textContent='기록 대기';
      else if(data.readiness>=80) status.textContent='실전 점검';
      else if(data.readiness>=60) status.textContent='약점 보완';
      else status.textContent='기록 보강';
    }
    renderAiTeacherCoachingScores(data);
    renderAiTeacherWeeklyPrescription(data);
    renderAiTeacherCoachingActions(data);
  }

  function bindDashboardAiFeedbackActions(){
    if(document.body?.dataset.dashboardAiFeedbackBound==='1') return;
    if(document.body) document.body.dataset.dashboardAiFeedbackBound='1';
    document.addEventListener('click',event=>{
      const daily=event.target.closest('[data-ai-daily-feedback]');
      if(daily && $('dashboardAiTeacherStatus')){
        event.preventDefault();
        createDailyAiFeedback(daily);
        return;
      }
      const growth=event.target.closest('[data-ai-growth-feedback]');
      if(growth && $('dashboardAiTeacherStatus')){
        event.preventDefault();
        createGrowthAiFeedback(growth);
      }
    });
  }

  async function loadCreditLedger(){
    state.creditLedger=readLocal('credit_ledger', []);
    const userId=state.user?.id || sessionStorage.getItem('shorthand_user_id');
    if(!userId || !window.SORIZAVA_SUPABASE) return;
    try{
      const {data,error}=await window.SORIZAVA_SUPABASE
        .from('credit_ledger')
        .select('*')
        .eq('user_id',userId)
        .order('created_at',{ascending:false})
        .limit(200);
      if(error) throw error;
      state.creditLedger=data||[];
    }catch(e){
      console.warn('credit_ledger DB 조회 실패, localStorage 기준으로 표시:', e);
    }
  }
  async function loadUnlockChanceLedger(){
    state.unlockChanceLedger=[];
    const userId=state.user?.id || sessionStorage.getItem('shorthand_user_id');
    if(!userId || !window.SORIZAVA_SUPABASE) return;
    try{
      const {data,error}=await window.SORIZAVA_SUPABASE
        .from('unlock_chance_ledger')
        .select('*')
        .eq('user_id',userId)
        .order('created_at',{ascending:false})
        .limit(500);
      if(error) throw error;
      state.unlockChanceLedger=data||[];
    }catch(e){
      console.warn('승급 추가 응시권 조회 실패, 로컬 추가 횟수 기준으로 표시:', e);
      state.unlockChanceLedger=[];
    }
  }
  function creditState(){
    const p=state.profile||{};
    const profileBalance = [p.credit_balance,p.credits,p.credit].map(Number).find(Number.isFinite);
    const ledger=state.creditLedger.length?state.creditLedger:readLocal('credit_ledger', []);
    const ledgerBalance=ledger.reduce((sum,row)=>sum+n(row.amount),0);
    return { balance: Number.isFinite(profileBalance)?profileBalance:ledgerBalance, ledger, source: Number.isFinite(profileBalance)?'profile':(state.creditLedger.length?'db':'local') };
  }
  async function createFeedbackForRecord(recordId){
    const r = state.records.find(x=>String(x.id||'')===String(recordId));
    if(!r){alert('피드백을 신청할 기록을 찾지 못했습니다.'); return;}
    const existing = state.feedback.find(f=>String(f.recordId)===String(recordId) && f.status!=='closed');
    if(existing){alert('이미 진행 중인 피드백 요청이 있습니다.'); return;}
    const memo = prompt('강사에게 요청할 피드백 내용을 입력하세요.', '이 기록에서 어떤 부분을 우선 교정해야 하는지 피드백 부탁드립니다.');
    if(memo===null) return;
    const item={id:`fb_${Date.now()}`,recordId:String(recordId),title:r.practice_title||toolLabel(r.tool_type),toolType:r.tool_type,status:'requested',request:memo.trim()||'피드백 요청',teacherComment:'',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};
    const saved=await persistFeedback(item);
    state.feedback.unshift(saved||item);
    if(!saved) saveFeedback();
    renderFeedbackAll(); alert(saved?'피드백 요청이 DB에 저장되었습니다.':'피드백 요청이 임시 저장되었습니다. feedback_requests 테이블을 만들면 DB 저장으로 전환됩니다.');
  }
  function feedbackBadge(status){return {requested:['접수','warn'],assigned:['배치',''],reviewing:['피드백 중',''],done:['도착','good'],closed:['확인완료',''],draft:['AI 초안','warn'],published:['공개','good']}[status] || ['접수','warn'];}
  function aiFeedbackTypeLabel(type){return {single_record:'파일별',daily:'일일 종합',growth_7_days:'성장 분석',general:'AI'}[type] || 'AI';}
  function feedbackCard(f){const [label,cls]=feedbackBadge(f.status);return `<article class="portal-feedback-card"><div class="status"><h3>${esc(f.title)}</h3><span class="portal-badge ${cls}">${label}</span></div><p><b>요청</b> ${esc(f.request||'-')}</p>${f.teacherComment?`<p><b>답변</b> ${esc(f.teacherComment)}</p>`:''}<p class="portal-record-meta">${fmtDate(f.createdAt)} · ${esc(toolLabel(f.toolType))}</p></article>`;}
  function aiFeedbackCard(f){const [label,cls]=feedbackBadge(f.status);const typeLabel=aiFeedbackTypeLabel(f.feedbackType);return `<article class="portal-feedback-card ai-feedback-card"><div class="status"><h3>${esc(f.title)} <span class="ai-feedback-kind-chip">${esc(typeLabel)}</span></h3><span class="portal-badge ${cls}">${label}</span></div><div class="ai-feedback-text">${esc(f.feedbackText||'-').replace(/\n/g,'<br>')}</div><p class="portal-record-meta">${fmtDate(f.createdAt)} · AI 선생님 피드백${f.model?` · ${esc(f.model)}`:''}</p><p class="ai-feedback-note">AI 피드백은 학습 보조용 초안입니다. 최종 평가는 담당자 확인 기준을 우선합니다.</p></article>`;}
  function combinedFeedbackList(limit=100){
    const ai=(state.aiFeedback||[]).map(item=>({...item,kind:'ai'}));
    const manual=(state.feedback||[]).map(item=>({...item,kind:'manual'}));
    return [...ai,...manual].sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)).slice(0,limit);
  }
  function renderFeedbackBox(id, limit=3){const root=$(id); if(!root) return; const list=combinedFeedbackList(limit); root.innerHTML=list.length?list.map(item=>item.kind==='ai'?aiFeedbackCard(item):feedbackCard(item)).join(''):'<div class="portal-empty"><b>피드백이 없습니다</b>학습 기록에서 AI 피드백을 생성하거나 강사 피드백을 신청하면 여기에 표시됩니다.</div>';}
  function aiFeedbackMonthKey(item){
    const date = new Date(item?.createdAt || Date.now());
    if(Number.isNaN(date.getTime())) return '날짜 미확인';
    return date.toLocaleDateString('ko-KR',{timeZone:'Asia/Seoul',year:'numeric',month:'long'});
  }
  function aiFeedbackArchiveItem(item, index){
    const [label,cls]=feedbackBadge(item.status);
    const typeLabel=aiFeedbackTypeLabel(item.feedbackType);
    const title=esc(item.title || 'AI 선생님 피드백');
    const text=esc(item.feedbackText||'-').replace(/\n/g,'<br>');
    const date=fmtDate(item.createdAt);
    const openAttr=index===0?' open':'';
    return `<details class="ai-feedback-archive-item"${openAttr}>
      <summary>
        <span class="ai-feedback-archive-main">
          <span class="ai-feedback-archive-title">${title}</span>
          <span class="ai-feedback-archive-meta">${date} · ${esc(typeLabel)}</span>
        </span>
        <span class="ai-feedback-archive-badges">
          <span class="ai-feedback-kind-chip">${esc(typeLabel)}</span>
          <span class="portal-badge ${cls}">${label}</span>
        </span>
      </summary>
      <div class="ai-feedback-archive-body">
        <div class="ai-feedback-text">${text}</div>
        <p class="portal-record-meta">${date} · AI 선생님 피드백${item.model?` · ${esc(item.model)}`:''}</p>
      </div>
    </details>`;
  }
  function renderAiFeedbackRoomList(limit=200){
    const root=$('aiTeacherFeedbackList');
    if(!root) return;
    const filterEl=$('aiFeedbackTypeFilter');
    const currentFilter=filterEl?.value || state.aiFeedbackFilter || 'all';
    state.aiFeedbackFilter=currentFilter;
    let list=(state.aiFeedback||[]).slice().sort((a,b)=>new Date(b.createdAt||0)-new Date(a.createdAt||0));
    const total=list.length;
    if(currentFilter!=='all') list=list.filter(item=>String(item.feedbackType||'general')===currentFilter);
    list=list.slice(0,limit);
    const chip=$('aiTeacherFeedbackCount');
    if(chip) chip.textContent=currentFilter==='all'?`${total}건`:`${list.length}/${total}건`;
    if(!list.length){
      root.innerHTML='<div class="portal-empty"><b>AI 분석 결과가 없습니다</b>오늘 전체 AI 피드백이나 최근 7일 성장 분석을 생성하면 여기에 표시됩니다.</div>';
      return;
    }
    const latest=list[0];
    const archive=list.slice(1);
    const groups=archive.reduce((acc,item)=>{
      const key=aiFeedbackMonthKey(item);
      if(!acc[key]) acc[key]=[];
      acc[key].push(item);
      return acc;
    },{});
    const archiveHtml=archive.length
      ? Object.entries(groups).map(([month,items])=>`<details class="ai-feedback-month-group" open>
          <summary><span>${esc(month)}</span><b>${items.length}건</b></summary>
          <div class="ai-feedback-month-list">${items.map((item,idx)=>aiFeedbackArchiveItem(item,idx+1)).join('')}</div>
        </details>`).join('')
      : '<div class="portal-empty compact"><b>이전 분석이 없습니다</b>분석이 누적되면 이곳에 월별로 접힙니다.</div>';
    root.innerHTML=`
      <section class="ai-feedback-latest-panel" aria-label="최신 AI 분석 결과">
        <div class="ai-feedback-section-title"><span>최신 분석</span><b>1건</b></div>
        ${aiFeedbackArchiveItem(latest,0)}
      </section>
      <section class="ai-feedback-archive-panel" aria-label="이전 AI 분석 보관함">
        <div class="ai-feedback-section-title"><span>이전 분석</span><b>${archive.length}건</b></div>
        <div class="ai-feedback-archive-scroll">${archiveHtml}</div>
      </section>`;
  }
  function renderDashboardFeedbackSummary(){
    const list=combinedFeedbackList(200);
    const total=list.length;
    const needCheck=list.filter(item=>['done','published','draft'].includes(String(item.status||'')) && String(item.status||'')!=='closed').length;
    const pending=list.filter(item=>['requested','assigned','reviewing'].includes(String(item.status||''))).length;
    const totalEl=$('dashboardFeedbackTotal'); if(totalEl) totalEl.textContent=`${total}건`;
    const needEl=$('dashboardFeedbackNeedCheck'); if(needEl) needEl.textContent=`${needCheck}건`;
    const homeFeedbackChip=$('dashboardHomeFeedbackChip'); if(homeFeedbackChip) homeFeedbackChip.textContent=`${needCheck}건`;
    const pendEl=$('dashboardFeedbackPending'); if(pendEl) pendEl.textContent=`${pending}건`;
    const latestEl=$('dashboardFeedbackLatest');
    if(latestEl){
      const latest=list[0];
      latestEl.textContent=latest?`최근 피드백: ${latest.title || '피드백'} · ${fmtDate(latest.createdAt)}`:'최근 피드백이 없습니다.';
    }
  }
  function renderFeedbackAll(){renderDashboardFeedbackSummary(); renderFeedbackBox('myFeedbackList',100); renderAiFeedbackRoomList(); const total=(state.feedback?.length||0)+(state.aiFeedback?.length||0); const chip=$('feedbackCountChip'); if(chip) chip.textContent=`${total}건`; const dchip=$('dashboardFeedbackChip'); if(dchip) dchip.textContent=`${total}건`; }

  async function fetchNotice(){
    try{const {data,error}=await window.SORIZAVA_SUPABASE.from('notices').select('*').eq('is_active',true).order('created_at',{ascending:false}).limit(1); if(error) throw error; const notice=data&&data[0]?data[0].content:''; if(notice && !localStorage.getItem('notice_closed_'+todayKey())){const txt=$('noticeText'),area=$('notice-area'); if(txt) txt.textContent=notice; if(area) area.style.display='flex';}}
    catch(e){console.warn('공지 조회 실패',e);}
  }
  function closeNotice(){const area=$('notice-area'); if(area) area.style.display='none'; localStorage.setItem('notice_closed_'+todayKey(),'1');}
  function renderDashboardBrief(){
    const today=todayRecords();
    const week=weekRecords();
    const course=inferDashboardCourse();
    const meta=dashboardCourseMeta(course);
    const subtitle=$('dashboardSubtitle');
    if(subtitle){
      if(state.records.length){ subtitle.textContent=`오늘 ${today.length}회, 최근 7일 ${week.length}회 학습했습니다. 목표·요일 균형·피드백만 간결하게 확인하세요.`; }
      else { subtitle.textContent=`아직 저장된 학습 기록이 없습니다. ${meta.label}에서 첫 기록을 저장하면 목표와 요일별 흐름이 자동으로 채워집니다.`; }
    }
    renderDashboardStats();
    renderDashboardAiTeacherSummary();
    renderDashboardWeekdayChart('dashboardWeekdayChart');
    renderDashboardGoals();
  }
  window.login = async function(){
    const email=$('nameInput')?.value.trim(); const pw=$('pwInput')?.value; if(!email||!pw) return alert('이메일과 비밀번호를 입력해주세요.'); setLoading(true);
    try{await window.SorizavaAuth.signIn(email,pw); await initDashboard();}catch(e){console.error(e);alert('로그인 실패:\n'+(e.userMessage||e.message||String(e)));}finally{setLoading(false);}
  };
  window.logout = function(){ if(confirm('로그아웃 하시겠습니까?')) window.SorizavaAuth.signOut(); };

  async function initDashboard(){
    setLoading(true);
    try{
      const ctx=await requirePage(); if(!ctx) return;
      $('login-wrapper') && ($('login-wrapper').style.display='none'); $('app-wrapper') && ($('app-wrapper').style.display='flex');
      await loadRecords(); await loadFeedback(); await loadAiFeedback(); await loadCreditLedger(); await loadUnlockChanceLedger(); syncShell();
      const name=displayName();
      const nameEl=$('dashboardUserName'); if(nameEl) nameEl.textContent=name;
      const av=$('dashboardAvatar'); if(av) av.textContent=firstChar(name);
      const pn=$('dashboardProfileName'); if(pn) pn.textContent=name;
      const pm=$('dashboardProfileMeta'); if(pm) pm.textContent=`${roleLabel(state.profile?.role)} · ${state.user?.email || ''}`;
      const pl=$('dashboardProfileList'); if(pl) pl.innerHTML=profileRows();
      bindDashboardAiFeedbackActions();
      renderDashboardBrief();
      renderFeedbackAll(); fetchNotice();
    }finally{setLoading(false);}
  }

  const INTERMEDIATE_LEVELS = [110, 120, 130, 140, 150, 160, 170];
  const INTERMEDIATE_PASS_ACCURACY = 90;
  const INTERMEDIATE_PROGRESS_KEY = 'sorizava_intermediate_progress_logs_v1';
  const INTERMEDIATE_LOCAL_MATERIALS_KEY = 'sorizava_intermediate_materials_v3';
  const INTERMEDIATE_LEGACY_SOURCE_PREFIX = 'sorizava_intermediate_source_';
  const PRACTICE_MODES = { audio:'listen', reading:'view', quest:'quest' };
  Object.assign(state, {
    selectedParagraph:'all',
    currentSpeed:1,
    audioBound:false,
    smartPauseTimer:null,
    smartPaused:false,
    pacemakerTimer:null,
    pacemakerIndex:0,
    pacemakerActive:false,
    autoFinishLock:false,
    intermediateLogs:[]
  });

  function parseContent(row){
    let c=row?.content;
    if(typeof c==='string'){
      try{c=JSON.parse(c);}catch(e){c={sourceText:row.content};}
    }
    if(!c || typeof c!=='object') c={};
    return c;
  }
  function extractLevelFromTitle(title){
    const match=String(title||'').match(/(110|120|130|140|150|160|170|190|210|230|250)\s*자/);
    return match?Number(match[1]):null;
  }
  function normalizeMaterial(row, idx){
    const c=parseContent(row);
    const toolType=String(row.tool_type||c.toolType||'');
    const level=Number(c.level || row.level || extractLevelFromTitle(c.title || row.display_title || row.title));
    const baseTitle=c.title || row.display_title || row.title || `자료 ${idx+1}`;
    const title=toolType==='intermediate' ? String(baseTitle).replace(/^\s*\d+\s*자\s*/,'') : String(baseTitle);
    const audioUrl=c.audioUrl || c.audio_url || row.audio_url || c.audioDataUrl || c.audio_data_url || '';
    const sourceText=c.sourceText || c.answerText || c.text || c.source || row.source_text || '';
    return {
      id:String(row.id||c.id||`row_${idx}`),
      rowId:row.id||null,
      toolType,
      title,
      level:Number.isFinite(level)?level:null,
      category:c.category||row.category||'',
      audioUrl,
      audioDataUrl:c.audioDataUrl || c.audio_data_url || '',
      audioName:c.audioName || c.audio_name || '',
      sourceText:String(sourceText||''),
      raw:row,
      source:'supabase'
    };
  }
  function normalizeLocalIntermediateMaterial(row, idx){
    const c=parseContent(row);
    const level=Number(c.level || row.level || extractLevelFromTitle(row.title) || 110);
    const title=String(c.title || row.display_title || row.title || `${level}자 자료 ${idx+1}`).replace(/^\s*\d+\s*자\s*/,'');
    return {
      id:String(row.id||c.id||`local_intermediate_${idx}`),
      rowId:row.id||null,
      toolType:'intermediate',
      title,
      level,
      category:'중급반',
      audioUrl:c.audioUrl || c.audioDataUrl || '',
      audioDataUrl:c.audioDataUrl || '',
      audioName:c.audioName || '',
      sourceText:String(c.sourceText || c.text || ''),
      raw:row,
      source:'local'
    };
  }
  async function loadMaterials(){
    state.materials=[];
    let serverRows=[];
    try{
      const {data,error}=await window.SORIZAVA_SUPABASE
        .from('practice_materials')
        .select('*')
        .eq('is_active',true)
        .order('created_at',{ascending:false})
        .limit(700);
      if(error) throw error;
      serverRows=(data||[]).map(normalizeMaterial);
    }catch(e){
      console.warn('자료 조회 실패, 로컬 중급반 자료까지 확인:',e);
      serverRows=[];
    }
    const localIntermediate=readLocalIntermediateMaterials();
    const legacyIntermediate=readLegacyIntermediateSources();
    const merged=new Map();
    [...serverRows,...localIntermediate,...legacyIntermediate].forEach(item=>{
      const key=[item.toolType,item.rowId||item.id,item.title,item.level].join('|');
      if(!merged.has(key)) merged.set(key,item);
    });
    state.materials=Array.from(merged.values()).sort((a,b)=>{
      const ai=a.toolType==='intermediate'?0:1;
      const bi=b.toolType==='intermediate'?0:1;
      return ai-bi || n(a.level,999)-n(b.level,999) || a.title.localeCompare(b.title,'ko');
    });
  }
  function readLocalIntermediateMaterials(){
    try{
      const rows=JSON.parse(localStorage.getItem(INTERMEDIATE_LOCAL_MATERIALS_KEY)||'[]');
      return Array.isArray(rows)?rows.map(normalizeLocalIntermediateMaterial):[];
    }catch(e){return [];}
  }
  function readLegacyIntermediateSources(){
    return INTERMEDIATE_LEVELS.map(level=>{
      const text=localStorage.getItem(INTERMEDIATE_LEGACY_SOURCE_PREFIX+level);
      if(!text) return null;
      return {id:`legacy_intermediate_${level}`,rowId:null,toolType:'intermediate',title:`${level}자 기존 저장 원문`,level,category:'중급반',audioUrl:'',audioDataUrl:'',audioName:'',sourceText:text,source:'legacy'};
    }).filter(Boolean);
  }
  function pureText(text){return String(text||'').replace(/[^a-zA-Z0-9가-힣]/g,'');}
  function formatTime(seconds){const safe=Math.max(0,Number(seconds)||0); const min=Math.floor(safe/60); const sec=Math.floor(safe%60); return `${min}:${String(sec).padStart(2,'0')}`;}
  function formatClock(seconds){const safe=Math.max(0,Math.floor(Number(seconds)||0)); const min=String(Math.floor(safe/60)).padStart(2,'0'); const sec=String(safe%60).padStart(2,'0'); return `${min}:${sec}`;}
  function pureCount(text){return pureText(text).length;}
  function isPaceCountedChar(ch){return /[a-zA-Z0-9가-힣]/.test(String(ch||''));}
  function toHtmlChar(ch){if(ch===' ') return ' '; if(ch==='\n') return '<br>'; return esc(ch);}
  function audioSrc(m){return m?.audioDataUrl || m?.audioUrl || '';}
  function isIntermediateMaterial(m){return String(m?.toolType||'')==='intermediate';}
  function practiceModeForRecord(){return PRACTICE_MODES[state.currentMode] || state.currentMode;}
  function isManager(){return ['admin','administrator','super_admin','superadmin','owner','manager','operator','staff','teacher','강사','선생님','관리자','운영팀'].includes(String(state.profile?.role||'').toLowerCase());}
  function materialKey(item){return item?String(item.rowId||item.id||item.title||''):'';}
  function readProgressLogs(){
    try{const rows=JSON.parse(localStorage.getItem(INTERMEDIATE_PROGRESS_KEY)||'[]'); return Array.isArray(rows)?rows:[];}catch(e){return [];}
  }
  function writeProgressLogs(rows){
    const clean=(Array.isArray(rows)?rows:[])
      .filter(row=>row && row.level && row.materialKey)
      .sort((a,b)=>new Date(b.createdAt||0)-new Date(a.createdAt||0))
      .slice(0,800);
    localStorage.setItem(INTERMEDIATE_PROGRESS_KEY,JSON.stringify(clean));
    state.intermediateLogs=clean;
  }
  function progressLogKey(row){return [row.createdAt||'',row.level||'',row.materialKey||'',row.mode||'',row.accuracy||''].join('|');}
  function mergeProgressLogs(...groups){const map=new Map(); groups.flat().forEach(row=>{if(row&&row.level&&row.materialKey) map.set(progressLogKey(row),row);}); return Array.from(map.values());}
  function parseProgressMemo(record){
    const memo=record&&record.memo;
    if(!memo || typeof memo!=='string') return null;
    try{const parsed=JSON.parse(memo); return parsed&&parsed.kind==='intermediate_progress'?parsed:null;}catch(e){return null;}
  }
  function syncIntermediateProgressLogs(){
    const remote=(state.records||[]).filter(r=>r.tool_type==='intermediate').map(record=>{
      const meta=parseProgressMemo(record);
      if(!meta || !meta.materialKey) return null;
      return {
        id:meta.id||String(record.id||''),
        level:Number(meta.level),
        materialId:meta.materialId||'',
        materialKey:meta.materialKey||'',
        materialTitle:meta.materialTitle||record.practice_title||'',
        mode:meta.mode||'view',
        paragraph:meta.paragraph||'전체 원문',
        accuracy:Number(record.accuracy ?? record.score ?? meta.accuracy ?? 0),
        cpm:Number(record.cpm||meta.cpm||0),
        elapsed:Number(record.elapsed_seconds||meta.elapsed||0),
        wrong:Number(record.wrong_count||meta.wrong||0),
        missing:Number(record.missing_count||meta.missing||0),
        added:Number(record.added_count||meta.added||0),
        resultLabel:meta.resultLabel||'',
        createdAt:record.created_at||meta.createdAt||new Date().toISOString()
      };
    }).filter(Boolean);
    state.intermediateLogs=mergeProgressLogs(remote,readProgressLogs());
    writeProgressLogs(state.intermediateLogs);
  }
  function materialsForLevel(level){return state.materials.filter(item=>isIntermediateMaterial(item)&&Number(item.level)===Number(level));}
  function bestListenLogForMaterial(item){
    const key=materialKey(item);
    return (state.intermediateLogs||readProgressLogs())
      .filter(row=>Number(row.level)===Number(item.level)&&row.materialKey===key&&row.mode==='listen')
      .sort((a,b)=>Number(b.accuracy||0)-Number(a.accuracy||0))[0]||null;
  }
  function getLevelProgress(level){
    const list=materialsForLevel(level);
    const rows=list.map(item=>{const best=bestListenLogForMaterial(item); return {material:item,best,passed:Boolean(best&&Number(best.accuracy)>=INTERMEDIATE_PASS_ACCURACY),bestAccuracy:best?Number(best.accuracy):null};});
    const passedCount=rows.filter(row=>row.passed).length;
    return {level:Number(level),total:list.length,passedCount,rows,passed:list.length>0&&passedCount===list.length};
  }
  function isLevelUnlocked(level){
    if(isManager()) return true;
    const target=Number(level);
    if(target===INTERMEDIATE_LEVELS[0]) return true;
    for(const step of INTERMEDIATE_LEVELS){
      if(step>=target) break;
      if(!getLevelProgress(step).passed) return false;
    }
    return true;
  }
  function lockedReason(level){
    if(isLevelUnlocked(level)) return '';
    const prev=INTERMEDIATE_LEVELS[INTERMEDIATE_LEVELS.indexOf(Number(level))-1];
    if(!prev) return '잠금';
    const p=getLevelProgress(prev);
    return `${prev}자 듣고치기 ${p.passedCount}/${p.total || 0}개 통과 후 열림`;
  }
  function canUseMaterialInMode(m, mode=state.currentMode){
    const t=String(m.toolType||'');
    if(mode==='quest') return t.includes('quest');
    if(isIntermediateMaterial(m)){
      if(mode==='audio') return Boolean(audioSrc(m));
      if(mode==='reading') return Boolean(m.sourceText);
      return false;
    }
    if(mode==='audio') return t.includes('audio') || Boolean(audioSrc(m));
    if(mode==='reading') return t.includes('reading') || (!audioSrc(m) && Boolean(m.sourceText));
    return false;
  }
  function getModeRows(mode=state.currentMode){return state.materials.filter(m=>canUseMaterialInMode(m,mode));}
  function setPracticeMode(mode){
    stopAllPracticeMotion(false);
    state.currentMode=mode;
    state.selectedParagraph='all';
    state.selectedMaterial=null;
    qsa('[data-practice-tab]').forEach(btn=>btn.classList.toggle('active',btn.dataset.practiceTab===mode));
    const tools=$('practiceToolsPanel'), layout=qs('.practice-layout');
    if(mode==='tools'){ if(layout) layout.style.display='none'; if(tools) tools.style.display='block'; return; }
    if(layout) layout.style.display='grid'; if(tools) tools.style.display='none';
    updatePracticeLabels(); renderMaterialList(); resetPracticeWorkspace();
  }
  function updatePracticeLabels(){
    const label=MODE_LABEL[state.currentMode]||'연습';
    const ml=$('practiceModeLabel'); if(ml) ml.textContent=label;
    if(!state.selectedMaterial){
      const title=$('practiceTitle'); if(title) title.textContent=`${label} 자료를 선택하세요`;
      const desc=$('practiceDesc'); if(desc) desc.textContent='중급반 공부방/고급반 공부방/급수반 공부방 자료를 같은 흐름으로 사용합니다.';
    }
  }
  function renderLevelFilter(){
    const sel=$('practiceLevelFilter'); if(!sel) return;
    const existing=sel.value;
    const levels=Array.from(new Set(getModeRows().map(m=>m.level).filter(Boolean))).sort((a,b)=>a-b);
    sel.innerHTML='<option value="">전체 단계</option>'+levels.map(l=>`<option value="${l}">${l}자</option>`).join('');
    if(levels.includes(Number(existing))) sel.value=existing;
  }
  function renderMaterialList(){
    const root=$('practiceMaterialList'); if(!root) return;
    renderLevelFilter();
    const q=String($('practiceSearch')?.value||'').trim().toLowerCase();
    const level=$('practiceLevelFilter')?.value||'';
    const rows=getModeRows().filter(m=>!q || `${m.title} ${m.level||''} ${toolLabel(m.toolType)}`.toLowerCase().includes(q)).filter(m=>!level || String(m.level)===String(level));
    const chip=$('practiceMaterialCount'); if(chip) chip.textContent=`${rows.length}개`;
    if(!rows.length){root.innerHTML='<div class="portal-empty"><b>등록 자료 없음</b>이 모드에서 사용할 수 있는 자료가 없습니다. 직접 연습하기를 사용하거나 자료를 등록하세요.</div>';return;}
    root.innerHTML=rows.map(m=>{
      const intermediate=isIntermediateMaterial(m);
      const locked=intermediate && !isLevelUnlocked(m.level);
      const best=intermediate?bestListenLogForMaterial(m):null;
      const passed=best&&Number(best.accuracy)>=INTERMEDIATE_PASS_ACCURACY;
      const status=intermediate
        ? `${m.level}자 · 중급반${state.currentMode==='audio'?' 듣고치기':' 보고치기'}${passed?' · 통과':''}${best&&!passed?` · 최고 ${Number(best.accuracy).toFixed(1)}%`:''}`
        : `${m.level?m.level+'자 · ':''}${toolLabel(m.toolType)}${audioSrc(m)?' · 음원':''}${m.sourceText?' · 원문':''}`;
      return `<button type="button" class="practice-material ${state.selectedMaterial?.id===m.id?'active':''} ${intermediate?'intermediate-material':''} ${locked?'locked':''}" data-material-id="${esc(m.id)}" ${locked?'disabled':''} title="${esc(locked?lockedReason(m.level):m.title)}"><b>${locked?'🔒 ':''}${esc(m.title)}</b><span>${esc(locked?lockedReason(m.level):status)}</span></button>`;
    }).join('');
  }
  function resetPracticeWorkspace(){
    stopAllPracticeMotion(true);
    const editor=$('practiceEditor'); if(editor) editor.value='';
    const result=$('practiceResult'); if(result){result.style.display='none'; result.innerHTML='';}
    const src=$('practiceSourceBox'); if(src){src.style.display='none'; src.innerHTML='';}
    const aud=$('practiceAudioBox'); if(aud){aud.style.display='none'; aud.innerHTML='';}
    updateLiveCount();
  }
  function applyMaterial(m){
    if(isIntermediateMaterial(m) && !isLevelUnlocked(m.level)) return alert(lockedReason(m.level));
    state.selectedMaterial=m;
    state.selectedParagraph='all';
    state.autoFinishLock=false;
    const title=$('practiceTitle'); if(title) title.textContent=isIntermediateMaterial(m)?`${m.level}자 ${m.title}`:m.title;
    const desc=$('practiceDesc');
    if(desc){
      const detail=isIntermediateMaterial(m)
        ? `중급반 자료 · ${state.currentMode==='audio'?'듣고치기 통과 기록은 진도 잠금 해제에 반영됩니다.':'보고치기 페이스메이커와 단락치기를 사용할 수 있습니다.'}`
        : `${m.level?m.level+'자 · ':''}${toolLabel(m.toolType)}${m.sourceText?' · 정답 비교 가능':' · 자유 기록'}`;
      desc.textContent=detail;
    }
    resetPracticeWorkspace();
    renderPracticeAdvancedPanel();
    setupAudioPanel();
    renderPracticeSourcePanel();
    const editor=$('practiceEditor'); if(editor){editor.disabled=false; editor.placeholder=state.currentMode==='audio'?'오디오를 들으며 입력하세요. 입력을 시작하면 학습시간과 속도가 집계됩니다.':'원문을 보며 입력하세요. ESC 키 또는 채점/저장을 누르면 결과가 저장됩니다.'; editor.focus();}
    renderMaterialList();
  }
  function applyManual(){
    const title=($('manualTitle')?.value||'').trim() || `${MODE_LABEL[state.currentMode]} 직접 연습`;
    const source=($('manualSource')?.value||'').trim();
    applyMaterial({id:'manual_'+Date.now(),toolType:MODE_TOOL[state.currentMode],title,level:null,category:'직접 입력',sourceText:source,audioUrl:'',audioDataUrl:'',audioName:'',manual:true});
  }
  function renderPracticeAdvancedPanel(){
    const box=$('practiceAdvancedBox'); if(!box) return;
    const m=state.selectedMaterial;
    if(!m){box.style.display='none'; box.innerHTML=''; return;}
    const progress=isIntermediateMaterial(m)?getLevelProgress(m.level):null;
    const best=isIntermediateMaterial(m)?bestListenLogForMaterial(m):null;
    box.style.display='grid';
    box.innerHTML=`
      <div class="practice-status-card"><span>현재 모드</span><b>${esc(MODE_LABEL[state.currentMode]||'연습')}</b><small>${isIntermediateMaterial(m)?'중급반 기능 통합':'기존 자료'}</small></div>
      <div class="practice-status-card"><span>자료 기준</span><b>${m.level?`${m.level}자`:'직접'}</b><small>${pureCount(m.sourceText)}자 원문</small></div>
      <div class="practice-status-card"><span>진도 상태</span><b>${progress?`${progress.passedCount}/${progress.total}`:'-'}</b><small>${best?`듣고치기 최고 ${Number(best.accuracy).toFixed(1)}%`:'듣고치기 기록 없음'}</small></div>
      <div class="practice-status-card"><span>기능</span><b>${state.currentMode==='audio'?'스마트 일시정지':'페이스메이커'}</b><small>${state.currentMode==='audio'?'오디오 속도·3초 이동':'단락치기·자동 스크롤'}</small></div>`;
  }
  function setupAudioPanel(){
    const box=$('practiceAudioBox'); if(!box) return;
    const m=state.selectedMaterial;
    const src=audioSrc(m);
    if(state.currentMode!=='audio') { box.style.display='none'; return; }
    box.style.display='block';
    box.innerHTML=`
      <div class="practice-audio-top"><div><b>🎧 듣고치기 오디오</b><span id="practiceAudioName">${src?esc(m.audioName||'등록 오디오'):'오디오 없음'}</span></div><span class="portal-chip" id="practiceAudioLeft">0초 남음</span></div>
      <div class="practice-audio-seek"><span id="practiceCurrentTime">0:00</span><input type="range" id="practiceSeekBar" value="0" min="0" max="100" step="0.1"><span id="practiceTotalTime">0:00</span></div>
      <div class="practice-audio-controls"><button type="button" class="portal-btn secondary" id="practiceBack3">⏪ 3초</button><button type="button" class="portal-btn primary" id="practicePlayBtn">▶ 재생</button><button type="button" class="portal-btn secondary" id="practiceForward3">3초 ⏩</button><div class="practice-speed-control"><button type="button" id="practiceSpeedDown">-</button><b id="practiceAudioSpeed">1.0</b><button type="button" id="practiceSpeedUp">+</button></div></div>
      <div class="practice-smart-pause"><label><input type="checkbox" id="practiceSmartPauseToggle"> 스마트 일시정지</label><input type="number" id="practiceSmartPauseTime" value="1.5" min="0.5" max="5" step="0.1"><span>초 입력 멈춤 시 일시정지</span></div>
      ${src?'':'<div class="practice-inline-warning">이 자료에는 오디오가 없습니다. 보고치기 탭에서 사용하거나 관리자 자료에 오디오를 등록해야 합니다.</div>'}`;
    const audio=ensureAudioElement();
    audio.pause();
    audio.src=src||'';
    audio.playbackRate=state.currentSpeed||1;
    if(src) audio.load();
    bindAudioPanelEvents();
  }
  function ensureAudioElement(){
    let audio=$('practiceAudioPlayer');
    if(!audio){audio=document.createElement('audio'); audio.id='practiceAudioPlayer'; audio.preload='metadata'; document.body.appendChild(audio);}
    if(!state.audioBound){
      audio.addEventListener('loadedmetadata',()=>{const total=$('practiceTotalTime'); if(total) total.textContent=formatTime(audio.duration||0); updateAudioProgress();});
      audio.addEventListener('timeupdate',updateAudioProgress);
      audio.addEventListener('ended',()=>{const btn=$('practicePlayBtn'); if(btn) btn.textContent='▶ 재생';});
      state.audioBound=true;
    }
    return audio;
  }
  function bindAudioPanelEvents(){
    const audio=ensureAudioElement();
    $('practiceSeekBar')?.addEventListener('input',()=>{if(audio.duration) audio.currentTime=(Number($('practiceSeekBar').value)/100)*audio.duration;});
    $('practiceBack3')?.addEventListener('click',()=>skipPracticeAudio(-3));
    $('practiceForward3')?.addEventListener('click',()=>skipPracticeAudio(3));
    $('practicePlayBtn')?.addEventListener('click',togglePracticeAudio);
    $('practiceSpeedDown')?.addEventListener('click',()=>adjustPracticeSpeed(-0.1));
    $('practiceSpeedUp')?.addEventListener('click',()=>adjustPracticeSpeed(0.1));
  }
  function updateAudioProgress(){
    const audio=$('practiceAudioPlayer'); if(!audio) return;
    const seek=$('practiceSeekBar'); if(seek&&audio.duration) seek.value=(audio.currentTime/audio.duration)*100;
    const cur=$('practiceCurrentTime'); if(cur) cur.textContent=formatTime(audio.currentTime||0);
    const total=$('practiceTotalTime'); if(total) total.textContent=formatTime(audio.duration||0);
    const left=$('practiceAudioLeft'); if(left) left.textContent=`${Math.max(0,Math.floor((audio.duration||0)-(audio.currentTime||0)))}초 남음`;
  }
  function togglePracticeAudio(){
    const audio=ensureAudioElement();
    if(!audio.src) return alert('이 자료에는 등록된 오디오가 없습니다.');
    if(audio.paused){audio.play().catch(()=>{}); const btn=$('practicePlayBtn'); if(btn) btn.textContent='⏸ 정지';}
    else {audio.pause(); const btn=$('practicePlayBtn'); if(btn) btn.textContent='▶ 재생';}
  }
  function skipPracticeAudio(seconds){
    const audio=ensureAudioElement(); if(!audio.duration) return;
    audio.currentTime=Math.min(Math.max(audio.currentTime+seconds,0),audio.duration);
  }
  function adjustPracticeSpeed(amount){
    let next=Math.round(((state.currentSpeed||1)+amount)*10)/10;
    if(next<0.5) next=0.5; if(next>2) next=2;
    state.currentSpeed=next;
    const audio=ensureAudioElement(); audio.playbackRate=next;
    const label=$('practiceAudioSpeed'); if(label) label.textContent=next.toFixed(1);
  }
  function getParagraphs(text=(state.selectedMaterial?.sourceText||'')){
    const normalized=String(text||'').replace(/\r\n/g,'\n').trim();
    if(!normalized) return [];
    let chunks=normalized.split(/\n\s*\n+/).map(v=>v.trim()).filter(Boolean);
    if(chunks.length<=1) chunks=normalized.split(/\n+/).map(v=>v.trim()).filter(Boolean);
    return chunks.slice(0,5);
  }
  function getPracticeSourceText(){
    const full=state.selectedMaterial?.sourceText||'';
    if(state.currentMode==='reading' && state.selectedParagraph!=='all'){
      const paragraphs=getParagraphs(full);
      return paragraphs[Number(state.selectedParagraph)]||full;
    }
    return full;
  }
  function paragraphLabel(){return state.currentMode!=='reading'||state.selectedParagraph==='all'?'전체 원문':`${Number(state.selectedParagraph)+1}단락`;}
  function renderPracticeSourcePanel(){
    const box=$('practiceSourceBox'); if(!box) return;
    const m=state.selectedMaterial;
    if(!m || state.currentMode==='audio'){box.style.display='none'; box.innerHTML=''; return;}
    box.style.display='block';
    const paragraphs=getParagraphs(m.sourceText);
    box.innerHTML=`
      <div class="practice-source-toolbar"><div><b>📄 보고치기 원문</b><span id="practiceSourceCount">${pureCount(getPracticeSourceText())}자</span></div><div class="practice-paragraph-buttons" id="practiceParagraphButtons"></div></div>
      <div class="practice-source-readonly" id="practiceSourceReadonly"></div>
      <div class="practice-pace-status" id="practicePaceStatus">입력을 시작하면 페이스메이커가 자동으로 출발합니다.</div>`;
    const pbox=$('practiceParagraphButtons');
    if(pbox){
      if(paragraphs.length>1){
        pbox.innerHTML=['<button type="button" class="paragraph-btn" data-paragraph="all">전체</button>',...paragraphs.map((p,idx)=>`<button type="button" class="paragraph-btn" data-paragraph="${idx}">${idx+1}단락 <small>${pureCount(p)}자</small></button>`)].join('');
        pbox.querySelectorAll('[data-paragraph]').forEach(btn=>btn.addEventListener('click',()=>selectParagraph(btn.dataset.paragraph)));
      }else{
        pbox.innerHTML='<span class="paragraph-empty">단락 분리 없음</span>';
      }
    }
    paintSourceText();
  }
  function selectParagraph(value){
    state.selectedParagraph=value==='all'?'all':Number(value);
    state.autoFinishLock=false;
    stopPacemaker();
    const ed=$('practiceEditor'); if(ed) ed.value='';
    paintSourceText(); updateLiveCount();
    const result=$('practiceResult'); if(result) result.style.display='none';
  }
  function paintSourceText(){
    const box=$('practiceSourceReadonly'); if(!box) return;
    const text=getPracticeSourceText();
    if(!text.trim()) box.innerHTML='<span class="pace-empty">등록된 원문이 없습니다.</span>';
    else box.innerHTML=text.split('').map((ch,idx)=>`<span data-pace-idx="${idx}" data-pace-counted="${isPaceCountedChar(ch)?'1':'0'}">${toHtmlChar(ch)}</span>`).join('');
    const count=$('practiceSourceCount'); if(count) count.textContent=`${pureCount(text)}자`;
    qsa('.paragraph-btn').forEach(btn=>btn.classList.toggle('active',String(btn.dataset.paragraph)===String(state.selectedParagraph)));
    setPaceStatus('입력을 시작하면 페이스메이커가 자동으로 출발합니다.');
  }
  function setPaceStatus(text){const label=$('practicePaceStatus'); if(label) label.textContent=text;}
  function startPacemaker(){
    const box=$('practiceSourceReadonly'); if(state.currentMode!=='reading'||!box) return;
    const spans=Array.from(box.querySelectorAll('[data-pace-idx]'));
    const level=n(state.selectedMaterial?.level,0);
    if(!spans.length||!level) return;
    stopPacemaker(false);
    const countedPositions=spans.map((span,idx)=>span.dataset.paceCounted==='1'?idx:null).filter(idx=>idx!==null);
    if(!countedPositions.length) return;
    state.pacemakerActive=true; state.pacemakerIndex=0;
    const msPerCountedChar=60000/Math.max(1,level);
    setPaceStatus(`${level}자 페이스 진행 중 · 공백/문장부호 제외 기준`);
    const paint=()=>{
      spans.forEach(span=>span.classList.remove('pace-current','pace-passed'));
      const rawIdx=countedPositions[state.pacemakerIndex];
      if(rawIdx===undefined){stopPacemaker(false); setPaceStatus('페이스메이커 종료'); return;}
      for(let i=0;i<rawIdx;i++) spans[i]?.classList.add('pace-passed');
      const current=spans[rawIdx];
      if(current){current.classList.add('pace-current'); scrollSourceToElement(current);}
      state.pacemakerIndex+=1;
    };
    paint(); state.pacemakerTimer=setInterval(paint,msPerCountedChar);
  }
  function stopPacemaker(clearHighlight=true){
    if(state.pacemakerTimer) clearInterval(state.pacemakerTimer);
    state.pacemakerTimer=null; state.pacemakerActive=false; state.pacemakerIndex=0;
    if(clearHighlight && $('practiceSourceReadonly')){
      $('practiceSourceReadonly').querySelectorAll('span').forEach(span=>span.classList.remove('pace-current','pace-passed'));
      setPaceStatus('입력을 시작하면 페이스메이커가 자동으로 출발합니다.');
    }
  }
  function scrollSourceToElement(el){
    const box=$('practiceSourceReadonly'); if(!box||!el) return;
    const boxRect=box.getBoundingClientRect(); const elRect=el.getBoundingClientRect();
    const offset=elRect.top-boxRect.top-box.clientHeight*0.45;
    box.scrollTo({top:box.scrollTop+offset,behavior:'smooth'});
  }
  function syncSourceToTypedProgress(){
    if(state.currentMode!=='reading') return;
    const typed=Math.max(0,pureCount($('practiceEditor')?.value||'')-1);
    const target=Array.from(($('practiceSourceReadonly')||document).querySelectorAll('[data-pace-counted="1"]'))[typed];
    if(target) scrollSourceToElement(target);
  }
  function checkParagraphAutoFinish(){
    if(state.currentMode!=='reading'||state.selectedParagraph==='all'||state.autoFinishLock) return;
    const target=pureCount(getPracticeSourceText()); const typed=pureCount($('practiceEditor')?.value||'');
    if(target>0&&typed>=target){state.autoFinishLock=true; setTimeout(()=>gradePractice({paragraphAuto:true}),120);}
  }
  function startTimer(){
    if(state.timer) return;
    state.startedAt=Date.now(); state.elapsed=0;
    state.timer=setInterval(()=>{state.elapsed=Math.floor((Date.now()-state.startedAt)/1000); updateTimer(); updateSpeedStats();},500);
    updateTimer(); updateSpeedStats();
    const audio=$('practiceAudioPlayer');
    if(state.currentMode==='audio' && audio && audio.src && audio.paused){audio.play().catch(()=>{}); const btn=$('practicePlayBtn'); if(btn) btn.textContent='⏸ 정지';}
    if(state.currentMode==='reading' && !state.pacemakerActive) startPacemaker();
  }
  function stopTimer(){if(state.timer) clearInterval(state.timer); state.timer=null;}
  function resetTimer(){stopTimer(); state.startedAt=null; state.elapsed=0; updateTimer(); updateSpeedStats();}
  function updateTimer(){const el=$('practiceTimer'); if(!el) return; const s=state.elapsed||0; const mm=String(Math.floor(s/60)).padStart(2,'0'); const ss=String(s%60).padStart(2,'0'); el.textContent=`${mm}:${ss}`;}
  function updateSpeedStats(){
    const typed=pureCount($('practiceEditor')?.value||'');
    const cpm=state.elapsed>0?Math.floor(typed/(state.elapsed/60)):0;
    const live=$('practiceLiveCount'); if(live) live.textContent=`${typed}자 입력 · ${cpm}자/분`;
  }
  function handleSmartPause(){
    if(state.currentMode!=='audio') return;
    const toggle=$('practiceSmartPauseToggle'); if(!toggle||!toggle.checked) return;
    const audio=$('practiceAudioPlayer'); if(!audio||!audio.src||!state.timer) return;
    clearTimeout(state.smartPauseTimer);
    const editor=$('practiceEditor'); if(editor) editor.classList.remove('paused-warning');
    if(audio.paused && state.smartPaused){audio.play().catch(()=>{}); state.smartPaused=false;}
    const delay=Math.max(0.5,Number($('practiceSmartPauseTime')?.value||1.5))*1000;
    state.smartPauseTimer=setTimeout(()=>{
      if(!audio.paused){audio.pause(); state.smartPaused=true; if(editor) editor.classList.add('paused-warning'); const btn=$('practicePlayBtn'); if(btn) btn.textContent='▶ 재생';}
    },delay);
  }
  function updateLiveCount(){
    const ed=$('practiceEditor');
    const typed=pureCount(ed?.value||'');
    if(typed>0 && !state.timer) startTimer();
    if(typed===0){resetTimer(); stopPacemaker();}
    updateSpeedStats();
    handleSmartPause();
    syncSourceToTypedProgress();
    checkParagraphAutoFinish();
  }
  function stopAllPracticeMotion(resetElapsed){
    stopTimer(); clearTimeout(state.smartPauseTimer); state.smartPauseTimer=null; state.smartPaused=false; stopPacemaker();
    const audio=$('practiceAudioPlayer'); if(audio){audio.pause(); if(resetElapsed && audio.src) audio.currentTime=0;}
    const btn=$('practicePlayBtn'); if(btn) btn.textContent='▶ 재생';
    if(resetElapsed){state.elapsed=0; state.startedAt=null; updateTimer();}
  }
  function calculateDiff(rawO,rawS){
    if(!String(rawO||'').trim()) return {accuracy:null,wrong:0,missing:0,added:0,diffHtml:'',originalLength:null,typedLength:pureCount(rawS)};
    let pureLength=pureCount(rawO); if(pureLength===0) pureLength=1;
    const oArr=String(rawO||'').trim().split('');
    const sArr=String(rawS||'').trim().split('');
    const nLen=oArr.length, mLen=sArr.length;
    const dp=Array.from({length:nLen+1},()=>Array(mLen+1).fill(0));
    for(let i=1;i<=nLen;i++) for(let j=1;j<=mLen;j++) dp[i][j]=oArr[i-1]===sArr[j-1]?dp[i-1][j-1]+1:Math.max(dp[i-1][j],dp[i][j-1]);
    let i=nLen,j=mLen,diffs=[];
    while(i>0||j>0){
      if(i>0&&j>0&&oArr[i-1]===sArr[j-1]){diffs.push({t:'same',c:oArr[i-1]});i--;j--;}
      else if(j>0&&(i===0||dp[i][j-1]>=dp[i-1][j])){diffs.push({t:'added',c:sArr[j-1]});j--;}
      else{diffs.push({t:'missing',c:oArr[i-1]});i--;}
    }
    diffs.reverse();
    let html='',wrong=0,missing=0,added=0,mBuffer=[],aBuffer=[];
    const isSpecial=ch=>/[^0-9a-zA-Z\uAC00-\uD7A3]/.test(ch);
    function flush(){
      let mi=0,ai=0;
      while(mi<mBuffer.length||ai<aBuffer.length){
        const mc=mBuffer[mi], ac=aBuffer[ai];
        if(mi<mBuffer.length&&isSpecial(mc)){html+=`<span>${toHtmlChar(mc)}</span>`;mi++;continue;}
        if(ai<aBuffer.length&&isSpecial(ac)){html+=`<span class="diff-muted">${toHtmlChar(ac)}</span>`;ai++;continue;}
        if(mi<mBuffer.length&&ai<aBuffer.length){html+=`<span class="d-wrong">${toHtmlChar(ac)}<span class="correction">${toHtmlChar(mc)}</span></span>`;wrong++;mi++;ai++;continue;}
        if(mi<mBuffer.length){html+=`<span class="d-missing">${toHtmlChar(mc)}</span>`;missing++;mi++;continue;}
        if(ai<aBuffer.length){html+=`<span class="d-added">${toHtmlChar(ac)}</span>`;added++;ai++;}
      }
      mBuffer=[]; aBuffer=[];
    }
    diffs.forEach(item=>{if(item.t==='same'){flush(); html+=`<span>${toHtmlChar(item.c)}</span>`;} else if(item.t==='missing') mBuffer.push(item.c); else aBuffer.push(item.c);});
    flush();
    const addedPenalty=Math.floor(added/3);
    const accuracy=Math.max(0,100-((wrong+missing+addedPenalty)/pureLength*100));
    return {accuracy:round1(accuracy),wrong,missing,added,diffHtml:html,originalLength:pureLength,typedLength:pureCount(rawS)};
  }
  function getResultLabel(score,elapsed,isParagraphMode){
    if(!isParagraphMode){if(score>=98)return'GREAT'; if(score>=95)return'NICE'; return'더 연습';}
    if(elapsed>60)return'시간 초과'; if(score===100)return'PERFECT'; if(score>=98)return'GREAT'; if(score>=95)return'NICE'; return'더 연습';
  }
  function makeGradeMessage(score,elapsed,isParagraphMode){
    if(!isParagraphMode) return '일반 보고치기/듣고치기 채점 결과입니다.';
    if(elapsed>60) return `시간 초과 · ${formatClock(elapsed)} 소요 / 1분 기준을 넘었습니다.`;
    if(score===100) return 'PERFECT · 1분 안에 정확도 100%로 완료했습니다.';
    if(score>=98) return 'GREAT · 1분 안에 정확도 98% 이상으로 완료했습니다.';
    if(score>=95) return 'NICE · 1분 안에 정확도 95% 이상으로 완료했습니다.';
    return '더 연습 · 1분 안에 들어왔지만 정확도가 부족합니다.';
  }
  function saveIntermediateProgressLog(record){
    const rows=readProgressLogs(); rows.unshift(record); writeProgressLogs(rows);
    sessionStorage.setItem('sorizava_intermediate_last_result',JSON.stringify(record));
  }
  async function gradePractice(options={}){
    const ed=$('practiceEditor'); if(!ed) return;
    const typed=ed.value||''; if(!typed.trim()) return alert('작성란에 입력한 내용이 없습니다.');
    const m=state.selectedMaterial || {title:`${MODE_LABEL[state.currentMode]} 직접 연습`,toolType:MODE_TOOL[state.currentMode],sourceText:'',manual:true};
    stopAllPracticeMotion(false);
    const rawO=getPracticeSourceText() || m.sourceText || '';
    const result=calculateDiff(rawO,typed);
    const elapsed=state.elapsed || (state.startedAt?Math.floor((Date.now()-state.startedAt)/1000):0);
    const cpm=elapsed>0?Math.floor(result.typedLength/(elapsed/60)):0;
    const isIntermediate=isIntermediateMaterial(m);
    const mode=isIntermediate ? practiceModeForRecord() : state.currentMode;
    const isParagraphMode=isIntermediate && state.currentMode==='reading' && state.selectedParagraph!=='all';
    const scoreValue=result.accuracy;
    const progressRecord=isIntermediate?{
      kind:'intermediate_progress',
      id:`${Date.now()}_${Math.random().toString(16).slice(2)}`,
      level:m.level,
      materialId:m.id||'',
      materialKey:materialKey(m),
      materialTitle:m.title,
      title:m.title,
      mode,
      paragraph:paragraphLabel(),
      accuracy:Number(scoreValue||0),
      score:Number(scoreValue||0),
      cpm,
      chars:result.typedLength,
      elapsed,
      wrong:result.wrong,
      missing:result.missing,
      added:result.added,
      resultLabel:getResultLabel(Number(scoreValue||0),elapsed,isParagraphMode),
      createdAt:new Date().toISOString(),
      date:new Date().toLocaleString('ko-KR',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'})
    }:null;
    if(progressRecord) saveIntermediateProgressLog(progressRecord);
    const toolType=isIntermediate?'intermediate':MODE_TOOL[state.currentMode];
    const practiceTitle=isIntermediate?`중급반 ${m.level}자 ${m.title} ${mode==='listen'?'듣고 치기':'보고 치기'} ${paragraphLabel()}`.trim():m.title;
    let saved=null;
    if(window.SorizavaRecords){
      saved=await window.SorizavaRecords.savePracticeRecord({
        tool_type:toolType,
        practice_title:practiceTitle,
        original_length:result.originalLength,
        typed_length:result.typedLength,
        accuracy:scoreValue,
        score:scoreValue,
        cpm,
        wrong_count:result.wrong,
        missing_count:result.missing,
        added_count:result.added,
        elapsed_seconds:elapsed,
        source_text_snapshot:String(rawO||'').slice(0,12000),
        typed_text_snapshot:String(typed||'').slice(0,12000),
        diff_summary:`오자 ${result.wrong}개 / 탈자 ${result.missing}개 / 첨자 ${result.added}개`,
        memo:JSON.stringify(isIntermediate?progressRecord:{kind:'practice_room',mode:state.currentMode,materialId:m.rowId||m.id||'',manual:Boolean(m.manual)})
      });
      if(saved&&saved.created_at&&progressRecord){progressRecord.createdAt=saved.created_at; saveIntermediateProgressLog(progressRecord);}
    }
    renderGradeResult({saved,result,elapsed,cpm,isIntermediate,isParagraphMode,progressRecord});
    await loadRecords(); syncIntermediateProgressLogs(); renderMaterialList(); renderPracticeAdvancedPanel();
    renderRecordList('practiceRecentRecords', state.records.filter(r=>['practice_room_audio','practice_room_reading','quest','intermediate'].includes(r.tool_type)).slice(0,8), {feedback:true});
  }
  function renderGradeResult({saved,result,elapsed,cpm,isIntermediate,isParagraphMode,progressRecord}){
    const panel=$('practiceResult'); if(!panel) return;
    const hasSource=result.accuracy!==null;
    let passText='';
    if(isIntermediate&&progressRecord?.mode==='listen'){
      const progress=getLevelProgress(progressRecord.level);
      const next=INTERMEDIATE_LEVELS[INTERMEDIATE_LEVELS.indexOf(Number(progressRecord.level))+1];
      if(progress.passed&&next) passText=`<p class="practice-pass-note">${progressRecord.level}자 듣고치기 통과 완료 · ${next}자 자료가 열렸습니다.</p>`;
      else if(progress.passed) passText=`<p class="practice-pass-note">중급반 170자까지 통과했습니다.</p>`;
      else passText=`<p class="practice-pass-note muted">진도 잠금 해제 기준: 해당 단계 듣고치기 전체 자료 90% 이상 통과</p>`;
    }
    panel.style.display='block';
    panel.innerHTML=`
      <h3>${saved?'저장 완료':'기록 저장 시도 완료'}${hasSource?` · 정확도 ${result.accuracy}%`:''}</h3>
      <div class="practice-result-grid"><div><span>시간</span><b>${formatClock(elapsed)}</b></div><div><span>속도</span><b>${cpm}</b></div><div><span>오자</span><b>${result.wrong}</b></div><div><span>탈자/첨자</span><b>${result.missing}/${result.added}</b></div></div>
      ${hasSource?`<div class="practice-grade-message">${esc(makeGradeMessage(Number(result.accuracy||0),elapsed,isParagraphMode))}</div><details class="practice-diff-box" open><summary>상세 비교</summary><div class="diff-view">${result.diffHtml}</div></details>`:'<p>원문/정답이 없는 자료라 정확도는 계산하지 않고 기록만 저장했습니다.</p>'}
      ${passText}`;
  }
  async function initPracticeRoom(){
    setLoading(true);
    try{
      const ctx=await requirePage(); if(!ctx) return;
      $('app-wrapper') && ($('app-wrapper').style.display='flex');
      await loadRecords(); await loadFeedback(); await loadAiFeedback(); await loadCreditLedger(); await loadUnlockChanceLedger(); await loadMaterials(); syncIntermediateProgressLogs();
      const params=new URLSearchParams(location.search); const mode=params.get('mode') || (params.get('quest')?'quest':'audio'); setPracticeMode(['audio','reading','quest','tools'].includes(mode)?mode:'audio');
      renderRecordList('practiceRecentRecords', state.records.filter(r=>['practice_room_audio','practice_room_reading','quest','intermediate'].includes(r.tool_type)).slice(0,8), {feedback:true});
      qsa('[data-practice-tab]').forEach(btn=>btn.addEventListener('click',()=>setPracticeMode(btn.dataset.practiceTab)));
      $('practiceSearch')?.addEventListener('input',renderMaterialList);
      $('practiceLevelFilter')?.addEventListener('change',renderMaterialList);
      $('manualApplyBtn')?.addEventListener('click',applyManual);
      $('practiceEditor')?.addEventListener('input',updateLiveCount);
      $('practiceResetBtn')?.addEventListener('click',()=>{const ed=$('practiceEditor'); if(ed) ed.value=''; resetTimer(); stopPacemaker(); const audio=$('practiceAudioPlayer'); if(audio){audio.pause(); if(audio.src) audio.currentTime=0;} updateLiveCount(); $('practiceResult')&&($('practiceResult').style.display='none');});
      qsa('[data-practice-grade]').forEach(btn=>btn.addEventListener('click',()=>gradePractice()));
      document.addEventListener('click',e=>{const mbtn=e.target.closest('[data-material-id]'); if(mbtn){const m=state.materials.find(x=>x.id===mbtn.dataset.materialId); if(m) applyMaterial(m);} const fb=e.target.closest('[data-feedback-record]'); if(fb) createFeedbackForRecord(fb.dataset.feedbackRecord); const ai=e.target.closest('[data-ai-feedback-record]'); if(ai) createAiFeedbackForRecord(ai.dataset.aiFeedbackRecord);});
      window.addEventListener('keydown',e=>{if(e.key==='Escape' && $('practiceEditor')?.value.trim()) gradePractice();});
    }finally{setLoading(false);}
  }

  function switchMyTab(tab){
    const safe=tab||'summary'; qsa('[data-my-tab]').forEach(b=>b.classList.toggle('active',b.dataset.myTab===safe)); qsa('.my-tab-panel').forEach(p=>p.classList.toggle('active',p.id===`my-${safe}`));
    if(location.hash.slice(1)!==safe) history.replaceState(null,'','#'+safe);
  }
  function renderInsight(){
    const root=$('myInsightBox'); if(!root) return; const ins=state.summary?.insight||{};
    const cards=[]; if(ins.progressStatus) cards.push(`<div class="portal-feedback-card"><div class="status"><h3>${esc(ins.progressStatus.label||'진도 상태')}</h3><span class="portal-badge">진도</span></div><p>${esc(ins.progressStatus.message||'기록이 쌓이면 자동 분석됩니다.')}</p></div>`);
    if(ins.dominantError) cards.push(`<div class="portal-feedback-card"><div class="status"><h3>주요 오류: ${esc(ins.dominantError.label||'오류')}</h3><span class="portal-badge bad">${n(ins.dominantError.count)}개</span></div><p>${esc((ins.recommendation||[])[0]||'오류 기록이 쌓이면 보강 방향을 제시합니다.')}</p></div>`);
    root.innerHTML=cards.length?cards.join(''):'<div class="portal-empty"><b>분석 대기</b>연습 기록이 쌓이면 진도와 오류 유형을 자동 분석합니다.</div>';
  }
  function renderRecordTable(){
    const root=$('myRecordTable'); if(!root) return;
    const types=Array.from(new Set(state.records.map(r=>r.tool_type||'unknown')));
    const pills=$('recordFilterPills'); if(pills){pills.innerHTML=`<button type="button" data-record-filter="all" class="${state.myFilter==='all'?'active':''}">전체</button>`+types.map(t=>`<button type="button" data-record-filter="${esc(t)}" class="${state.myFilter===t?'active':''}">${esc(toolLabel(t))}</button>`).join('');}
    const rows=(state.myFilter==='all'?state.records:state.records.filter(r=>r.tool_type===state.myFilter));
    if(!rows.length){root.innerHTML='<div class="portal-empty"><b>기록 없음</b>선택한 조건에 해당하는 기록이 없습니다.</div>';return;}
    root.innerHTML=`<table class="portal-table"><thead><tr><th>일시</th><th>종류</th><th>제목</th><th>정확도</th><th>속도</th><th>오/탈/첨</th><th>피드백</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${fmtDate(r.created_at)}</td><td>${esc(toolLabel(r.tool_type))}</td><td class="title-cell">${esc(r.practice_title||'-')}</td><td>${score(r)!==null?round1(score(r))+'%':'-'}</td><td>${r.cpm?esc(r.cpm)+'자':'-'}</td><td>${n(r.wrong_count)}/${n(r.missing_count)}/${n(r.added_count)}</td><td><div class="record-feedback-actions"><button class="portal-btn primary" type="button" data-ai-feedback-record="${esc(r.id||'')}">AI 피드백</button><button class="portal-btn secondary" type="button" data-feedback-record="${esc(r.id||'')}">강사 신청</button></div></td></tr>`).join('')}</tbody></table>`;
  }
  function localDiffSegments(original, typed, maxItems=6){
    const source=String(original||'').trim();
    const input=String(typed||'').trim();
    if(!source || !input) return [];
    const oArr=source.split('');
    const sArr=input.split('');
    const nLen=oArr.length, mLen=sArr.length;
    const dp=Array.from({length:nLen+1},()=>Array(mLen+1).fill(0));
    for(let i=1;i<=nLen;i+=1){
      for(let j=1;j<=mLen;j+=1){
        dp[i][j]=oArr[i-1]===sArr[j-1]?dp[i-1][j-1]+1:Math.max(dp[i-1][j],dp[i][j-1]);
      }
    }
    let i=nLen,j=mLen;
    const diffs=[];
    while(i>0||j>0){
      if(i>0&&j>0&&oArr[i-1]===sArr[j-1]){diffs.unshift({t:'same',c:oArr[i-1],idx:i-1});i-=1;j-=1;}
      else if(j>0&&(i===0||dp[i][j-1]>=dp[i-1][j])){diffs.unshift({t:'added',c:sArr[j-1],idx:Math.max(0,i)});j-=1;}
      else{diffs.unshift({t:'missing',c:oArr[i-1],idx:i-1});i-=1;}
    }
    const out=[];
    let missing='', added='', pos=0;
    function push(){
      if(!missing && !added) return;
      const len=Math.max(missing.length,added.length);
      for(let k=0;k<len&&out.length<maxItems;k+=1){
        const expected=missing[k]||'';
        const actual=added[k]||'';
        const type=expected&&actual?'wrong':expected?'missing':'added';
        const center=Math.max(0,pos);
        out.push({type,expected,actual,context:source.slice(Math.max(0,center-12),Math.min(source.length,center+18))});
      }
      missing=''; added='';
    }
    diffs.forEach(item=>{
      if(item.t==='same'){push(); pos=item.idx+1;}
      else if(item.t==='missing'){if(!missing&&!added) pos=item.idx; missing+=item.c;}
      else if(item.t==='added'){if(!missing&&!added) pos=item.idx; added+=item.c;}
    });
    push();
    return out;
  }
  function wrongRecordSegments(record){
    const memo=parseRecordMemo(record)||{};
    const source=record.source_text_snapshot||memo.sourceText||memo.originalText||memo.original||'';
    const typed=record.typed_text_snapshot||memo.typedText||memo.submittedText||memo.submitted||'';
    const segments=localDiffSegments(source,typed,6);
    if(segments.length) return segments;
    const fallback=[];
    if(n(record.wrong_count)>0) fallback.push({type:'wrong',expected:'',actual:'',context:'오자가 기록된 자료입니다. 원문 대비 다른 글자를 우선 복습하세요.'});
    if(n(record.missing_count)>0) fallback.push({type:'missing',expected:'',actual:'',context:'탈자가 기록된 자료입니다. 빠뜨린 조사·어미·반복어를 확인하세요.'});
    if(n(record.added_count)>0) fallback.push({type:'added',expected:'',actual:'',context:'첨자가 기록된 자료입니다. 불필요하게 추가한 입력을 줄이는 연습이 필요합니다.'});
    return fallback.slice(0,3);
  }
  function wrongSegmentLabel(type){return type==='missing'?'탈자':type==='added'?'첨자':'오자';}
  function wrongRecordPriority(record){
    const total=n(record.wrong_count)+n(record.missing_count)+n(record.added_count)+n(record.spacing_error_count);
    const s=score(record);
    if(s!==null&&s<90) return '재연습 필요';
    if(total>=10) return '집중 관리';
    return '부분 복습';
  }

  function renderWrongNote(){
    const root=$('myWrongNote'); if(!root) return;
    const rows=state.records.filter(r=>n(r.wrong_count)+n(r.missing_count)+n(r.added_count)+n(r.spacing_error_count)>0).slice(0,30);
    if(!rows.length){root.innerHTML='<div class="portal-empty"><b>오답 기록이 없습니다</b>오자/탈자/첨자가 저장된 기록이 생기면 자동으로 모입니다.</div>';return;}
    const focus=errorFocus(rows);
    root.innerHTML=`<section class="wrong-management-summary">
      <div><span>관리 대상</span><b>${rows.length}건</b></div>
      <div><span>총 오류</span><b>${focus.total}개</b></div>
      <div><span>우선 유형</span><b>${esc(focus.top.label)}</b></div>
      <p>${esc(focus.top.advice)}</p>
    </section>` + rows.map(r=>{
      const segments=wrongRecordSegments(r);
      return `<article class="wrong-card managed">
        <div class="wrong-card-head">
          <div><b>${esc(r.practice_title||toolLabel(r.tool_type))}</b><span>${fmtDate(r.created_at)} · ${esc(toolLabel(r.tool_type))} · ${wrongRecordPriority(r)}</span></div>
          <div class="portal-record-score"><span class="portal-badge bad">오 ${n(r.wrong_count)}</span><span class="portal-badge warn">탈 ${n(r.missing_count)}</span><span class="portal-badge">첨 ${n(r.added_count)}</span></div>
        </div>
        <div class="wrong-detail-grid">${segments.map(seg=>`<div class="wrong-detail-chip ${esc(seg.type)}"><span>${esc(wrongSegmentLabel(seg.type))}</span><strong>${esc(seg.context||'복습 문맥 없음')}</strong>${seg.expected||seg.actual?`<small>입력 ${esc(seg.actual||'없음')} → 목표 ${esc(seg.expected||'삭제')}</small>`:''}</div>`).join('')}</div>
        <div class="wrong-card-actions"><a class="portal-btn primary" href="wrong-note.html">오답 랜덤 복습</a>${r.id?`<button class="portal-btn secondary" type="button" data-ai-feedback-record="${esc(r.id)}">AI 피드백</button>`:''}</div>
      </article>`;
    }).join('');
  }
  function renderMyActionPlan(){
    const root=$('myActionPlan');
    if(!root) return;
    const chip=$('myActionPlanChip');
    const today=todayRecords();
    const week=weekRecords();
    const courseStatus=summaryCourseStatus();
    const todayAvg=averageScore(today);
    const weekAvg=averageScore(week);
    const error=errorFocus(week.length?week:state.records);
    const weekday=dashboardWeekdaySeries();
    const activeDays=weekday.filter(row=>row.count>0 || row.seconds>0).length;
    const feedbackList=combinedFeedbackList(200);
    const needFeedbackCheck=feedbackList.filter(item=>['done','published','draft'].includes(String(item.status||''))).length;
    const actions=[];
    const pushAction=(type,icon,title,desc,cta,attrs)=>actions.push({type,icon,title,desc,cta,attrs});

    if(!state.records.length){
      pushAction('priority','①','첫 학습 기록 만들기',`${courseStatus.meta.label}에서 채점/저장을 1회 완료하면 요약 데이터가 자동으로 누적됩니다.`,'공부방 가기',`href="${esc(courseStatus.meta.href)}"`);
    }else if(!today.length){
      pushAction('priority','①','오늘 기록 1개 저장',`오늘은 아직 저장된 기록이 없습니다. ${courseStatus.meta.label}에서 1개만 먼저 완료하세요.`,'공부방 가기',`href="${esc(courseStatus.meta.href)}"`);
    }else if(todayAvg!==null && todayAvg<90){
      pushAction('priority','①','90% 미만 기록 보완',`오늘 평균 정확도 ${todayAvg}%입니다. 속도보다 정확도 회복을 우선해야 합니다.`,'오답 관리',`href="#wrongnote" data-open-my-tab="wrongnote"`);
    }else{
      pushAction('good','①','오늘 기본 학습 완료',todayAvg!==null?`오늘 평균 정확도 ${todayAvg}%입니다. 다음은 승급/오류 보완으로 넘어가면 됩니다.`:`오늘 기록이 저장됐습니다. 정확도 기록이 있는 자료도 함께 저장하면 분석 정확도가 올라갑니다.`,'기록 보기',`href="#records" data-open-my-tab="records"`);
    }

    const unlock=courseStatus.unlock;
    if(unlock.nextTarget){
      if(unlock.remaining>0){
        pushAction('normal','②','승급 응시 가능',`${unlock.nextTarget.label} 승급 기준입니다. 이번 주 무료 응시 ${unlock.remaining}회가 남아 있습니다.`,'승급실 가기',`href="${esc(unlock.href)}"`);
      }else{
        pushAction('warn','②','이번 주 승급 응시 소진',`무료 ${unlock.freeLimit}회를 모두 사용했습니다. 추가 응시는 크레딧 연결 구조에서 처리하면 됩니다.`,'계정 확인',`href="#plan" data-open-my-tab="plan"`);
      }
    }else{
      pushAction('good','②','승급 단계 완료','현재 기준으로 열려 있는 승급 단계가 모두 완료된 상태입니다. 다음 학습은 실전 유지 관리 중심으로 잡으면 됩니다.','학습 기록',`href="#records" data-open-my-tab="records"`);
    }

    if(error.total>0){
      pushAction(error.top.value>=10?'warn':'normal','③',`${error.top.label} 우선 교정`,`${error.top.advice} 최근 기준 ${error.top.value}개가 누적됐습니다.`,'오답 관리',`href="#wrongnote" data-open-my-tab="wrongnote"`);
    }else{
      pushAction('normal','③','오류 데이터 수집 대기','오자·탈자·첨자가 저장된 기록이 생기면 우선 교정 항목을 자동으로 잡아줍니다.','기록 보기',`href="#records" data-open-my-tab="records"`);
    }

    if(needFeedbackCheck>0){
      pushAction('normal','④','피드백 확인',`확인할 피드백이 ${needFeedbackCheck}건 있습니다. 답변 확인 후 같은 유형을 다시 채점하세요.`,'피드백 보기',`href="#feedback" data-open-my-tab="feedback"`);
    }else if(activeDays<3 && week.length){
      pushAction('warn','④','학습 요일 분산 필요',`최근 7일 중 ${activeDays}일만 학습했습니다. 몰아서 하기보다 최소 3일 이상으로 나누는 편이 안정적입니다.`,'기록 보기',`href="#records" data-open-my-tab="records"`);
    }else{
      pushAction('normal','④','루틴 유지',weekAvg!==null?`최근 7일 평균 정확도 ${weekAvg}%입니다. 같은 패턴으로 기록을 누적하면 됩니다.`:`최근 7일 기록이 집계되고 있습니다. 정확도 산출 자료를 더 저장하면 처방이 구체화됩니다.`,'공부방 가기',`href="${esc(courseStatus.meta.href)}"`);
    }

    if(chip){
      const priorityCount=actions.filter(item=>item.type==='priority' || item.type==='warn').length;
      chip.textContent=priorityCount?`점검 ${priorityCount}개`:'양호';
      chip.classList.toggle('good', !priorityCount);
      chip.classList.toggle('warn', !!priorityCount);
    }
    root.innerHTML=actions.map(item=>`
      <article class="my-action-item ${esc(item.type)}">
        <div class="my-action-no">${esc(item.icon)}</div>
        <div class="my-action-copy"><strong>${esc(item.title)}</strong><p>${esc(item.desc)}</p></div>
        <a class="my-action-link" ${item.attrs}>${esc(item.cta)}</a>
      </article>`).join('');
  }

  function renderPlan(){
    const plan=$('myPlanBox'); if(plan){const c=creditState(); plan.innerHTML=`<div class="portal-feedback-card"><div class="status"><h3>현재 크레딧</h3><span class="portal-badge ${c.balance>0?'good':''}">${c.balance}개</span></div><p>${c.source==='profile'?'프로필에 저장된 크레딧 값을 표시합니다.':(c.source==='db'?'credit_ledger DB 사용 내역 기준으로 표시합니다.':'원본에 크레딧 전용 테이블이 없어 사용자별 로컬 사용 내역 기준으로 표시합니다.')}</p></div><div class="portal-feedback-card"><div class="status"><h3>피드백 요청</h3><span class="portal-badge">${state.feedback.length}건</span></div><p>학습 기록에서 피드백을 신청하면 이 사용자의 피드백 목록에 저장됩니다.</p></div>`;}
    const settings=$('mySettingsBox'); if(settings) settings.innerHTML=profileRows();
  }
  async function renderMyPage(){
    const name=displayName(); $('mypageTitle') && ($('mypageTitle').textContent=`${name}님의 학습 관리`); $('myAvatar') && ($('myAvatar').textContent=firstChar(name)); $('myName') && ($('myName').textContent=name); $('myMeta') && ($('myMeta').textContent=`${roleLabel(state.profile?.role)} · ${state.user?.email||''}`); $('myProfileList') && ($('myProfileList').innerHTML=profileRows());
    renderMetrics('myMetricGrid'); renderInsight(); renderMyLearningSummary(); renderMyActionPlan(); renderRecordTable(); renderFeedbackAll(); renderWrongNote(); renderPlan();
  }
  async function initMyPage(){
    setLoading(true);
    try{const ctx=await requirePage(); if(!ctx) return; $('app-wrapper') && ($('app-wrapper').style.display='flex'); await loadRecords(); await loadFeedback(); await loadAiFeedback(); await loadCreditLedger(); await loadUnlockChanceLedger(); await renderMyPage(); switchMyTab(location.hash.replace('#','')||'summary');
      qsa('[data-my-tab]').forEach(btn=>btn.addEventListener('click',()=>switchMyTab(btn.dataset.myTab))); qsa('[data-open-my-tab]').forEach(btn=>btn.addEventListener('click',()=>switchMyTab(btn.dataset.openMyTab)));
      document.addEventListener('click',e=>{const openTab=e.target.closest('[data-open-my-tab]'); if(openTab){e.preventDefault(); switchMyTab(openTab.dataset.openMyTab);} const daily=e.target.closest('[data-ai-daily-feedback]'); if(daily){createDailyAiFeedback(daily); return;} const growth=e.target.closest('[data-ai-growth-feedback]'); if(growth){createGrowthAiFeedback(growth); return;} const f=e.target.closest('[data-record-filter]'); if(f){state.myFilter=f.dataset.recordFilter; qsa('[data-record-filter]').forEach(b=>b.classList.toggle('active',b===f)); renderRecordTable();} const fb=e.target.closest('[data-feedback-record]'); if(fb) createFeedbackForRecord(fb.dataset.feedbackRecord); const ai=e.target.closest('[data-ai-feedback-record]'); if(ai) createAiFeedbackForRecord(ai.dataset.aiFeedbackRecord);});
      window.addEventListener('hashchange',()=>switchMyTab(location.hash.replace('#','')||'summary'));
    }finally{setLoading(false);}
  }
  async function initAiTeacherPage(){
    setLoading(true);
    try{
      const ctx=await requirePage(); if(!ctx) return;
      $('app-wrapper') && ($('app-wrapper').style.display='flex');
      await loadRecords(); await loadFeedback(); await loadAiFeedback(); await loadCreditLedger(); await loadUnlockChanceLedger(); syncShell();
      bindDashboardAiFeedbackActions();
      const typeFilter=$('aiFeedbackTypeFilter');
      if(typeFilter && !typeFilter.dataset.bound){
        typeFilter.dataset.bound='1';
        typeFilter.addEventListener('change',()=>{ state.aiFeedbackFilter=typeFilter.value || 'all'; renderAiFeedbackRoomList(); });
      }
      renderDashboardAiTeacherSummary();
      renderAiTeacherLearningReport();
      renderAiTeacherCoachingBoard();
      renderAiFeedbackRoomList();
      renderFeedbackAll();
    }finally{setLoading(false);}
  }
  async function refreshMyPage(){await loadRecords(); await loadFeedback(); await loadAiFeedback(); await loadCreditLedger(); await loadUnlockChanceLedger(); await renderMyPage();}

  window.SorizavaPortal = { initDashboard, initPracticeRoom, initMyPage, initAiTeacherPage, refreshMyPage, closeNotice };
})();
