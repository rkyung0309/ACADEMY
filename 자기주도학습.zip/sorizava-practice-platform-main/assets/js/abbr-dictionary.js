(function () {
  const STORAGE_KEY = 'sorizava_abbr_dictionary_v2';
  const LAST_WORD_KEY = 'sorizava_abbr_dictionary_last_word';
  const KEYMAP_VERSION_KEY = 'sorizava_abbr_dictionary_keymap_version';
  const CURRENT_KEYMAP_VERSION = '20260612-hyphen-k-left-kk';
  const DEFAULT_DICT_PATH = 'assets/data/zvdicKor_sori.txt';
  const DEFAULT_COLOR = '#DCE8FF';
  const DEFAULT_BORDER = '#7FA7FF';

  const LEFT_KEY_MAP = {
    'ㄱ': 'key_l_g', 'ㄲ': 'key_l_kk', 'ㄴ': 'key_l_n', 'ㄷ': 'key_l_d', 'ㄹ': 'key_l_r',
    'ㅁ': 'key_l_side_m', 'ㅂ': 'key_l_b', 'ㅅ': 'key_l_side_s', 'ㅈ': 'key_l_j',
    'ㅊ': 'key_l_side_ch', 'ㅋ': 'key_l_k', 'ㅌ': 'key_l_t', 'ㅍ': 'key_l_p', 'ㅎ': 'key_l_h'
  };
  const RIGHT_KEY_MAP = {
    'ㄱ': 'key_r_g', 'ㄲ': 'key_r_gg', 'ㄴ': 'key_r_n', 'ㄷ': 'key_r_d', 'ㄹ': 'key_r_r',
    'ㅁ': 'key_r_m', 'ㅂ': 'key_r_side_b', 'ㅅ': 'key_r_s', 'ㅆ': 'key_r_ss', 'ㅇ': 'key_r_ng',
    'ㅈ': 'key_r_side_j', 'ㅊ': 'key_r_ch', 'ㅋ': 'key_l_kk', 'ㅌ': 'key_r_t', 'ㅍ': 'key_r_side_p', 'ㅎ': 'key_r_h'
  };
  const VOWEL_KEY_MAP = {
    'ㅏ': ['key_thumb_a'], 'ㅓ': ['key_thumb_eo'], 'ㅗ': ['key_thumb_o'], 'ㅜ': ['key_thumb_u'], 'ㅡ': ['key_thumb_eu'], 'ㅣ': ['key_thumb_i'],
    'ㅢ': ['key_thumb_eu', 'key_thumb_i'], 'ㅐ': ['key_thumb_a', 'key_thumb_i'], 'ㅔ': ['key_thumb_eo', 'key_thumb_i'],
    'ㅚ': ['key_thumb_o', 'key_thumb_i'], 'ㅘ': ['key_thumb_o', 'key_thumb_a'], 'ㅙ': ['key_thumb_o', 'key_thumb_a', 'key_thumb_i'],
    'ㅝ': ['key_thumb_u', 'key_thumb_eo'], 'ㅞ': ['key_thumb_u', 'key_thumb_eo', 'key_thumb_i'], 'ㅟ': ['key_thumb_u', 'key_thumb_i'],
    'ㅑ': ['key_thumb_a'], 'ㅕ': ['key_thumb_eo'], 'ㅛ': ['key_thumb_o'], 'ㅠ': ['key_thumb_u'], 'ㅒ': ['key_thumb_a', 'key_thumb_i'], 'ㅖ': ['key_thumb_eo', 'key_thumb_i']
  };

  const state = {
    entries: [],
    selectedKeys: [],
    editingId: null,
    currentEntry: null,
    keyboardReady: false,
    svgRoot: null,
    filteredEntries: [],
    highlightColor: DEFAULT_COLOR,
    sortDir: 'asc',
    selectionMode: 'entry',
    keyboardMatchEntries: [],
  };

  const $ = (id) => document.getElementById(id);
  const els = {};

  document.addEventListener('DOMContentLoaded', () => {
    cacheEls();
    bindEvents();
    initAuth();
    initPage();
  });

  function cacheEls() {
    [
      'keyboardMount','dictWord','dictKeys','dictNote','searchWord','searchAbbr','entryCount','selectedCount','searchCount','lastUpdated',
      'selectedChips','statusMsg','importFile','highlightColor','tableBody','currentWordLabel','currentMetaLabel','sortOutputBtn','sortOutputIcon',
      'resetSelectionBtn','saveEntryBtn','clearFormBtn','exportJsonBtn','downloadCsvBtn','clearAllBtn','applyKeysBtn','copyKeysBtn','defaultDictBtn'
    ].forEach(id => els[id] = $(id));
  }

  function bindEvents() {
    els.highlightColor?.addEventListener('input', (e) => {
      state.highlightColor = e.target.value || DEFAULT_COLOR;
      updateHighlightStyle();
    });
    els.dictKeys?.addEventListener('input', syncSelectionFromTextarea);
    els.dictWord?.addEventListener('input', updateSelectionUI);
    els.searchWord?.addEventListener('input', renderTable);
        els.sortOutputBtn?.addEventListener('click', toggleOutputSort);
    els.importFile?.addEventListener('change', handleImportFile);
    els.resetSelectionBtn?.addEventListener('click', clearSelection);
    els.clearFormBtn?.addEventListener('click', clearForm);
    els.saveEntryBtn?.addEventListener('click', saveEntry);
    els.exportJsonBtn?.addEventListener('click', exportJson);
    els.downloadCsvBtn?.addEventListener('click', exportCsv);
    els.clearAllBtn?.addEventListener('click', clearAllEntries);
    els.applyKeysBtn?.addEventListener('click', syncSelectionFromTextarea);
    els.copyKeysBtn?.addEventListener('click', copyKeys);
    els.defaultDictBtn?.addEventListener('click', () => loadBundledDictionary({ silent: false, force: true }));
  }

  async function initPage() {
    state.entries = migrateStoredKeyMappings(readEntries());
    await loadKeyboard();
    if (!state.entries.length) await loadBundledDictionary({ silent: true, force: false });
    renderStats();
    renderTable();
    updateSelectionUI();
    restoreLastWord();
  }

  function initAuth() {
    if (window.SorizavaAuth && document.body.dataset.auth === 'approved') {
      window.SorizavaAuth.requireApproved({ redirect: true }).catch(() => { location.href = 'index.html'; });
    }
    const currentUser = sessionStorage.getItem('shorthand_user') || 'User';
    const nameEl = document.getElementById('sideUserName');
    if (nameEl) nameEl.textContent = currentUser;
  }

  async function loadKeyboard() {
    try {
      const res = await fetch('assets/img/steno-keyboard.svg');
      const svgText = await res.text();
      els.keyboardMount.innerHTML = svgText;
      state.svgRoot = els.keyboardMount.querySelector('svg');
      if (!state.svgRoot) throw new Error('keyboard svg not found');
      updateHighlightStyle();
      bindKeyboardEvents();
      state.keyboardReady = true;
      applySelection();
    } catch (err) {
      showStatus('키보드 도면을 불러오지 못했습니다.', 'error');
      console.error(err);
    }
  }

  function bindKeyboardEvents() {
    els.keyboardMount.querySelectorAll('.steno-key').forEach((node) => {
      node.addEventListener('click', () => toggleSelectedKey(node.id));
      const label = node.getAttribute('data-label') || '';
      const title = document.createElementNS('http://www.w3.org/2000/svg', 'title');
      title.textContent = `${friendlyName(node.id)} · ${label}`;
      node.appendChild(title);
    });
  }

  function updateHighlightStyle() {
    if (!state.svgRoot) return;
    const border = adjustBorderColor(state.highlightColor);
    state.svgRoot.style.setProperty('--keyboard-highlight', state.highlightColor);
    state.svgRoot.style.setProperty('--keyboard-highlight-border', border);
    document.documentElement.style.setProperty('--keyboard-highlight', state.highlightColor);
    document.documentElement.style.setProperty('--keyboard-highlight-border', border);
  }

  function adjustBorderColor(hex) {
    const c = String(hex || '').replace('#','');
    if (c.length !== 6) return DEFAULT_BORDER;
    const nums = c.match(/.{2}/g).map(v => parseInt(v, 16));
    const dark = nums.map(v => Math.max(0, v - 60));
    return '#' + dark.map(v => v.toString(16).padStart(2,'0')).join('');
  }

  function readEntries() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      const parsed = raw ? JSON.parse(raw) : [];
      return Array.isArray(parsed) ? parsed : [];
    } catch (err) { console.error(err); return []; }
  }

  function migrateStoredKeyMappings(entries) {
    const list = Array.isArray(entries) ? entries : [];
    let changed = localStorage.getItem(KEYMAP_VERSION_KEY) !== CURRENT_KEYMAP_VERSION;
    const migrated = list.map((entry) => {
      if (!entry || !entry.abbrCode) return entry;
      const nextKeys = parseStenoCodeToKeyIds(entry.abbrCode);
      if (!nextKeys.length) return entry;
      const prevKeys = Array.isArray(entry.keys) ? entry.keys : [];
      const same = prevKeys.length === nextKeys.length && prevKeys.every((key, idx) => key === nextKeys[idx]);
      if (same) return entry;
      changed = true;
      return { ...entry, keys: nextKeys };
    });
    if (changed) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(migrated));
      localStorage.setItem(KEYMAP_VERSION_KEY, CURRENT_KEYMAP_VERSION);
    }
    return migrated;
  }

  function writeEntries() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state.entries));
    renderStats();
    renderTable();
  }

  async function loadBundledDictionary({ silent = false, force = false } = {}) {
    try {
      let text = window.SORIZAVA_ABBR_ZVDIC_TEXT || '';
      if (!text) {
        const res = await fetch(DEFAULT_DICT_PATH);
        if (!res.ok) throw new Error('default dictionary not found');
        text = await res.text();
      }
      const imported = parseZvdicDictionary(text);
      if (!imported.length) throw new Error('empty dictionary');
      if (force) {
        const incomingKeys = new Set(imported.map(entryKey));
        state.entries = state.entries.filter(entry => !incomingKeys.has(entryKey(entry)));
      }
      mergeEntries(imported);
      if (!silent) showStatus(`기본 약어사전 ${imported.length}개를 반영했습니다.`, 'success');
      return imported.length;
    } catch (err) {
      console.error(err);
      if (!silent) showStatus('기본 약어사전을 불러오지 못했습니다.', 'error');
      return 0;
    }
  }

  function toggleSelectedKey(keyId) {
    if (!keyId) return;
    state.selectedKeys = state.selectedKeys.includes(keyId) ? state.selectedKeys.filter(id => id !== keyId) : [...state.selectedKeys, keyId];
    state.currentEntry = null;
    state.editingId = null;
    state.selectionMode = 'keyboard';
    applySelection();
    updateSelectionUI();
    renderTable();
    focusFirstKeyboardMatchRow();
  }


  function clearSelection() {
    state.selectedKeys = [];
    state.currentEntry = null;
    state.editingId = null;
    state.selectionMode = 'entry';
    state.keyboardMatchEntries = [];
    applySelection();
    updateSelectionUI();
    renderTable();
  }


  function applySelection() {
    if (!state.keyboardReady) return;
    els.keyboardMount.querySelectorAll('.steno-key').forEach((node) => {
      const active = state.selectedKeys.includes(node.id);
      node.classList.toggle('is-selected', active);
      node.setAttribute('data-selected', active ? 'true' : 'false');
    });
  }

  function updateSelectionUI() {
    if (els.dictKeys) els.dictKeys.value = state.selectedKeys.join(', ');
    if (els.selectedCount) els.selectedCount.textContent = state.selectedKeys.length;
    const isKeyboardLookup = state.selectionMode === 'keyboard' && state.selectedKeys.length > 0 && !state.currentEntry;
    const matchedEntries = isKeyboardLookup ? findEntriesBySelectedKeys() : [];
    const exactKeyboardMatches = isKeyboardLookup ? getExactKeyboardMatches(matchedEntries) : [];
    state.keyboardMatchEntries = matchedEntries;
    if (els.currentWordLabel) {
      if (state.currentEntry) {
        els.currentWordLabel.textContent = displayOutput(state.currentEntry);
      } else if (isKeyboardLookup) {
        els.currentWordLabel.textContent = buildKeyboardLookupTitle(matchedEntries, exactKeyboardMatches);
      } else {
        els.currentWordLabel.textContent = '약어를 선택하세요';
      }
    }
    if (els.currentMetaLabel) {
      if (state.currentEntry) {
        const rawCode = state.currentEntry.abbrCode || '-';
        els.currentMetaLabel.textContent = `약어 자리: ${rawCode} · 표시 키 ${state.selectedKeys.length}개`;
      } else if (isKeyboardLookup) {
        els.currentMetaLabel.textContent = buildKeyboardLookupMeta(matchedEntries);
      } else {
        els.currentMetaLabel.textContent = '오른쪽 목록에서 약어 행을 클릭하거나 키보드 자리를 선택하면 표시됩니다';
      }
    }
    if (!els.selectedChips) return;
    els.selectedChips.innerHTML = '';
    if (!state.selectedKeys.length) {
      const chip = document.createElement('span');
      chip.className = 'chip';
      chip.textContent = '표시된 키 없음';
      els.selectedChips.appendChild(chip);
      return;
    }
    state.selectedKeys.forEach((keyId) => {
      const chip = document.createElement('span');
      chip.className = 'chip';
      chip.textContent = `${friendlyName(keyId)} (${keyId})`;
      els.selectedChips.appendChild(chip);
    });
  }

  function findEntriesBySelectedKeys() {
    const selected = dedupe(state.selectedKeys || []);
    if (!selected.length) return [];
    const matches = state.entries.filter(entry => entryHasSelectedKeys(entry, selected));
    return sortKeyboardMatches(matches, selected);
  }

  function entryHasSelectedKeys(entry, selectedKeys = state.selectedKeys) {
    const keys = Array.isArray(entry?.keys) ? entry.keys : [];
    if (!selectedKeys.length || !keys.length) return false;
    return selectedKeys.every(keyId => keys.includes(keyId));
  }

  function entryMatchesExactlySelectedKeys(entry, selectedKeys = state.selectedKeys) {
    const keys = dedupe(Array.isArray(entry?.keys) ? entry.keys : []);
    const selected = dedupe(selectedKeys || []);
    if (!selected.length || !keys.length || keys.length !== selected.length) return false;
    return selected.every(keyId => keys.includes(keyId));
  }

  function getExactKeyboardMatches(matches) {
    return (matches || []).filter(entry => entryMatchesExactlySelectedKeys(entry));
  }

  function sortKeyboardMatches(entries, selectedKeys = state.selectedKeys) {
    return (entries || []).slice().sort((a, b) => {
      const aExact = entryMatchesExactlySelectedKeys(a, selectedKeys);
      const bExact = entryMatchesExactlySelectedKeys(b, selectedKeys);
      if (aExact !== bExact) return aExact ? -1 : 1;
      const outputCompare = displayOutput(a).localeCompare(displayOutput(b), 'ko', { numeric: true, sensitivity: 'base' });
      if (outputCompare) return state.sortDir === 'asc' ? outputCompare : -outputCompare;
      return String(a.abbrCode || '').localeCompare(String(b.abbrCode || ''), 'ko', { numeric: true, sensitivity: 'base' });
    });
  }

  function buildKeyboardLookupTitle(matches, exactMatches = getExactKeyboardMatches(matches)) {
    if (!matches.length) return '선택 자리 약어 없음';
    const mainEntry = exactMatches[0] || matches[0];
    const moreCount = Math.max(0, matches.length - 1);
    return moreCount ? `${displayOutput(mainEntry)} 외 ${moreCount}개` : displayOutput(mainEntry);
  }

  function buildKeyboardLookupMeta(matches) {
    const selectedNames = (state.selectedKeys || []).map(friendlyName).join(' + ') || '-';
    if (!matches.length) return `선택 자리: ${selectedNames} · 등록된 약어 없음`;
    const exactMatches = getExactKeyboardMatches(matches);
    const mainEntry = exactMatches[0] || matches[0];
    const abbrCode = mainEntry?.abbrCode || '-';
    const exactText = exactMatches.length ? ` · 정확히 같은 자리 ${exactMatches.length}개` : ' · 정확히 같은 자리 없음';
    return `선택 자리: ${selectedNames} · 약어 자리: ${abbrCode}${exactText} · 전체 ${matches.length}개`;
  }

  function focusFirstKeyboardMatchRow() {
    if (state.selectionMode !== 'keyboard' || !state.keyboardMatchEntries.length || !els.tableBody) return;
    const first = els.tableBody.querySelector('tr.dict-row');
    if (!first) return;
    first.classList.add('active-row');
    first.scrollIntoView({ block: 'nearest' });
  }


  function syncSelectionFromTextarea() {
    const raw = (els.dictKeys.value || '').trim();
    state.currentEntry = null;
    state.editingId = null;
    state.selectionMode = 'keyboard';
    if (!raw) {
      state.selectedKeys = [];
      state.keyboardMatchEntries = [];
      applySelection();
      updateSelectionUI();
      renderTable();
      return;
    }
    const requested = raw.split(/[\n,|/]+/).map(v => v.trim()).filter(Boolean);
    state.selectedKeys = dedupe(normalizeKeyTokens(requested));
    applySelection();
    updateSelectionUI();
    renderTable();
    focusFirstKeyboardMatchRow();
  }


  function normalizeKeyTokens(tokens) {
    const validIds = getAllKeyIds();
    return tokens.map(token => resolveTokenToId(token, validIds)).filter(Boolean);
  }
  function getAllKeyIds() { return els.keyboardMount ? Array.from(els.keyboardMount.querySelectorAll('.steno-key')).map(node => node.id) : []; }
  function resolveTokenToId(token, validIds) {
    if (validIds.includes(token)) return token;
    const normalized = token.toLowerCase().replace(/\s+/g, '');
    const found = validIds.find(id => id.toLowerCase() === normalized);
    if (found) return found;
    const aliasMap = buildAliasMap(validIds);
    return aliasMap[normalized] || null;
  }
  function buildAliasMap(validIds) {
    const map = {};
    validIds.forEach((id) => {
      const name = friendlyName(id);
      map[name.toLowerCase().replace(/\s+/g,'')] = id;
      map[id.toLowerCase().replace(/\s+/g,'')] = id;
      map[id.replace(/^key_/, '').toLowerCase()] = id;
    });
    return map;
  }
  function dedupe(arr) { return Array.from(new Set(arr)); }

  function saveEntry() {
    const word = (els.dictWord?.value || '').trim();
    const note = (els.dictNote?.value || '').trim();
    const keys = dedupe(normalizeKeyTokens((els.dictKeys.value || '').split(/[\n,|/]+/).map(v => v.trim()).filter(Boolean)));
    if (!word) { showStatus('약어를 먼저 입력해 주세요.', 'error'); els.dictWord?.focus(); return; }
    if (!keys.length) { showStatus('최소 1개 이상의 키를 선택해 주세요.', 'error'); return; }
    const now = new Date().toISOString();
    const entry = {
      id: state.editingId || `manual_${Date.now()}`,
      source: 'manual', word, outputRaw: word, abbrCode: '', keys, note, updatedAt: now,
      createdAt: state.editingId ? (state.entries.find(v => v.id === state.editingId)?.createdAt || now) : now,
    };
    const idx = state.entries.findIndex(v => v.id === entry.id);
    if (idx >= 0) state.entries[idx] = entry; else state.entries.unshift(entry);
    localStorage.setItem(LAST_WORD_KEY, word);
    writeEntries();
    showStatus(state.editingId ? '약어 항목을 수정했습니다.' : '약어 항목을 저장했습니다.', 'success');
    state.editingId = entry.id;
    loadEntry(entry.id);
  }

  function clearForm() {
    state.editingId = null;
    state.currentEntry = null;
    state.selectionMode = 'entry';
    state.keyboardMatchEntries = [];
    if (els.dictWord) els.dictWord.value = '';
    if (els.dictNote) els.dictNote.value = '';
    clearSelection();
    setActiveRow('');
  }

  function renderStats() {
    if (els.entryCount) els.entryCount.textContent = state.entries.length;
    const filtered = filterEntries();
    if (els.searchCount) els.searchCount.textContent = filtered.length;
    const latest = state.entries.slice().sort((a,b) => String(b.updatedAt).localeCompare(String(a.updatedAt)))[0];
    if (els.lastUpdated) els.lastUpdated.textContent = latest ? formatDate(latest.updatedAt) : '-';
  }

  function filterEntries() {
    const outputQuery = (els.searchWord?.value || '').trim().toLowerCase();
    const keyboardLookupActive = state.selectionMode === 'keyboard' && state.selectedKeys.length > 0 && !state.currentEntry;
    const matched = state.entries.filter(entry => {
      const outputText = displayOutput(entry).toLowerCase();
      const outputOk = !outputQuery || outputText.includes(outputQuery);
      const keyOk = !keyboardLookupActive || entryHasSelectedKeys(entry);
      return outputOk && keyOk;
    });
    const filtered = keyboardLookupActive ? sortKeyboardMatches(matched) : matched.sort((a, b) => {
      const result = displayOutput(a).localeCompare(displayOutput(b), 'ko', { numeric: true, sensitivity: 'base' });
      return state.sortDir === 'asc' ? result : -result;
    });
    state.filteredEntries = filtered;
    updateSortUI();
    return filtered;
  }


  function toggleOutputSort() {
    state.sortDir = state.sortDir === 'asc' ? 'desc' : 'asc';
    renderTable();
  }

  function updateSortUI() {
    if (els.sortOutputIcon) els.sortOutputIcon.textContent = state.sortDir === 'asc' ? '오름차순 ↑' : '내림차순 ↓';
    if (els.sortOutputBtn) els.sortOutputBtn.setAttribute('aria-label', `약어 ${state.sortDir === 'asc' ? '오름차순' : '내림차순'} 정렬`);
  }

  function renderTable() {
    if (!els.tableBody) return;
    const rows = filterEntries();
    els.tableBody.innerHTML = '';
    if (!rows.length) {
      const tr = document.createElement('tr');
      const emptyText = state.selectionMode === 'keyboard' && state.selectedKeys.length
        ? '선택한 키보드 자리에 해당하는 약어가 없습니다.'
        : '등록된 약어가 없습니다. 기본 약어사전을 불러오거나 TXT/CSV/JSON 파일을 업로드해 주세요.';
      tr.innerHTML = `<td colspan="2" class="empty-state">${emptyText}</td>`;
      els.tableBody.appendChild(tr);
      renderStats();
      return;
    }
    rows.forEach((entry) => {
      const tr = document.createElement('tr');
      tr.className = 'dict-row';
      tr.dataset.id = entry.id;
      const outputText = displayOutput(entry);
      tr.innerHTML = `
        <td class="word-cell"><b>${escapeHtml(outputText)}</b></td>
        <td class="abbr-cell"><b>${escapeHtml(entry.abbrCode || '-')}</b></td>`;
      els.tableBody.appendChild(tr);
    });
    els.tableBody.querySelectorAll('tr.dict-row').forEach((row) => {
      row.addEventListener('click', () => loadEntry(row.dataset.id, false));
    });
    renderStats();
  }

  function displayOutput(entry) {
    return String(entry?.outputRaw || entry?.word || '').trim();
  }

  function loadEntry(id, editMode = false) {
    const entry = state.entries.find(v => v.id === id);
    if (!entry) return;
    state.editingId = null;
    state.currentEntry = entry;
    state.selectionMode = 'entry';
    state.keyboardMatchEntries = [];
    if (els.dictWord) els.dictWord.value = displayOutput(entry);
    if (els.dictNote) els.dictNote.value = entry.note || '';
    state.selectedKeys = dedupe(entry.keys || []);
    if (els.dictKeys) els.dictKeys.value = state.selectedKeys.join(', ');
    applySelection();
    updateSelectionUI();
    setActiveRow(entry.id);
    localStorage.setItem(LAST_WORD_KEY, displayOutput(entry));
  }

  function setActiveRow(id) {
    if (!els.tableBody) return;
    els.tableBody.querySelectorAll('tr.dict-row').forEach(row => row.classList.toggle('active-row', row.dataset.id === id));
  }

  function restoreLastWord() {
    const lastWord = localStorage.getItem(LAST_WORD_KEY); if (!lastWord) return;
    const entry = state.entries.find(v => v.word === lastWord || displayOutput(v) === lastWord); if (entry) loadEntry(entry.id, false);
  }

  function deleteEntry(id) {
    const entry = state.entries.find(v => v.id === id); if (!entry) return;
    if (!confirm(`"${entry.word}" 항목을 삭제할까요?`)) return;
    state.entries = state.entries.filter(v => v.id !== id); writeEntries();
    if (state.editingId === id) clearForm(); showStatus('약어 항목을 삭제했습니다.', 'success');
  }

  function exportJson() {
    if (!state.entries.length) return showStatus('내보낼 약어 데이터가 없습니다.', 'error');
    downloadBlob(JSON.stringify(state.entries, null, 2), 'sorizava-abbr-dictionary.json', 'application/json'); showStatus('JSON 파일로 내보냈습니다.', 'success');
  }
  function exportCsv() {
    if (!state.entries.length) return showStatus('내보낼 약어 데이터가 없습니다.', 'error');
    const header = ['약어','약어자리'];
    const rows = state.entries.map(entry => [displayOutput(entry), entry.abbrCode || '']);
    const csv = [header, ...rows].map(row => row.map(csvEscape).join(',')).join('\n');
    downloadBlob('\ufeff' + csv, 'sorizava-abbr-dictionary.csv', 'text/csv;charset=utf-8;'); showStatus('CSV 파일로 내보냈습니다.', 'success');
  }
  function csvEscape(value) { const text = String(value ?? ''); return '"' + text.replace(/"/g, '""') + '"'; }
  function downloadBlob(text, filename, type) {
    const blob = new Blob([text], { type }); const url = URL.createObjectURL(blob); const a = document.createElement('a');
    a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  }

  function handleImportFile(e) {
    const file = e.target.files?.[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const text = decodeTextFileBuffer(reader.result);
        const imported = parseImport(text, file.name || '');
        if (!imported.length) throw new Error('데이터가 없습니다.');
        mergeEntries(imported); showStatus(`${imported.length}개 항목을 불러왔습니다.`, 'success');
      } catch (err) {
        console.error(err); showStatus('파일 형식을 읽지 못했습니다. 기존 zvdic TXT 또는 CSV/JSON 형식을 확인해 주세요.', 'error');
      } finally { e.target.value = ''; }
    };
    reader.readAsArrayBuffer(file);
  }

  function decodeTextFileBuffer(buffer) {
    const bytes = new Uint8Array(buffer || []);
    if (bytes.length >= 2 && bytes[0] === 0xFF && bytes[1] === 0xFE) return new TextDecoder('utf-16le').decode(bytes);
    if (bytes.length >= 2 && bytes[0] === 0xFE && bytes[1] === 0xFF) return new TextDecoder('utf-16be').decode(bytes);
    if (bytes.length >= 3 && bytes[0] === 0xEF && bytes[1] === 0xBB && bytes[2] === 0xBF) return new TextDecoder('utf-8').decode(bytes);
    try {
      const utf8 = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
      if ((utf8.match(/�/g) || []).length < 3) return utf8;
    } catch (e) {}
    try { return new TextDecoder('euc-kr').decode(bytes); } catch (e) { return new TextDecoder('utf-8').decode(bytes); }
  }

  function parseImport(text, filename) {
    const ext = filename.toLowerCase().split('.').pop();
    if (isZvdicText(text, filename)) return parseZvdicDictionary(text);
    if (ext === 'json') {
      const parsed = JSON.parse(text); if (!Array.isArray(parsed)) throw new Error('invalid json');
      return parsed.map(normalizeImportedEntry).filter(Boolean);
    }
    return parseCsv(text).map(normalizeImportedEntry).filter(Boolean);
  }

  function isZvdicText(text, filename = '') {
    if (/zvdic|sori/i.test(filename)) return true;
    if (text.includes('약어는 초성중성종성숫자')) return true;
    const lines = text.split(/\r?\n/).slice(0, 80);
    let score = 0;
    lines.forEach(line => {
      const t = line.trim();
      if (!t || t.startsWith(';')) return;
      if (/^[ㄱ-ㅎㅏ-ㅣ0-9\-]+\t+/.test(line)) score += 1;
    });
    return score >= 3;
  }

  function parseZvdicDictionary(text) {
    const now = new Date().toISOString();
    return String(text || '')
      .replace(/^\uFEFF/, '')
      .split(/\r?\n/)
      .map(line => line.replace(/\s+$/g, ''))
      .filter(line => line.trim() && !line.trim().startsWith(';'))
      .map((line) => {
        const parts = line.split(/\t+/);
        if (parts.length < 2) return null;
        const abbrCode = (parts.shift() || '').trim();
        const outputRaw = parts.join('\t').trim();
        if (!abbrCode || !outputRaw) return null;
        const keys = parseStenoCodeToKeyIds(abbrCode);
        if (!keys.length) return null;
        const word = outputRaw;
        return {
          id: `zvdic_${simpleHash(abbrCode + '|' + outputRaw)}`,
          source: 'zvdic', word, outputRaw, abbrCode, keys,
          note: `약어 자리: ${abbrCode}`,
          createdAt: now, updatedAt: now,
        };
      })
      .filter(Boolean);
  }

  function parseStenoCodeToKeyIds(rawCode) {
    const chars = Array.from(String(rawCode || '').replace(/[0-9]/g, '').replace(/\s+/g, ''));
    let phase = 'left';
    const keys = [];
    chars.forEach((ch) => {
      if (ch === '-') { phase = 'right'; return; }
      if (VOWEL_KEY_MAP[ch]) { keys.push(...VOWEL_KEY_MAP[ch]); phase = 'vowel'; return; }
      if (phase === 'vowel') phase = 'right';
      const id = phase === 'right' ? RIGHT_KEY_MAP[ch] : LEFT_KEY_MAP[ch];
      if (id) keys.push(id);
    });
    return dedupe(keys);
  }

  function cleanOutputText(outputRaw) {
    return String(outputRaw || '')
      .replace(/↙/g, '')
      .replace(/#/g, ' ')
      .replace(/\|/g, '↵')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function parseCsv(text) {
    const rows = splitCsvRows(text.trim()); if (!rows.length) return [];
    const headers = rows[0].map(h => String(h || '').trim());
    return rows.slice(1).filter(r => r.some(v => String(v || '').trim())).map(row => {
      const obj = {}; headers.forEach((h, idx) => obj[h] = row[idx] ?? ''); return obj;
    });
  }
  function splitCsvRows(text) {
    const rows = []; let row = []; let cur = ''; let inQuotes = false;
    for (let i=0;i<text.length;i++) {
      const ch = text[i], next = text[i+1];
      if (ch === '"') { if (inQuotes && next === '"') { cur += '"'; i++; } else inQuotes = !inQuotes; }
      else if (ch === ',' && !inQuotes) { row.push(cur); cur = ''; }
      else if ((ch === '\n' || ch === '\r') && !inQuotes) { if (ch === '\r' && next === '\n') i++; row.push(cur); rows.push(row); row = []; cur = ''; }
      else cur += ch;
    }
    row.push(cur); rows.push(row); return rows;
  }

  function normalizeImportedEntry(item) {
    const rawOutput = String(item.outputRaw || item.약어 || item.출력내용 || item.word || item.단어 || '').trim();
    const word = rawOutput;
    const keyRaw = item.keys || item.keyIds || item.배열 || item.key_array || '';
    const note = String(item.note || item.memo || item.비고 || '').trim();
    const abbrCode = String(item.abbrCode || item.약어자리 || item.약어키 || '').trim();
    const outputRaw = rawOutput;
    if (!word) return null;
    const keys = abbrCode ? parseStenoCodeToKeyIds(abbrCode) : dedupe(normalizeKeyTokens(String(keyRaw).split(/[\n,|/]+/).map(v => v.trim()).filter(Boolean)));
    if (!keys.length) return null;
    const now = new Date().toISOString();
    return { id: `abbr_${Date.now()}_${Math.random().toString(36).slice(2,7)}`, source: 'import', word, outputRaw, abbrCode, keys, note, createdAt: now, updatedAt: now };
  }

  function mergeEntries(imported) {
    const map = new Map(state.entries.map(entry => [entryKey(entry), entry]));
    imported.forEach((entry) => {
      const key = entryKey(entry); const prev = map.get(key);
      map.set(key, prev ? { ...prev, ...entry, id: prev.id, createdAt: prev.createdAt || entry.createdAt } : entry);
    });
    state.entries = Array.from(map.values()).sort((a,b) => String(a.word).localeCompare(String(b.word), 'ko'));
    writeEntries();
  }

  function entryKey(entry) {
    if (entry.source === 'zvdic' || entry.abbrCode) return `code:${entry.abbrCode}|out:${entry.outputRaw || entry.word}`;
    return `manual:${entry.word}|keys:${(entry.keys || []).join('|')}`;
  }

  function clearAllEntries() {
    if (!state.entries.length) return showStatus('삭제할 약어 데이터가 없습니다.', 'error');
    if (!confirm('등록된 약어 데이터를 모두 삭제할까요?')) return;
    state.entries = []; writeEntries(); clearForm(); showStatus('전체 약어 데이터를 삭제했습니다.', 'success');
  }

  function copyKeys() {
    const value = (els.dictKeys.value || '').trim(); if (!value) return showStatus('복사할 약어 자리이 없습니다.', 'error');
    navigator.clipboard.writeText(value).then(() => showStatus('약어 자리을 복사했습니다.', 'success')).catch(() => showStatus('복사에 실패했습니다.', 'error'));
  }

  function friendlyName(id) {
    const nameMap = {
      key_l_side_ch: '좌측 세로 ㅊ', key_l_side_s: '좌측 세로 ㅅ', key_l_side_m: '좌측 세로 ㅁ',
      key_l_t: '좌측 ㅌ', key_l_k: '좌측 위 ㅋ', key_l_b: '좌측 ㅂ', key_l_p: '좌측 ㅍ',
      key_l_d: '좌측 ㄷ', key_l_j: '좌측 ㅈ', key_l_g: '좌측 ㄱ', key_l_kk: '좌측 아래 ㅋ',
      key_l_r: '좌측 ㄹ', key_l_n: '좌측 ㄴ', key_l_h: '좌측 ㅎ', key_l_eo: '좌측 ㅓ',
      key_r_gg: '우측 ㄲ', key_r_h: '우측 ㅎ', key_r_t: '우측 ㅌ', key_r_ch: '우측 ㅊ',
      key_r_side_p: '우측 세로 ㅍ', key_r_g: '우측 ㄱ', key_r_n: '우측 ㄴ', key_r_r: '우측 ㄹ', key_r_s: '우측 ㅅ',
      key_r_side_b: '우측 세로 ㅂ', key_r_ss: '우측 ㅆ', key_r_ng: '우측 ㅇ', key_r_m: '우측 ㅁ', key_r_d: '우측 ㄷ',
      key_r_side_j: '우측 세로 ㅈ', key_thumb_o: '하단 ㅗ', key_thumb_a: '하단 ㅏ', key_thumb_u: '하단 ㅜ', key_thumb_eu: '하단 ㅡ',
      key_thumb_eo: '하단 ㅓ', key_thumb_i: '하단 ㅣ', key_function_enter: '줄바꿈', key_function_join: '붙여쓰기'
    };
    return nameMap[id] || id;
  }

  function formatDate(iso) {
    if (!iso) return '-'; const d = new Date(iso); if (Number.isNaN(d.getTime())) return '-';
    const y = d.getFullYear(), m = String(d.getMonth()+1).padStart(2,'0'), day = String(d.getDate()).padStart(2,'0');
    const hh = String(d.getHours()).padStart(2,'0'), mm = String(d.getMinutes()).padStart(2,'0'); return `${y}-${m}-${day} ${hh}:${mm}`;
  }
  function simpleHash(str) { let h = 0; for (let i = 0; i < str.length; i++) h = Math.imul(31, h) + str.charCodeAt(i) | 0; return Math.abs(h).toString(36); }
  function showStatus(msg, type='success') {
    if (!els.statusMsg) return;
    els.statusMsg.textContent = msg; els.statusMsg.className = `status-msg show ${type}`;
    clearTimeout(showStatus._timer); showStatus._timer = setTimeout(() => { els.statusMsg.className = 'status-msg'; }, 2600);
  }
  function escapeHtml(str) { return String(str ?? '').replace(/[&<>"]+/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[s] || s)); }
  function toggleSidebar() { document.querySelector('.sidebar')?.classList.toggle('active'); document.querySelector('.sidebar-overlay')?.classList.toggle('active'); }
  function logout() { if (window.SorizavaAuth) return window.SorizavaAuth.signOut(); sessionStorage.clear(); location.href = 'index.html'; }
  window.toggleSidebar = toggleSidebar; window.logout = logout;
})();
