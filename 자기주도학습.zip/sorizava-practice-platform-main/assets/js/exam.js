    // 사이드바 토글 함수 추가
    function toggleSidebar() {
        const sidebar = document.querySelector('.sidebar');
        const overlay = document.querySelector('.sidebar-overlay');
        sidebar.classList.toggle('active');
        overlay.classList.toggle('active');
    }

    const ALL_SETS = {
        "1": [ {s:"사회는 하나의 배와 같은 것이다.", a:"회는 의 와 같은 것이다."}, {s:"이 세상에 악이 없다면 선도 없을 것이다.", a:"에 이 없다면 도 없을 것이다."}, {s:"눈에서 멀어지면 마음에서 멀어진다.", a:"에서 지면 에서 진다."}, {s:"우리는 부정부패 척결에 나서고 있습니다.", a:"리는 에 고 있습니다."}, {s:"우리는 시인하지 않을 수 없습니다.", a:"리는 하지 않을 수 없습니다."}, {s:"얼굴은 결코 거짓말을 하지 않는다.", a:"은 을 하지 않는다."}, {s:"새로운 세계를 창조해내고 있습니다.", a:"를 고 있습니다."}, {s:"위기를 맞고 있는 것은 우리 민주주의입니다.", a:"를 고 있는 것은 입니다."}, {s:"도덕적 승리는 셈을 하지 않는 것이다.", a:"리는 을 하지 않는 것이다."}, {s:"희망이 없다면 아무것도 성공하지 못한다.", a:"이 없다면 것도 하지 한다."} ],
        "2": [ {s:"사랑은 아낌없이 뺏는 것이다.", a:"은 없이 는 것이다."}, {s:"우리가 건설하고자 하는 국가입니다.", a:"가 하고자 하는 입니다."}, {s:"더불어 손잡고 사는 사회를 건설하는 일입니다.", a:"고 사는 를 하는 입니다."}, {s:"새로운 세계질서가 모색되고 있습니다.", a:"가 되고 있습니다."}, {s:"무엇보다 인간성을 회복해야 합니다.", a:"을 합니다."}, {s:"국가와 민족을 위해 우리 함께 노력해야 합니다.", a:"와 을 합니다."}, {s:"한국은 수준 높은 민주정치를 실현했습니다.", a:"은 은 를 했습니다."}, {s:"에너지 절약하는 길밖에 없습니다.", a:"하는 에 없습니다."}, {s:"대통령 선거가 눈앞에 다가왔습니다.", a:"가 에 습니다."}, {s:"새로운 사고를 요구하고 있습니다.", a:"를 하고 있습니다."} ],
        "3": [ {s:"수출의욕의 회생이 중요합니다.", a:"의 이 합니다."}, {s:"나라의 중심은 중소기업입니다.", a:"의 은 입니다."}, {s:"우리와 함께 평화통일로 가는 것입니다.", a:"와 로 가는 것입니다."}, {s:"새로운 국제질서가 형성되고 있습니다.", a:"가 되고 있습니다."}, {s:"여러분을 자랑스럽게 생각하고 있습니다.", a:"을 게 하고 있습니다."}, {s:"지원과 협력을 아끼지 않을 것입니다.", a:"과 을 지 않을 것입니다."}, {s:"고위공직자들이 재산을 공개했습니다.", a:"이 을 했습니다."}, {s:"우리는 더불어 사는 공동체입니다.", a:"리는 사는 입니다."}, {s:"고난 속에서 좌절하지 않았습니다.", a:"에서 하지 않았습니다."}, {s:"우리는 목도하고 있지 않습니까?", a:"리는 하고 있 지 않습니까?"} ],
        "4": [ {s:"여자에게 가장 엄격한 것은 여자이다.", a:"에게 한 것은 이다."}, {s:"시련을 극복할 수 있었습니다.", a:"을 할 수 있었습니다."}, {s:"국민에게 그것을 호소할 수 있습니다.", a:"에게 을 할 수 있습니다."}, {s:"다음은 노사문제에 대해 묻겠습니다.", a:"은 에 습니다."}, {s:"대비를 튼튼히 하지 않을 수 없다.", a:"를 하지 않을 수 없다."}, {s:"그것은 나라 바로 세우기인 것입니다.", a:"은 로 것입니다."}, {s:"우리 국민은 자신감을 가져야 합니다.", a:"은 을 합니다."}, {s:"사회는 거대화된 정보체계를 이룬다.", a:"회는 를 룬다."}, {s:"북방정책을 적극적으로 추진해야 한다.", a:"을 적으로 한다."}, {s:"우리는 지금 강력한 정부를 애써 이룩했다.", a:"리는 한 를 했다."} ],
        "5": [ {s:"국회는 민주주의의 전당인 것입니다.", a:"회는 의 것입니다."}, {s:"어린이 사랑은 나라 사랑입니다.", a:"은 입니다."}, {s:"깨어 있다는 것은 살아 있다는 것이다.", a:"있다는 것은 있다는 것이다."}, {s:"위대한 사람은 위대한 사랑을 한다.", a:"한 은 한 을 한다."}, {s:"국민 모두의 자발적인 참여가 필요합니다.", a:"의 적인 가 합니다."}, {s:"높은 도덕성이 중시되어야 할 것입니다.", a:"은 이 되어야 것입니다."}, {s:"형식적인 지적으로 그치는 경우가 많다.", a:"적인 으로 치는 가 많다."}, {s:"내일을 향한 이정표이기도 합니다.", a:"을 한 도 합니다."}, {s:"아시아 태평양 시대는 저절로 오지 않습니다.", a:"대는 로 지 않습니다."}, {s:"환경은 인간이 생존하는 바탕입니다.", a:"은 이 하는 입니다."} ],
        "6": [ {s:"모두의 힘을 모아 풍요로운 사회를 만듭시다.", a:"의 을 를 다."}, {s:"법과 도덕의 중요성을 재인식해야 합니다.", a:"과 의 을 합니다."}, {s:"경제력만으로 선진국이 될 수 없습니다.", a:"으로 이 될 수 없습니다."}, {s:"학교의 자율은 최대한 존중되어야 한다.", a:"의 은 한 되어야 한다."}, {s:"새로운 시대 열어가야 한다고 봅니다.", a:"다고 봅니다."}, {s:"정부는 안정과 편의를 도모하고 있습니다.", a:"부는 과 를 하고 있습니다."}, {s:"크게 기여하는 나라를 만들고자 합니다.", a:"게 하는 를 고자 합니다."}, {s:"이것이 미래로 나아가는 한국의 이야기입니다.", a:"이 로 가는 의 입니다."}, {s:"우리 두 나라는 가장 가까운 벗이 되었습니다.", a:"라는 이 되었습니다."}, {s:"미래를 이끌어가는 지도자가 될 것입니다.", a:"를 가는 가 것입니다."} ],
        "7": [ {s:"개혁은 민족의 생존을 위해 피할 수 없습니다.", a:"은 의 을 할 수 없습니다."}, {s:"경쟁력을 높이기에 앞장서 주시기 바랍니다.", a:"을 에 랍니다."}, {s:"우리는 때때로 역경을 겪게 된다.", a:"리는 로 을 게 된다."}, {s:"한국의 성공은 무엇보다도 평화의 결실입니다.", a:"의 은 도 의 입니다."}, {s:"앞으로 보다 강력한 동반자가 될 것입니다.", a:"으로 한 가 것입니다."}, {s:"각국의 공동노력과 협력이 필요합니다.", a:"의 과 이 합니다."}, {s:"모든 문제를 분명히 인식하였습니다.", a:"를 하였습니다."}, {s:"국가와 민족을 위해 다 함께 뜁시다.", a:"와 을 다."}, {s:"한반도 역사의 발전을 가로막고 있습니다.", a:"의 을 고 있습니다."}, {s:"그 어느 때보다 바삐 움직여야 했습니다.", a:"했습니다."} ],
        "8": [ {s:"정부의 예산을 깨끗하고 바르게 써야 한다.", a:"의 을 하고 르게 한다."}, {s:"중소기업의 투자가 활기를 띠고 있습니다.", a:"의 가 를 고 있습니다."}, {s:"이제 여러분도 피부로 느낄 것입니다.", a:"도 로 것입니다."}, {s:"세계가 하나의 공동체가 되었습니다.", a:"가 의 가 되었습니다."}, {s:"반드시 남과 북은 통일이 되어야 합니다.", a:"과 은 이 되어야 합니다."}, {s:"아시아에는 한국이 버티고 있다.", a:"에는 이 고 있다."}, {s:"버려진 섬마다 꽃이 피었다.", a:"이 었다."}, {s:"두 나라 국민에게 의미 있는 날입니다.", a:"에게 있는 입니다."}, {s:"함께 달려온 장정을 보람되게 생각합니다.", a:"을 되게 합니다."}, {s:"한반도 정세는 아직 냉전 상태입니다.", a:"세는 입니다."} ],
        "9": [ {s:"의미 있는 한 달을 보내야 하겠습니다.", a:"있는 을 습니다."}, {s:"우리의 국제적 위상을 실감할 수 있었습니다.", a:"의 적 을 할 수 있었습니다."}, {s:"우리 모두가 다 영웅이 될 수 없다.", a:"가 이 될 수 없다."}, {s:"내 사랑은 생명의 꽃이다.", a:"은 의 이다."}, {s:"빈곤은 재앙이 아니라 불편이다.", a:"은 이 이다."}, {s:"결혼은 사랑의 무덤이 아닙니다.", a:"은 의 이 닙니다."}, {s:"돌아본 과거의 삶은 순간들의 연속이다.", a:"의 은 의 이다."}, {s:"적극 검토하여 이루어질 수 있도록 노력하겠습니다.", a:"하여 질 수 있도록 습니다."}, {s:"육아휴직 의무화를 반드시 성사시키겠습니다.", a:"를 습니다."}, {s:"한꺼번에 제도적 장치를 마련할 수는 없습니까?", a:"에 적 를 할 수 는 없습니까?"} ]
    };

    const GRADUATION_SET_KEY = 'sorizava_graduation_exam_passed_sets_v1';
    const GRADUATION_ALL_FLAG = 'sorizava_graduation_exam_all_sets_passed';
    const GRADUATION_LEGACY_FLAG = 'sorizava_graduation_exam_passed';

    let currentIndex = 0, currentSentences = [], lineStartTime = null, speeds = [];
    let isQuizMode = false, quizIndex = 0, totalAbbrChars = 0, correctAbbrChars = 0;
    let backspaceCount = 0;
    let liveErrorCount = 0;
    let liveAccuracy = 0;
    let liveSpeedTimer = null;

    const inputEl = document.getElementById('typing-input'), displayEl = document.getElementById('text-display');
    const quizOverlay = document.getElementById('quiz-overlay'), quizInput = document.getElementById('quiz-input');
    let currentUser = sessionStorage.getItem('shorthand_user');

    function startLiveSpeedTimer() {
        if (liveSpeedTimer) return;
        liveSpeedTimer = setInterval(refreshRealtimeMetrics, 250);
    }

    function stopLiveSpeedTimer() {
        if (!liveSpeedTimer) return;
        clearInterval(liveSpeedTimer);
        liveSpeedTimer = null;
    }

    function updateLiveStatElements() {
        const speedEl = document.getElementById('live-speed');
        const backEl = document.getElementById('live-backspace');
        const errEl = document.getElementById('live-errors');
        const accuracyEl = document.getElementById('live-accuracy');

        if (speedEl) speedEl.textContent = Number.isFinite(window.__examLiveSpeed) ? Math.round(window.__examLiveSpeed) : 0;
        if (backEl) backEl.textContent = Number(backspaceCount || 0);
        if (errEl) errEl.textContent = Number(liveErrorCount || 0);
        if (accuracyEl) accuracyEl.textContent = Number(liveAccuracy || 0).toFixed(1);
    }

    function resetLiveStats() {
        stopLiveSpeedTimer();
        window.__examLiveSpeed = 0;
        liveErrorCount = 0;
        liveAccuracy = 0;
        backspaceCount = 0;
        updateLiveStatElements();
    }

    function calculateTypingMismatchCount(target, entered) {
        const cleanTarget = cleanText(target || '');
        const cleanEntered = cleanText(entered || '');
        let mismatches = 0;

        for (let i = 0; i < cleanEntered.length; i++) {
            if (cleanTarget[i] !== cleanEntered[i]) mismatches++;
        }

        return mismatches;
    }

    function refreshRealtimeMetrics() {
        if (!inputEl) return;

        const targetText = currentSentences[currentIndex]?.s || '';
        const typed = inputEl.value || '';
        const cleanTypedLength = cleanText(typed).length;

        if (lineStartTime && cleanTypedLength > 0) {
            const elapsedSec = Math.max((Date.now() - lineStartTime) / 1000, 0.01);
            window.__examLiveSpeed = (cleanTypedLength / elapsedSec) * 60;
        } else {
            window.__examLiveSpeed = 0;
        }

        liveErrorCount = calculateTypingMismatchCount(targetText, typed);
        liveAccuracy = cleanTypedLength > 0
            ? Math.max(0, ((cleanTypedLength - liveErrorCount) / cleanTypedLength) * 100)
            : 0;

        updateLiveStatElements();
    }


    if (currentUser) {
        const sideName = document.getElementById('sideUserName') || document.getElementById('userNameSide');
        if (sideName) sideName.innerText = currentUser;
    }

    function examUserKey() {
        return String(sessionStorage.getItem('shorthand_user_id') || sessionStorage.getItem('shorthand_user') || 'guest').replace(/[^가-힣a-zA-Z0-9_-]/g, '_');
    }

    function examHistoryKey() {
        return `sorizava_graduation_exam_history_${examUserKey()}_v1`;
    }

    function readExamHistory() {
        try {
            const rows = JSON.parse(localStorage.getItem(examHistoryKey()) || '[]');
            return Array.isArray(rows) ? rows : [];
        } catch (error) {
            return [];
        }
    }

    function saveExamHistory(rows) {
        localStorage.setItem(examHistoryKey(), JSON.stringify((rows || []).slice(0, 100)));
    }

    function addExamHistory(row) {
        const rows = readExamHistory();
        rows.unshift(row);
        saveExamHistory(rows);
        renderExamHistory();
    }

    function examHistoryRowHtml(row) {
        const passed = row && row.passed;
        const color = passed ? 'var(--success)' : 'var(--danger)';
        const resultText = row.completeAll ? '최종 통과' : (passed ? '세트 통과' : '미통과');
        return `<tr><td>${row.setNo}</td><td>${Number(row.cpm || 0).toFixed(1)}</td><td>${Number(row.accuracy || 0).toFixed(1)}%</td><td>${Number(row.backspaceCount || 0)}회</td><td><span style="color:${color}; font-weight:bold;">${resultText}</span></td></tr>`;
    }

    function renderExamHistory() {
        const tbody = document.querySelector('#result-table tbody');
        if (!tbody) return;
        const rows = readExamHistory();
        tbody.innerHTML = rows.map(examHistoryRowHtml).join('');
        const section = document.getElementById('history-section');
        if (section && rows.length) section.style.display = 'block';
    }

    function isPassingRemoteExamRecord(row) {
        const tool = String(row?.tool_type || '').toLowerCase();
        const memo = String(row?.memo || '');
        if (tool !== 'exam' || memo.includes('불합격') || memo.includes('미통과')) return false;
        return memo.includes('합격') || memo.includes('통과') || Number(row?.accuracy ?? row?.score ?? 0) >= 90;
    }

    function mergeRemoteExamHistory(remoteRows) {
        const existing = readExamHistory();
        const map = new Map(existing.map(row => [row.id || `${row.createdAt}_${row.setNo}`, row]));
        (remoteRows || []).forEach(row => {
            if (String(row?.tool_type || '').toLowerCase() !== 'exam') return;
            const text = `${row.practice_title || ''} ${row.memo || ''}`;
            const setMatch = text.match(/([1-9])\s*세트/);
            const backspaceMatch = text.match(/백(?:스페이스|키)\s*(\d+)\s*회/);
            const id = row.id ? `remote_${row.id}` : `remote_${row.created_at || ''}_${setMatch?.[1] || 'exam'}`;
            const accuracy = Number(row.accuracy ?? row.score ?? 0);
            const passed = isPassingRemoteExamRecord(row);
            map.set(id, {
                id,
                setNo: setMatch ? setMatch[1] : '-',
                cpm: Number(row.cpm || 0),
                accuracy,
                backspaceCount: backspaceMatch ? Number(backspaceMatch[1]) : 0,
                passed,
                completeAll: /9\s*세트\s*(전체\s*)?(합격|통과)|전체\s*(합격|통과)|최종\s*통과/.test(text),
                createdAt: row.created_at || new Date().toISOString()
            });
        });
        const merged = Array.from(map.values())
            .sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0))
            .slice(0, 100);
        saveExamHistory(merged);
        renderExamHistory();
    }

    async function hydrateGraduationProgressFromRemote() {
        try {
            if (!window.SorizavaRecords?.getMyRecentRecords) return;
            const remoteRows = await window.SorizavaRecords.getMyRecentRecords(1000);
            mergeRemoteExamHistory(remoteRows);
            const passedRows = readPassedSets();
            let changed = false;
            (remoteRows || []).filter(isPassingRemoteExamRecord).forEach(row => {
                const text = `${row.practice_title || ''} ${row.memo || ''}`;
                if (/9\s*세트\s*(전체\s*)?(합격|통과)/.test(text) || /전체\s*(합격|통과)|최종\s*통과/.test(text)) {
                    Object.keys(ALL_SETS).forEach(key => {
                        if (!passedRows[key]?.passed) {
                            passedRows[key] = { passed: true, passedAt: row.created_at || new Date().toISOString(), recovered: true };
                            changed = true;
                        }
                    });
                    return;
                }
                const match = text.match(/([1-9])\s*세트/);
                if (match && !passedRows[match[1]]?.passed) {
                    passedRows[match[1]] = {
                        passed: true,
                        passedAt: row.created_at || new Date().toISOString(),
                        cpm: Number(row.cpm || 0),
                        accuracy: Number(row.accuracy ?? row.score ?? 0),
                        recovered: true
                    };
                    changed = true;
                }
            });
            if (changed) writePassedSets(passedRows);
            if (allSetsPassed(passedRows)) {
                localStorage.setItem(GRADUATION_ALL_FLAG, 'true');
                localStorage.setItem(GRADUATION_LEGACY_FLAG, 'true');
            }
            updateSetProgressUI();
        } catch (error) {
            console.warn('입문반 졸업시험 원격 누적 기록 복구 실패:', error);
        }
    }

    // [채점 기준 변경 적용] 공백, 특수문자 제거 후 비교
    function cleanText(str) {
        return str.replace(/[^가-힣a-zA-Z0-9]/g, ""); 
    }

    function normalizeForQuiz(s) {
        if (!s) return "";
        return s.replace(/\s/g, "").replace(/으로는/g, "므로").replace(/를/g, "을").replace(/과/g, "와");
    }

    let examClearGuardUntil = 0;
    let lastClearedExamText = '';

    function forceClearExamInput(el, previousCleanText = '') {
        if (!el) return;
        lastClearedExamText = previousCleanText || '';
        examClearGuardUntil = Date.now() + 900;
        el.value = '';
        el.defaultValue = '';
        try { el.setAttribute('value', ''); } catch (error) {}
        requestAnimationFrame(() => clearExamCarryoverIfNeeded(el));
        setTimeout(() => clearExamCarryoverIfNeeded(el), 60);
        setTimeout(() => clearExamCarryoverIfNeeded(el), 180);
    }

    function getCurrentExamTarget(el) {
        if (el === quizInput) return normalizeForQuiz(currentSentences[quizIndex]?.a || '');
        return cleanText(currentSentences[currentIndex]?.s || '');
    }

    function clearExamCarryoverIfNeeded(el) {
        if (!el || !el.value || Date.now() > examClearGuardUntil) return false;
        const value = el === quizInput ? normalizeForQuiz(el.value) : cleanText(el.value);
        if (!value || !lastClearedExamText) return false;
        const target = getCurrentExamTarget(el);
        if (target && target.startsWith(value)) return false;
        if (lastClearedExamText.endsWith(value) || (value.length >= 2 && lastClearedExamText.includes(value))) {
            el.value = '';
            el.defaultValue = '';
            try { el.setAttribute('value', ''); } catch (error) {}
            return true;
        }
        return false;
    }

    function readPassedSets() {
        try {
            const rows = JSON.parse(localStorage.getItem(GRADUATION_SET_KEY) || '{}');
            return rows && typeof rows === 'object' ? rows : {};
        } catch (error) { return {}; }
    }

    function writePassedSets(rows) {
        localStorage.setItem(GRADUATION_SET_KEY, JSON.stringify(rows || {}));
    }

    function allSetsPassed(rows = readPassedSets()) {
        return Object.keys(ALL_SETS).every(key => rows[key] && rows[key].passed);
    }

    function passedSetCount(rows = readPassedSets()) {
        return Object.keys(ALL_SETS).filter(key => rows[key] && rows[key].passed).length;
    }

    function nextIncompleteSet(rows = readPassedSets()) {
        return Object.keys(ALL_SETS).find(key => !(rows[key] && rows[key].passed)) || Object.keys(ALL_SETS)[0];
    }

    function markSetPassed(setNo, metrics) {
        const rows = readPassedSets();
        rows[String(setNo)] = { passed: true, passedAt: new Date().toISOString(), ...metrics };
        writePassedSets(rows);
        if (allSetsPassed(rows)) {
            localStorage.setItem(GRADUATION_ALL_FLAG, 'true');
            localStorage.setItem(GRADUATION_LEGACY_FLAG, 'true');
            localStorage.setItem('sorizava_graduation_exam_passed_at', new Date().toISOString());
        }
        return rows;
    }

    function updateSetProgressUI() {
        const rows = readPassedSets();
        const selector = document.getElementById('set-selector');
        if (selector) {
            Array.from(selector.options).forEach(option => {
                const passed = rows[option.value] && rows[option.value].passed;
                const base = `제 ${option.value}세트`;
                option.textContent = passed ? `${base} ✅ 통과` : base;
                option.disabled = Boolean(passed);
            });
            if (allSetsPassed(rows)) {
                selector.disabled = true;
            } else if (selector.options[selector.selectedIndex]?.disabled) {
                selector.value = nextIncompleteSet(rows);
            }
        }
        const stat = document.getElementById('stat-progress');
        if (stat && !isQuizMode && currentIndex === 0) {
            stat.innerText = `[통과 세트: ${passedSetCount(rows)}/9]`;
        }
    }

    function startPractice() {
        const rows = readPassedSets();
        if (allSetsPassed(rows)) {
            alert('입문반 졸업시험 9세트를 모두 통과했습니다. 중급반 공부방이 열립니다.');
            updateSetProgressUI();
            return;
        }
        const selector = document.getElementById('set-selector');
        if (rows[selector.value] && rows[selector.value].passed) {
            selector.value = nextIncompleteSet(rows);
            alert('이미 통과한 세트입니다. 다음 미통과 세트로 이동합니다.');
            updateSetProgressUI();
            return;
        }
        currentSentences = ALL_SETS[selector.value];
        currentIndex = 0; speeds = [];
        resetLiveStats();
        quizOverlay.style.display = 'none'; isQuizMode = false;
        inputEl.disabled = false; loadSentence();
        
        inputEl.placeholder = "위 문장을 보고 입력하세요";
        inputEl.focus();
    }

    function loadSentence() {
        if (currentIndex < 10) {
            stopLiveSpeedTimer();
            displayEl.innerText = currentSentences[currentIndex].s;
            forceClearExamInput(inputEl, cleanText(currentSentences[currentIndex - 1]?.s || '')); lineStartTime = null;
            window.__examLiveSpeed = 0;
            liveErrorCount = 0;
            liveAccuracy = 0;
            updateLiveStatElements();
            document.getElementById('stat-progress').innerText = `[연습 중: ${currentIndex+1}/10]`;
            inputEl.focus();
        } else { startQuizMode(); }
    }

    inputEl.addEventListener('input', () => {
        clearExamCarryoverIfNeeded(inputEl);
        if (!lineStartTime && cleanText(inputEl.value || '').length > 0) {
            lineStartTime = Date.now();
            startLiveSpeedTimer();
        }
        refreshRealtimeMetrics();
    });

    inputEl.addEventListener('keydown', (e) => { 
        const isTextInputKey = e.key && e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey;
        if (!lineStartTime && isTextInputKey) {
            lineStartTime = Date.now();
            startLiveSpeedTimer();
        } 
        if (e.key === "Backspace") {
            backspaceCount++;
            updateLiveStatElements();
        }
        requestAnimationFrame(refreshRealtimeMetrics);
    });

    inputEl.addEventListener('keypress', (e) => {
        if (e.key === "Enter") {
            if (clearExamCarryoverIfNeeded(inputEl)) return;
            const entered = inputEl.value;
            // [수정됨] 특수문자/공백 무시하고 글자만 비교
            if (cleanText(currentSentences[currentIndex].s) !== cleanText(entered)) {
                alert("오타가 있습니다!");
                forceClearExamInput(inputEl, cleanText(entered));

                // 오타로 입력창이 초기화되면 같은 문장을 처음부터 다시 치는 상태이므로
                // 실시간 속도도 기존 시작 시간을 버리고 다음 첫 입력부터 다시 측정합니다.
                stopLiveSpeedTimer();
                lineStartTime = null;
                window.__examLiveSpeed = 0;
                liveErrorCount = 0;
                liveAccuracy = 0;
                updateLiveStatElements();
                return;
            }
            const sec = (Date.now() - lineStartTime) / 1000;
            speeds.push((cleanText(entered).length / sec) * 60);
            currentIndex++; loadSentence();
        }
    });

    function startQuizMode() {
        stopLiveSpeedTimer();
        isQuizMode = true; quizIndex = 0; totalAbbrChars = 0; correctAbbrChars = 0;
        currentSentences.forEach(item => totalAbbrChars += normalizeForQuiz(item.a).length);
        quizOverlay.style.display = 'flex'; loadQuizQuestion();
    }

    function loadQuizQuestion() {
        if (quizIndex < 10) {
            document.getElementById('quiz-count').innerText = `${quizIndex + 1}/10`;
            document.getElementById('quiz-sentence').innerText = currentSentences[quizIndex].s;
            forceClearExamInput(quizInput, normalizeForQuiz(currentSentences[quizIndex - 1]?.a || '')); quizInput.disabled = false;
            document.getElementById('quiz-feedback').style.visibility = 'hidden';
            quizInput.focus();
        } else { finishAll(); }
    }

    quizInput.addEventListener('input', () => { clearExamCarryoverIfNeeded(quizInput); });

    quizInput.addEventListener('keypress', (e) => {
        if (e.key === "Enter" && !quizInput.disabled) {
            if (clearExamCarryoverIfNeeded(quizInput)) return;
            const correctRaw = currentSentences[quizIndex].a;
            const userRaw = quizInput.value;
            const normCorrect = normalizeForQuiz(correctRaw);
            const normUser = normalizeForQuiz(userRaw);
            const feedback = document.getElementById('quiz-feedback');
            const statusText = document.getElementById('status-text');

            feedback.style.visibility = 'visible';
            quizInput.disabled = true;

            if (normCorrect === normUser) {
                correctAbbrChars += normCorrect.length;
                statusText.innerText = "● 정답입니다!";
                statusText.style.color = "var(--success)";
                document.getElementById('user-diff-display').innerHTML = "";
                document.getElementById('quiz-correct-ans').innerText = "";
                setTimeout(() => { quizIndex++; loadQuizQuestion(); }, 1000);
            } else {
                statusText.innerText = "X 오답입니다";
                statusText.style.color = "var(--danger)";
                let matches = 0;
                for(let i=0; i<Math.min(normCorrect.length, normUser.length); i++) {
                    if(normCorrect[i] === normUser[i]) matches++;
                }
                correctAbbrChars += matches;
                showWrongFeedback(userRaw, correctRaw);
                setTimeout(() => { quizIndex++; loadQuizQuestion(); }, 2500);
            }
        }
    });

    function showWrongFeedback(user, correct) {
        const userDiffArea = document.getElementById('user-diff-display');
        const correctArea = document.getElementById('quiz-correct-ans');
        let diffHtml = "나의 입력: ";
        for (let i = 0; i < user.length; i++) {
            if (!correct.includes(user[i])) diffHtml += `<span class="wrong">${user[i]}</span>`;
            else diffHtml += `<span>${user[i]}</span>`;
        }
        userDiffArea.innerHTML = diffHtml;
        correctArea.innerText = `정답: ${correct}`;
    }

    function finishAll() {
        stopLiveSpeedTimer();
        quizOverlay.style.display = 'none';
        const setNo = document.getElementById('set-selector').value;
        const avgCpm = speeds.reduce((a, b) => a + b, 0) / Math.max(1, speeds.length);
        const finalRatio = totalAbbrChars > 0 ? correctAbbrChars / totalAbbrChars : 0;
        const passed = (avgCpm >= 70 && finalRatio >= 0.90);
        const metrics = { cpm: Number(avgCpm.toFixed(1)), accuracy: Number((finalRatio*100).toFixed(1)), backspaceCount };
        const passedRows = passed ? markSetPassed(setNo, metrics) : readPassedSets();
        const completeAll = allSetsPassed(passedRows);
        const setCount = passedSetCount(passedRows);

        alert(`[시험 결과]\n응시 세트: ${setNo}세트\n평균 속도: ${avgCpm.toFixed(1)}자\n약어 정확도: ${(finalRatio*100).toFixed(1)}%\n백스페이스: ${backspaceCount}회\n세트 결과: ${passed ? '통과' : '미통과'}\n누적 통과: ${setCount}/9세트${completeAll ? '\n전체 결과: 입문반 졸업시험 최종 통과' : ''}`);
        addExamHistory({
            id: `${Date.now()}_${Math.random().toString(16).slice(2)}`,
            setNo,
            cpm: Number(avgCpm.toFixed(1)),
            accuracy: Number((finalRatio * 100).toFixed(1)),
            backspaceCount,
            passed,
            completeAll,
            createdAt: new Date().toISOString()
        });
        
        document.getElementById('history-section').style.display = 'block';
        updateSetProgressUI();
        if (window.SorizavaRecords) {
            window.SorizavaRecords.savePracticeRecord({
                tool_type: 'exam',
                practice_title: `입문반 졸업시험 ${setNo}세트`,
                accuracy: Number((finalRatio*100).toFixed(1)),
                score: Number((finalRatio*100).toFixed(1)),
                cpm: Number(avgCpm.toFixed(1)),
                wrong_count: Math.max(0, totalAbbrChars - correctAbbrChars),
                memo: completeAll ? `입문반 졸업시험 9세트 전체 합격 / 백스페이스 ${backspaceCount}회` : (passed ? `입문반 졸업시험 ${setNo}세트 합격 / 백스페이스 ${backspaceCount}회` : `입문반 졸업시험 ${setNo}세트 불합격 / 백스페이스 ${backspaceCount}회`)
            });
        }
    }

    function toggleHistory() {
        const s = document.getElementById('history-section');
        s.style.display = s.style.display === 'block' ? 'none' : 'block';
    }
    
    function initExamPage() {
        renderExamHistory();
        updateSetProgressUI();
        hydrateGraduationProgressFromRemote();
        updateLiveStatElements();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initExamPage);
    } else {
        initExamPage();
    }
    
    function logout() { 
        if(confirm("로그아웃 하시겠습니까?")) window.SorizavaAuth.signOut(); 
    }
