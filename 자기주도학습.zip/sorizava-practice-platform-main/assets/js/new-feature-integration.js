
// New dashboard / practice room / mypage integration bridge - 2026-05-05
(function () {
  const $ = (id) => document.getElementById(id);
  const qa = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const toolLabelFallback = {
    editorial: '사설연습', toksori2: '똑소리2', king: '타자왕', exam: '입문반 졸업시험', exam_simulation: '실전 시험 모드',
    random: '약어랜덤', random_dictionary: '내 약어장 보고치기', random_voice_dictionary: '내 약어장 듣고치기', random_abbr_wrong_visual: '약어 오답 보고치기', random_abbr_wrong_voice: '약어 오답 듣고치기', measure: '자수측정', sparta: '스파르타', intermediate: '중급반 공부방', advanced: '고급반 공부방', grade: '급수반 공부방',
    practice_room_audio: '기존 듣고치기', practice_room_reading: '기존 보고치기', quest: '퀘스트', practice_room_quest: '퀘스트', unknown: '기타'
  };
  let appContext = null;
  let practiceSaveLock = false;
  let lastSavedSignature = '';

  function esc(value) {
    return String(value ?? '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  }
  function num(value, fallback = 0) {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
  }
  function nullableNum(value) {
    const n = Number(value);
    return Number.isFinite(n) ? n : null;
  }
  function round1(value) {
    const n = Number(value);
    return Number.isFinite(n) ? Math.round(n * 10) / 10 : 0;
  }
  function toolLabel(type) {
    return window.SorizavaRecords?.getToolLabel?.(type) || toolLabelFallback[type] || type || '기타';
  }
  function kstDateTime(value) {
    if (!value) return '-';
    try { return new Date(value).toLocaleString('ko-KR', { timeZone: 'Asia/Seoul', year:'numeric', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit' }); }
    catch(e) { return '-'; }
  }
  function passBadge(record) {
    const score = nullableNum(record?.accuracy ?? record?.score);
    const pass = score !== null && score >= 90;
    return pass
      ? '<span class="rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-1 text-xs font-black text-emerald-700">통과</span>'
      : '<span class="rounded-full border border-rose-200 bg-rose-50 px-2.5 py-1 text-xs font-black text-rose-700">미통과</span>';
  }
  function scoreText(record) {
    const score = nullableNum(record?.accuracy ?? record?.score);
    return score === null ? '-' : `${round1(score)}%`;
  }
  function cpmFromTitle(title) {
    const m = String(title || '').match(/(110|120|130|140|150|160|170|180|190|200|210|220|230|240|250|270|300|330)\s*자/);
    return m ? Number(m[1]) : null;
  }
  function setLoading(show) { const el = $('loading-overlay'); if (el) el.style.display = show ? 'flex' : 'none'; }
  function getDisplayName(ctx) { return ctx?.profile?.name || ctx?.user?.email || sessionStorage.getItem('shorthand_user') || 'User'; }
  function getUserKey() { return appContext?.user?.id || sessionStorage.getItem('shorthand_user_id') || 'guest'; }
  function showToast(message, type = '') {
    let el = document.querySelector('.new-feature-toast');
    if (!el) { el = document.createElement('div'); el.className = 'new-feature-toast'; document.body.appendChild(el); }
    el.className = `new-feature-toast ${type || ''}`.trim();
    el.textContent = message;
    clearTimeout(showToast._timer);
    showToast._timer = setTimeout(() => el.remove(), 2600);
  }
  function setProfile(ctx) {
    appContext = ctx || appContext;
    const name = getDisplayName(ctx);
    qa('#userNameSide, #sideUserName').forEach(el => { el.textContent = name; });
    qa('#userAvatar').forEach(el => { el.textContent = String(name || 'U').charAt(0).toUpperCase(); });
    qa('p, h1, h2').forEach(el => {
      if (el.textContent.includes('김속기님')) el.textContent = el.textContent.replace(/김속기님/g, `${name}님`);
      if (el.textContent.trim() === '김속기') el.textContent = name;
    });
    const adminBtn = $('adminBtn');
    const role = String(ctx?.profile?.role || '').toLowerCase();
    if (adminBtn && ['admin', 'operator', 'teacher'].includes(role)) adminBtn.style.display = 'block';
  }
  function attachGoLinks() {
    qa('[data-go]').forEach(el => {
      if (el.dataset.goBound) return;
      el.dataset.goBound = '1';
      el.addEventListener('click', () => { location.href = el.getAttribute('data-go'); });
    });
  }

  async function login() {
    const email = $('nameInput')?.value?.trim();
    const pw = $('pwInput')?.value;
    if (!email || !pw) return alert('이메일과 비밀번호를 입력해 주세요.');
    setLoading(true);
    try {
      const { profile } = await window.SorizavaAuth.signIn(email, pw);
      if (profile.status !== 'approved') { location.href = 'pending.html'; return; }
      await initNewDashboardApp();
    } catch (e) {
      console.error('로그인 실패:', e);
      alert('로그인 실패 상세:\n' + (e?.userMessage || e?.message || String(e)));
    } finally { setLoading(false); }
  }

  function logout() { if (confirm('로그아웃 하시겠습니까?')) window.SorizavaAuth.signOut(); }
  function closeNotice() { const n = $('notice-area'); if (n) n.style.display = 'none'; localStorage.setItem('notice_closed_' + todayKey(), 'true'); }
  function todayKey() {
    const d = new Date();
    const k = new Date(d.getTime() + 9 * 60 * 60 * 1000);
    return k.toISOString().slice(0, 10);
  }

  async function fetchActiveNotice() {
    try {
      const { data, error } = await window.SORIZAVA_SUPABASE.from('notices').select('*').eq('is_active', true).order('created_at', { ascending: false }).limit(5);
      if (error) throw error;
      return data || [];
    } catch (e) { console.warn('공지사항 조회 실패:', e); return []; }
  }

  function renderNoticeList(list) {
    const area = $('dashboardNoticeList');
    if (!area) return;
    if (!list.length) {
      area.innerHTML = '<p class="py-3 text-sm text-slate-500">등록된 공지사항이 없습니다.</p>';
      return;
    }
    area.innerHTML = list.map((n, idx) => `
      <a class="block py-3 hover:bg-slate-50" href="#">
        <div class="flex items-center gap-2">
          <span class="rounded-full ${idx === 0 ? 'bg-rose-50 text-rose-700' : 'bg-slate-100 text-slate-600'} px-2 py-0.5 text-[11px] font-black">${idx === 0 ? '중요' : '공지'}</span>
          <p class="truncate text-sm font-black">${esc(n.title || n.content || '공지사항')}</p>
        </div>
        <p class="mt-1 text-xs text-slate-400">${kstDateTime(n.created_at).slice(0, 12)}</p>
      </a>`).join('');
  }

  function recordRow(record, colspanFeedback) {
    const missing = num(record.missing_count);
    const added = num(record.added_count);
    const wrong = num(record.wrong_count);
    const feedbackBtn = colspanFeedback ? `<td class="px-4 py-4"><button class="rounded-xl border border-indigo-200 bg-indigo-50 px-3 py-2 text-xs font-black text-indigo-700" data-feedback-record="${esc(record.id || '')}">신청하기</button></td>` : '';
    return `<tr>
      <td class="px-4 py-4 font-medium">${kstDateTime(record.created_at)}</td>
      <td class="px-4 py-4"><span class="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-black text-slate-700">${esc(toolLabel(record.tool_type))}</span></td>
      <td class="px-4 py-4">${esc(record.practice_title || '-')}</td>
      <td class="px-4 py-4 font-black">${scoreText(record)}</td>
      <td class="px-4 py-4 text-blue-600">${missing}</td>
      <td class="px-4 py-4 text-amber-600">${added}</td>
      <td class="px-4 py-4 text-rose-600">${wrong}</td>
      <td class="px-4 py-4">${passBadge(record)}</td>${feedbackBtn}
    </tr>`;
  }

  function practiceRecordRow(record) {
    return `<tr>
      <td class="px-4 py-3 font-medium">${kstDateTime(record.created_at)}</td>
      <td class="px-4 py-3">${esc(toolLabel(record.tool_type))}</td>
      <td class="px-4 py-3">${esc(record.practice_title || '-')}</td>
      <td class="px-4 py-3 font-black">${scoreText(record)}</td>
      <td class="px-4 py-3 text-blue-600">${num(record.missing_count)}</td>
      <td class="px-4 py-3 text-amber-600">${num(record.added_count)}</td>
      <td class="px-4 py-3 text-rose-600">${num(record.wrong_count)}</td>
      <td class="px-4 py-3">${passBadge(record)}</td>
    </tr>`;
  }

  async function renderDashboardData() {
    const [summary, notices] = await Promise.all([
      window.SorizavaRecords.getMyStudyInsight().catch(e => { console.warn(e); return { records: [], avgAcc: 0, maxCPM: 0, streak: 0, graphData: [], insight: {} }; }),
      fetchActiveNotice()
    ]);
    renderNoticeList(notices);
    if (notices[0] && !localStorage.getItem('notice_closed_' + todayKey())) {
      const nt = $('noticeText'), na = $('notice-area');
      if (nt && na) { nt.textContent = notices[0].content || notices[0].title || ''; na.style.display = 'flex'; }
    }
    const records = summary.records || [];
    const recentBody = $('dashboardRecentBody');
    if (recentBody) {
      recentBody.innerHTML = records.length ? records.slice(0, 8).map(r => recordRow(r, false)).join('') : '<tr><td colspan="8" class="px-4 py-6 text-center text-slate-500">아직 저장된 연습 기록이 없습니다.</td></tr>';
    }
    updateDashboardText(summary);
    renderDashboardFeedback();
  }

  function updateDashboardText(summary) {
    const records = summary.records || [];
    const insight = summary.insight || {};
    const avg = round1(summary.avgAcc || 0);
    const level = insight.progressStatus?.currentLevel || cpmFromTitle(records[0]?.practice_title) || '-';
    const progress = Math.min(100, Math.max(0, records.length ? Math.round((records.length / 40) * 100) : 0));
    qa('p').forEach(p => {
      if (p.textContent.includes('현재 단계는')) p.textContent = level === '-' ? '연습 기록이 쌓이면 현재 단계와 진도 상태가 자동으로 표시됩니다.' : `현재 단계는 ${level}자 기준으로 분석 중입니다. 최근 평균 정확도는 ${avg}%입니다.`;
    });
    const statCards = qa('section .rounded-2xl, section .rounded-3xl');
    qa('p, h2, h3').forEach(el => {
      const t = el.textContent.trim();
      if (t === '18' && el.className.includes('text-4xl')) el.textContent = String(getCreditState().balance);
      if (t === '고급' && level !== '-') el.textContent = level >= 190 ? '고급' : '중급';
      if (t.includes('연설 190자 / 논설 160자') && level !== '-') el.textContent = `${level}자 구간 기록 분석 중`;
      if (t === '62%') el.textContent = `${progress}%`;
    });
  }

  async function initNewDashboardApp() {
    setLoading(true);
    try {
      const session = await window.SorizavaAuth.getSession();
      if (!session) {
        const loginWrap = $('login-wrapper'), appWrap = $('app-wrapper');
        if (loginWrap) loginWrap.style.display = 'flex';
        if (appWrap) appWrap.style.display = 'none';
        return;
      }
      const ctx = await window.SorizavaAuth.requireApproved({ redirect: false });
      if (!ctx) {
        const loginWrap = $('login-wrapper'), appWrap = $('app-wrapper');
        if (loginWrap) loginWrap.style.display = 'flex';
        if (appWrap) appWrap.style.display = 'none';
        return;
      }
      if (!ctx.approved) { location.href = 'pending.html'; return; }
      setProfile(ctx);
      const loginWrap = $('login-wrapper'), appWrap = $('app-wrapper');
      if (loginWrap) loginWrap.style.display = 'none';
      if (appWrap) appWrap.style.display = 'flex';
      attachGoLinks();
      await renderDashboardData();
    } finally { setLoading(false); }
  }

  function exactStats(original, typed) {
    const rawO = String(original || '').trim();
    const rawS = String(typed || '').trim();
    const isSpecial = (char) => /[^0-9a-zA-Z\uAC00-\uD7A3]/.test(char);
    let pureLength = rawO.replace(/[^0-9a-zA-Z\uAC00-\uD7A3]/g, '').length || 1;
    const oArr = rawO.split('');
    const sArr = rawS.split('');
    const n = oArr.length, m = sArr.length;
    const dp = Array.from({ length: n + 1 }, () => Array(m + 1).fill(0));
    for (let i = 1; i <= n; i++) for (let j = 1; j <= m; j++) dp[i][j] = oArr[i - 1] === sArr[j - 1] ? dp[i - 1][j - 1] + 1 : Math.max(dp[i - 1][j], dp[i][j - 1]);
    let i = n, j = m, diffs = [];
    while (i > 0 || j > 0) {
      if (i > 0 && j > 0 && oArr[i - 1] === sArr[j - 1]) { diffs.push({ t: 'same', c: oArr[i - 1] }); i--; j--; }
      else if (j > 0 && (i === 0 || dp[i][j - 1] >= dp[i - 1][j])) { diffs.push({ t: 'added', c: sArr[j - 1] }); j--; }
      else { diffs.push({ t: 'missing', c: oArr[i - 1] }); i--; }
    }
    diffs.reverse();
    let wrong = 0, missing = 0, added = 0, mBuf = [], aBuf = [];
    function flush() {
      let mi = 0, ai = 0;
      while (mi < mBuf.length || ai < aBuf.length) {
        const mc = mBuf[mi], ac = aBuf[ai];
        if (mi < mBuf.length && isSpecial(mc)) { mi++; continue; }
        if (ai < aBuf.length && isSpecial(ac)) { ai++; continue; }
        if (mi < mBuf.length && ai < aBuf.length) { wrong++; mi++; ai++; continue; }
        if (mi < mBuf.length) { missing++; mi++; continue; }
        if (ai < aBuf.length) { added++; ai++; continue; }
      }
      mBuf = []; aBuf = [];
    }
    diffs.forEach(d => { if (d.t === 'same') flush(); else if (d.t === 'missing') mBuf.push(d.c); else aBuf.push(d.c); });
    flush();
    const addPenalty = Math.floor(added / 3);
    const accuracy = Math.max(0, 100 - ((wrong + missing + addPenalty) / pureLength * 100));
    return { accuracy: round1(accuracy), wrong, missing, added, originalLength: pureLength, typedLength: rawS.length };
  }

  function getPracticeTitle() {
    const resultPath = $('resultPath')?.textContent || $('selectionSummary')?.textContent || '';
    return resultPath.replace(/^\s*(듣고치기|보고치기|퀘스트)\s*·\s*/, '').trim() || '기존 연습 기록';
  }
  function getModeLabel() { return ($('resultPath')?.textContent || $('selectionSummary')?.textContent || '').includes('보고치기') ? '보고치기' : '듣고치기'; }
  function getAnswerForCurrentPractice(title, mode) {
    if (mode === '보고치기') return $('sourceText')?.textContent?.trim() || '';
    try {
      const map = window.SORIZAVA_PRACTICE_ANSWERS || JSON.parse(localStorage.getItem('sorizava_practice_answers_v1') || '{}');
      return map[title] || map[title.replace(/\s+/g, '')] || '';
    } catch (e) { return ''; }
  }
  function updateResultPanelFromStats(stats, modeLabel, title) {
    if ($('resultAccuracy')) $('resultAccuracy').textContent = stats.accuracy;
    if ($('resultOmit')) $('resultOmit').textContent = stats.missing;
    if ($('resultAdd')) $('resultAdd').textContent = stats.added;
    if ($('resultWrong')) $('resultWrong').textContent = stats.wrong;
    if ($('resultPath')) $('resultPath').textContent = `${modeLabel} · ${title}`;
  }
  async function saveCurrentPracticeRecord() {
    if (practiceSaveLock) return;
    const modeLabel = getModeLabel();
    const title = getPracticeTitle();
    const typed = modeLabel === '보고치기' ? ($('readingEditor')?.value || '') : ($('audioEditor')?.value || '');
    const answer = getAnswerForCurrentPractice(title, modeLabel);
    let stats;
    if (answer) stats = exactStats(answer, typed);
    else {
      stats = {
        accuracy: num($('resultAccuracy')?.textContent, modeLabel === '보고치기' ? 89 : 92),
        missing: num($('resultOmit')?.textContent, modeLabel === '보고치기' ? 4 : 2),
        added: num($('resultAdd')?.textContent, modeLabel === '보고치기' ? 2 : 1),
        wrong: num($('resultWrong')?.textContent, modeLabel === '보고치기' ? 5 : 3),
        originalLength: null,
        typedLength: typed.length
      };
    }
    updateResultPanelFromStats(stats, modeLabel, title);
    const sig = [modeLabel, title, typed, stats.accuracy, stats.wrong, stats.missing, stats.added].join('|');
    if (sig === lastSavedSignature) return;
    lastSavedSignature = sig;
    practiceSaveLock = true;
    try {
      const saved = await window.SorizavaRecords.savePracticeRecord({
        tool_type: new URLSearchParams(location.search).get('quest') === '1' ? 'quest' : (modeLabel === '보고치기' ? 'practice_room_reading' : 'practice_room_audio'),
        practice_title: `${title}${modeLabel === '듣고치기' ? ' · ' + ($('speedLabel')?.textContent || '+1.0x') : ''}`,
        original_length: stats.originalLength,
        typed_length: stats.typedLength,
        accuracy: stats.accuracy,
        score: stats.accuracy,
        cpm: cpmFromTitle(title),
        wrong_count: stats.wrong,
        missing_count: stats.missing,
        added_count: stats.added,
        spacing_error_count: 0,
        memo: answer ? '정답 비교 자동 저장' : '기록 저장: 정답 원문 미연결로 화면 결과값 기준 저장'
      });
      if (saved) {
        showToast('연습 기록을 기존 practice_records에 저장했습니다.', 'good');
        await renderPracticeRecentRecords();
      } else {
        showToast('기록 저장에 실패했습니다. 로그인과 Supabase 연결을 확인하세요.', 'bad');
      }
    } finally { practiceSaveLock = false; }
  }

  function attachPracticeSave() {
    ['gradeBtnTop', 'gradeBtnBottom'].forEach(id => {
      const btn = $(id);
      if (!btn || btn.dataset.integratedSave) return;
      btn.dataset.integratedSave = '1';
      btn.addEventListener('click', () => setTimeout(saveCurrentPracticeRecord, 80));
    });
    const allRecord = qa('button').find(b => b.textContent.includes('전체 기록 보기'));
    if (allRecord && !allRecord.dataset.integratedRecord) {
      allRecord.dataset.integratedRecord = '1';
      allRecord.addEventListener('click', () => { location.href = 'mypage.html#records'; });
    }
  }

  function attachAudioPlayback() {
    const playBtn = document.querySelector('#audioWorkspace button');
    if (!playBtn || playBtn.dataset.audioBound) return;
    playBtn.dataset.audioBound = '1';
    let audio = $('practiceAudio');
    if (!audio) { audio = document.createElement('audio'); audio.id = 'practiceAudio'; audio.preload = 'metadata'; document.body.appendChild(audio); }
    playBtn.addEventListener('click', async () => {
      const title = $('audioTitle')?.textContent?.trim() || '';
      if (!title) return showToast('먼저 문제를 선택해 주세요.', 'warn');
      const src = (window.SORIZAVA_PRACTICE_AUDIO || {})[title] || `assets/audio/${title}`;
      if (audio.src && audio.src.endsWith(src) && !audio.paused) { audio.pause(); playBtn.textContent = '▶'; return; }
      audio.src = src;
      try { await audio.play(); playBtn.textContent = 'Ⅱ'; }
      catch(e) { playBtn.textContent = '▶'; showToast(`음원 파일 경로가 연결되었습니다. 실제 파일을 추가하세요: ${src}`, 'warn'); }
    });
    audio.addEventListener('ended', () => { playBtn.textContent = '▶'; });
  }

  async function renderPracticeRecentRecords() {
    const body = $('recordTable');
    if (!body) return;
    let records = [];
    try { records = await window.SorizavaRecords.getMyRecentRecords(80); } catch(e) { console.warn(e); }
    const filtered = records.filter(r => ['practice_room_audio', 'practice_room_reading', 'quest', 'practice_room_quest'].includes(r.tool_type));
    body.innerHTML = filtered.length ? filtered.slice(0, 20).map(practiceRecordRow).join('') : '<tr><td colspan="8" class="px-4 py-6 text-center text-slate-500">중급반 공부방/고급반 공부방/급수반 공부방에서 채점하면 이곳에 기록됩니다.</td></tr>';
  }

  async function initNewPracticeRoomPage(ctx) {
    setProfile(ctx);
    const app = $('app-wrapper'); if (app) app.style.display = 'flex';
    attachGoLinks();
    attachPracticeSave();
    attachAudioPlayback();
    await renderPracticeRecentRecords();
    if (typeof window.initStudyToolsPage === 'function') {
      try { await window.initStudyToolsPage(ctx); } catch(e) { console.warn('기존 공부방 기능 로드 실패:', e); }
    }
    if (new URLSearchParams(location.search).get('quest') === '1') showToast('퀘스트 모드로 입장했습니다. 문제를 선택하고 채점하면 퀘스트 기록으로 저장됩니다.', 'good');
  }

  function creditKey() { return `sorizava_credit_${getUserKey()}_v1`; }
  function getCreditState() {
    try {
      const raw = JSON.parse(localStorage.getItem(creditKey()) || 'null');
      if (raw && typeof raw === 'object') return { balance: num(raw.balance, 18), ledger: Array.isArray(raw.ledger) ? raw.ledger : [] };
    } catch(e) {}
    return { balance: 18, ledger: [{ date: new Date().toISOString(), type: '지급', text: '초기 크레딧', change: 18, balance: 18, status: '지급 완료' }] };
  }
  function setCreditState(state) { localStorage.setItem(creditKey(), JSON.stringify(state)); }
  function feedbackKey() { return `sorizava_feedback_${getUserKey()}_v1`; }
  function getFeedbacks() { try { return JSON.parse(localStorage.getItem(feedbackKey()) || '[]'); } catch(e) { return []; } }
  function setFeedbacks(list) { localStorage.setItem(feedbackKey(), JSON.stringify(list.slice(0, 100))); }
  function createFeedback(record, question) {
    const credits = getCreditState();
    if (credits.balance < 2) { showToast('크레딧이 부족합니다.', 'bad'); return false; }
    credits.balance -= 2;
    credits.ledger.unshift({ date: new Date().toISOString(), type: '사용', text: `강사 피드백 신청 · ${record.practice_title || '채점 내역'}`, change: -2, balance: credits.balance, status: '접수 완료' });
    setCreditState(credits);
    const list = getFeedbacks();
    list.unshift({ id: `fb_${Date.now()}`, createdAt: new Date().toISOString(), status: 'received', record, question: question || '채점 결과에 대한 피드백을 요청합니다.', answer: buildAutoFeedback(record), checked: false });
    setFeedbacks(list);
    showToast('피드백 신청을 접수하고 크레딧 2개를 차감했습니다.', 'good');
    return true;
  }
  function buildAutoFeedback(record) {
    const wrong = num(record?.wrong_count), missing = num(record?.missing_count), added = num(record?.added_count);
    const max = Math.max(wrong, missing, added);
    if (!max) return '오류 수가 적습니다. 같은 속도에서 정확도 유지 여부를 2회 더 확인하세요.';
    if (missing === max) return '탈자가 가장 많습니다. 후반부 구간을 짧게 끊어 반복하고, 속도보다 누락 방지를 우선하세요.';
    if (wrong === max) return '오자가 가장 많습니다. 비슷한 어미와 조사를 구분하는 훈련이 필요합니다.';
    return '첨자가 가장 많습니다. 들리지 않은 말을 보태는 습관을 줄이고 원문 흐름을 짧게 확인하세요.';
  }

  function activateMyPage(pageId) {
    const tabs = qa('.tab');
    const pages = qa('.page');
    tabs.forEach(tab => tab.classList.toggle('active', tab.dataset.page === pageId));
    pages.forEach(page => page.classList.toggle('active', page.id === pageId));
    if (location.hash.slice(1) !== pageId) history.replaceState(null, '', `#${pageId}`);
  }
  function attachMyPageTabs() {
    qa('.tab').forEach(tab => {
      if (tab.dataset.integratedTab) return;
      tab.dataset.integratedTab = '1';
      tab.addEventListener('click', () => activateMyPage(tab.dataset.page));
    });
    qa('[data-page-button]').forEach(btn => {
      if (btn.dataset.integratedPageBtn) return;
      btn.dataset.integratedPageBtn = '1';
      btn.addEventListener('click', () => activateMyPage(btn.dataset.pageButton));
    });
    const start = location.hash ? location.hash.slice(1) : 'summary';
    if ($(start)) activateMyPage(start);
  }

  function renderMySummary(summary) {
    const records = summary.records || [];
    const name = getDisplayName(appContext);
    qa('#summary .text-xl.font-black').forEach(el => { if (el.textContent.includes('김속기')) el.textContent = `${name}님`; });
    qa('#summary p, #summary span, #summary strong').forEach(el => {
      const t = el.textContent.trim();
      if (t === '18') el.textContent = String(getCreditState().balance);
      if (t === '91.4%') el.textContent = `${round1(summary.avgAcc || 0)}%`;
      if (t === '128') el.textContent = String(records.length);
      if (t === '23') el.textContent = String(records.filter(r => ['quest','practice_room_quest'].includes(r.tool_type)).length);
      if (t === '2') el.textContent = String(getFeedbacks().length);
    });
    const recentCards = qa('#summary .mt-5.grid.gap-3')[0];
    if (recentCards) {
      recentCards.innerHTML = records.slice(0, 3).map(r => `<div class="flex flex-col justify-between gap-3 rounded-2xl border border-slate-200 p-4 sm:flex-row sm:items-center"><div><p class="text-sm font-black">${esc(r.practice_title || '-')}</p><p class="mt-1 text-xs text-slate-500">${kstDateTime(r.created_at)} · ${esc(toolLabel(r.tool_type))}</p></div><div class="flex items-center gap-2"><span class="text-sm font-black">${scoreText(r)}</span>${passBadge(r)}</div></div>`).join('') || '<div class="rounded-2xl border border-slate-200 p-4 text-sm text-slate-500">최근 학습 기록이 없습니다.</div>';
    }
  }
  function renderMyRecords(records) {
    const body = $('mypageRecordBody');
    if (!body) return;
    body.innerHTML = records.length ? records.slice(0, 100).map(r => recordRow(r, true)).join('') : '<tr><td colspan="9" class="px-4 py-6 text-center text-slate-500">저장된 학습 기록이 없습니다.</td></tr>';
    qa('[data-feedback-record]').forEach(btn => btn.addEventListener('click', () => {
      const record = records.find(r => String(r.id || '') === String(btn.dataset.feedbackRecord)) || records[0];
      const question = document.querySelector('#records textarea')?.value || '';
      if (record && createFeedback(record, question)) renderMyPageData({ records });
    }));
  }
  function renderCredit() {
    const st = getCreditState();
    qa('#plan p, #plan strong').forEach(el => {
      if (el.textContent.trim() === '18') el.textContent = String(st.balance);
    });
    const tbody = document.querySelector('#plan tbody');
    if (tbody) tbody.innerHTML = st.ledger.map(l => `<tr><td class="px-4 py-4">${kstDateTime(l.date).slice(0,12)}</td><td class="px-4 py-4">${esc(l.type)}</td><td class="px-4 py-4">${esc(l.text)}</td><td class="px-4 py-4 font-black ${l.change < 0 ? 'text-rose-600' : 'text-emerald-600'}">${l.change > 0 ? '+' : ''}${l.change}</td><td class="px-4 py-4 font-black">${l.balance}</td><td class="px-4 py-4"><span class="rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-black text-emerald-700">${esc(l.status || '완료')}</span></td></tr>`).join('');
  }
  function renderFeedback() {
    const list = getFeedbacks();
    const counts = { total: list.length, doing: list.filter(f => f.status !== 'received' && !f.checked).length, received: list.filter(f => f.status === 'received' && !f.checked).length, done: list.filter(f => f.checked).length };
    const statNums = qa('#feedback .grid.gap-4.md\\:grid-cols-4 .text-4xl');
    if (statNums.length >= 4) { statNums[0].textContent = counts.total; statNums[1].textContent = counts.doing; statNums[2].textContent = counts.received; statNums[3].textContent = counts.done; }
    const box = $('mypageFeedbackList');
    if (box) box.innerHTML = list.length ? list.map((f, idx) => `<button class="w-full rounded-2xl border ${idx===0?'border-indigo-300 bg-indigo-50 ring-4 ring-indigo-100':'border-slate-200 bg-white'} p-4 text-left" data-feedback-id="${esc(f.id)}"><div class="flex items-center justify-between"><p class="text-sm font-black">${esc(f.record?.practice_title || '피드백')}</p><span class="rounded-full ${f.checked?'bg-slate-100 text-slate-600':'bg-emerald-600 text-white'} px-2.5 py-1 text-xs font-black">${f.checked?'확인 완료':'도착'}</span></div><p class="mt-1 text-xs text-slate-500">${kstDateTime(f.createdAt)} · 연결 기록 ${scoreText(f.record || {})}</p></button>`).join('') : '<div class="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-5 text-sm text-slate-500">신청된 피드백이 없습니다. 학습 기록 탭에서 신청할 수 있습니다.</div>';
    qa('[data-feedback-id]').forEach(btn => btn.addEventListener('click', () => renderFeedbackDetail(list.find(f => f.id === btn.dataset.feedbackId))));
    renderFeedbackDetail(list[0]);
  }
  function renderFeedbackDetail(f) {
    const box = $('mypageFeedbackDetail');
    if (!box) return;
    if (!f) { box.innerHTML = '<div class="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm text-sm text-slate-500">피드백을 선택하면 상세 내용이 표시됩니다.</div>'; return; }
    box.innerHTML = `<div class="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm"><div class="flex flex-col justify-between gap-4 lg:flex-row lg:items-start"><div><p class="text-xs font-bold uppercase tracking-wide text-slate-400">Feedback Detail</p><h2 class="mt-1 text-xl font-black">${esc(f.record?.practice_title || '피드백')}</h2><p class="mt-1 text-sm text-slate-500">연결 기록 ${kstDateTime(f.record?.created_at || f.createdAt)} · 정확도 ${scoreText(f.record || {})}</p></div><span class="rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-black text-emerald-700">피드백 도착</span></div><div class="mt-6 grid gap-5 lg:grid-cols-2"><div class="rounded-2xl bg-slate-50 p-5"><p class="text-sm font-black">내가 보낸 질문</p><p class="mt-3 text-sm leading-7 text-slate-700">${esc(f.question)}</p></div><div class="rounded-2xl bg-slate-50 p-5"><p class="text-sm font-black">연결된 채점 내역</p><div class="mt-3 grid grid-cols-4 gap-2 text-center"><div class="rounded-xl bg-white p-3"><p class="text-xs text-slate-500">정확도</p><p class="mt-1 font-black">${scoreText(f.record || {})}</p></div><div class="rounded-xl bg-white p-3"><p class="text-xs text-slate-500">탈자</p><p class="mt-1 font-black text-blue-600">${num(f.record?.missing_count)}</p></div><div class="rounded-xl bg-white p-3"><p class="text-xs text-slate-500">첨자</p><p class="mt-1 font-black text-amber-600">${num(f.record?.added_count)}</p></div><div class="rounded-xl bg-white p-3"><p class="text-xs text-slate-500">오자</p><p class="mt-1 font-black text-rose-600">${num(f.record?.wrong_count)}</p></div></div></div></div></div><div class="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm"><p class="text-xs font-bold uppercase tracking-wide text-slate-400">Teacher Response</p><h2 class="mt-1 text-lg font-black">강사 답변</h2><div class="mt-5 rounded-2xl border border-slate-200 bg-slate-50 p-5"><p class="text-sm font-black">텍스트 피드백</p><p class="mt-3 text-sm leading-7 text-slate-700">${esc(f.answer)}</p></div><div class="mt-5 grid gap-3 sm:grid-cols-3"><button class="rounded-2xl border border-slate-200 bg-white px-5 py-4 text-sm font-black text-slate-700" data-go="intermediate.html">다시 연습하기</button><button class="rounded-2xl bg-indigo-600 px-5 py-4 text-sm font-black text-white" data-go="intermediate.html">비슷한 문제 풀기</button><button class="rounded-2xl bg-slate-950 px-5 py-4 text-sm font-black text-white" id="feedbackDoneBtn">확인 완료 처리</button></div></div>`;
    attachGoLinks();
    const done = $('feedbackDoneBtn');
    if (done) done.onclick = () => { const list = getFeedbacks().map(x => x.id === f.id ? { ...x, checked: true } : x); setFeedbacks(list); renderFeedback(); showToast('확인 완료 처리했습니다.', 'good'); };
  }
  function renderWrongNote(records) {
    const wrong = records.reduce((s,r)=>s+num(r.wrong_count),0), missing=records.reduce((s,r)=>s+num(r.missing_count),0), added=records.reduce((s,r)=>s+num(r.added_count),0);
    const nums = qa('#wrongnote .text-4xl');
    if (nums.length >= 3) { nums[0].textContent = missing; nums[1].textContent = wrong; nums[2].textContent = added; }
    const box = $('mypageWrongRecommendations');
    if (box) {
      const rows = [...records].sort((a,b)=>(num(b.wrong_count)+num(b.missing_count)+num(b.added_count))-(num(a.wrong_count)+num(a.missing_count)+num(a.added_count))).slice(0,5);
      const inner = box.querySelector('.mt-4.grid') || box;
      inner.innerHTML = rows.length ? rows.map(r => `<div class="flex flex-col justify-between gap-3 rounded-2xl bg-slate-50 p-4 sm:flex-row sm:items-center"><div><p class="text-sm font-black">${esc(r.practice_title || '-')}</p><p class="mt-1 text-xs text-slate-500">오류 ${num(r.wrong_count)+num(r.missing_count)+num(r.added_count)}개 · ${toolLabel(r.tool_type)}</p></div><button class="rounded-xl bg-indigo-600 px-4 py-2 text-xs font-black text-white" data-go="intermediate.html">다시 풀기</button></div>`).join('') : '<div class="rounded-2xl bg-slate-50 p-4 text-sm text-slate-500">추천할 오답 기록이 없습니다.</div>';
      attachGoLinks();
    }
  }
  function renderSettings() {
    const name = getDisplayName(appContext), email = appContext?.user?.email || appContext?.profile?.email || '-';
    const section = document.querySelector('#settings[data-dynamic-settings]');
    if (!section) return;
    qa('p', section).forEach(el => {
      if (el.textContent.trim() === '김속기') el.textContent = name;
      if (el.textContent.trim() === 'student@example.com') el.textContent = email;
    });
  }
  async function renderMyPageData(existing) {
    let summary = existing && existing.records ? existing : null;
    if (!summary || !summary.avgAcc) {
      try { summary = await window.SorizavaRecords.getMyStudyInsight(); } catch(e) { console.warn(e); summary = { records: [], avgAcc: 0, maxCPM: 0, streak: 0, insight: {} }; }
    }
    const records = summary.records || [];
    renderMySummary(summary);
    renderMyRecords(records);
    renderCredit();
    renderFeedback();
    renderWrongNote(records);
    renderSettings();
  }
  async function initNewMyPage(ctx) {
    setProfile(ctx);
    const app = $('app-wrapper'); if (app) app.style.display = 'flex';
    attachMyPageTabs();
    attachGoLinks();
    await renderMyPageData();
  }
  function renderDashboardFeedback() {
    const list = getFeedbacks();
    const countSpan = qa('span').find(el => /건$/.test(el.textContent.trim()) && el.textContent.trim() === '2건');
    if (countSpan) countSpan.textContent = `${list.length}건`;
  }

  window.initNewDashboardApp = initNewDashboardApp;
  window.initNewPracticeRoomPage = initNewPracticeRoomPage;
  window.initNewMyPage = initNewMyPage;
  window.login = login;
  window.logout = logout;
  window.closeNotice = closeNotice;
})();
