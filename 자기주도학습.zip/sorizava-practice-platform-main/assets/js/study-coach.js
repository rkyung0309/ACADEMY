// Study coach layer for mypage: training checklist, retry history, weak-file vault,
// exam D-day plan, focus timer, error-cause log, memo history and practical exam mode.
(function () {
  const LEVELS = [110, 120, 130, 140, 150, 160, 170, 190, 210, 230, 250];
  const TOOL_LABELS = {
    editorial: '사설연습',
    toksori2: '똑소리2',
    king: '타자왕',
    exam: '입문반 졸업시험',
    random: '약어랜덤',
    measure: '자수측정',
    sparta: '스파르타',
    unknown: '기타'
  };
  const ERROR_CAUSES = [
    '속도 따라가기 어려움',
    '발음 구분 어려움',
    '숫자/단위 약함',
    '문장 끝처리 약함',
    '집중력 저하',
    '띄어쓰기 불안정',
    '고유명사 약함'
  ];

  let active = {
    container: null,
    userKey: 'guest',
    records: [],
    insight: {},
    summary: {}
  };

  let timer = {
    seconds: 25 * 60,
    remaining: 25 * 60,
    running: false,
    interval: null
  };

  function esc(value) {
    return String(value ?? '').replace(/[&<>'"]/g, function (ch) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[ch];
    });
  }

  function toNumber(value, fallback = 0) {
    const num = Number(value);
    return Number.isFinite(num) ? num : fallback;
  }

  function toNullableNumber(value) {
    const num = Number(value);
    return Number.isFinite(num) ? num : null;
  }

  function round1(value) {
    const num = Number(value);
    return Number.isFinite(num) ? Math.round(num * 10) / 10 : 0;
  }

  function todayKey() {
    const now = new Date();
    const kst = new Date(now.getTime() + 9 * 60 * 60 * 1000);
    return kst.toISOString().slice(0, 10);
  }

  function getDateKey(value) {
    if (!value) return '';
    try {
      return new Date(value).toLocaleDateString('sv-SE', { timeZone: 'Asia/Seoul' });
    } catch (e) {
      return '';
    }
  }

  function fmtDate(value) {
    if (!value) return '-';
    try {
      return new Date(value).toLocaleDateString('ko-KR', { timeZone: 'Asia/Seoul', month: '2-digit', day: '2-digit' });
    } catch (e) {
      return '-';
    }
  }

  function getScore(record) {
    const accuracy = toNullableNumber(record?.accuracy);
    if (accuracy !== null) return accuracy;
    const score = toNullableNumber(record?.score);
    return score !== null ? score : null;
  }

  function getErrors(record) {
    return {
      wrong: toNumber(record?.wrong_count),
      missing: toNumber(record?.missing_count),
      added: toNumber(record?.added_count),
      spacing: toNumber(record?.spacing_error_count)
    };
  }

  function totalErrors(record) {
    const e = getErrors(record);
    return e.wrong + e.missing + e.added + e.spacing;
  }

  function avg(values) {
    const nums = values.map(Number).filter(Number.isFinite);
    if (!nums.length) return 0;
    return nums.reduce((sum, value) => sum + value, 0) / nums.length;
  }

  function normalizeTitle(record) {
    const title = String(record?.practice_title || '').trim();
    const tool = record?.tool_type || 'unknown';
    if (title) return `${tool}__${title.replace(/\s+/g, ' ')}`;
    return `${tool}__제목 없음`;
  }

  function cleanTitle(key) {
    return String(key || '').replace(/^[^_]+__/, '') || '제목 없음';
  }

  function getToolLabel(toolType) {
    if (window.SorizavaRecords?.getToolLabel) return window.SorizavaRecords.getToolLabel(toolType);
    return TOOL_LABELS[toolType] || toolType || '기타';
  }

  function getPracticeLevel(record) {
    const title = String(record?.practice_title || '').replace(/\s+/g, ' ');
    const explicit = title.match(/(110|120|130|140|150|160|170|190|210|230|250)\s*자/);
    if (explicit) return Number(explicit[1]);
    const cpm = toNullableNumber(record?.cpm);
    if (cpm === null || cpm < 90 || cpm > 280) return null;
    return LEVELS.reduce((best, step) => Math.abs(step - cpm) < Math.abs(best - cpm) ? step : best, LEVELS[0]);
  }

  function nextLevel(level) {
    const index = LEVELS.indexOf(Number(level));
    if (index < 0 || index >= LEVELS.length - 1) return null;
    return LEVELS[index + 1];
  }

  function groupByFile(records) {
    const groups = new Map();
    records.forEach(record => {
      const score = getScore(record);
      if (score === null) return;
      const key = normalizeTitle(record);
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(record);
    });
    groups.forEach(list => list.sort((a, b) => new Date(a.created_at) - new Date(b.created_at)));
    return groups;
  }

  function getCurrentLevel(records) {
    const hit = records
      .map(record => ({ record, level: getPracticeLevel(record), score: getScore(record) }))
      .filter(item => item.level && item.score !== null)
      .sort((a, b) => new Date(b.record.created_at) - new Date(a.record.created_at))[0];
    return hit?.level || null;
  }

  function getDominantErrorLabel(insight) {
    const item = insight?.dominantError;
    if (!item || !item.count) return '오류 누적 없음';
    return `${item.label} ${item.count}개`;
  }

  function getStorageKey(userKey, suffix) {
    return `sorizava_study_coach_${userKey}_${suffix}`;
  }

  function readJson(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
      return fallback;
    }
  }

  function writeJson(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  function getSettings(userKey) {
    return {
      goalGrade: '3급',
      goalLevel: '230',
      examDate: '',
      ...readJson(getStorageKey(userKey, 'settings'), {})
    };
  }

  function setSettings(userKey, settings) {
    writeJson(getStorageKey(userKey, 'settings'), settings);
  }

  function getMemoList(userKey) {
    return readJson(getStorageKey(userKey, 'memos'), []);
  }

  function setMemoList(userKey, list) {
    writeJson(getStorageKey(userKey, 'memos'), list.slice(0, 50));
  }

  function getCauseLog(userKey) {
    return readJson(getStorageKey(userKey, 'causes'), []);
  }

  function setCauseLog(userKey, list) {
    writeJson(getStorageKey(userKey, 'causes'), list.slice(-300));
  }

  function getTimerLog(userKey) {
    return readJson(getStorageKey(userKey, 'timer_log'), []);
  }

  function setTimerLog(userKey, list) {
    writeJson(getStorageKey(userKey, 'timer_log'), list.slice(-120));
  }

  function buildRetryHistory(records) {
    const groups = groupByFile(records);
    const rows = [];
    groups.forEach((list, key) => {
      if (list.length < 2) return;
      const first = list[0];
      const last = list[list.length - 1];
      const firstScore = getScore(first);
      const lastScore = getScore(last);
      rows.push({
        key,
        title: cleanTitle(key),
        toolLabel: getToolLabel(last.tool_type),
        attempts: list.length,
        firstScore: round1(firstScore),
        lastScore: round1(lastScore),
        delta: round1(lastScore - firstScore),
        lastDate: last.created_at,
        lastErrors: totalErrors(last)
      });
    });
    return rows.sort((a, b) => new Date(b.lastDate) - new Date(a.lastDate)).slice(0, 8);
  }

  function buildWeakFileVault(records) {
    const groups = groupByFile(records);
    const rows = [];
    groups.forEach((list, key) => {
      const scores = list.map(getScore).filter(v => v !== null);
      if (!scores.length) return;
      const errorAvg = round1(avg(list.map(totalErrors)));
      const scoreAvg = round1(avg(scores));
      const last = list[list.length - 1];
      const lowScore = scoreAvg < 95;
      const highErrors = errorAvg >= 5;
      const latestLow = getScore(last) !== null && getScore(last) < 94;
      if (!lowScore && !highErrors && !latestLow) return;
      rows.push({
        key,
        title: cleanTitle(key),
        toolLabel: getToolLabel(last.tool_type),
        count: list.length,
        avgScore: scoreAvg,
        avgErrors: errorAvg,
        lastDate: last.created_at,
        reason: lowScore ? '정확도 낮음' : highErrors ? '오류 많음' : '최근 기록 불안정'
      });
    });
    return rows.sort((a, b) => (a.avgScore - b.avgScore) || (b.avgErrors - a.avgErrors)).slice(0, 8);
  }

  function buildStudyVolume(records, timerLog) {
    const weekRecords = records.filter(record => {
      const created = new Date(record.created_at).getTime();
      if (!Number.isFinite(created)) return false;
      return Date.now() - created <= 7 * 24 * 60 * 60 * 1000;
    });
    const byDay = {};
    weekRecords.forEach(record => {
      const day = getDateKey(record.created_at);
      if (!day) return;
      byDay[day] = (byDay[day] || 0) + 1;
    });
    const totalElapsed = weekRecords.reduce((sum, record) => sum + toNumber(record.elapsed_seconds), 0);
    const timerMinutes = timerLog
      .filter(item => item.date && item.date >= new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10))
      .reduce((sum, item) => sum + toNumber(item.minutes), 0);
    return {
      studyDays: Object.keys(byDay).length,
      fileCount: weekRecords.length,
      elapsedMinutes: Math.round(totalElapsed / 60),
      timerMinutes,
      bestDayCount: Math.max(0, ...Object.values(byDay))
    };
  }

  function buildUpgradeCriteria(records, insight, settings) {
    const current = insight?.promotionCandidate?.currentLevel || getCurrentLevel(records);
    const next = insight?.promotionCandidate?.nextLevel || nextLevel(current);
    const recentLevelRecords = records
      .filter(record => getPracticeLevel(record) === current && getScore(record) !== null)
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
      .slice(0, 3);
    const recentAvg = round1(avg(recentLevelRecords.map(getScore).filter(v => v !== null)));
    const errorAvg = round1(avg(recentLevelRecords.map(totalErrors)));
    const goalLevel = toNumber(settings.goalLevel, 230);
    const remainSteps = current ? LEVELS.filter(level => level > current && level <= goalLevel).length : null;
    return {
      current,
      next,
      goalLevel,
      remainSteps,
      recentAvg,
      errorAvg,
      passAccuracy: recentAvg >= 98,
      passErrors: errorAvg <= 3,
      passCount: recentLevelRecords.length >= 3,
      status: insight?.promotionCandidate?.label || '판단 대기'
    };
  }

  function buildWeakTrainingSet(records, insight, weakFiles) {
    const currentLevel = insight?.promotionCandidate?.currentLevel || insight?.progressStatus?.currentLevel || getCurrentLevel(records);
    const baseLevel = currentLevel || 170;
    const dominantKey = insight?.dominantError?.key;
    const items = [];

    if (weakFiles[0]) {
      items.push({
        title: '취약 파일 재응시',
        text: `${weakFiles[0].title} 1회 재응시`,
        detail: `평균 ${weakFiles[0].avgScore}% / ${weakFiles[0].reason}`
      });
      items.push({
        title: '취약 파일 반복',
        text: `${weakFiles[0].title} 같은 파일 1회 추가 반복`,
        detail: '1회차 대비 정확도 개선폭을 확인합니다.'
      });
    } else {
      items.push({
        title: '현재 속도 안정화',
        text: `${baseLevel}자 파일 1개 정확도 98% 목표`,
        detail: '취약 파일이 없으면 현재 속도에서 오류 수를 줄이는 훈련을 유지합니다.'
      });
    }

    if (dominantKey === 'missing') {
      items.push({ title: '탈자 교정', text: '짧은 파일 1개를 끊김 없이 끝까지 듣기', detail: '문장 끝과 조사 누락을 집중 점검합니다.' });
    } else if (dominantKey === 'wrong') {
      items.push({ title: '오자 교정', text: '헷갈린 어절 5개를 메모하고 같은 파일 재입력', detail: '발음이 비슷한 단어와 고유명사를 우선 확인합니다.' });
    } else if (dominantKey === 'added') {
      items.push({ title: '첨자 교정', text: '들은 내용만 입력하는 속도 낮춤 훈련 1회', detail: '추측 입력과 불필요한 조사 추가를 줄입니다.' });
    } else if (dominantKey === 'spacing') {
      items.push({ title: '띄어쓰기 교정', text: '문장부호 뒤 공백과 이중 공백 점검 1회', detail: '마침표·물음표 뒤 처리 기준을 확인합니다.' });
    } else {
      items.push({ title: '오류 원인 점검', text: '연습 후 오답 원인 1개 선택', detail: '원인 로그가 쌓이면 다음 추천이 더 정확해집니다.' });
    }

    if (insight?.promotionCandidate?.eligible) {
      items.push({ title: '상위 속도 테스트', text: `${insight.promotionCandidate.nextLevel}자 1회만 테스트`, detail: '96% 이상이면 다음 진도 검토가 가능합니다.' });
    } else if (insight?.progressStatus?.status === 'stagnant') {
      items.push({ title: '정체 구간 회복', text: `${baseLevel}자 새 파일 금지 · 기존 파일 2회 반복`, detail: '정확도 변화보다 오류 수 감소를 먼저 봅니다.' });
    }

    return items.slice(0, 5);
  }

  function buildChecklist(userKey, trainingSet) {
    const key = getStorageKey(userKey, `checklist_${todayKey()}`);
    const saved = readJson(key, null);
    if (saved && Array.isArray(saved.items) && saved.items.length) return saved.items;
    const items = trainingSet.map((item, index) => ({
      id: `${todayKey()}_${index}_${item.title}`.replace(/\s+/g, '_'),
      text: item.text,
      detail: item.detail,
      done: false
    }));
    writeJson(key, { date: todayKey(), items });
    return items;
  }

  function saveChecklist(userKey, items) {
    writeJson(getStorageKey(userKey, `checklist_${todayKey()}`), { date: todayKey(), items });
  }

  function buildCauseSummary(causeLog) {
    const since = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
    const recent = causeLog.filter(item => item.date >= since);
    const counts = {};
    recent.forEach(item => { counts[item.cause] = (counts[item.cause] || 0) + 1; });
    return Object.entries(counts).map(([cause, count]) => ({ cause, count })).sort((a, b) => b.count - a.count).slice(0, 5);
  }

  function buildDdayPlan(records, insight, settings) {
    const goalLevel = toNumber(settings.goalLevel, 230);
    const currentLevel = insight?.promotionCandidate?.currentLevel || insight?.progressStatus?.currentLevel || getCurrentLevel(records);
    const dday = settings.examDate ? Math.ceil((new Date(`${settings.examDate}T00:00:00+09:00`).getTime() - Date.now()) / (24 * 60 * 60 * 1000)) : null;
    const recentAvg = insight?.trend?.recentAvg || insight?.weeklyAvg || 0;
    const phase = dday === null ? '시험일 미설정' : dday < 0 ? '시험일 경과' : dday <= 7 ? '직전 점검' : dday <= 21 ? '실전 반복' : '기초 안정화';
    const items = [];
    if (dday === null) {
      items.push('시험일을 저장하면 D-Day 기준 학습 플랜이 자동으로 나옵니다.');
    } else if (dday <= 7 && dday >= 0) {
      items.push('새 진도보다 실전 파일 반복과 오답 축소가 우선입니다.');
      items.push('연설/논설을 같은 비율로 배치하고, 낮은 유형만 추가 보강하세요.');
    } else if (dday <= 21 && dday >= 0) {
      items.push('주 3회 이상 실전 모드를 기록해 합격권 여부를 확인하세요.');
      items.push('취약 파일 보관함에 들어간 파일을 우선 복습하세요.');
    } else if (dday > 21) {
      items.push(`${goalLevel}자 목표 전 현재 ${currentLevel || '-'}자 안정화가 먼저입니다.`);
      items.push('정확도 98% 기준을 넘긴 뒤 상위 속도 테스트를 1회만 진행하세요.');
    } else {
      items.push('새 시험일을 다시 설정하면 플랜을 갱신할 수 있습니다.');
    }
    return { dday, phase, goalLevel, currentLevel, recentAvg, items };
  }

  function buildTeacherCards(insight, weakFiles, retryHistory, upgrade) {
    const cards = [];
    cards.push({
      title: '오늘 수업 핵심',
      text: insight?.promotionCandidate?.eligible
        ? `${upgrade.current}자 안정권입니다. ${upgrade.next}자 테스트를 1회만 진행하세요.`
        : insight?.progressStatus?.status === 'stagnant'
          ? '진도 정체 가능성이 있습니다. 새 진도보다 기존 파일 오류 감소를 확인하세요.'
          : '현재 기록을 기준으로 정확도와 오류 수를 함께 확인하세요.'
    });
    cards.push({
      title: '우선 피드백',
      text: weakFiles[0]
        ? `${weakFiles[0].title} 파일이 취약합니다. 평균 ${weakFiles[0].avgScore}%입니다.`
        : `${getDominantErrorLabel(insight)} 기준으로 짧게 피드백하면 됩니다.`
    });
    cards.push({
      title: '반복 효과',
      text: retryHistory[0]
        ? `${retryHistory[0].title} 재응시 개선폭 ${retryHistory[0].delta >= 0 ? '+' : ''}${retryHistory[0].delta}%p입니다.`
        : '같은 파일 반복 기록이 아직 부족합니다. 재응시 기록을 남기게 하세요.'
    });
    return cards;
  }

  function getCoachData(records, insight, summary, userKey) {
    const settings = getSettings(userKey);
    const timerLog = getTimerLog(userKey);
    const retryHistory = buildRetryHistory(records);
    const weakFiles = buildWeakFileVault(records);
    const trainingSet = buildWeakTrainingSet(records, insight, weakFiles);
    const checklist = buildChecklist(userKey, trainingSet);
    const causeLog = getCauseLog(userKey);
    const causeSummary = buildCauseSummary(causeLog);
    const memos = getMemoList(userKey);
    const volume = buildStudyVolume(records, timerLog);
    const upgrade = buildUpgradeCriteria(records, insight, settings);
    const ddayPlan = buildDdayPlan(records, insight, settings);
    const teacherCards = buildTeacherCards(insight, weakFiles, retryHistory, upgrade);
    return { settings, retryHistory, weakFiles, trainingSet, checklist, causeSummary, memos, volume, upgrade, ddayPlan, teacherCards, timerLog };
  }

  function renderChecklist(items) {
    if (!items.length) return '<div class="coach-empty">오늘 훈련 세트가 없습니다.</div>';
    const doneCount = items.filter(item => item.done).length;
    const percent = items.length ? Math.round(doneCount / items.length * 100) : 0;
    return `<div class="check-progress"><b>오늘 훈련 완료율 ${percent}%</b><span>${doneCount}/${items.length}개 완료</span></div>` +
      items.map(item => `<label class="coach-check-item ${item.done ? 'done' : ''}">
        <input type="checkbox" ${item.done ? 'checked' : ''} onchange="window.SorizavaStudyCoach.toggleTask('${esc(item.id)}')">
        <span><b>${esc(item.text)}</b><em>${esc(item.detail || '')}</em></span>
      </label>`).join('');
  }

  function renderWeakFiles(files) {
    if (!files.length) return '<div class="coach-empty">현재 자동 보관할 취약 파일이 없습니다.</div>';
    return files.map(file => `<div class="weak-file-row">
      <div><b>${esc(file.title)}</b><span>${esc(file.toolLabel)} · ${fmtDate(file.lastDate)} · ${esc(file.reason)}</span></div>
      <strong>${file.avgScore}%</strong><em>오류 ${file.avgErrors}개</em>
    </div>`).join('');
  }

  function renderRetryHistory(rows) {
    if (!rows.length) return '<div class="coach-empty">같은 파일을 2회 이상 기록하면 재응시 개선폭이 표시됩니다.</div>';
    return rows.map(row => `<div class="retry-row">
      <div><b>${esc(row.title)}</b><span>${esc(row.toolLabel)} · ${row.attempts}회 재응시 · 최근 ${fmtDate(row.lastDate)}</span></div>
      <strong class="${row.delta >= 0 ? 'good' : 'bad'}">${row.delta >= 0 ? '+' : ''}${row.delta}%p</strong>
      <em>${row.firstScore}% → ${row.lastScore}%</em>
    </div>`).join('');
  }

  function renderCauseButtons(summary) {
    const top = summary[0];
    const buttons = ERROR_CAUSES.map(cause => `<button type="button" onclick="window.SorizavaStudyCoach.addCause('${esc(cause)}')">${esc(cause)}</button>`).join('');
    const list = summary.length
      ? summary.map(item => `<span>${esc(item.cause)} <b>${item.count}</b></span>`).join('')
      : '<span>최근 원인 기록 없음</span>';
    return `<div class="cause-buttons">${buttons}</div><div class="cause-summary"><b>최근 14일 원인 TOP</b>${list}</div>${top ? `<p class="coach-hint">현재 가장 많이 선택된 원인은 <b>${esc(top.cause)}</b>입니다.</p>` : ''}`;
  }

  function renderUpgrade(upgrade) {
    const checks = [
      { label: '최근 3회 기록', ok: upgrade.passCount, value: upgrade.passCount ? '충족' : '부족' },
      { label: '평균 정확도 98% 이상', ok: upgrade.passAccuracy, value: `${upgrade.recentAvg || 0}%` },
      { label: '평균 오류 3개 이하', ok: upgrade.passErrors, value: `${upgrade.errorAvg || 0}개` }
    ];
    return `<div class="upgrade-main">
      <div><span>현재 단계</span><b>${upgrade.current ? upgrade.current + '자' : '-'}</b></div>
      <div><span>다음 단계</span><b>${upgrade.next ? upgrade.next + '자' : '-'}</b></div>
      <div><span>목표 단계</span><b>${upgrade.goalLevel}자</b></div>
      <div><span>남은 단계</span><b>${upgrade.remainSteps === null ? '-' : upgrade.remainSteps + '단계'}</b></div>
    </div>
    <div class="criteria-list">${checks.map(item => `<div class="criteria-item ${item.ok ? 'pass' : 'wait'}"><span>${item.ok ? '✓' : '•'}</span><b>${esc(item.label)}</b><em>${esc(item.value)}</em></div>`).join('')}</div>`;
  }

  function renderDday(plan, settings) {
    const ddayText = plan.dday === null ? '미설정' : plan.dday < 0 ? `D+${Math.abs(plan.dday)}` : `D-${plan.dday}`;
    return `<div class="dday-form">
      <label>목표 급수<select id="coachGoalGrade"><option ${settings.goalGrade === '3급' ? 'selected' : ''}>3급</option><option ${settings.goalGrade === '2급' ? 'selected' : ''}>2급</option><option ${settings.goalGrade === '1급' ? 'selected' : ''}>1급</option></select></label>
      <label>목표 속도<select id="coachGoalLevel">${LEVELS.map(level => `<option value="${level}" ${String(settings.goalLevel) === String(level) ? 'selected' : ''}>${level}자</option>`).join('')}</select></label>
      <label>시험일<input type="date" id="coachExamDate" value="${esc(settings.examDate || '')}"></label>
      <button type="button" onclick="window.SorizavaStudyCoach.saveSettings()">저장</button>
    </div>
    <div class="dday-result"><strong>${esc(ddayText)}</strong><span>${esc(plan.phase)} · 목표 ${plan.goalLevel}자 · 최근 평균 ${round1(plan.recentAvg)}%</span></div>
    <ol class="coach-ordered">${plan.items.map(item => `<li>${esc(item)}</li>`).join('')}</ol>`;
  }

  function renderTeacherCards(cards) {
    return cards.map(card => `<div class="teacher-card"><b>${esc(card.title)}</b><p>${esc(card.text)}</p></div>`).join('');
  }

  function renderMemoList(memos) {
    if (!memos.length) return '<div class="coach-empty">아직 저장된 학습 메모가 없습니다.</div>';
    return memos.slice(0, 8).map(memo => `<div class="memo-row"><div><b>${esc(memo.date)}</b><p>${esc(memo.text)}</p></div><button type="button" onclick="window.SorizavaStudyCoach.removeMemo('${esc(memo.id)}')">삭제</button></div>`).join('');
  }

  function renderTimerLog(log) {
    const recent = log.slice(-5).reverse();
    if (!recent.length) return '<span>완료한 집중 훈련 없음</span>';
    return recent.map(item => `<span>${esc(item.date)} · ${item.minutes}분</span>`).join('');
  }

  function renderExamJudge(accuracy, wrong, missing, added) {
    const acc = toNumber(accuracy);
    const errors = toNumber(wrong) + toNumber(missing) + toNumber(added);
    if (!acc) return '정확도를 입력하면 판정이 표시됩니다.';
    if (acc >= 98 && errors <= 3) return '합격권 안정: 상위 난도 또는 실전 반복으로 넘어가도 됩니다.';
    if (acc >= 96 && errors <= 6) return '합격권 근접: 탈자/오자만 줄이면 실전 안정권입니다.';
    return '재훈련 필요: 속도 상승보다 같은 파일 반복과 오류 원인 점검이 먼저입니다.';
  }

  function render(container, context) {
    active.container = container;
    active.userKey = context.userKey || 'guest';
    active.records = Array.isArray(context.records) ? context.records : [];
    active.insight = context.insight || {};
    active.summary = context.summary || {};

    const data = getCoachData(active.records, active.insight, active.summary, active.userKey);
    const timerDisplay = formatTimer(timer.remaining);

    container.innerHTML = `<div class="coach-head">
      <div><h2>학습 코치</h2><p>분석 결과를 실제 훈련 행동으로 연결하는 영역입니다. DB 변경 없이 기존 기록과 브라우저 저장값으로 작동합니다.</p></div>
      <button type="button" class="copy-report-btn" onclick="window.SorizavaStudyCoach.copyCoachPlan()">오늘 훈련안 복사</button>
    </div>

    <div class="coach-summary-strip">
      <div><span>이번 주 연습일</span><b>${data.volume.studyDays}일</b></div>
      <div><span>이번 주 파일</span><b>${data.volume.fileCount}개</b></div>
      <div><span>기록된 훈련시간</span><b>${data.volume.elapsedMinutes + data.volume.timerMinutes}분</b></div>
      <div><span>오답 원인 1위</span><b>${data.causeSummary[0] ? esc(data.causeSummary[0].cause) : '누적 없음'}</b></div>
    </div>

    <div class="coach-grid top">
      <article class="coach-panel checklist-panel"><div class="coach-panel-title">오늘의 약점 훈련 세트</div>${renderChecklist(data.checklist)}</article>
      <article class="coach-panel"><div class="coach-panel-title">취약 파일 자동 보관함</div>${renderWeakFiles(data.weakFiles)}</article>
      <article class="coach-panel"><div class="coach-panel-title">파일 재응시 기록</div>${renderRetryHistory(data.retryHistory)}</article>
    </div>

    <div class="coach-grid mid">
      <article class="coach-panel"><div class="coach-panel-title">오답 원인 선택</div>${renderCauseButtons(data.causeSummary)}</article>
      <article class="coach-panel"><div class="coach-panel-title">개인별 승급 조건표</div>${renderUpgrade(data.upgrade)}</article>
      <article class="coach-panel"><div class="coach-panel-title">시험 D-Day 학습 플랜</div>${renderDday(data.ddayPlan, data.settings)}</article>
    </div>

    <div class="coach-grid mid">
      <article class="coach-panel"><div class="coach-panel-title">선생님용 수업 전 확인 카드</div><div class="teacher-card-grid">${renderTeacherCards(data.teacherCards)}</div></article>
      <article class="coach-panel"><div class="coach-panel-title">집중 훈련 타이머</div>
        <div class="timer-box"><strong id="coachTimerDisplay">${timerDisplay}</strong><div><button type="button" onclick="window.SorizavaStudyCoach.startTimer()">시작</button><button type="button" onclick="window.SorizavaStudyCoach.pauseTimer()">정지</button><button type="button" onclick="window.SorizavaStudyCoach.resetTimer()">리셋</button><button type="button" onclick="window.SorizavaStudyCoach.completeTimer()">완료기록</button></div></div>
        <label class="timer-minute">훈련 시간<input id="coachTimerMinutes" type="number" min="5" max="90" value="${Math.round(timer.seconds / 60)}">분</label>
        <div class="timer-log">${renderTimerLog(data.timerLog)}</div>
      </article>
      <article class="coach-panel"><div class="coach-panel-title">학생별 학습 메모 히스토리</div>
        <div class="memo-input"><textarea id="coachMemoText" placeholder="예: 170자 탈자 많음. 다음 수업 전 같은 파일 2회 반복."></textarea><button type="button" onclick="window.SorizavaStudyCoach.addMemo()">메모 저장</button></div>
        <div class="memo-list">${renderMemoList(data.memos)}</div>
      </article>
    </div>

    <article class="coach-panel exam-mode-panel"><div class="coach-panel-title">실전 모드 결과 기록</div>
      <div class="exam-form">
        <label>급수<select id="examGrade"><option>3급</option><option>2급</option><option>1급</option></select></label>
        <label>유형<select id="examType"><option>연설</option><option>논설</option></select></label>
        <label>속도<select id="examLevel">${LEVELS.map(level => `<option value="${level}">${level}자</option>`).join('')}</select></label>
        <label>파일명<input id="examTitle" placeholder="예: 연설 230자 4번"></label>
        <label>정확도<input id="examAccuracy" type="number" step="0.1" min="0" max="100" placeholder="96.8"></label>
        <label>오자<input id="examWrong" type="number" min="0" value="0"></label>
        <label>탈자<input id="examMissing" type="number" min="0" value="0"></label>
        <label>첨자<input id="examAdded" type="number" min="0" value="0"></label>
        <button type="button" onclick="window.SorizavaStudyCoach.submitExamResult()">실전 결과 저장</button>
      </div>
      <div class="exam-judge" id="examJudge">정확도를 입력하면 합격권 여부를 판단합니다.</div>
    </article>`;

    const acc = container.querySelector('#examAccuracy');
    ['examAccuracy', 'examWrong', 'examMissing', 'examAdded'].forEach(id => {
      const el = container.querySelector(`#${id}`);
      if (el) el.addEventListener('input', updateExamJudge);
    });
    if (acc) updateExamJudge();
  }

  function rerender() {
    if (active.container) render(active.container, active);
  }

  function getCurrentChecklist() {
    const key = getStorageKey(active.userKey, `checklist_${todayKey()}`);
    const saved = readJson(key, { date: todayKey(), items: [] });
    return Array.isArray(saved.items) ? saved.items : [];
  }

  function toggleTask(id) {
    const items = getCurrentChecklist();
    const target = items.find(item => item.id === id);
    if (target) target.done = !target.done;
    saveChecklist(active.userKey, items);
    rerender();
  }

  function addCause(cause) {
    const list = getCauseLog(active.userKey);
    list.push({ id: `${Date.now()}_${Math.random().toString(16).slice(2)}`, date: todayKey(), cause });
    setCauseLog(active.userKey, list);
    rerender();
  }

  function saveSettings() {
    const settings = {
      goalGrade: document.getElementById('coachGoalGrade')?.value || '3급',
      goalLevel: document.getElementById('coachGoalLevel')?.value || '230',
      examDate: document.getElementById('coachExamDate')?.value || ''
    };
    setSettings(active.userKey, settings);
    rerender();
  }

  function addMemo() {
    const text = document.getElementById('coachMemoText')?.value?.trim();
    if (!text) return alert('저장할 메모를 입력해 주세요.');
    const list = getMemoList(active.userKey);
    list.unshift({ id: `${Date.now()}_${Math.random().toString(16).slice(2)}`, date: todayKey(), text });
    setMemoList(active.userKey, list);
    rerender();
  }

  function removeMemo(id) {
    const list = getMemoList(active.userKey).filter(item => item.id !== id);
    setMemoList(active.userKey, list);
    rerender();
  }

  function formatTimer(seconds) {
    const m = Math.floor(seconds / 60).toString().padStart(2, '0');
    const s = Math.floor(seconds % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  }

  function paintTimer() {
    const el = document.getElementById('coachTimerDisplay');
    if (el) el.textContent = formatTimer(timer.remaining);
  }

  function applyTimerMinutes() {
    const minutes = Math.max(5, Math.min(90, toNumber(document.getElementById('coachTimerMinutes')?.value, Math.round(timer.seconds / 60))));
    timer.seconds = minutes * 60;
    if (!timer.running) timer.remaining = timer.seconds;
    paintTimer();
  }

  function startTimer() {
    applyTimerMinutes();
    if (timer.running) return;
    timer.running = true;
    timer.interval = setInterval(() => {
      timer.remaining = Math.max(0, timer.remaining - 1);
      paintTimer();
      if (timer.remaining <= 0) {
        pauseTimer();
        alert('집중 훈련 시간이 끝났습니다. 완료기록을 남기면 이번 주 훈련량에 반영됩니다.');
      }
    }, 1000);
  }

  function pauseTimer() {
    timer.running = false;
    if (timer.interval) clearInterval(timer.interval);
    timer.interval = null;
  }

  function resetTimer() {
    pauseTimer();
    applyTimerMinutes();
    timer.remaining = timer.seconds;
    paintTimer();
  }

  function completeTimer() {
    pauseTimer();
    const used = Math.max(1, Math.round((timer.seconds - timer.remaining) / 60));
    const list = getTimerLog(active.userKey);
    list.push({ id: `${Date.now()}_${Math.random().toString(16).slice(2)}`, date: todayKey(), minutes: used });
    setTimerLog(active.userKey, list);
    timer.remaining = timer.seconds;
    rerender();
  }

  function updateExamJudge() {
    const judge = document.getElementById('examJudge');
    if (!judge) return;
    judge.textContent = renderExamJudge(
      document.getElementById('examAccuracy')?.value,
      document.getElementById('examWrong')?.value,
      document.getElementById('examMissing')?.value,
      document.getElementById('examAdded')?.value
    );
  }

  async function submitExamResult() {
    const grade = document.getElementById('examGrade')?.value || '3급';
    const type = document.getElementById('examType')?.value || '연설';
    const level = toNumber(document.getElementById('examLevel')?.value, 230);
    const title = document.getElementById('examTitle')?.value?.trim() || `${type} ${level}자 실전`;
    const accuracy = toNullableNumber(document.getElementById('examAccuracy')?.value);
    if (accuracy === null) return alert('정확도를 입력해 주세요.');
    const wrong = toNumber(document.getElementById('examWrong')?.value);
    const missing = toNumber(document.getElementById('examMissing')?.value);
    const added = toNumber(document.getElementById('examAdded')?.value);
    const saved = await window.SorizavaRecords.savePracticeRecord({
      tool_type: 'exam',
      practice_title: `실전 ${grade} ${title}`,
      accuracy,
      score: accuracy,
      cpm: level,
      wrong_count: wrong,
      missing_count: missing,
      added_count: added,
      spacing_error_count: 0,
      memo: `${grade} ${type} 실전 모드 / ${renderExamJudge(accuracy, wrong, missing, added)}`
    });
    if (!saved) return alert('실전 결과 저장에 실패했습니다. 로그인 상태를 확인해 주세요.');
    alert('실전 결과를 저장했습니다.');
    if (typeof window.loadRecords === 'function') window.loadRecords();
  }

  function copyCoachPlan() {
    const data = getCoachData(active.records, active.insight, active.summary, active.userKey);
    const checklist = data.checklist.map((item, index) => `${index + 1}. ${item.text}${item.done ? ' [완료]' : ''}`).join('\n');
    const weak = data.weakFiles[0] ? `${data.weakFiles[0].title} / 평균 ${data.weakFiles[0].avgScore}%` : '취약 파일 없음';
    const plan = [
      '[오늘의 훈련안]',
      `목표: ${data.settings.goalGrade} / ${data.settings.goalLevel}자`,
      `D-Day: ${data.ddayPlan.dday === null ? '미설정' : data.ddayPlan.dday < 0 ? 'D+' + Math.abs(data.ddayPlan.dday) : 'D-' + data.ddayPlan.dday}`,
      `취약 파일: ${weak}`,
      '',
      '[훈련 체크리스트]',
      checklist || '-',
      '',
      '[수업 전 확인]',
      ...data.teacherCards.map(card => `- ${card.title}: ${card.text}`)
    ].join('\n');
    navigator.clipboard?.writeText(plan).then(() => alert('오늘 훈련안을 복사했습니다.')).catch(() => {
      const area = document.createElement('textarea');
      area.value = plan;
      document.body.appendChild(area);
      area.select();
      document.execCommand('copy');
      area.remove();
      alert('오늘 훈련안을 복사했습니다.');
    });
  }

  window.SorizavaStudyCoach = {
    render,
    toggleTask,
    addCause,
    saveSettings,
    addMemo,
    removeMemo,
    startTimer,
    pauseTimer,
    resetTimer,
    completeTimer,
    submitExamResult,
    copyCoachPlan
  };
})();
