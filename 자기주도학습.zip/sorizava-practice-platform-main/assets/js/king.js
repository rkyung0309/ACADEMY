    // --- [1] 기본 설정 및 변수 ---
    function toggleSidebar() {
        document.querySelector('.sidebar').classList.toggle('active');
        document.querySelector('.sidebar-overlay').classList.toggle('active');
    }

    let currentUser = sessionStorage.getItem('shorthand_user');

    const KING_MANAGER_ROLES = ['admin', 'administrator', 'super_admin', 'superadmin', 'owner', 'manager', 'operator', 'staff', 'teacher', '강사', '선생님', '관리자', '운영팀'];
    function normalizeRole(role) {
        return String(role || '').trim().toLowerCase();
    }
    function getCachedKingRole() {
        try { return JSON.parse(sessionStorage.getItem('sorizava_profile') || '{}').role || ''; } catch (error) { return ''; }
    }
    function canManageKingText() {
        return [sessionStorage.getItem('shorthand_role'), getCachedKingRole()].map(normalizeRole).some(role => KING_MANAGER_ROLES.includes(role));
    }

    function getCurrentPlayerName() {
        try {
            const profile = JSON.parse(sessionStorage.getItem('sorizava_profile') || '{}');
            return profile.name || sessionStorage.getItem('shorthand_user') || profile.email || '학생';
        } catch (error) {
            return sessionStorage.getItem('shorthand_user') || '학생';
        }
    }

    function getCurrentPlayerId() {
        return sessionStorage.getItem('shorthand_user_id') || '';
    }

    function getCurrentPlayerPhone() {
        try {
            const profile = JSON.parse(sessionStorage.getItem('sorizava_profile') || '{}');
            const candidates = [
                profile.phone,
                profile.phone_number,
                profile.mobile,
                profile.mobile_phone,
                profile.tel,
                profile.telephone,
                sessionStorage.getItem('shorthand_phone')
            ];
            const digits = String(candidates.find(Boolean) || '').replace(/\D/g, '');
            return digits;
        } catch (error) {
            return String(sessionStorage.getItem('shorthand_phone') || '').replace(/\D/g, '');
        }
    }

    function getCurrentTextTitle() {
        return (document.getElementById('file-name-display')?.innerText || '기본 연습 지문').trim();
    }

    function getKstDateKey(value) {
        if (!value) return '';
        return new Date(value).toLocaleDateString('sv-SE', { timeZone: 'Asia/Seoul' });
    }

    function escapeHtml(value) {
        return String(value ?? '').replace(/[&<>'"]/g, ch => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
        }[ch]));
    }

    function parsePlayerNameFromMemo(memo) {
        const text = String(memo || '');
        const match = text.match(/(?:참가자|이름)\s*:\s*([^|]+)/);
        return match ? match[1].trim() : '';
    }

    function parsePlayerPhoneFromMemo(memo) {
        const text = String(memo || '');
        const match = text.match(/(?:전화|휴대폰|연락처)\s*:\s*([^|]+)/);
        const digits = String(match ? match[1] : '').replace(/\D/g, '');
        return digits;
    }

    function findProfilePhone(profile = {}) {
        const candidates = [profile.phone, profile.phone_number, profile.mobile, profile.mobile_phone, profile.tel, profile.telephone];
        return String(candidates.find(Boolean) || '').replace(/\D/g, '');
    }

    function maskPlayerName(name) {
        const clean = String(name || '학생').trim();
        if (clean.length <= 1) return clean;
        if (clean.length == 2) return clean[0] + '*';
        if (clean.length == 3) return clean[0] + '*' + clean[2];
        return clean[0] + '*'.repeat(Math.max(1, clean.length - 2)) + clean[clean.length - 1];
    }

    function getPhoneLast4(phone) {
        const digits = String(phone || '').replace(/\D/g, '');
        return digits.length >= 4 ? digits.slice(-4) : '----';
    }

    function formatRankPlayerLabel(name, phone) {
        return `${maskPlayerName(name)} · ${getPhoneLast4(phone)}`;
    }

    function resolveRankPlayer(record, profileMap = {}) {
        const memoName = parsePlayerNameFromMemo(record?.memo);
        const profile = profileMap[record?.user_id] || {};
        const rawName = memoName || profile?.name || profile?.email || (record?.user_id && record.user_id === getCurrentPlayerId() ? getCurrentPlayerName() : '학생');
        const rawPhone = parsePlayerPhoneFromMemo(record?.memo) || findProfilePhone(profile) || (record?.user_id && record.user_id === getCurrentPlayerId() ? getCurrentPlayerPhone() : '');
        return {
            rawName,
            rawPhone,
            displayName: formatRankPlayerLabel(rawName, rawPhone)
        };
    }

    // 게임 상태 변수
    let rawText = "", displayChunks = [], curIdx = 0;
    let startTime = null, timerInt = null;
    let totalTypedLength = 0, isTransitioning = false;
    let chunkSize = 30;
    let isGameRunning = false; // API 최적화를 위한 플래그
    let lastCompletedCleanText = '';
    let transitionGuardUntil = 0;
    let activeInputCreatedAt = 0;
    let activeInputLastKeyAt = 0;

    // 모바일 문장 전환 시 새 입력창 focus 때문에 화면이 상단으로 튀는 현상 방지
    function captureTypingScrollState() {
        const main = document.querySelector('.main-content');
        return {
            windowX: window.scrollX || 0,
            windowY: window.scrollY || 0,
            mainTop: main ? main.scrollTop : 0,
            mainLeft: main ? main.scrollLeft : 0
        };
    }

    function restoreTypingScrollState(state) {
        if (!state) return;
        const main = document.querySelector('.main-content');
        if (main) {
            main.scrollTop = state.mainTop || 0;
            main.scrollLeft = state.mainLeft || 0;
        }
        window.scrollTo({
            left: state.windowX || 0,
            top: state.windowY || 0,
            behavior: 'auto'
        });
    }

    function scheduleTypingScrollRestore(state) {
        if (!state) return;
        restoreTypingScrollState(state);
        requestAnimationFrame(() => restoreTypingScrollState(state));
        setTimeout(() => restoreTypingScrollState(state), 40);
        setTimeout(() => restoreTypingScrollState(state), 140);
    }

    function forceClearTypingInput(input) {
        if (!input) return;
        input.value = '';
        input.defaultValue = '';
        try { input.setAttribute('value', ''); } catch (error) {}
    }

    function isLikelyCarryoverFromPrevious(rawValue) {
        const value = cleanText(rawValue || '');
        if (!value || !lastCompletedCleanText) return false;
        const currentTarget = cleanText(displayChunks[curIdx] || '');

        // 다음 문장의 정상 시작 입력이면 보존한다.
        if (currentTarget && currentTarget.startsWith(value)) return false;

        // 직전 문장의 끝부분 또는 일부가 IME 조합 완료로 늦게 들어온 경우 제거한다.
        return lastCompletedCleanText.endsWith(value)
            || (value.length >= 2 && lastCompletedCleanText.includes(value));
    }

    function clearCarryoverIfNeeded(input) {
        if (!input || !input.value) return false;
        if (Date.now() > transitionGuardUntil) return false;
        if (!isLikelyCarryoverFromPrevious(input.value)) return false;
        forceClearTypingInput(input);
        return true;
    }

    function guardNewTypingInput(input) {
        if (!input) return;
        activeInputCreatedAt = Date.now();
        activeInputLastKeyAt = 0;
        input.dataset.typingCreatedAt = String(activeInputCreatedAt);
        input.addEventListener('keydown', () => { activeInputLastKeyAt = Date.now(); });
        input.addEventListener('compositionstart', () => { activeInputLastKeyAt = Date.now(); });

        // 모바일/한글 IME에서 이전 input의 조합 종료 문자가 새 input으로 밀려 들어오는 경우 보정한다.
        requestAnimationFrame(() => { if (clearCarryoverIfNeeded(input)) render(); });
        setTimeout(() => { if (clearCarryoverIfNeeded(input)) render(); }, 60);
        setTimeout(() => { if (clearCarryoverIfNeeded(input)) render(); }, 180);
    }


    // 모바일 타자왕: 입력창 포커스를 정상 유지하고, 문장 전환 시 스크롤 튐만 막는다.
    // 가상키보드 강제 차단은 기기별로 외장 키보드 입력을 막을 수 있어 제거한다.
    function isMobileTypingKingView() {
        return /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent || '')
            || (window.matchMedia && window.matchMedia('(max-width: 900px)').matches);
    }

    function focusTypingInputWithoutKeyboard(input, scrollState = null) {
        if (!input) return;
        const state = scrollState || captureTypingScrollState();

        // 외장 키보드 입력 보존: readonly/inputmode 차단을 쓰지 않는다.
        prepareTypingInputForMobile(input);

        try {
            input.focus({ preventScroll: true });
        } catch (error) {
            input.focus();
        }

        scheduleTypingScrollRestore(state);
    }

    function prepareTypingInputForMobile(input) {
        if (!input) return;
        input.removeAttribute('readonly');
        input.readOnly = false;
        input.removeAttribute('inputmode');
        input.setAttribute('enterkeyhint', 'done');
        input.setAttribute('autocomplete', 'off');
        input.setAttribute('autocorrect', 'off');
        input.setAttribute('autocapitalize', 'off');
        input.setAttribute('spellcheck', 'false');
        try { input.removeAttribute('virtualkeyboardpolicy'); } catch (error) {}

        // 터치/포인터 기본 동작을 막지 않는다. 정상 focus 흐름을 유지해야 블루투스 키보드 입력이 산다.
        if (!input.dataset.mobileKeyboardSafeBound) {
            input.dataset.mobileKeyboardSafeBound = 'true';
            input.addEventListener('focus', () => prepareTypingInputForMobile(input));
            input.addEventListener('touchstart', () => prepareTypingInputForMobile(input), { passive: true });
            input.addEventListener('pointerdown', (event) => {
                if (!event.pointerType || event.pointerType === 'touch') prepareTypingInputForMobile(input);
            }, { passive: true });
        }
    }

    // 고도화 변수 (콤보, 소리, 차트 등)
    let combo = 0;
    let soundEnabled = true;
    let cpmHistory = []; // 그래프용 데이터 [0, 100, 200...]
    let chartInstance = null;
    
    // 기계식 키보드 사운드 (짧고 가벼운 소리)
    const keySound = new Audio("https://cdn.pixabay.com/audio/2022/03/24/audio_824e8a4555.mp3"); 
    keySound.volume = 0.4;

    // --- [2] 초기화 ---
    function initApp() {
    currentUser = sessionStorage.getItem('shorthand_user');
        if (!currentUser) {
            alert("로그인을 먼저 해주세요!");
            location.href = 'index.html';
            return;
        }
        if(document.getElementById('sideUserName')) document.getElementById('sideUserName').innerText = currentUser;
        
        const uploadBtn = document.getElementById('admin-upload-btn');
        if (uploadBtn && canManageKingText()) {
            uploadBtn.style.display = 'inline-flex';
        }

        // 저장된 설정 불러오기
        const savedDark = localStorage.getItem('shorthand_dark') === 'true';
        document.getElementById('dark-mode-toggle').checked = savedDark;
        toggleDarkMode(savedDark);
        
        createNewInput(); 
        syncContent(); 
        // 10초마다 싱크 (게임 중엔 스킵)
        setInterval(() => {
            if(!isGameRunning) syncContent();
        }, 10000);
    }

    // --- [3] 설정 관련 함수 ---
    function updateChunkSize(val) {
        chunkSize = parseInt(val);
        document.getElementById('chunk-val').innerText = val + "자";
        if(rawText) { displayChunks = sliceTextByEojeol(rawText, chunkSize); resetGame(); }
    }

    function toggleSound(checked) {
        soundEnabled = checked;
    }

    function toggleDarkMode(checked) {
        if(checked) document.body.classList.add('dark-mode');
        else document.body.classList.remove('dark-mode');
        localStorage.setItem('shorthand_dark', checked);
    }

    // --- [4] 텍스트 처리 및 입력 생성 ---
    function sliceTextByEojeol(text, limit) {
        if(!text) return [];
        let result = [], str = text.replace(/\s+/g, ' ').trim();
        while (str.length > 0) {
            if (str.length <= limit) { result.push(str); break; }
            let cutPos = str.lastIndexOf(' ', limit);
            if (cutPos === -1) cutPos = str.indexOf(' ', limit);
            if (cutPos === -1) cutPos = str.length;
            result.push(str.substring(0, cutPos).trim());
            str = str.substring(cutPos).trim();
        }
        return result;
    }

    function createNewInput(scrollState = null) {
        const wrapper = document.getElementById('input-wrapper');
        wrapper.innerHTML = '';
        const newInp = document.createElement('input');
        newInp.type = 'text'; newInp.id = 'input-field'; newInp.className = 'typing-input';
        newInp.placeholder = isMobileTypingKingView()
            ? '외장 키보드로 입력하세요'
            : '위 문장을 보고 입력하세요 (Enter나 Space로 진행)'; 
        newInp.autocomplete = 'off';
        forceClearTypingInput(newInp);
        prepareTypingInputForMobile(newInp);
        guardNewTypingInput(newInp);
        newInp.addEventListener('input', handleTyping);
        wrapper.appendChild(newInp);

        if (scrollState) restoreTypingScrollState(scrollState);
        focusTypingInputWithoutKeyboard(newInp, scrollState);
        
        // 피버 모드 클래스 제거
        newInp.classList.remove('fever-mode');
    }

    // --- [5] 서버 통신 (API 최적화) ---
    async function syncContent() {
        try {
            const { data: materials } = await window.SORIZAVA_SUPABASE
                .from('practice_materials')
                .select('*')
                .eq('tool_type', 'king')
                .eq('is_active', true)
                .order('created_at', { ascending: false })
                .limit(1);
            const target = materials && materials[0];
            if (target && target.title !== document.getElementById('file-name-display').innerText) {
                document.getElementById('file-name-display').innerText = target.title;
                rawText = target.content;
                displayChunks = sliceTextByEojeol(rawText, chunkSize);
                resetGame();
            } else if (!target && !rawText) {
                document.getElementById('file-name-display').innerText = '기본 연습 지문';
                rawText = '속기 연습은 매일 조금씩 꾸준히 반복할 때 가장 큰 효과를 냅니다. 정확하게 듣고 빠르게 입력하는 습관을 만들어 보세요.';
                displayChunks = sliceTextByEojeol(rawText, chunkSize);
                resetGame();
            }
            const today = window.SorizavaRecords.todayKstDateString();
            const currentTextTitle = getCurrentTextTitle();
            const { data: rankRows } = await window.SORIZAVA_SUPABASE
                .from('practice_records')
                .select('user_id,practice_title,cpm,created_at,memo')
                .eq('tool_type','king')
                .eq('practice_title', currentTextTitle)
                .not('cpm','is',null)
                .gte('created_at', `${today}T00:00:00+09:00`)
                .order('cpm',{ascending:false})
                .limit(200);

            let profileMap = {};
            const userIds = Array.from(new Set((rankRows || []).map(r => r.user_id).filter(Boolean)));
            if (userIds.length) {
                try {
                    const { data: profiles } = await window.SORIZAVA_SUPABASE
                        .from('profiles')
                        .select('*')
                        .in('id', userIds);
                    profileMap = (profiles || []).reduce((acc, profile) => {
                        acc[profile.id] = profile;
                        return acc;
                    }, {});
                } catch (profileError) {
                    console.warn('타자왕 참가자 이름 조회 실패:', profileError);
                }
            }

            updateRankingUI((rankRows || []).map(r => {
                const player = resolveRankPlayer(r, profileMap);
                return {
                    name: player.rawName,
                    phone: player.rawPhone,
                    displayName: player.displayName,
                    userId: r.user_id || '',
                    cpm: r.cpm,
                    date: getKstDateKey(r.created_at),
                    fileName: r.practice_title || currentTextTitle
                };
            }));
        } catch(e) { console.warn(e); }
    }

    function updateRankingUI(ranks) {
        const fName = document.getElementById('file-name-display').innerText;
        const today = new Date(new Date().getTime() + (9 * 60 * 60 * 1000)).toISOString().split('T')[0];
        const bests = {};
        ranks.filter(r => r.date === today && r.fileName === fName).forEach(r => {
            const key = r.userId || r.name;
            if (!bests[key] || r.cpm > bests[key].cpm) bests[key] = r;
        });
        const sorted = Object.values(bests).sort((a, b) => b.cpm - a.cpm);
        
        ['p1','p2','p3'].forEach((id, i) => {
            const d = sorted[i];
            document.getElementById(`${id}-name`).innerText = d ? (d.displayName || d.name) : "-";
            document.getElementById(`${id}-cpm`).innerText = d ? d.cpm + "자" : "0자";
        });
        document.getElementById('rank-list').innerHTML = sorted.map((r, i) => `
            <div class="rank-list-item">
                <span><b>${i+1}위</b> ${escapeHtml(r.displayName || r.name)}</span><span>${Number(r.cpm) || 0} 자</span>
            </div>`).join('') || "<div style='padding:20px; text-align:center; color:#aaa;'>아직 기록이 없습니다.</div>";
    }

    // --- [6] 핵심 게임 로직 (Gamification 추가) ---
    function handleTyping(e) {
        const inp = document.getElementById('input-field');
        if (!inp) return;
        if (clearCarryoverIfNeeded(inp)) {
            render();
            return;
        }
        const currentVal = inp.value;
        const targetText = displayChunks[curIdx] || "";
        const cleanTarget = cleanText(targetText);
        const cleanTyped = cleanText(currentVal);

        // 1. 소리 재생
        if (soundEnabled && e.inputType !== 'deleteContentBackward') {
             const soundClone = keySound.cloneNode();
             soundClone.play().catch(()=>{});
        }

        // 2. 타이머 시작
        if (!startTime && currentVal.length > 0) { 
            startTime = new Date(); 
            isGameRunning = true; // 게임 시작 플래그
            timerInt = setInterval(() => {
                const elap = (new Date() - startTime) / 1000;
                document.getElementById('timer').innerText = Math.floor(elap) + "초";
                
                const curTyped = cleanTyped.length;
                const total = totalTypedLength + curTyped;
                const cpm = elap > 0 ? Math.floor(total/(elap/60)) : 0;
                
                document.getElementById('current-cpm').innerText = cpm;
                
                // 그래프용 데이터 수집 (1초 단위로 대략적 기록)
                if (Math.floor(elap) > cpmHistory.length) {
                    cpmHistory.push(cpm);
                }
            }, 500);
        }

        // 3. 콤보 로직 (간단 구현: 입력 길이 증가 시 콤보 증가, 오타 시 리셋은 render에서 체크)
        // 여기서는 정밀 판정보다 '치고 있다'는 느낌을 위해 렌더링 함수에 위임
        
        render();
    }

    function render() {
        if (isTransitioning) return;
        const targetText = displayChunks[curIdx] || "";
        const cleanTarget = cleanText(targetText);
        const inp = document.getElementById('input-field');
        const cleanTyped = cleanText(inp ? inp.value : "");
        const box = document.getElementById('target-box');
        
        box.innerHTML = '';
        
        let tPtr = 0, dPtr = 0;
        let isAllCorrectSoFar = true;

        targetText.split('').forEach(char => {
            const span = document.createElement('span');
            span.innerText = char;
            if (/[^ㄱ-ㅎ가-힣a-zA-Z0-9]/.test(char)) span.className = 'char';
            else {
                span.className = 'char';
                if (dPtr < cleanTyped.length) {
                    const isMatch = cleanTyped[dPtr] === cleanTarget[tPtr];
                    span.classList.add(isMatch ? 'correct' : 'incorrect');
                    if(!isMatch) isAllCorrectSoFar = false;
                    dPtr++;
                }
                tPtr++;
            }
            box.appendChild(span);
        });

        // 콤보 업데이트
        if (dPtr > 0 && isAllCorrectSoFar) {
            // 오타 없이 진행 중이면 글자 수만큼 콤보라고 가정 (단순화)
            // 실제로는 이전 상태와 비교해야 하지만, 여기선 '현재 입력 길이'로 시각적 효과 대체
            // 또는 별도 변수 운용
        } else if (dPtr > 0 && !isAllCorrectSoFar) {
            combo = 0; // 오타 발생 시 콤보 초기화
            updateComboUI();
        }

        // 정답 완료 체크
        if (cleanTyped.length > 0 && cleanTyped === cleanTarget) {
            // 문장 완료 시 콤보 대폭 상승 효과
            combo += 5; 
            showComboEffect();
            updateComboUI();

            isTransitioning = true;
            totalTypedLength += cleanTarget.length;
            lastCompletedCleanText = cleanTarget;
            transitionGuardUntil = Date.now() + 900;
            const scrollState = captureTypingScrollState();
            const activeInput = document.getElementById('input-field');
            if (activeInput) {
                activeInput.removeEventListener('input', handleTyping);
                forceClearTypingInput(activeInput);
                // 입력창 자체를 비우고 제거한다. readOnly/disabled는 외장 키보드 입력 차단 이슈가 있어 쓰지 않는다.
            }
            document.getElementById('input-wrapper').replaceChildren();
            
            if (curIdx < displayChunks.length - 1) {
                curIdx++;
                setTimeout(() => {
                    isTransitioning = false;
                    createNewInput(scrollState);
                    render();
                    scheduleTypingScrollRestore(scrollState);
                }, 50);
            } else { finishGame(); }
        }
    }

    function showComboEffect() {
        const container = document.getElementById('combo-effect-container');
        const el = document.createElement('div');
        el.className = 'combo-text';
        el.innerText = "Nice!";
        container.appendChild(el);
        setTimeout(() => el.remove(), 600);
    }

    function updateComboUI() {
        const el = document.getElementById('combo-display');
        el.innerText = combo + " Combo";
        
        const inp = document.getElementById('input-field');
        if (combo >= 30 && inp) inp.classList.add('fever-mode');
        else if (inp) inp.classList.remove('fever-mode');
    }

    // --- [7] 게임 종료 및 결과 처리 (차트, 티어) ---
    async function finishGame() {
        clearInterval(timerInt);
        isGameRunning = false; // 게임 종료 플래그
        
        // Anti-Cheat: 서버 전송 전 검증 로직 (여기선 단순화하여 표시)
        const endTime = new Date();
        const durationMin = (endTime - startTime) / 1000 / 60;
        const calculatedCPM = durationMin > 0 ? Math.floor(totalTypedLength / durationMin) : 0;
        
        document.getElementById('final-cpm-res').innerText = calculatedCPM;
        
        // 티어 결정
        const tierEl = document.getElementById('tier-badge');
        let tierColor = "#aaa", tierName = "Unranked";
        if (calculatedCPM >= 900) { tierName = "💎 Diamond"; tierColor = "#00CEC9"; }
        else if (calculatedCPM >= 700) { tierName = "💠 Platinum"; tierColor = "#74B9FF"; }
        else if (calculatedCPM >= 500) { tierName = "🥇 Gold"; tierColor = "#FFD700"; }
        else if (calculatedCPM >= 300) { tierName = "🥈 Silver"; tierColor = "#C0C0C0"; }
        else { tierName = "🥉 Bronze"; tierColor = "#CD7F32"; }
        
        tierEl.innerText = tierName;
        tierEl.style.backgroundColor = tierColor;

        // 결과 모달 표시
        document.getElementById('overlay').style.display = 'block';
        document.getElementById('result-modal').style.display = 'block';

        // 차트 그리기
        drawResultChart(cpmHistory);

        // 서버 저장
        if (currentUser && calculatedCPM > 0) {
            const playerName = getCurrentPlayerName();
            const textTitle = getCurrentTextTitle();
            const playerPhone = getCurrentPlayerPhone();
            await window.SorizavaRecords.savePracticeRecord({
                tool_type: 'king',
                practice_title: textTitle,
                original_length: totalTypedLength,
                typed_length: totalTypedLength,
                cpm: calculatedCPM,
                elapsed_seconds: Math.round((endTime - startTime) / 1000),
                memo: `타자왕 자동 저장 | 지문: ${textTitle} | 참가자: ${playerName} | 전화: ${playerPhone}`
            });
            syncContent();
        }
    }

    function drawResultChart(data) {
        const ctx = document.getElementById('resultChart').getContext('2d');
        if (chartInstance) chartInstance.destroy(); // 기존 차트 파괴

        chartInstance = new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.map((_, i) => (i * 0.5) + "s"), // 0.5초 간격 라벨
                datasets: [{
                    label: '타자 속도(CPM)',
                    data: data,
                    borderColor: '#6C5CE7',
                    backgroundColor: 'rgba(108, 92, 231, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    }

    function resetGame() {
        curIdx = 0; totalTypedLength = 0; startTime = null; isTransitioning = false; isGameRunning = false;
        lastCompletedCleanText = ''; transitionGuardUntil = 0;
        combo = 0; cpmHistory = []; updateComboUI();
        if (timerInt) clearInterval(timerInt);
        document.getElementById('timer').innerText = '0초';
        document.getElementById('current-cpm').innerText = '0';
        createNewInput(); render();
    }

    function cleanText(str) { return str.replace(/[^ㄱ-ㅎ가-힣a-zA-Z0-9]/g, ""); }
    
    function closeAllModals() {
        document.getElementById('overlay').style.display = 'none';
        document.getElementById('rank-modal').style.display = 'none';
        document.getElementById('result-modal').style.display = 'none';
        resetGame();
    }

    function toggleRank() {
        const m = document.getElementById('rank-modal');
        const o = document.getElementById('overlay');
        m.style.display = 'block'; o.style.display = 'block';
        syncContent();
    }
    
    function logout() { 
        if(confirm("로그아웃 하시겠습니까?")) window.SorizavaAuth.signOut(); 
    }

    document.getElementById('file-selector').addEventListener('change', (e) => {
        const file = e.target.files[0];
        if(!file) return;
        const reader = new FileReader();
        reader.onload = async (ev) => { 
            if (!canManageKingText()) return alert('관리자/강사만 글을 등록할 수 있습니다.');
            const { error } = await window.SORIZAVA_SUPABASE.from('practice_materials').insert({
                tool_type: 'king', title: file.name, content: ev.target.result, is_active: true, created_by: sessionStorage.getItem('shorthand_user_id')
            });
            if (error) { alert('업로드 실패: ' + error.message); return; }
            syncContent(); 
        };
        reader.readAsText(file, 'utf-8');
    });

    // 앱 실행
    window.SorizavaAuth.bootPage(initApp);
