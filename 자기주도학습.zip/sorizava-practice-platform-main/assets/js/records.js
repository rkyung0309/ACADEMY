// Shared practice record helpers
(function () {
  const TOOL_LABELS = {
    editorial: '사설연습',
    toksori2: '똑소리2',
    king: '타자왕',
    exam: '입문반 졸업시험',
    exam_simulation: '실전 시험 모드',
    random: '약어랜덤',
    random_dictionary: '약어장 보고치기',
    random_voice_dictionary: '약어장 듣고치기',
    random_abbr_wrong_visual: '약어 오답 보고치기',
    random_abbr_wrong_voice: '약어 오답 듣고치기',
    measure: '자수측정',
    sparta: '스파르타',
    intermediate: '중급반 공부방',
    advanced: '고급반 공부방',
    grade: '급수반 공부방',
    intermediate_unlock: '진도 승급실',
    advanced_unlock: '진도 승급실',
    grade_unlock: '진도 승급실',
    practice_room_audio: '기존 듣고치기',
    practice_room_reading: '기존 보고치기',
    quest: '퀘스트',
    unknown: '기타'
  };

  const ERROR_LABELS = {
    wrong: '오자',
    missing: '탈자',
    added: '첨자',
    spacing: '띄어쓰기'
  };

  function todayKstDateString() {
    const now = new Date();
    const kst = new Date(now.getTime() + 9 * 60 * 60 * 1000);
    return kst.toISOString().slice(0, 10);
  }

  function toNumber(value, fallback = 0) {
    const num = Number(value);
    return Number.isFinite(num) ? num : fallback;
  }

  function toNullableNumber(value) {
    const num = Number(value);
    return Number.isFinite(num) ? num : null;
  }

  function round1(value) {
    const num = Number(value);
    return Number.isFinite(num) ? Math.round(num * 10) / 10 : 0;
  }

  function getRecordScore(record) {
    const accuracy = toNullableNumber(record?.accuracy);
    if (accuracy !== null) return accuracy;
    const score = toNullableNumber(record?.score);
    if (score !== null) return score;
    return null;
  }

  function getToolLabel(toolType) {
    return TOOL_LABELS[toolType] || toolType || '기타';
  }

  function calcAverage(values) {
    const nums = values.map(Number).filter(Number.isFinite);
    if (!nums.length) return 0;
    return nums.reduce((sum, value) => sum + value, 0) / nums.length;
  }

  function getKstDateKey(value) {
    if (!value) return '';
    return new Date(value).toLocaleDateString('sv-SE', { timeZone: 'Asia/Seoul' });
  }

  function getRecordsFromLastDays(records, days) {
    const todayKey = todayKstDateString();
    const end = new Date(`${todayKey}T23:59:59+09:00`).getTime();
    const start = end - (days - 1) * 24 * 60 * 60 * 1000;
    return records.filter(record => {
      const createdAt = new Date(record.created_at).getTime();
      return Number.isFinite(createdAt) && createdAt >= start && createdAt <= end;
    });
  }

  function getErrorCounts(record) {
    return {
      wrong: toNumber(record?.wrong_count),
      missing: toNumber(record?.missing_count),
      added: toNumber(record?.added_count),
      spacing: toNumber(record?.spacing_error_count)
    };
  }

  function sumErrors(records) {
    return records.reduce((acc, record) => {
      const counts = getErrorCounts(record);
      acc.wrong += counts.wrong;
      acc.missing += counts.missing;
      acc.added += counts.added;
      acc.spacing += counts.spacing;
      return acc;
    }, { wrong: 0, missing: 0, added: 0, spacing: 0 });
  }

  function getDominantError(errorTotals) {
    const entries = Object.entries(errorTotals || {});
    const sorted = entries.sort((a, b) => b[1] - a[1]);
    const [key, count] = sorted[0] || ['wrong', 0];
    return {
      key,
      label: ERROR_LABELS[key] || '오류',
      count: count || 0
    };
  }

  function getTrend(scoreRecords) {
    const recent = scoreRecords.slice(0, 5).map(getRecordScore).filter(v => v !== null);
    const previous = scoreRecords.slice(5, 10).map(getRecordScore).filter(v => v !== null);
    const recentAvg = round1(calcAverage(recent));
    const previousAvg = previous.length ? round1(calcAverage(previous)) : null;
    const delta = previousAvg === null ? null : round1(recentAvg - previousAvg);

    let status = 'hold';
    let label = '분석 대기';
    let message = '정확도 기록이 조금 더 쌓이면 상승/하락 추이를 판단할 수 있습니다.';

    if (recent.length > 0 && previousAvg === null) {
      status = 'new';
      label = '기록 누적 중';
      message = `최근 평균 정확도는 ${recentAvg}%입니다. 5회 이상 더 기록되면 전후 비교가 가능합니다.`;
    }

    if (delta !== null) {
      if (delta >= 1) {
        status = 'up';
        label = '상승세';
        message = `직전 구간보다 ${Math.abs(delta).toFixed(1)}%p 상승했습니다. 현재 훈련 흐름을 유지해도 좋습니다.`;
      } else if (delta <= -1) {
        status = 'down';
        label = '하락세';
        message = `직전 구간보다 ${Math.abs(delta).toFixed(1)}%p 하락했습니다. 속도보다 정확도 안정 훈련이 먼저 필요합니다.`;
      } else {
        status = 'flat';
        label = '보합';
        message = `직전 구간과 거의 비슷합니다. 같은 속도에서 오류 수를 줄이는 훈련이 필요합니다.`;
      }
    }

    return { recentAvg, previousAvg, delta, status, label, message };
  }

  function getWeakestTool(scoreRecords) {
    const groups = {};
    scoreRecords.forEach(record => {
      const score = getRecordScore(record);
      if (score === null) return;
      const key = record.tool_type || 'unknown';
      if (!groups[key]) groups[key] = [];
      groups[key].push(score);
    });

    const candidates = Object.entries(groups)
      .map(([key, values]) => ({ key, label: getToolLabel(key), count: values.length, avg: round1(calcAverage(values)) }))
      .filter(item => item.count >= 2)
      .sort((a, b) => a.avg - b.avg);

    return candidates[0] || null;
  }

  function getBestRecord(scoreRecords) {
    return scoreRecords
      .map(record => ({ record, score: getRecordScore(record) }))
      .filter(item => item.score !== null)
      .sort((a, b) => b.score - a.score)[0] || null;
  }

  function getDownwardRisk(scoreRecords) {
    const latest = scoreRecords.slice(0, 3).map(getRecordScore).filter(v => v !== null);
    if (latest.length < 3) return false;
    return latest[0] < latest[1] && latest[1] < latest[2];
  }


  const LEVEL_STEPS = [110, 120, 130, 140, 150, 160, 170, 190, 210, 230, 250];

  function getPracticeLevel(record) {
    const title = String(record?.practice_title || '').replace(/\s+/g, ' ');
    const explicit = title.match(/(110|120|130|140|150|160|170|190|210|230|250)\s*자/);
    if (explicit) return Number(explicit[1]);

    const cpm = toNullableNumber(record?.cpm);
    if (cpm === null || cpm < 90 || cpm > 280) return null;

    return LEVEL_STEPS.reduce((best, step) => {
      return Math.abs(step - cpm) < Math.abs(best - cpm) ? step : best;
    }, LEVEL_STEPS[0]);
  }

  function getNextLevel(level) {
    const idx = LEVEL_STEPS.indexOf(Number(level));
    if (idx < 0 || idx >= LEVEL_STEPS.length - 1) return null;
    return LEVEL_STEPS[idx + 1];
  }

  function getCurrentLevel(scoreRecords) {
    const withLevel = scoreRecords
      .map(record => ({ record, level: getPracticeLevel(record), score: getRecordScore(record) }))
      .filter(item => item.level && item.score !== null);
    return withLevel[0]?.level || null;
  }

  function getAverageErrors(records) {
    if (!records.length) return 0;
    const total = records.reduce((sum, record) => {
      const e = getErrorCounts(record);
      return sum + e.wrong + e.missing + e.added + e.spacing;
    }, 0);
    return round1(total / records.length);
  }

  function getScoreDeltaForRecords(records) {
    const latest = records.slice(0, 3).map(getRecordScore).filter(v => v !== null);
    const previous = records.slice(3, 6).map(getRecordScore).filter(v => v !== null);
    if (latest.length < 3 || previous.length < 2) return null;
    return round1(calcAverage(latest) - calcAverage(previous));
  }

  function getLevelSpanDays(records) {
    const dates = records
      .map(record => new Date(record.created_at).getTime())
      .filter(Number.isFinite);
    if (dates.length < 2) return 0;
    const min = Math.min(...dates);
    const max = Math.max(...dates);
    return Math.max(1, Math.round((max - min) / (24 * 60 * 60 * 1000)) + 1);
  }

  function analyzeProgressStatus(scoreRecords) {
    const currentLevel = getCurrentLevel(scoreRecords);
    if (!scoreRecords.length) {
      return {
        currentLevel: null,
        status: 'empty',
        label: '기록 없음',
        message: '정확도 기록이 쌓이면 진도 정체 여부를 자동으로 판단합니다.',
        detail: '최소 5회 이상 기록되면 같은 속도 구간의 변화량을 비교할 수 있습니다.',
        className: 'new'
      };
    }

    if (!currentLevel) {
      const trend = getTrend(scoreRecords);
      return {
        currentLevel: null,
        status: trend.status === 'down' ? 'risk' : 'unknown',
        label: trend.status === 'down' ? '점검 필요' : '속도 추정 불가',
        message: trend.status === 'down'
          ? '최근 정확도 흐름이 하락 중입니다. 파일명에 170자처럼 속도가 들어가면 정체 판단이 더 정확해집니다.'
          : '파일명 또는 속도 정보가 부족해 현재 진도는 자동 추정하지 못했습니다.',
        detail: '파일명에 “연설 170자 3번”처럼 속도를 포함하면 진도 관리가 안정적으로 작동합니다.',
        className: trend.status === 'down' ? 'bad' : 'hold'
      };
    }

    const levelRecords = scoreRecords.filter(record => getPracticeLevel(record) === currentLevel);
    const recentLevelRecords = levelRecords.slice(0, 6);
    const recentAvg = round1(calcAverage(recentLevelRecords.slice(0, 3).map(getRecordScore).filter(v => v !== null)));
    const delta = getScoreDeltaForRecords(recentLevelRecords);
    const spanDays = getLevelSpanDays(levelRecords);
    const avgErrors = getAverageErrors(recentLevelRecords.slice(0, 3));

    if (levelRecords.length < 5) {
      return {
        currentLevel,
        status: 'watch',
        label: `${currentLevel}자 관찰 중`,
        message: `현재 ${currentLevel}자 기록이 ${levelRecords.length}회입니다. 5회 이상 쌓이면 정체 여부를 판단합니다.`,
        detail: `최근 평균 ${recentAvg || '-'}% / 최근 평균 오류 ${avgErrors}개`,
        className: 'new'
      };
    }

    if (delta !== null && delta <= 0.3 && recentAvg < 97.5 && spanDays >= 7) {
      return {
        currentLevel,
        status: 'stagnant',
        label: '진도 정체 가능성',
        message: `최근 ${currentLevel}자 구간에서 정확도 변화가 ${delta >= 0 ? '+' : ''}${delta}%p 수준입니다. 상위 속도보다 현재 속도 안정화가 먼저입니다.`,
        detail: `${currentLevel}자 기록 ${levelRecords.length}회 / 관찰 기간 ${spanDays}일 / 최근 평균 오류 ${avgErrors}개`,
        className: 'bad'
      };
    }

    if (recentAvg < 93 && levelRecords.length >= 3) {
      return {
        currentLevel,
        status: 'risk',
        label: `${currentLevel}자 불안정`,
        message: `최근 ${currentLevel}자 평균 정확도가 ${recentAvg}%입니다. 진도 상승보다 이전 속도 복습이 필요합니다.`,
        detail: `최근 평균 오류 ${avgErrors}개 / 최근 기록 ${Math.min(levelRecords.length, 6)}회 기준`,
        className: 'bad'
      };
    }

    return {
      currentLevel,
      status: 'stable',
      label: `${currentLevel}자 안정 관리`,
      message: `최근 ${currentLevel}자 평균 정확도는 ${recentAvg || '-'}%입니다. 오류 수를 줄이면서 다음 판단 기록을 더 쌓으면 됩니다.`,
      detail: `정확도 변화 ${delta === null ? '-' : (delta >= 0 ? '+' : '') + delta + '%p'} / 최근 평균 오류 ${avgErrors}개`,
      className: 'good'
    };
  }

  function analyzePromotionCandidate(scoreRecords) {
    const currentLevel = getCurrentLevel(scoreRecords);
    if (!currentLevel) {
      return {
        eligible: false,
        currentLevel: null,
        nextLevel: null,
        label: '승급 판단 대기',
        message: '속도 정보가 있는 기록이 쌓이면 승급 후보 여부를 자동 판단합니다.',
        detail: '기준: 최근 3회 평균 정확도 98% 이상 + 평균 오류 3개 이하',
        className: 'hold'
      };
    }

    const nextLevel = getNextLevel(currentLevel);
    const levelRecords = scoreRecords.filter(record => getPracticeLevel(record) === currentLevel);
    const latest3 = levelRecords.slice(0, 3);
    if (!nextLevel) {
      return {
        eligible: false,
        currentLevel,
        nextLevel: null,
        label: '최상위 구간',
        message: `${currentLevel}자 이후 상위 속도 단계가 설정되어 있지 않습니다. 정확도 유지와 실전 대비를 기준으로 관리하세요.`,
        detail: '내부 속도 단계 기준: 110→120→130→140→150→160→170→190→210→230→250',
        className: 'good'
      };
    }

    if (latest3.length < 3) {
      return {
        eligible: false,
        currentLevel,
        nextLevel,
        label: '승급 판단 대기',
        message: `${currentLevel}자 최근 기록이 ${latest3.length}회입니다. 최근 3회 기록이 쌓이면 ${nextLevel}자 이동 가능성을 판단합니다.`,
        detail: '기준: 최근 3회 평균 정확도 98% 이상 + 평균 오류 3개 이하',
        className: 'new'
      };
    }

    const avgScore = round1(calcAverage(latest3.map(getRecordScore).filter(v => v !== null)));
    const avgErrors = getAverageErrors(latest3);
    const eligible = avgScore >= 98 && avgErrors <= 3;
    const near = !eligible && avgScore >= 97 && avgErrors <= 5;

    if (eligible) {
      return {
        eligible: true,
        currentLevel,
        nextLevel,
        avgScore,
        avgErrors,
        label: '승급 후보',
        message: `최근 3회 ${currentLevel}자 평균 ${avgScore}%, 평균 오류 ${avgErrors}개입니다. ${nextLevel}자 응시 검토가 가능합니다.`,
        detail: `권장: ${nextLevel}자 1회 테스트 후 정확도 96% 이상이면 반 이동/진도 상승 검토`,
        className: 'good'
      };
    }

    if (near) {
      return {
        eligible: false,
        currentLevel,
        nextLevel,
        avgScore,
        avgErrors,
        label: '승급 근접',
        message: `최근 3회 평균 ${avgScore}%로 흐름은 좋지만 평균 오류가 ${avgErrors}개입니다. 오류를 조금 더 줄이면 ${nextLevel}자 응시가 가능합니다.`,
        detail: '권장: 같은 속도 파일 2회 추가 후 재판단',
        className: 'hold'
      };
    }

    return {
      eligible: false,
      currentLevel,
      nextLevel,
      avgScore,
      avgErrors,
      label: '현 단계 유지',
      message: `최근 3회 평균 ${avgScore}%, 평균 오류 ${avgErrors}개입니다. 아직은 ${currentLevel}자 안정화가 우선입니다.`,
      detail: `승급 기준까지 정확도 ${Math.max(0, round1(98 - avgScore))}%p 보완 필요`,
      className: 'hold'
    };
  }

  function buildTeacherComment({ trend, dominantError, weakestTool, progressStatus, promotionCandidate, weeklyRecords, weeklyAvg }) {
    const lines = [];

    if (promotionCandidate?.eligible) {
      lines.push(`최근 기록 기준으로 ${promotionCandidate.currentLevel}자 구간은 안정권에 들어왔습니다.`);
      lines.push(`최근 3회 평균 정확도 ${promotionCandidate.avgScore}%, 평균 오류 ${promotionCandidate.avgErrors}개로 ${promotionCandidate.nextLevel}자 응시 검토가 가능합니다.`);
    } else if (progressStatus?.status === 'stagnant') {
      lines.push(`현재 ${progressStatus.currentLevel}자 구간에서 진도 정체 가능성이 보입니다.`);
      lines.push('상위 속도 응시보다 현재 속도에서 탈자·오자 수를 줄이는 안정화 훈련을 먼저 진행하는 것이 좋습니다.');
    } else if (progressStatus?.status === 'risk') {
      lines.push(`최근 ${progressStatus.currentLevel || ''}자 기록이 불안정합니다.`.replace(/\s+자/, '자'));
      lines.push('새 파일 진도보다 이전 파일 복습과 정확도 회복 훈련을 우선 배치하는 것이 좋습니다.');
    } else if (trend?.status === 'up') {
      lines.push('최근 정확도 흐름이 상승세입니다. 현재 훈련 방향은 유지해도 좋습니다.');
    } else if (trend?.status === 'down') {
      lines.push('최근 정확도 흐름이 하락세입니다. 속도 상승보다 정확도 회복 훈련이 먼저 필요합니다.');
    } else {
      lines.push('최근 기록은 큰 변동 없이 유지되고 있습니다. 같은 속도에서 오류 수를 줄이는 미세 교정이 필요합니다.');
    }

    if (dominantError?.count > 0) {
      lines.push(`특히 ${dominantError.label}가 반복되고 있어 이 부분을 집중적으로 점검해야 합니다.`);
    }

    if (weakestTool) {
      lines.push(`${weakestTool.label} 유형 평균이 상대적으로 낮아 이번 주 보강 유형으로 우선 배치하겠습니다.`);
    }

    if (weeklyRecords.length < 3) {
      lines.push('최근 7일 연습 횟수가 적어 짧게라도 주 3회 이상 기록을 남기는 것이 필요합니다.');
    } else if (weeklyAvg >= 97) {
      lines.push(`최근 7일 평균 정확도는 ${weeklyAvg.toFixed(1)}%로 양호합니다.`);
    }

    return lines.join('\n');
  }

  function buildTrainingRecommendation({ records, scoreRecords, trend, dominantError, weakestTool, weeklyRecords, progressStatus, promotionCandidate }) {
    if (!records.length) {
      return [
        '오늘은 연습 기록 1회를 먼저 남기는 것이 우선입니다.',
        '정확도와 오류 수가 저장되면 다음부터 맞춤 훈련을 자동으로 추천합니다.',
        '처음에는 속도보다 입력 안정성과 누락 방지를 기준으로 봅니다.'
      ];
    }

    const recs = [];

    if (promotionCandidate?.eligible) {
      recs.push(`${promotionCandidate.nextLevel}자 응시 가능성이 있습니다. 단, 첫 응시는 테스트 1회로만 진행하고 정확도 96% 이상인지 확인하세요.`);
    }

    if (progressStatus?.status === 'stagnant') {
      recs.push('진도 정체 가능성이 있습니다. 상위 속도보다 현재 속도 파일을 2회 반복해 오류 수 감소 여부를 먼저 확인하세요.');
    } else if (progressStatus?.status === 'risk') {
      recs.push('현재 진도 기록이 불안정합니다. 이전 속도 파일 1개를 복습한 뒤 현재 속도로 돌아오는 방식이 안전합니다.');
    }

    if (dominantError.count > 0) {
      if (dominantError.key === 'missing') {
        recs.push('탈자가 가장 많습니다. 긴 파일보다 짧은 파일을 2회 반복해 듣는 흐름을 끊지 않는 훈련이 필요합니다.');
      } else if (dominantError.key === 'wrong') {
        recs.push('오자가 가장 많습니다. 속도를 올리기보다 같은 파일을 다시 치면서 헷갈린 어절을 고정하는 훈련이 필요합니다.');
      } else if (dominantError.key === 'added') {
        recs.push('첨자가 가장 많습니다. 들은 내용을 바로 확장해서 치는 습관을 줄이고, 어절 단위로 멈춤 없는 입력을 점검해야 합니다.');
      } else if (dominantError.key === 'spacing') {
        recs.push('띄어쓰기 오류가 누적되고 있습니다. 문장부호 뒤 처리와 이중 공백 여부를 먼저 점검하는 훈련이 필요합니다.');
      }
    }

    if (trend.status === 'down') {
      recs.push('최근 정확도가 하락 중입니다. 다음 훈련은 상위 속도 응시보다 현재 속도 파일 재훈련으로 잡는 것이 안전합니다.');
    } else if (trend.status === 'up' && trend.recentAvg >= 97) {
      recs.push('정확도 흐름이 좋습니다. 같은 유형에서 파일 난이도를 1단계만 올려도 됩니다.');
    } else if (trend.recentAvg && trend.recentAvg < 90) {
      recs.push('최근 평균 정확도가 낮습니다. 새 파일 진도보다 기존 파일 재청취와 오답 정리가 먼저입니다.');
    }

    if (weakestTool) {
      recs.push(`${weakestTool.label} 평균이 ${weakestTool.avg}%로 상대적으로 낮습니다. 이번 주 보강 유형으로 우선 배치하세요.`);
    }

    if (weeklyRecords.length < 3) {
      recs.push('최근 7일 연습 횟수가 적습니다. 짧게라도 주 3회 이상 기록을 남겨야 추세 판단이 정확해집니다.');
    }

    if (!recs.length) {
      recs.push('현재 기록은 안정적입니다. 같은 속도에서 오류 수를 줄이는 미세 교정 훈련을 유지하세요.');
    }

    return recs.slice(0, 4);
  }

  function buildWeeklyReportText({ records, weeklyRecords, weeklyAvg, trend, dominantError, bestRecord, recommendation, progressStatus, promotionCandidate, teacherComment }) {
    if (!records.length) {
      return '[주간 학습 리포트]\n아직 저장된 연습 기록이 없습니다. 오늘 연습 1회를 완료하면 다음부터 주간 리포트가 자동 생성됩니다.';
    }

    const bestText = bestRecord
      ? `${bestRecord.record.practice_title || getToolLabel(bestRecord.record.tool_type)} ${round1(bestRecord.score)}%`
      : '-';

    return [
      '[주간 학습 리포트]',
      `최근 7일 연습 횟수: ${weeklyRecords.length}회`,
      `최근 7일 평균 정확도: ${weeklyAvg ? weeklyAvg.toFixed(1) + '%' : '-'}`,
      `최근 정확도 흐름: ${trend.label}`,
      `주요 오류 유형: ${dominantError.count > 0 ? dominantError.label + ' ' + dominantError.count + '개' : '누적 오류 없음'}`,
      `가장 좋은 기록: ${bestText}`,
      `진도 상태: ${progressStatus?.label || '-'}`,
      `승급 판단: ${promotionCandidate?.label || '-'}`,
      '',
      '[선생님 코멘트]',
      teacherComment || '-',
      '',
      '[다음 훈련 방향]',
      ...recommendation.map((item, index) => `${index + 1}. ${item}`)
    ].join('\n');
  }

  function buildStudyInsight(records) {
    const safeRecords = Array.isArray(records) ? records : [];
    const scoreRecords = safeRecords.filter(record => getRecordScore(record) !== null);
    const weeklyRecords = getRecordsFromLastDays(safeRecords, 7);
    const weeklyScoreRecords = weeklyRecords.filter(record => getRecordScore(record) !== null);
    const allAvg = round1(calcAverage(scoreRecords.map(getRecordScore).filter(v => v !== null)));
    const weeklyAvg = round1(calcAverage(weeklyScoreRecords.map(getRecordScore).filter(v => v !== null)));
    const trend = getTrend(scoreRecords);
    const errorTotals = sumErrors(safeRecords);
    const weeklyErrorTotals = sumErrors(weeklyRecords);
    const totalErrors = Object.values(errorTotals).reduce((sum, value) => sum + value, 0);
    const dominantError = getDominantError(errorTotals);
    const weakestTool = getWeakestTool(scoreRecords);
    const bestRecord = getBestRecord(scoreRecords);
    const downwardRisk = getDownwardRisk(scoreRecords);
    const progressStatus = analyzeProgressStatus(scoreRecords);
    const promotionCandidate = analyzePromotionCandidate(scoreRecords);
    const recommendation = buildTrainingRecommendation({ records: safeRecords, scoreRecords, trend, dominantError, weakestTool, weeklyRecords, progressStatus, promotionCandidate });
    const teacherComment = buildTeacherComment({ trend, dominantError, weakestTool, progressStatus, promotionCandidate, weeklyRecords, weeklyAvg });
    const reportText = buildWeeklyReportText({ records: safeRecords, weeklyRecords, weeklyAvg, trend, dominantError, bestRecord, recommendation, progressStatus, promotionCandidate, teacherComment });

    return {
      totalRecords: safeRecords.length,
      scoreRecordCount: scoreRecords.length,
      weeklyCount: weeklyRecords.length,
      allAvg,
      weeklyAvg,
      trend,
      errorTotals,
      weeklyErrorTotals,
      totalErrors,
      dominantError,
      weakestTool,
      bestRecord: bestRecord ? {
        title: bestRecord.record.practice_title || getToolLabel(bestRecord.record.tool_type),
        toolType: bestRecord.record.tool_type || 'unknown',
        toolLabel: getToolLabel(bestRecord.record.tool_type),
        score: round1(bestRecord.score),
        date: getKstDateKey(bestRecord.record.created_at)
      } : null,
      downwardRisk,
      progressStatus,
      promotionCandidate,
      teacherComment,
      recommendation,
      reportText
    };
  }

  async function getCurrentUserId() {
    let userId = sessionStorage.getItem('shorthand_user_id');
    if (userId) return userId;
    const session = await window.SorizavaAuth.getSession();
    return session && session.user ? session.user.id : null;
  }

  async function savePracticeRecord(payload) {
    try {
      const userId = await getCurrentUserId();
      if (!userId) throw new Error('로그인 정보가 없습니다.');
      const row = {
        user_id: userId,
        tool_type: payload.tool_type || 'unknown',
        practice_title: payload.practice_title || payload.title || null,
        original_length: Number.isFinite(Number(payload.original_length)) ? Number(payload.original_length) : null,
        typed_length: Number.isFinite(Number(payload.typed_length)) ? Number(payload.typed_length) : null,
        accuracy: Number.isFinite(Number(payload.accuracy)) ? Number(payload.accuracy) : null,
        score: Number.isFinite(Number(payload.score)) ? Number(payload.score) : null,
        cpm: Number.isFinite(Number(payload.cpm)) ? Math.round(Number(payload.cpm)) : null,
        wrong_count: Number.isFinite(Number(payload.wrong_count)) ? Number(payload.wrong_count) : 0,
        missing_count: Number.isFinite(Number(payload.missing_count)) ? Number(payload.missing_count) : 0,
        added_count: Number.isFinite(Number(payload.added_count)) ? Number(payload.added_count) : 0,
        spacing_error_count: Number.isFinite(Number(payload.spacing_error_count)) ? Number(payload.spacing_error_count) : 0,
        elapsed_seconds: Number.isFinite(Number(payload.elapsed_seconds)) ? Math.round(Number(payload.elapsed_seconds)) : null,
        source_text_snapshot: payload.source_text_snapshot || null,
        typed_text_snapshot: payload.typed_text_snapshot || null,
        diff_summary: payload.diff_summary || null,
        memo: payload.memo || null
      };
      const { data, error } = await window.SORIZAVA_SUPABASE
        .from('practice_records')
        .insert(row)
        .select()
        .single();
      if (error) throw error;
      return data;
    } catch (e) {
      console.error('연습 기록 저장 실패:', e);
      return null;
    }
  }

  async function savePracticeInputLog(payload) {
    try {
      const userId = await getCurrentUserId();
      if (!userId || !payload?.practice_record_id) return null;
      const row = {
        user_id: userId,
        practice_record_id: payload.practice_record_id,
        started_at: payload.started_at || null,
        ended_at: payload.ended_at || null,
        total_duration_ms: Number.isFinite(Number(payload.total_duration_ms)) ? Math.round(Number(payload.total_duration_ms)) : null,
        pause_count: Number.isFinite(Number(payload.pause_count)) ? Number(payload.pause_count) : 0,
        max_pause_ms: Number.isFinite(Number(payload.max_pause_ms)) ? Math.round(Number(payload.max_pause_ms)) : 0,
        backspace_count: Number.isFinite(Number(payload.backspace_count)) ? Number(payload.backspace_count) : 0,
        paste_detected: Boolean(payload.paste_detected),
        raw_events: payload.raw_events || [],
        section_stats: payload.section_stats || {}
      };
      const { data, error } = await window.SORIZAVA_SUPABASE
        .from('practice_input_logs')
        .insert(row)
        .select()
        .single();
      if (error) throw error;
      return data;
    } catch (e) {
      console.warn('AI 분석용 입력 로그 저장 실패:', e);
      return null;
    }
  }

  async function savePracticeAbbrevLog(payload) {
    try {
      const userId = await getCurrentUserId();
      if (!userId || !payload?.practice_record_id) return null;
      const row = {
        user_id: userId,
        practice_record_id: payload.practice_record_id,
        abbrev_hint_enabled: Boolean(payload.abbrev_hint_enabled),
        total_abbrev_count: Number.isFinite(Number(payload.total_abbrev_count)) ? Number(payload.total_abbrev_count) : 0,
        correct_abbrev_count: Number.isFinite(Number(payload.correct_abbrev_count)) ? Number(payload.correct_abbrev_count) : 0,
        slow_abbrev_count: Number.isFinite(Number(payload.slow_abbrev_count)) ? Number(payload.slow_abbrev_count) : 0,
        error_abbrev_count: Number.isFinite(Number(payload.error_abbrev_count)) ? Number(payload.error_abbrev_count) : 0,
        missed_abbrevs: payload.missed_abbrevs || [],
        weak_abbrev_patterns: payload.weak_abbrev_patterns || []
      };
      const { data, error } = await window.SORIZAVA_SUPABASE
        .from('practice_abbrev_logs')
        .insert(row)
        .select()
        .single();
      if (error) throw error;
      return data;
    } catch (e) {
      console.warn('AI 분석용 약어 로그 저장 실패:', e);
      return null;
    }
  }

  async function getMyRecentRecords(limit = 50) {
    const userId = await getCurrentUserId();
    if (!userId) return [];
    const { data, error } = await window.SORIZAVA_SUPABASE
      .from('practice_records')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(limit);
    if (error) throw error;
    return data || [];
  }

  async function getDashboardSummary() {
    const records = await getMyRecentRecords(500);
    const avgAccRecords = records.filter(r => r.accuracy !== null || r.score !== null);
    const avgAcc = avgAccRecords.length
      ? avgAccRecords.reduce((sum, r) => sum + Number(r.accuracy ?? r.score ?? 0), 0) / avgAccRecords.length
      : 0;
    const maxCpm = records.reduce((max, r) => Math.max(max, Number(r.cpm || 0)), 0);
    const byDate = {};
    records.forEach(r => {
      const day = new Date(r.created_at).toLocaleDateString('sv-SE', { timeZone: 'Asia/Seoul' });
      byDate[day] = (byDate[day] || 0) + 1;
    });
    let streak = 0;
    for (let i = 0; i < 365; i++) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const day = new Date(d.getTime() + 9 * 60 * 60 * 1000).toISOString().slice(0, 10);
      if (byDate[day]) streak++;
      else if (i === 0) continue;
      else break;
    }
    const graphData = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const kst = new Date(d.getTime() + 9 * 60 * 60 * 1000);
      const day = kst.toISOString().slice(0, 10);
      graphData.push({ label: `${kst.getMonth()+1}/${kst.getDate()}`, value: byDate[day] || 0 });
    }
    return {
      records,
      streak,
      avgAcc,
      maxCPM: maxCpm,
      graphData,
      maxActivity: Math.max(1, ...graphData.map(d => d.value))
    };
  }

  async function getMyStudyInsight() {
    const summary = await getDashboardSummary();
    return {
      ...summary,
      insight: buildStudyInsight(summary.records)
    };
  }

  window.SorizavaRecords = {
    savePracticeRecord,
    savePracticeInputLog,
    savePracticeAbbrevLog,
    getMyRecentRecords,
    getDashboardSummary,
    getMyStudyInsight,
    buildStudyInsight,
    analyzeProgressStatus,
    analyzePromotionCandidate,
    todayKstDateString,
    getToolLabel
  };

// 공부방 승급 공통 가드
(function () {
  const PASS_FLAG = 'sorizava_graduation_exam_all_sets_passed';
  const LEGACY_PASS_FLAG = 'sorizava_graduation_exam_passed';
  const SET_PASS_KEY = 'sorizava_graduation_exam_passed_sets_v1';
  const CHECK_CACHE_KEY = 'sorizava_graduation_exam_checked_at';
  const PASS_MESSAGE = '입문반 졸업시험을 먼저 통과해야 중급반 공부방이 열립니다.\n\n순서: 입문반 졸업시험 합격 → 중급반 공부방 입장 → 진도 승급실에서 110자부터 단계별 승급';
  const STAFF_ROLES = ['admin','administrator','super_admin','superadmin','owner','manager','operator','staff','teacher','강사','선생님','관리자','운영팀'];
  function normalizeRole(value) { return String(value || '').trim().toLowerCase(); }
  function hasStaffRole() {
    const roles = [sessionStorage.getItem('shorthand_role')];
    try {
      const cached = JSON.parse(sessionStorage.getItem('sorizava_profile_cache') || 'null');
      roles.push(cached?.role, cached?.profile?.role);
    } catch (e) {}
    return roles.map(normalizeRole).some(role => STAFF_ROLES.includes(role));
  }
  function readLocalGraduationSetPasses() {
    try {
      const rows = JSON.parse(localStorage.getItem(SET_PASS_KEY) || '{}');
      return rows && typeof rows === 'object' ? rows : {};
    } catch (error) { return {}; }
  }
  function hasLocalAllGraduationSetsPassed() {
    const rows = readLocalGraduationSetPasses();
    return Array.from({ length: 9 }, (_, idx) => String(idx + 1)).every(key => rows[key] && rows[key].passed);
  }
  function isGraduationPassRecord(row) {
    const tool = String(row?.tool_type || '').toLowerCase();
    const memo = String(row?.memo || '');
    return tool === 'exam' && !memo.includes('불합격') && (
      memo.includes('9세트 전체 합격') ||
      memo.includes('전체 합격') ||
      memo.includes('최종 통과')
    );
  }
  function hasRemoteAllGraduationSetsPassed(rows = []) {
    const passed = new Set();
    rows.forEach(row => {
      const tool = String(row?.tool_type || '').toLowerCase();
      const memo = String(row?.memo || '');
      const title = String(row?.practice_title || '');
      if (tool !== 'exam' || memo.includes('불합격')) return;
      const match = `${title} ${memo}`.match(/([1-9])\s*세트/);
      if (match && memo.includes('합격')) passed.add(match[1]);
    });
    return passed.size >= 9;
  }
  async function hasGraduationPassed(force = false) {
    if (hasStaffRole()) return true;
    if (localStorage.getItem(PASS_FLAG) === 'true' || hasLocalAllGraduationSetsPassed()) {
      localStorage.setItem(PASS_FLAG, 'true');
      localStorage.setItem(LEGACY_PASS_FLAG, 'true');
      return true;
    }
    const lastChecked = Number(localStorage.getItem(CHECK_CACHE_KEY) || 0);
    if (!force && lastChecked && Date.now() - lastChecked < 60 * 1000) return false;
    localStorage.setItem(CHECK_CACHE_KEY, String(Date.now()));
    try {
      if (!window.SorizavaRecords?.getMyRecentRecords) return false;
      const rows = await window.SorizavaRecords.getMyRecentRecords(500);
      if ((rows || []).some(isGraduationPassRecord) || hasRemoteAllGraduationSetsPassed(rows || [])) {
        localStorage.setItem(PASS_FLAG, 'true');
        localStorage.setItem(LEGACY_PASS_FLAG, 'true');
        localStorage.setItem('sorizava_graduation_exam_passed_at', new Date().toISOString());
        return true;
      }
    } catch (error) {
      console.warn('졸업시험 통과 기록 확인 실패:', error);
    }
    return false;
  }
  async function guardClick(event, href) {
    const targetHref = href || event?.currentTarget?.getAttribute?.('href') || event?.target?.closest?.('a')?.getAttribute?.('href') || '';
    if (!/intermediate\.html/i.test(targetHref)) return true;
    if (await hasGraduationPassed()) return true;
    if (event) event.preventDefault();
    alert(PASS_MESSAGE);
    return false;
  }
  function installLinkGuard() {
    document.addEventListener('click', function (event) {
      const link = event.target.closest && event.target.closest('a[href*="intermediate.html"]');
      if (!link) return;
      if (hasStaffRole() || localStorage.getItem(PASS_FLAG) === 'true' || hasLocalAllGraduationSetsPassed()) return;
      event.preventDefault();
      guardClick(event, link.getAttribute('href')).then(ok => { if (ok) location.href = link.href; });
    }, true);
  }
  window.SorizavaCourseGate = { hasGraduationPassed, guardClick, isGraduationPassRecord, message: PASS_MESSAGE };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', installLinkGuard);
  else installLinkGuard();
})();

})();
