    // [1] 전역 변수 및 설정
    let sentences = ["파일을 불러오거나 입력을 시작하세요."];
    let curIdx = 0, curLineIdx = 0;
    
    // 누적 통계 관련 (파일 전체 기준)
    let fileStartTime = null;   // 파일 전체 시작 시간 (절대 시간)
    let accumulatedPause = 0;   // 총 일시정지 시간
    let speedDeductionTime = 0; // 에러 리셋으로 인해 '속도 계산'에서 뺄 시간
    let completedCharsGlobal = 0; // 이미 완료된 이전 문장들의 글자 수
    let totalFileChars = 0;     // 파일 전체 글자 수
    
    let lineStartTime = null;   // 현재 '줄'을 시작한 시간
    let timerInt = null;
    let isPaused = false;
    let pauseStartAt = null;

    // 페이스메이커 관련
    let pmInt = null;
    let pmCursorIdx = 0; 
    let isPmActive = false;

    // DOM 요소
    const box = document.getElementById('target-box');
    const inp = document.getElementById('input-field');
    const progressBar = document.getElementById('progress-bar');
    const bestRecordEl = document.getElementById('best-record');
    const pmToggle = document.getElementById('pm-toggle');
    const pmSpeedInp = document.getElementById('pm-speed');
    const pauseOverlay = document.getElementById('pause-overlay');

    // 사용자 정보 로드 (세션 스토리지)
    let currentUser = sessionStorage.getItem('shorthand_user');
    if(currentUser) {
        const sideNameEl = document.getElementById('sideUserName') || document.getElementById('userNameSide');
        if (sideNameEl) sideNameEl.innerText = currentUser;
    }
    
    // [기록 저장 키 생성 함수] 사용자별 키 분리
    function getStorageKey() {
        if(currentUser) return 'sparta_best_cpm_' + currentUser;
        return 'sparta_best_cpm'; // 로그인 안 된 경우 기본 키
    }

    // 최고 기록 불러오기 (사용자별)
    function loadBestRecord() {
        const key = getStorageKey();
        const savedBest = localStorage.getItem(key);
        bestRecordEl.innerText = savedBest ? savedBest : 0;
    }
    function getPaceSpeedKey() {
        if(currentUser) return 'sparta_pacemaker_speed_' + currentUser;
        return 'sparta_pacemaker_speed';
    }
    function loadPaceSpeed() {
        const saved = localStorage.getItem(getPaceSpeedKey());
        if(saved && pmSpeedInp) pmSpeedInp.value = saved;
    }
    function savePaceSpeed() {
        if(!pmSpeedInp) return 300;
        const value = Math.max(10, parseInt(pmSpeedInp.value) || 300);
        pmSpeedInp.value = value;
        localStorage.setItem(getPaceSpeedKey(), String(value));
        return value;
    }
    loadBestRecord();
    loadPaceSpeed();

    const clean = (t) => t.split('').filter(c => /[ㄱ-ㅎ가-힣a-zA-Z0-9]/.test(c)).join('');

    let lastClearedPracticeText = '';
    let clearGuardUntil = 0;

    function forceClearPracticeInput(previousCleanText = '') {
        if (!inp) return;
        lastClearedPracticeText = previousCleanText || '';
        clearGuardUntil = Date.now() + 900;
        inp.value = '';
        inp.defaultValue = '';
        try { inp.setAttribute('value', ''); } catch (error) {}
        requestAnimationFrame(clearCarryoverInputIfNeeded);
        setTimeout(clearCarryoverInputIfNeeded, 60);
        setTimeout(clearCarryoverInputIfNeeded, 180);
    }

    function currentCleanLine() {
        const lines = getLines();
        return clean(lines[curLineIdx] || '');
    }

    function clearCarryoverInputIfNeeded() {
        if (!inp || !inp.value || Date.now() > clearGuardUntil) return false;
        const value = clean(inp.value);
        if (!value || !lastClearedPracticeText) return false;
        const target = currentCleanLine();
        if (target && target.startsWith(value)) return false;
        if (lastClearedPracticeText.endsWith(value) || (value.length >= 2 && lastClearedPracticeText.includes(value))) {
            inp.value = '';
            inp.defaultValue = '';
            try { inp.setAttribute('value', ''); } catch (error) {}
            return true;
        }
        return false;
    }

    // [2] 텍스트 분할 및 파일 로드 시 전체 글자 수 계산
    function getLines() {
        const text = sentences[curIdx] || "";
        const limit = parseInt(document.getElementById('line-limit').value);
        const words = text.split(' ');
        let lines = [], cur = "";
        words.forEach(w => {
            if ((cur + w).length > limit && cur !== "") { lines.push(cur.trim()); cur = w + " "; }
            else { cur += w + " "; }
        });
        lines.push(cur.trim());
        return lines;
    }

    function calculateTotalChars() {
        let count = 0;
        sentences.forEach(s => count += clean(s).length);
        totalFileChars = count;
        document.getElementById('remain-count').innerText = totalFileChars;
    }

    // [3] 페이스메이커 로직
    function startPacemaker() {
        if (!pmToggle.checked) return;
        
        stopPacemaker(); 
        isPmActive = true;
        pmCursorIdx = 0; 

        const targetCPM = savePaceSpeed();
        const msPerChar = 60000 / targetCPM; 

        pmInt = setInterval(() => {
            if(isPaused) return; 

            const lines = getLines();
            const currentLineLen = lines[curLineIdx].length;

            if (pmCursorIdx < currentLineLen) {
                pmCursorIdx++;
                renderPacemakerOnly(); 
            } else {
                clearInterval(pmInt);
            }
        }, msPerChar);
    }

    function stopPacemaker() {
        if(pmInt) clearInterval(pmInt);
        isPmActive = false;
        pmCursorIdx = 0;
        renderPacemakerOnly(); 
    }

    function renderPacemakerOnly() {
        const spans = box.querySelectorAll('span');
        spans.forEach(span => span.classList.remove('pacemaker-cursor'));
        if (isPmActive && pmCursorIdx < spans.length) {
            spans[pmCursorIdx].classList.add('pacemaker-cursor');
        }
    }

    // [4] 메인 렌더링 함수
    function render() {
        const lines = getLines();
        const activeText = lines[curLineIdx];
        if (!activeText) return;

        const typedVal = inp.value;
        const typedC = clean(typedVal);
        const activeC = clean(activeText);

        box.innerHTML = '';
        activeText.split('').forEach((char, i) => {
            const span = document.createElement('span');
            span.innerText = char;
            const isAlpha = /[ㄱ-ㅎ가-힣a-zA-Z0-9]/.test(char);
            span.className = isAlpha ? 'char' : 'ignored';
            
            if (isAlpha) {
                const cIdx = clean(activeText.substring(0, i)).length;
                const tChar = typedC[cIdx];
                if (tChar != null) span.classList.add(tChar === char ? 'correct' : 'incorrect');
            }
            box.appendChild(span);
        });
        
        renderPacemakerOnly();
        updateStats();
    }

    // [5] 입력 이벤트 핸들러
    if (pmSpeedInp) {
        pmSpeedInp.addEventListener('change', () => {
            savePaceSpeed();
            if (fileStartTime && pmToggle.checked) {
                stopPacemaker();
                startPacemaker();
            }
        });
        pmSpeedInp.addEventListener('input', () => {
            localStorage.setItem(getPaceSpeedKey(), pmSpeedInp.value || '300');
        });
    }

    inp.addEventListener('input', () => {
        if (isPaused) return;
        if (clearCarryoverInputIfNeeded()) {
            render();
            return;
        }

        // 파일의 첫 시작
        if (!fileStartTime && inp.value.length > 0) {
            fileStartTime = new Date();
            lineStartTime = new Date(); // 첫 줄 시작 시간
            timerInt = setInterval(updateStats, 200); 
            startPacemaker(); 
        }
        render();
    });

    inp.addEventListener('keydown', (e) => {
        if (isPaused) { e.preventDefault(); return; }
        if (e.key === 'Backspace') e.preventDefault(); 
        
        if (e.key === 'Enter') {
            const lines = getLines();
            const cleanLine = clean(lines[curLineIdx]);
            const cleanInput = clean(inp.value);

            if (cleanLine === cleanInput) {
                // [성공]
                const len = cleanLine.length;
                completedCharsGlobal += len; 

                if (curLineIdx === lines.length - 1) {
                    if (curIdx === sentences.length - 1) {
                        finishGame(); 
                    } else { 
                        curIdx++; 
                        resetForNextSentence(cleanLine); 
                    }
                } else {
                    curLineIdx++; 
                    forceClearPracticeInput(cleanLine); 
                    lineStartTime = new Date();
                    stopPacemaker();
                    startPacemaker(); 
                    render();
                }
            } else {
                // [실패] 오타 발생 후 엔터 -> 리셋 및 속도 보정
                if (lineStartTime) {
                    const now = new Date();
                    const wasted = now - lineStartTime; 
                    speedDeductionTime += wasted; 
                    lineStartTime = now; 
                }

                forceClearPracticeInput(cleanInput); 
                render(); 
                stopPacemaker();
                startPacemaker();
            }
        }
    });

    function resetForNextSentence(previousCleanText = '') {
        curLineIdx = 0;
        forceClearPracticeInput(previousCleanText);
        lineStartTime = new Date(); 
        stopPacemaker();
        startPacemaker();
        render();
    }

    // [6] 일시정지 기능
    window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') togglePause();
    });

    function togglePause() {
        if (!fileStartTime) return; 

        isPaused = !isPaused;
        
        if (isPaused) {
            pauseStartAt = new Date();
            clearInterval(timerInt);
            inp.disabled = true;
            pauseOverlay.style.display = 'flex';
        } else {
            const pausedDuration = new Date() - pauseStartAt;
            accumulatedPause += pausedDuration; 
            
            if(lineStartTime) {
                lineStartTime = new Date(lineStartTime.getTime() + pausedDuration);
            }

            timerInt = setInterval(updateStats, 200);
            inp.disabled = false;
            inp.focus();
            pauseOverlay.style.display = 'none';
        }
    }

    // [7] 통계 업데이트
    function updateStats() {
        if (!fileStartTime || isPaused) return;

        const now = new Date();
        const realElapsedTimeMS = now - fileStartTime - accumulatedPause;
        document.getElementById('timer').innerText = Math.floor(realElapsedTimeMS / 1000) + "초";

        const currentInputLen = clean(inp.value).length;
        const totalTypedChars = completedCharsGlobal + currentInputLen;
        const netTimeMS = realElapsedTimeMS - speedDeductionTime;
        
        let cpm = 0;
        if (netTimeMS > 0) {
            cpm = Math.floor(totalTypedChars / (netTimeMS / 60000));
        }
        document.getElementById('current-cpm').innerText = cpm;

        let percent = 0;
        if (totalFileChars > 0) {
            percent = (totalTypedChars / totalFileChars) * 100;
        }
        
        progressBar.style.width = Math.min(percent, 100) + "%";
        const progressLabel = document.getElementById('progress-percent-label');
        if (progressLabel) progressLabel.innerText = Math.floor(Math.min(percent, 100));
        document.getElementById('remain-count').innerText = Math.max(0, totalFileChars - totalTypedChars);
    }

    // [8] 게임 종료 및 저장 (사용자별 저장)
    function finishGame() {
        clearInterval(timerInt);
        stopPacemaker();

        const finalTimeStr = document.getElementById('timer').innerText;
        const finalCpm = parseInt(document.getElementById('current-cpm').innerText);
        
        // 사용자별 키 사용
        const key = getStorageKey();
        const savedBest = parseInt(localStorage.getItem(key) || 0);
        
        let msg = `🎉 연습 완료!\n\n최종 진행 시간: ${finalTimeStr}\n최종 평균 속도: ${finalCpm} 자`;

        if (finalCpm > savedBest) {
            localStorage.setItem(key, finalCpm);
            msg += `\n\n🏆 신기록 달성! 축하합니다!`;
        }

        alert(msg);
        location.reload();
    }

    // [9] 유틸리티 및 초기화
    document.getElementById('file-selector').addEventListener('change', (e) => {
        const reader = new FileReader();
        reader.onload = (ev) => { 
            sentences = ev.target.result.split(/\n/).filter(s => s.trim()); 
            curIdx = 0;
            fullReset(); 
        };
        reader.readAsText(e.target.files[0], 'utf-8');
    });

    document.getElementById('line-limit').addEventListener('change', () => {
        if(fileStartTime) {
            if(confirm("설정을 변경하면 진행 상황이 초기화됩니다. 계속하시겠습니까?")) {
                fullReset();
            }
        } else {
            fullReset();
        }
    });

    function fullReset() {
        forceClearPracticeInput(clean(inp.value || '')); 
        curIdx = 0;
        curLineIdx = 0; 
        
        fileStartTime = null;
        accumulatedPause = 0;
        speedDeductionTime = 0;
        completedCharsGlobal = 0;
        lineStartTime = null;
        
        isPaused = false;
        if (timerInt) clearInterval(timerInt);
        stopPacemaker();

        calculateTotalChars();

        document.getElementById('timer').innerText = '0초'; 
        document.getElementById('current-cpm').innerText = '0';
        progressBar.style.width = "0%";
        const progressLabel = document.getElementById('progress-percent-label');
        if (progressLabel) progressLabel.innerText = '0';
        
        pauseOverlay.style.display = 'none';
        inp.disabled = false;
        render(); 
        inp.focus();
    }
    
    function logout() { 
        if(confirm("로그아웃 하시겠습니까?")) window.SorizavaAuth.signOut(); 
    }
    
    // 공용 사이드바와 스파르타 전용 모바일 버튼 상태 동기화
    // responsive-sidebar.js가 실제 toggleSidebar를 담당하므로 여기서는 body 상태만 보정합니다.
    function syncSpartaSidebarState() {
        const sidebar = document.querySelector('.sidebar');
        document.body.classList.toggle('sidebar-open', !!(sidebar && sidebar.classList.contains('active')));
    }

    document.addEventListener('DOMContentLoaded', () => {
        const sidebar = document.querySelector('.sidebar');
        syncSpartaSidebarState();
        if (sidebar && window.MutationObserver) {
            new MutationObserver(syncSpartaSidebarState).observe(sidebar, { attributes: true, attributeFilter: ['class'] });
        }
    });

    calculateTotalChars();
    render();
