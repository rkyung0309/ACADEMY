console.log("[LOGIN-DEBUG-2] index.js loaded");
let currentUser = sessionStorage.getItem('shorthand_user');
let currentProfile = null;

async function initApp() {
    const d = new Date();
    document.getElementById('dateBadge').innerText = `${d.getMonth()+1}월 ${d.getDate()}일`;

    const session = await window.SorizavaAuth.getSession();
    if (!session) {
        document.getElementById('login-wrapper').style.display = 'flex';
        document.getElementById('app-wrapper').style.display = 'none';
        return;
    }

    const ctx = await window.SorizavaAuth.requireApproved({ redirect: false });
    if (!ctx) {
        document.getElementById('login-wrapper').style.display = 'flex';
        document.getElementById('app-wrapper').style.display = 'none';
        return;
    }
    if (!ctx.approved) {
        location.href = 'pending.html';
        return;
    }

    currentProfile = ctx.profile;
    currentUser = currentProfile.name || ctx.user.email;
    document.getElementById('login-wrapper').style.display = 'none';
    document.getElementById('app-wrapper').style.display = 'flex';
    document.getElementById('welcomeMsg').innerText = `반가워요, ${currentUser}님!`;
    document.getElementById('userNameSide').innerText = currentUser;
    document.getElementById('userAvatar').innerText = currentUser.charAt(0);

    if(currentProfile.role === 'admin') {
        document.getElementById('adminBtn').style.display = 'block';
    }

    fetchDashboardData();
    fetchNotice();
    fetchRanking();
}

async function fetchDashboardData() {
    try {
        const data = await window.SorizavaRecords.getDashboardSummary();
        animateValue("streakVal", 0, data.streak, 500, "일째");
        animateValue("accVal", 0, Math.round(data.avgAcc), 500, "%");
        animateValue("cpmVal", 0, data.maxCPM, 500, "자");
        const bars = document.querySelectorAll('.bar');
        const labels = document.querySelectorAll('.day-label');
        data.graphData.forEach((dayData, index) => {
            if (bars[index]) {
                const fill = bars[index].querySelector('.bar-fill');
                labels[index].innerText = dayData.label;
                const heightPercent = data.maxActivity > 0 ? (dayData.value / data.maxActivity) * 100 : 0;
                setTimeout(() => {
                    fill.style.height = `${heightPercent}%`;
                    fill.title = `${dayData.value}회 연습`;
                }, 150 + (index * 60));
            }
        });
    } catch (e) {
        console.error("대시보드 실패:", e);
    }
}

function animateValue(id, start, end, duration, suffix) {
    const obj = document.getElementById(id);
    const range = end - start;
    if (!obj) return;
    if (range === 0) { obj.innerHTML = end + suffix; return; }
    let current = start;
    const stepTime = Math.max(15, Math.min(50, Math.abs(Math.floor(duration / range))));
    const increment = end > start ? 1 : -1;
    const timer = setInterval(function() {
        current += increment;
        obj.innerHTML = current + suffix;
        if (current === end) clearInterval(timer);
    }, stepTime);
}

async function login() {
    const email = document.getElementById('nameInput').value.trim();
    const pw = document.getElementById('pwInput').value;
    if(!email || !pw) return alert("이메일과 비밀번호를 입력해주세요.");
    document.getElementById('loading-overlay').style.display = 'flex';
    try {
        const { profile } = await window.SorizavaAuth.signIn(email, pw);
        if (profile.status !== 'approved') {
            location.href = 'pending.html';
            return;
        }
        await initApp();
    } catch(e) {
        console.error("[LOGIN-DEBUG-2] 로그인 실패 원본 오류:", e);
        const detail = e?.message || e?.userMessage || e?.error_description || e?.details || e?.hint || String(e);
        alert("[LOGIN-DEBUG-2] 로그인 실패 상세:\n" + detail);
    } finally {
        document.getElementById('loading-overlay').style.display = 'none';
    }
}

function toggleSidebar() {
    document.querySelector('.sidebar').classList.toggle('active');
    document.querySelector('.sidebar-overlay').classList.toggle('active');
}

async function fetchNotice() {
    try {
        const { data, error } = await window.SORIZAVA_SUPABASE
            .from('notices')
            .select('*')
            .eq('is_active', true)
            .order('created_at', { ascending: false })
            .limit(1);
        if (error) throw error;
        const notice = data && data[0] ? data[0].content : '';
        if (notice && !localStorage.getItem('notice_closed_' + getTodayStr())) {
            document.getElementById('noticeText').innerText = notice;
            document.getElementById('notice-area').style.display = 'flex';
        }
    } catch(e) { console.warn(e); }
}

function closeNotice() {
    document.getElementById('notice-area').style.display = 'none';
    localStorage.setItem('notice_closed_' + getTodayStr(), 'true');
}

function getTodayStr() {
    const d = new Date();
    return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`;
}

function openAdmin() { location.href = 'admin.html'; }
function closeAdmin() { document.getElementById('adminModal').style.display = 'none'; }

async function saveNotice() {
    const txt = document.getElementById('adminNoticeInput').value.trim();
    if(!txt) return;
    try {
        await window.SORIZAVA_SUPABASE.from('notices').update({ is_active: false }).eq('is_active', true);
        const { error } = await window.SORIZAVA_SUPABASE.from('notices').insert({ content: txt, is_active: true, created_by: sessionStorage.getItem('shorthand_user_id') });
        if (error) throw error;
        alert("저장되었습니다.");
        document.getElementById('noticeText').innerText = txt;
        document.getElementById('notice-area').style.display = 'flex';
        localStorage.removeItem('notice_closed_' + getTodayStr());
        closeAdmin();
    } catch(e) { console.error(e); alert("저장 실패: 관리자 권한을 확인해주세요."); }
}

async function fetchRanking() {
    try {
        const today = window.SorizavaRecords.todayKstDateString();
        const { data, error } = await window.SORIZAVA_SUPABASE
            .from('practice_records')
            .select('practice_title, cpm, created_at, user_id')
            .eq('tool_type', 'king')
            .not('cpm', 'is', null)
            .gte('created_at', `${today}T00:00:00+09:00`)
            .order('cpm', { ascending: false })
            .limit(3);
        if (error) throw error;
        const list = document.getElementById('rankListMini');
        list.innerHTML = '';
        (data || []).forEach((r, idx) => {
            list.innerHTML += `<div class="rank-item"><span class="rank-num">${idx+1}</span><span class="rank-name">${r.practice_title || '타자왕'}</span><span class="rank-score">${r.cpm}타</span></div>`;
        });
        if(!data || data.length === 0) list.innerHTML = '<div style="padding:10px;">오늘 기록이 없습니다.</div>';
    } catch(e) {
        document.getElementById('rankListMini').innerHTML = '<div style="padding:10px; opacity:.8;">기록을 불러올 수 없습니다.</div>';
    }
}

function logout() {
    if(confirm("로그아웃 하시겠습니까?")) window.SorizavaAuth.signOut();
}

async function checkAuth() { return window.SorizavaAuth.requireApproved({ redirect: true }); }
