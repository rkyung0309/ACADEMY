// Study tools separated from mypage: study room, wrong-note vault, review alerts, teacher pre-check.
(function () {
  const LEVELS = [110, 120, 130, 140, 150, 160, 170, 190, 210, 230, 250];
  const INTERMEDIATE_LEVELS = [110, 120, 130, 140, 150, 160, 170];
  const INTERMEDIATE_MATERIALS_KEY = 'sorizava_intermediate_materials_v3';
  const INTERMEDIATE_PROGRESS_KEY = 'sorizava_intermediate_progress_logs_v1';
  const INTERMEDIATE_PASS_ACCURACY = 90;
  const ERROR_CAUSES = [
    '속도 따라가기 어려움',
    '발음 구분 어려움',
    '숫자/단위 약함',
    '집중력 저하',
    '띄어쓰기 불안정',
    '고유명사 약함'
  ];
  const NUMBER_DRILL_SETS = [
    ['2026년 4월 27일', '오후 2시 30분', '16만 원', '3개월', '97.5%', '제3조', '1,250명', 'D-24'],
    ['2027년 1월 8일', '오전 9시 10분', '23만 5천 원', '7개월', '84.2%', '제12항', '3,400건', '2분 15초'],
    ['2026년 12월 31일', '밤 9시', '1억 2천만 원', '11주', '99.1%', '제5장', '48개', '0.8초'],
    ['2028년 6월 15일', '오후 6시 45분', '7만 8천 원', '14일', '63.9%', '제22조', '520쪽', '3.5배'],
    ['2026년 5월 3일', '오전 11시', '9,900원', '4회차', '100%', '제1항', '18명', '15분']
  ];

  let state = {
    page: '',
    userKey: 'guest',
    profile: null,
    records: [],
    insight: {},
    summary: {},
    data: {},
    intermediate: { materials: [], logs: [], summary: null },
    segment: { audio: null, objectUrl: '', start: 0, end: 10, loops: 3, currentLoop: 0, playing: false },
    wrongDetailCache: {},
    wrongDrill: { queue: [], current: null, total: 0, correct: 0, wrong: 0, started: false, finished: false, answerVisible: false, mode: 'visual' }
  };

  function $(id) { return document.getElementById(id); }
  function esc(value) {
    return String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  }
  function toNumber(value, fallback = 0) {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
  }
  function toNullableNumber(value) {
    const n = Number(value);
    return Number.isFinite(n) ? n : null;
  }
  function round1(value) {
    const n = Number(value);
    return Number.isFinite(n) ? Math.round(n * 10) / 10 : 0;
  }
  function todayKey() {
    const now = new Date();
    const kst = new Date(now.getTime() + 9 * 60 * 60 * 1000);
    return kst.toISOString().slice(0, 10);
  }
  function kstDate(value) {
    if (!value) return '';
    try { return new Date(value).toLocaleDateString('sv-SE', { timeZone: 'Asia/Seoul' }); }
    catch (e) { return ''; }
  }
  function fmtDate(value) {
    if (!value) return '-';
    try { return new Date(value).toLocaleDateString('ko-KR', { timeZone: 'Asia/Seoul', month: '2-digit', day: '2-digit' }); }
    catch (e) { return '-'; }
  }
  function dayDiff(fromDateKey) {
    if (!fromDateKey) return 0;
    const from = new Date(`${fromDateKey}T00:00:00+09:00`).getTime();
    const to = new Date(`${todayKey()}T00:00:00+09:00`).getTime();
    return Math.max(0, Math.floor((to - from) / 86400000));
  }
  function score(record) {
    const acc = toNullableNumber(record?.accuracy);
    if (acc !== null) return acc;
    const sc = toNullableNumber(record?.score);
    return sc !== null ? sc : null;
  }
  function errors(record) {
    return {
      wrong: toNumber(record?.wrong_count),
      missing: toNumber(record?.missing_count),
      added: toNumber(record?.added_count),
      spacing: toNumber(record?.spacing_error_count)
    };
  }
  function totalErrors(record) {
    const e = errors(record);
    return e.wrong + e.missing + e.added + e.spacing;
  }
  function avg(values) {
    const nums = values.map(Number).filter(Number.isFinite);
    return nums.length ? nums.reduce((sum, v) => sum + v, 0) / nums.length : 0;
  }
  function normalizeTitle(record) {
    const tool = record?.tool_type || 'unknown';
    const title = String(record?.practice_title || '제목 없음').replace(/\s+/g, ' ').trim();
    return `${tool}__${title}`;
  }
  function cleanTitle(key) { return String(key || '').replace(/^[^_]+__/, '') || '제목 없음'; }
  function toolLabel(toolType) {
    if (window.SorizavaRecords?.getToolLabel) return window.SorizavaRecords.getToolLabel(toolType);
    return { editorial: '사설연습', toksori2: '똑소리2', king: '타자왕', exam: '입문반 졸업시험', exam_simulation: '실전 시험 모드', random: '약어랜덤', random_dictionary: '약어장 보고치기', random_voice_dictionary: '약어장 듣고치기', random_abbr_wrong_visual: '약어 오답 보고치기', random_abbr_wrong_voice: '약어 오답 듣고치기', measure: '자수측정', sparta: '스파르타', intermediate: '중급반 공부방', unknown: '기타' }[toolType] || toolType || '기타';
  }
  function getLevel(record) {
    const title = String(record?.practice_title || '');
    const matched = title.match(/(110|120|130|140|150|160|170|190|210|230|250)\s*자/);
    if (matched) return Number(matched[1]);
    const cpm = toNullableNumber(record?.cpm);
    if (cpm === null || cpm < 90 || cpm > 280) return null;
    return LEVELS.reduce((best, level) => Math.abs(level - cpm) < Math.abs(best - cpm) ? level : best, LEVELS[0]);
  }
  function nextLevel(level) {
    const idx = LEVELS.indexOf(Number(level));
    return idx >= 0 && idx < LEVELS.length - 1 ? LEVELS[idx + 1] : null;
  }
  function prevLevel(level) {
    const idx = LEVELS.indexOf(Number(level));
    return idx > 0 ? LEVELS[idx - 1] : null;
  }
  function storageKey(suffix) { return `sorizava_study_tools_${state.userKey}_${suffix}`; }
  function readJson(key, fallback) {
    try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : fallback; }
    catch (e) { return fallback; }
  }
  function writeJson(key, value) { localStorage.setItem(key, JSON.stringify(value)); }
  function setting() { return { goalGrade: '3급', goalLevel: '230', examDate: '', ...readJson(storageKey('settings'), {}) }; }
  function saveSetting(next) { writeJson(storageKey('settings'), next); }
  function assignments() { return readJson(storageKey('assignments'), []); }
  function saveAssignments(list) { writeJson(storageKey('assignments'), list.slice(0, 200)); }
  function reviews() { return readJson(storageKey('reviews'), {}); }
  function saveReviews(map) { writeJson(storageKey('reviews'), map); }
  function causes() { return readJson(storageKey('causes'), []); }
  function saveCauses(list) { writeJson(storageKey('causes'), list.slice(-300)); }
  function drills() { return readJson(storageKey('number_drills'), []); }
  function saveDrills(list) { writeJson(storageKey('number_drills'), list.slice(-100)); }

  function wrongNoteMasteryKey() { return storageKey('wrong_note_mastery_v2'); }
  function wrongNotePracticeKey() { return storageKey('wrong_note_practice_v2'); }
  function readWrongNoteMastery() { return readJson(wrongNoteMasteryKey(), {}); }
  function saveWrongNoteMastery(map) { writeJson(wrongNoteMasteryKey(), map || {}); }
  function readWrongNotePractice() { return readJson(wrongNotePracticeKey(), {}); }
  function saveWrongNotePractice(map) { writeJson(wrongNotePracticeKey(), map || {}); }
  function wrongTypeLabel(type) { return { wrong: '오자', missing: '탈자', added: '첨자' }[type] || '오류'; }
  function stripScoreIgnored(value) { return String(value || '').replace(/[^0-9a-zA-Zㄱ-ㅎㅏ-ㅣ가-힣]/g, '').replace(/\s+/g, ''); }
  function normalizeWrongAnswer(value) {
    return String(value || '')
      .replace(/\s+/g, '')
      .replace(/[.,/#!$%^&*;:{}=\-_`~()\[\]"'“”‘’·]/g, '')
      .toLowerCase();
  }
  function compactText(value, max = 80) {
    const text = String(value || '').replace(/\s+/g, ' ').trim();
    if (text.length <= max) return text;
    return `${text.slice(0, Math.max(10, max - 1))}…`;
  }
  function getRecordSourceText(record) {
    return String(record?.source_text_snapshot || record?.source_text || record?.original_text || '').trim();
  }
  function getRecordTypedText(record) {
    return String(record?.typed_text_snapshot || record?.typed_text || record?.student_text || '').trim();
  }
  function makeWrongNoteId(record, block, index) {
    const base = String(record?.id || `${record?.created_at || ''}_${record?.practice_title || ''}`);
    const raw = `${base}_${block.type}_${block.sourceIndex ?? index}_${block.expected}_${block.actual}_${block.answerText || ''}`;
    let hash = 0;
    for (let i = 0; i < raw.length; i++) hash = ((hash << 5) - hash + raw.charCodeAt(i)) | 0;
    return `wn_${Math.abs(hash)}_${index}`;
  }
  function answerTextFromContext(expected, context) {
    const answer = String(expected || '').trim();
    const ctx = String(context || '').trim();
    if (!answer || !ctx) return answer;
    const idx = ctx.indexOf(answer);
    if (idx < 0) return answer;
    const sliced = sliceWrongContextByEojeol(ctx, idx, idx + answer.length, 0);
    return compactText(sliced.targetWord || answer, 80);
  }
  function sliceWrongContext(source, start, end, side = 10) {
    const safeStart = Math.max(0, Number(start) || 0);
    const safeEnd = Math.max(safeStart, Number(end) || safeStart);
    const left = Math.max(0, safeStart - side);
    const right = Math.min(source.length, safeEnd + side);
    const before = source.slice(left, safeStart);
    const target = source.slice(safeStart, safeEnd);
    const after = source.slice(safeEnd, right);
    const context = `${left > 0 ? '…' : ''}${before}${target}${after}${right < source.length ? '…' : ''}`;
    return { before, target, after, context };
  }

  function sliceWrongContextByEojeol(source, start, end, sideWords = 1) {
    const text = String(source || '');
    const safeStart = Math.max(0, Math.min(text.length, Number(start) || 0));
    const safeEnd = Math.max(safeStart, Math.min(text.length, Number(end) || safeStart));
    const tokens = [];
    const re = /\S+/g;
    let match;
    while ((match = re.exec(text))) {
      tokens.push({ start: match.index, end: match.index + match[0].length, text: match[0] });
    }
    if (!tokens.length) return sliceWrongContext(text, safeStart, safeEnd, 10);

    let firstIdx = tokens.findIndex(token => token.end > safeStart && token.start < Math.max(safeEnd, safeStart + 1));
    if (firstIdx < 0) {
      firstIdx = tokens.findIndex(token => token.start >= safeStart);
      if (firstIdx < 0) firstIdx = tokens.length - 1;
    }
    let lastIdx = firstIdx;
    for (let idx = firstIdx; idx < tokens.length; idx += 1) {
      if (tokens[idx].start >= Math.max(safeEnd, safeStart + 1)) break;
      if (tokens[idx].end > safeStart) lastIdx = idx;
    }

    const contextStartIdx = Math.max(0, firstIdx - sideWords);
    const contextEndIdx = Math.min(tokens.length - 1, lastIdx + sideWords);
    const left = tokens[contextStartIdx].start;
    const right = tokens[contextEndIdx].end;
    const before = text.slice(left, safeStart);
    const target = text.slice(safeStart, safeEnd);
    const after = text.slice(safeEnd, right);
    const targetWord = text.slice(tokens[firstIdx].start, tokens[lastIdx].end).trim();
    const context = `${contextStartIdx > 0 ? '…' : ''}${text.slice(left, right).trim()}${contextEndIdx < tokens.length - 1 ? '…' : ''}`;
    return { before, target, after, targetWord, context };
  }
  function computeWrongBlocksFromSnapshots(record, maxItems = 20) {
    let source = getRecordSourceText(record);
    let typed = getRecordTypedText(record);
    if (!source || !typed) return [];
    source = source.slice(0, 4500);
    typed = typed.slice(0, 4500);
    const maxCells = 3200000;
    if (source.length * typed.length > maxCells) {
      const limit = Math.max(900, Math.floor(Math.sqrt(maxCells)));
      source = source.slice(0, limit);
      typed = typed.slice(0, limit);
    }
    const oArr = source.split('');
    const sArr = typed.split('');
    const n = oArr.length;
    const m = sArr.length;
    if (!n || !m) return [];
    const dp = Array.from({ length: n + 1 }, () => Array(m + 1).fill(0));
    for (let i = 1; i <= n; i++) {
      for (let j = 1; j <= m; j++) {
        dp[i][j] = oArr[i - 1] === sArr[j - 1] ? dp[i - 1][j - 1] + 1 : Math.max(dp[i - 1][j], dp[i][j - 1]);
      }
    }
    let i = n;
    let j = m;
    const diffs = [];
    while (i > 0 || j > 0) {
      if (i > 0 && j > 0 && oArr[i - 1] === sArr[j - 1]) {
        diffs.push({ t: 'same', c: oArr[i - 1], sourceIndex: i - 1, typedIndex: j - 1 });
        i--; j--;
      } else if (j > 0 && (i === 0 || dp[i][j - 1] >= dp[i - 1][j])) {
        diffs.push({ t: 'added', c: sArr[j - 1], sourceIndex: i, typedIndex: j - 1 });
        j--;
      } else {
        diffs.push({ t: 'missing', c: oArr[i - 1], sourceIndex: i - 1, typedIndex: j });
        i--;
      }
    }
    diffs.reverse();

    const blocks = [];
    let expected = '';
    let actual = '';
    let startSource = null;
    let endSource = null;
    let startTyped = null;
    const flush = () => {
      const expectedCore = stripScoreIgnored(expected);
      const actualCore = stripScoreIgnored(actual);
      if (!expectedCore && !actualCore) {
        expected = ''; actual = ''; startSource = null; endSource = null; startTyped = null;
        return;
      }
      const type = expectedCore && actualCore ? 'wrong' : expectedCore ? 'missing' : 'added';
      if (type === 'missing') {
        expected = ''; actual = ''; startSource = null; endSource = null; startTyped = null;
        return;
      }
      const anchorStart = startSource === null ? Math.max(0, endSource || 0) : startSource;
      const anchorEnd = expected ? Math.max(anchorStart + expected.length, endSource || anchorStart) : anchorStart + 1;
      const ctx = sliceWrongContextByEojeol(source, anchorStart, anchorEnd, 1);
      const addedFallback = compactText(ctx.context.replace(/^…|…$/g, ''), 50);
      const answerText = compactText(expectedCore ? (ctx.targetWord || expected) : addedFallback, 50);
      if (!normalizeWrongAnswer(answerText)) {
        expected = ''; actual = ''; startSource = null; endSource = null; startTyped = null;
        return;
      }
      blocks.push({
        type,
        expected: compactText(expected, 50),
        actual: compactText(actual, 50),
        expectedCore,
        actualCore,
        answerText,
        sourceIndex: anchorStart,
        typedIndex: startTyped ?? null,
        context: compactText(ctx.context, 90)
      });
      expected = ''; actual = ''; startSource = null; endSource = null; startTyped = null;
    };

    for (const item of diffs) {
      if (item.t === 'same') {
        flush();
        continue;
      }
      if (startSource === null) startSource = item.sourceIndex;
      if (startTyped === null) startTyped = item.typedIndex;
      if (item.t === 'missing') {
        expected += item.c;
        endSource = Math.max(endSource ?? item.sourceIndex, item.sourceIndex + 1);
      } else if (item.t === 'added') {
        actual += item.c;
        endSource = Math.max(endSource ?? item.sourceIndex, item.sourceIndex);
      }
      if ((expected + actual).length >= 16) flush();
      if (blocks.length >= maxItems) break;
    }
    flush();
    return blocks.slice(0, maxItems);
  }
  function parseWrongBlocksFromSummary(record, maxItems = 10) {
    const text = String(record?.diff_summary || '');
    if (!text.trim()) return [];
    const parts = text.split('/').map(part => part.trim()).filter(Boolean);
    const blocks = [];
    parts.forEach((part, idx) => {
      const wrong = part.match(/오자\s*:\s*([^→]+)→([^\(]+)(?:\(([^)]*)\))?/);
      const missing = part.match(/탈자\s*:\s*([^\(]+)(?:\(([^)]*)\))?/);
      const added = part.match(/첨자\s*:\s*([^\(]+)(?:\(([^)]*)\))?/);
      if (wrong) {
        const ctx = wrong[3] || '';
        blocks.push({ type: 'wrong', expected: wrong[1].trim(), actual: wrong[2].trim(), context: ctx, sourceIndex: idx, answerText: answerTextFromContext(wrong[1].trim(), ctx) });
      }
      else if (missing) {
        return;
      }
      else if (added) blocks.push({ type: 'added', expected: '', actual: added[1].trim(), context: added[2] || '', sourceIndex: idx, answerText: (added[2] || '').trim() });
    });
    return blocks.filter(item => item.type !== 'missing' && normalizeWrongAnswer(item.answerText || item.expected || item.context)).slice(0, maxItems);
  }
  function detailedWrongItems(records = state.records) {
    const mastery = readWrongNoteMastery();
    const practice = readWrongNotePractice();
    const items = [];
    const candidates = (records || [])
      .filter(record => totalErrors(record) > 0)
      .sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0))
      .slice(0, 25);
    candidates.forEach(record => {
      const cacheKey = `${record?.id || record?.created_at || record?.practice_title || ''}_${record?.wrong_count || 0}_${record?.missing_count || 0}_${record?.added_count || 0}_${String(record?.source_text_snapshot || '').length}_${String(record?.typed_text_snapshot || '').length}`;
      let cached = state.wrongDetailCache[cacheKey];
      if (!cached) {
        const blocks = computeWrongBlocksFromSnapshots(record, 12);
        const fallback = blocks.length ? [] : parseWrongBlocksFromSummary(record, 8);
        cached = [...blocks, ...fallback];
        state.wrongDetailCache[cacheKey] = cached;
      }
      cached.filter(block => block?.type !== 'missing').forEach((block, idx) => {
        const id = makeWrongNoteId(record, block, idx);
        const saved = practice[id] || {};
        items.push({
          ...block,
          id,
          recordId: record.id || '',
          title: record.practice_title || toolLabel(record.tool_type),
          toolType: record.tool_type || 'unknown',
          toolLabel: toolLabel(record.tool_type),
          date: record.created_at || '',
          score: score(record),
          mastered: Boolean(mastery[id]?.mastered),
          masteredAt: mastery[id]?.masteredAt || '',
          attempts: Number(saved.attempts || 0),
          correct: Number(saved.correct || 0),
          lastAnswer: saved.lastAnswer || ''
        });
      });
    });
    const dedup = new Map();
    items.forEach(item => {
      const key = `${item.type}_${normalizeWrongAnswer(item.answerText || item.expected || item.context)}_${item.title}`;
      if (!dedup.has(key)) dedup.set(key, item);
    });
    return Array.from(dedup.values()).sort((a, b) => Number(a.mastered) - Number(b.mastered) || new Date(b.date || 0) - new Date(a.date || 0)).slice(0, 120);
  }
  function detailedWrongSummary() {
    const all = detailedWrongItems();
    const active = all.filter(item => !item.mastered);
    const mastered = all.filter(item => item.mastered);
    const byType = active.reduce((acc, item) => {
      acc[item.type] = (acc[item.type] || 0) + 1;
      return acc;
    }, { wrong: 0, added: 0 });
    return { all, active, mastered, byType, total: active.length, masteredCount: mastered.length };
  }
  function shuffleWrongItems(list) {
    return [...(list || [])].sort(() => Math.random() - 0.5);
  }

  function parseIntermediatePayload(content) {
    let payload = content;
    if (typeof payload === 'string') {
      try { payload = JSON.parse(payload); }
      catch (error) { payload = { sourceText: payload }; }
    }
    return payload && typeof payload === 'object' ? payload : {};
  }
  function normalizeIntermediateMaterial(row, index = 0, source = 'supabase') {
    const payload = parseIntermediatePayload(row.content);
    const level = Number(payload.level || row.level || extractIntermediateLevel(row.title) || 110);
    const title = payload.title || row.display_title || row.title || `${level}자 자료 ${index + 1}`;
    return {
      id: String(row.id || payload.id || `${source}_${level}_${index}`),
      rowId: row.id || null,
      source,
      level,
      title: String(title).replace(/^\d+자\s*/, ''),
      sourceText: payload.sourceText || payload.text || '',
      audioName: payload.audioName || '',
      createdAt: row.created_at || payload.createdAt || ''
    };
  }
  function extractIntermediateLevel(value) {
    const match = String(value || '').match(/(110|120|130|140|150|160|170)\s*자?/);
    return match ? Number(match[1]) : null;
  }
  function intermediateMaterialKey(item) {
    return item ? String(item.rowId || item.id || item.title || '') : '';
  }
  function readLocalIntermediateMaterials() {
    const rows = readJson(INTERMEDIATE_MATERIALS_KEY, []);
    return rows.map((row, idx) => normalizeIntermediateMaterial(row, idx, 'local'));
  }
  async function loadIntermediateMaterials() {
    try {
      const client = window.SORIZAVA_SUPABASE;
      if (!client) throw new Error('Supabase client missing');
      const { data, error } = await client
        .from('practice_materials')
        .select('*')
        .eq('tool_type', 'intermediate')
        .eq('is_active', true)
        .order('created_at', { ascending: true });
      if (error) throw error;
      const rows = (data || []).map((row, idx) => normalizeIntermediateMaterial(row, idx, 'supabase'));
      if (rows.length) return rows.sort((a, b) => a.level - b.level || a.title.localeCompare(b.title, 'ko'));
    } catch (error) {
      console.warn('중급반 자료 조회 실패, 로컬 자료로 대체:', error);
    }
    return readLocalIntermediateMaterials().sort((a, b) => a.level - b.level || a.title.localeCompare(b.title, 'ko'));
  }
  function parseIntermediateMemo(record) {
    const memo = record && record.memo;
    if (!memo || typeof memo !== 'string') return null;
    try {
      const parsed = JSON.parse(memo);
      return parsed && parsed.kind === 'intermediate_progress' ? parsed : null;
    } catch (error) {
      return null;
    }
  }
  function normalizeIntermediateLog(row) {
    if (!row) return null;
    const meta = (row.kind === 'intermediate_progress' || row.materialKey) ? row : parseIntermediateMemo(row);
    if (meta) {
      return {
        id: meta.id || String(row.id || ''),
        level: Number(meta.level),
        materialId: meta.materialId || '',
        materialKey: meta.materialKey || '',
        materialTitle: meta.materialTitle || row.practice_title || '',
        mode: meta.mode || 'view',
        paragraph: meta.paragraph || '전체 원문',
        abbrEnabled: Boolean(meta.abbrEnabled),
        accuracy: Number(row.accuracy ?? row.score ?? meta.accuracy ?? 0),
        cpm: Number(row.cpm || meta.cpm || 0),
        elapsed: Number(row.elapsed_seconds || meta.elapsed || 0),
        wrong: Number(row.wrong_count || meta.wrong || 0),
        missing: Number(row.missing_count || meta.missing || 0),
        added: Number(row.added_count || meta.added || 0),
        resultLabel: meta.resultLabel || '',
        createdAt: row.created_at || meta.createdAt || new Date().toISOString()
      };
    }
    if (row.tool_type !== 'intermediate') return null;
    const level = extractIntermediateLevel(row.practice_title);
    if (!level) return null;
    return {
      id: String(row.id || ''),
      level,
      materialId: '',
      materialKey: '',
      materialTitle: String(row.practice_title || '').replace(/^.*?\d+자\s*/, '').replace(/\s+(보고 치기|듣고 치기).*$/, '') || '자료',
      mode: String(row.practice_title || '').includes('듣고') ? 'listen' : 'view',
      paragraph: '전체 원문',
      abbrEnabled: false,
      accuracy: Number(row.accuracy ?? row.score ?? 0),
      cpm: Number(row.cpm || 0),
      elapsed: Number(row.elapsed_seconds || 0),
      wrong: Number(row.wrong_count || 0),
      missing: Number(row.missing_count || 0),
      added: Number(row.added_count || 0),
      resultLabel: '',
      createdAt: row.created_at || new Date().toISOString()
    };
  }
  function readIntermediateLogs() {
    const local = readJson(INTERMEDIATE_PROGRESS_KEY, []).map(normalizeIntermediateLog).filter(Boolean);
    const remote = (state.records || []).map(normalizeIntermediateLog).filter(Boolean);
    const map = new Map();
    [...local, ...remote].forEach(row => {
      const key = [row.createdAt, row.level, row.materialKey || row.materialTitle, row.mode, row.accuracy].join('|');
      map.set(key, row);
    });
    return Array.from(map.values()).sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
  }
  function buildIntermediateSummary() {
    const materials = state.intermediate.materials || [];
    const logs = state.intermediate.logs || [];
    const byLevel = INTERMEDIATE_LEVELS.map(level => {
      const levelMaterials = materials.filter(item => Number(item.level) === Number(level));
      const fileRows = levelMaterials.map((item, idx) => {
        const key = intermediateMaterialKey(item);
        const related = logs.filter(log => Number(log.level) === level && (log.materialKey ? log.materialKey === key : log.materialTitle.includes(item.title)));
        const listenBest = related.filter(log => log.mode === 'listen').sort((a, b) => Number(b.accuracy || 0) - Number(a.accuracy || 0))[0] || null;
        const viewBest = related.filter(log => log.mode !== 'listen').sort((a, b) => Number(b.accuracy || 0) - Number(a.accuracy || 0))[0] || null;
        const latest = related.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0))[0] || null;
        return {
          index: idx + 1,
          material: item,
          title: item.title,
          passed: Boolean(listenBest && Number(listenBest.accuracy) >= INTERMEDIATE_PASS_ACCURACY),
          listenBest,
          viewBest,
          latest,
          url: `intermediate.html?level=${level}&material=${encodeURIComponent(item.id)}&mode=${listenBest ? 'listen' : 'listen'}`
        };
      });
      const passedCount = fileRows.filter(row => row.passed).length;
      return {
        level,
        total: levelMaterials.length,
        passedCount,
        passed: levelMaterials.length > 0 && passedCount === levelMaterials.length,
        files: fileRows
      };
    });
    let unlockedLevel = INTERMEDIATE_LEVELS[0];
    for (const row of byLevel) {
      if (row.level === INTERMEDIATE_LEVELS[0]) {
        unlockedLevel = row.level;
        if (!row.passed) break;
      } else {
        const prevIndex = INTERMEDIATE_LEVELS.indexOf(row.level) - 1;
        const prev = byLevel[prevIndex];
        if (prev && prev.passed) unlockedLevel = row.level;
        else break;
      }
    }
    const current = byLevel.find(row => row.level === unlockedLevel) || byLevel[0];
    const recent = logs.slice(0, 8);
    const weeklyLogs = logs.filter(log => {
      const d = new Date(log.createdAt).getTime();
      const start = new Date(`${todayKey()}T00:00:00+09:00`).getTime() - 6 * 86400000;
      return Number.isFinite(d) && d >= start;
    });
    const recentScores = logs.slice(0, 10).map(log => Number(log.accuracy)).filter(Number.isFinite);
    return {
      materials,
      logs,
      byLevel,
      unlockedLevel,
      current,
      recent,
      weeklyCount: weeklyLogs.length,
      recentAvg: round1(avg(recentScores)),
      last: logs[0] || null
    };
  }

  function groupByFile(records) {
    const groups = new Map();
    records.forEach(record => {
      if (score(record) === null) return;
      const key = normalizeTitle(record);
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(record);
    });
    groups.forEach(list => list.sort((a, b) => new Date(a.created_at) - new Date(b.created_at)));
    return groups;
  }
  function currentLevel(records) {
    const recent = records
      .map(record => ({ record, level: getLevel(record), score: score(record) }))
      .filter(item => item.level && item.score !== null)
      .sort((a, b) => new Date(b.record.created_at) - new Date(a.record.created_at))[0];
    return recent?.level || null;
  }
  function dominantError() {
    const item = state.insight?.dominantError;
    return item?.count > 0 ? item : { key: '', label: '누적 오류 없음', count: 0 };
  }
  function weakFiles(records) {
    const rows = [];
    groupByFile(records).forEach((list, key) => {
      const scores = list.map(score).filter(v => v !== null);
      const scoreAvg = round1(avg(scores));
      const errAvg = round1(avg(list.map(totalErrors)));
      const last = list[list.length - 1];
      const lastScore = score(last);
      const isWeak = scoreAvg < 95 || errAvg >= 5 || (lastScore !== null && lastScore < 94);
      if (!isWeak) return;
      rows.push({
        key,
        title: cleanTitle(key),
        tool: last.tool_type || 'unknown',
        toolLabel: toolLabel(last.tool_type),
        count: list.length,
        avgScore: scoreAvg,
        avgErrors: errAvg,
        lastScore: round1(lastScore),
        lastDate: last.created_at,
        lastDateKey: kstDate(last.created_at),
        reason: scoreAvg < 95 ? '정확도 낮음' : errAvg >= 5 ? '오류 많음' : '최근 기록 불안정'
      });
    });
    return rows.sort((a, b) => a.avgScore - b.avgScore || b.avgErrors - a.avgErrors).slice(0, 12);
  }
  function retryRows(records) {
    const rows = [];
    groupByFile(records).forEach((list, key) => {
      if (list.length < 2) return;
      const first = list[0];
      const last = list[list.length - 1];
      rows.push({
        key,
        title: cleanTitle(key),
        toolLabel: toolLabel(last.tool_type),
        attempts: list.length,
        firstScore: round1(score(first)),
        lastScore: round1(score(last)),
        delta: round1(score(last) - score(first)),
        lastDate: last.created_at,
        lastErrors: totalErrors(last)
      });
    });
    return rows.sort((a, b) => new Date(b.lastDate) - new Date(a.lastDate)).slice(0, 12);
  }
  function reviewAlerts(files) {
    const reviewMap = reviews();
    return files.map(file => {
      const passed = dayDiff(file.lastDateKey);
      const nextGap = file.avgScore < 92 ? 1 : file.avgScore < 95 ? 3 : 7;
      const reviewedDate = reviewMap[file.key] || '';
      const reviewedToday = reviewedDate === todayKey();
      const due = !reviewedToday && passed >= nextGap;
      return { ...file, passed, nextGap, reviewedToday, due };
    }).filter(item => item.due || !item.reviewedToday).sort((a, b) => Number(b.due) - Number(a.due) || a.avgScore - b.avgScore).slice(0, 10);
  }
  function trainingSet(files) {
    const level = currentLevel(state.records) || 170;
    const d = dominantError();
    const items = [];
    if (files[0]) {
      items.push({ title: '취약 파일 재응시', text: `${files[0].title} 1회 재응시`, detail: `${files[0].reason} · 평균 ${files[0].avgScore}%` });
      items.push({ title: '취약 파일 반복', text: `${files[0].title} 같은 파일 1회 추가 반복`, detail: '재응시 비교 화면에서 개선폭을 확인합니다.' });
    } else {
      items.push({ title: '현재 속도 안정화', text: `${level}자 파일 1개 정확도 98% 목표`, detail: '취약 파일이 없으면 현재 속도에서 오류 수를 줄입니다.' });
    }
    if (d.key === 'missing') items.push({ title: '탈자 교정', text: '같은 속도 파일 1개를 낮은 긴장도로 재입력', detail: '누락 수가 줄어드는지 확인합니다.' });
    else if (d.key === 'wrong') items.push({ title: '오자 교정', text: '헷갈린 단어 5개 메모 후 재입력', detail: '발음 유사 단어와 고유명사를 우선 확인합니다.' });
    else if (d.key === 'added') items.push({ title: '첨자 교정', text: '추측 입력 금지 훈련 1회', detail: '들은 내용만 입력하고 불필요한 조사 추가를 줄입니다.' });
    else if (d.key === 'spacing') items.push({ title: '띄어쓰기 교정', text: '이중 공백과 문장부호 뒤 공백 점검', detail: '제출 전 공백 오류를 확인합니다.' });
    else items.push({ title: '오답 원인 기록', text: '연습 후 오답 원인 1개 선택', detail: '원인 로그가 쌓이면 추천이 더 정확해집니다.' });
    items.push({ title: '숫자·단위 훈련', text: '숫자·날짜·금액 표현 8개 받아쓰기', detail: '숫자 오류가 없더라도 매일 짧게 유지합니다.' });
    return items.slice(0, 5);
  }
  function weekVolume(records) {
    const recent = records.filter(record => {
      const t = new Date(record.created_at).getTime();
      return Number.isFinite(t) && Date.now() - t <= 7 * 86400000;
    });
    const days = new Set(recent.map(r => kstDate(r.created_at)).filter(Boolean));
    return { days: days.size, files: recent.length, avg: round1(avg(recent.map(score).filter(v => v !== null))) };
  }
  function speedLadder() {
    const level = currentLevel(state.records);
    const recentLevelRecords = state.records
      .filter(r => getLevel(r) === level && score(r) !== null)
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
      .slice(0, 3);
    const recentAvg = round1(avg(recentLevelRecords.map(score).filter(v => v !== null)));
    const errAvg = round1(avg(recentLevelRecords.map(totalErrors)));
    const prev = prevLevel(level);
    const next = nextLevel(level);
    let decision = '기록 누적 필요';
    let action = '현재 속도 기록을 3회 이상 남겨 주세요.';
    if (recentLevelRecords.length >= 3 && recentAvg >= 98 && errAvg <= 3 && next) {
      decision = '상위 속도 1회 응시 가능';
      action = `${next}자 파일을 1회만 테스트하고, 96% 미만이면 바로 현재 속도로 복귀하세요.`;
    } else if (recentLevelRecords.length >= 3 && (recentAvg < 95 || errAvg >= 7) && prev) {
      decision = '하위 속도 안정화 권장';
      action = `${prev}자 파일 1회로 오류 수를 줄인 뒤 현재 속도에 재응시하세요.`;
    } else if (recentLevelRecords.length >= 3) {
      decision = '현재 속도 유지';
      action = `${level}자에서 정확도 98%와 오류 3개 이하를 먼저 맞추세요.`;
    }
    return { level, prev, next, recentAvg, errAvg, decision, action, count: recentLevelRecords.length };
  }
  function causeSummary() {
    const since = new Date(Date.now() - 14 * 86400000).toISOString().slice(0, 10);
    const counts = {};
    causes().filter(item => item.date >= since).forEach(item => { counts[item.cause] = (counts[item.cause] || 0) + 1; });
    return Object.entries(counts).map(([cause, count]) => ({ cause, count })).sort((a, b) => b.count - a.count).slice(0, 6);
  }
  function assignmentSummary() {
    const list = assignments();
    const active = list.filter(item => item.date === todayKey() || !item.submitted);
    const done = active.filter(item => item.submitted).length;
    return { list: active.slice(0, 12), done, total: active.length };
  }
  function buildData() {
    const weak = weakFiles(state.records);
    const retry = retryRows(state.records);
    const alerts = reviewAlerts(weak);
    const training = trainingSet(weak);
    const volume = weekVolume(state.records);
    const ladder = speedLadder();
    const cause = causeSummary();
    const assign = assignmentSummary();
    const abbrWrong = abbrWrongSummary();
    const detailedWrong = detailedWrongSummary();
    const graduation = fileGraduationRows(state.records);
    state.data = { weak, retry, alerts, training, volume, ladder, cause, assign, abbrWrong, detailedWrong, graduation, setting: setting() };
    return state.data;
  }

  function renderMiniNav(activePage) {
    return `<div class="study-tabbar">
      <a href="intermediate.html" class="">중급반 공부방</a>
      <a href="wrong-note.html" class="${activePage === 'wrong-note' ? 'active' : ''}">오답노트</a>
      <a href="teacher-check.html" class="${activePage === 'teacher-check' ? 'active' : ''}">수업 전 점검</a>
    </div>`;
  }
  function renderStatCards(data) {
    const studyTimeText = window.SorizavaStudyTimer?.getStats?.().todayText || '0분';
    return `<div class="study-stat-grid">
      <div class="study-stat"><span>이번 주 연습일</span><b>${data.volume.days}일</b></div>
      <div class="study-stat"><span>이번 주 파일</span><b>${data.volume.files}개</b></div>
      <div class="study-stat"><span>최근 평균</span><b>${data.volume.avg || 0}%</b></div>
      <div class="study-stat study-time-room-stat"><span>오늘 공부시간</span><b data-study-time="today-text">${studyTimeText}</b></div>
      <div class="study-stat"><span>복습 예정</span><b>${data.alerts.filter(x => x.due).length}개</b></div>
    </div>`;
  }
  function renderTrainingList(items) {
    return `<div class="training-list">${items.map((item, idx) => `<div class="training-item"><span>${idx + 1}</span><div><b>${esc(item.text)}</b><em>${esc(item.detail)}</em></div><button type="button" onclick="window.SorizavaStudyTools.addAssignmentFromTraining(${idx})">과제 추가</button></div>`).join('')}</div>`;
  }
  function renderAssignments(assign) {
    if (!assign.list.length) return '<div class="empty-box">등록된 과제가 없습니다. 오늘의 훈련 세트에서 과제를 추가하거나 직접 입력하세요.</div>';
    return `<div class="assignment-list">${assign.list.map(item => `<div class="assignment-row ${item.submitted ? 'done' : ''}">
      <div><b>${esc(item.title)}</b><span>${esc(item.date)} · ${item.submitted ? '제출완료' : '진행중'}</span></div>
      <button type="button" onclick="window.SorizavaStudyTools.toggleAssignment('${esc(item.id)}')">${item.submitted ? '완료취소' : '제출완료'}</button>
    </div>`).join('')}</div>`;
  }
  function renderRetry(rows) {
    if (!rows.length) return '<div class="empty-box">같은 파일을 2회 이상 기록하면 재응시 비교가 표시됩니다.</div>';
    return `<div class="retry-list">${rows.map(row => `<div class="retry-item"><div><b>${esc(row.title)}</b><span>${esc(row.toolLabel)} · ${row.attempts}회 · 최근 ${fmtDate(row.lastDate)}</span></div><strong class="${row.delta >= 0 ? 'good' : 'bad'}">${row.delta >= 0 ? '+' : ''}${row.delta}%p</strong><em>${row.firstScore}% → ${row.lastScore}%</em></div>`).join('')}</div>`;
  }
  function renderWeak(files, withReviewButton) {
    if (!files.length) return '<div class="empty-box">현재 자동 보관할 취약 파일이 없습니다.</div>';
    return `<div class="weak-list">${files.map(file => `<div class="weak-item ${file.due ? 'due' : ''}"><div><b>${esc(file.title)}</b><span>${esc(file.toolLabel)} · ${fmtDate(file.lastDate)} · ${esc(file.reason || '')}</span></div><strong>${file.avgScore}%</strong><em>오류 ${file.avgErrors}개</em>${withReviewButton ? `<button type="button" onclick="window.SorizavaStudyTools.markReviewed('${esc(file.key)}')">복습완료</button>` : ''}</div>`).join('')}</div>`;
  }
  function renderSpeedLadder(ladder) {
    return `<div class="ladder-box">
      <div class="ladder-current"><span>현재 추정 속도</span><b>${ladder.level ? ladder.level + '자' : '-'}</b><em>${esc(ladder.decision)}</em></div>
      <div class="ladder-steps">
        <div class="${ladder.prev ? '' : 'muted'}"><span>이전</span><b>${ladder.prev ? ladder.prev + '자' : '-'}</b></div>
        <div class="active"><span>현재</span><b>${ladder.level ? ladder.level + '자' : '-'}</b></div>
        <div class="${ladder.next ? '' : 'muted'}"><span>다음</span><b>${ladder.next ? ladder.next + '자' : '-'}</b></div>
      </div>
      <p>${esc(ladder.action)}</p>
      <small>최근 ${ladder.count}회 · 평균 ${ladder.recentAvg || 0}% · 오류 평균 ${ladder.errAvg || 0}개</small>
    </div>`;
  }
  function renderCauseButtons(summary) {
    const buttons = ERROR_CAUSES.map(cause => `<button type="button" onclick="window.SorizavaStudyTools.addCause('${esc(cause)}')">${esc(cause)}</button>`).join('');
    const top = summary.length ? summary.map(item => `<span>${esc(item.cause)} <b>${item.count}</b></span>`).join('') : '<span>최근 원인 기록 없음</span>';
    return `<div class="cause-buttons">${buttons}</div><div class="cause-summary"><b>최근 14일 오답 원인</b>${top}</div>`;
  }
  function renderNumberDrill() {
    const saved = drills().slice(-1)[0];
    const items = saved?.date === todayKey() ? saved.items : NUMBER_DRILL_SETS[Math.floor(Math.random() * NUMBER_DRILL_SETS.length)];
    if (!saved || saved.date !== todayKey()) saveDrills([...drills(), { id: String(Date.now()), date: todayKey(), items, answers: [] }]);
    return `<div class="number-drill">
      <div class="drill-phrases">${items.map((item, idx) => `<span>${idx + 1}. ${esc(item)}</span>`).join('')}</div>
      <textarea id="numberDrillInput" placeholder="위 문구를 줄바꿈해서 그대로 입력하세요."></textarea>
      <div class="tool-actions"><button type="button" onclick="window.SorizavaStudyTools.checkNumberDrill()">채점</button><button type="button" class="ghost" onclick="window.SorizavaStudyTools.newNumberDrill()">새 문제</button></div>
      <div id="numberDrillResult" class="drill-result">숫자·날짜·금액·단위 표현을 정확히 옮기는 훈련입니다.</div>
    </div>`;
  }
  function renderSegmentTrainer() {
    return `<div class="segment-trainer">
      <input type="file" id="segmentAudioFile" accept="audio/*" onchange="window.SorizavaStudyTools.loadSegmentAudio(event)">
      <audio id="segmentAudio" controls></audio>
      <div class="segment-form">
        <label>시작초<input id="segmentStart" type="number" min="0" step="0.1" value="0"></label>
        <label>끝초<input id="segmentEnd" type="number" min="0" step="0.1" value="15"></label>
        <label>반복<input id="segmentLoops" type="number" min="1" max="20" value="3"></label>
        <button type="button" onclick="window.SorizavaStudyTools.playSegment()">구간 반복 시작</button>
        <button type="button" class="ghost" onclick="window.SorizavaStudyTools.stopSegment()">정지</button>
      </div>
      <div id="segmentStatus" class="segment-status">연습 음성 파일을 선택한 뒤 구간을 지정하세요.</div>
    </div>`;
  }

  function renderIntermediateOverview() {
    const data = state.intermediate.summary || buildIntermediateSummary();
    const last = data.last;
    const current = data.current || data.byLevel[0];
    const currentFile = current?.files?.find(file => !file.passed) || current?.files?.[0] || null;
    const continueUrl = last && last.materialId
      ? `intermediate.html?level=${last.level}&material=${encodeURIComponent(last.materialId)}&mode=${last.mode || 'listen'}`
      : currentFile ? currentFile.url : `intermediate.html?level=${data.unlockedLevel || 110}&mode=listen`;
    const lastText = last
      ? `${last.level}자 · ${esc(last.materialTitle || '자료')} · ${last.mode === 'listen' ? '듣고치기' : '보고치기'} · ${round1(last.accuracy)}%`
      : '아직 중급반 연습 기록이 없습니다.';
    return `<article class="study-panel intermediate-panel wide" id="intermediate-progress">
      <div class="panel-head">
        <div>
          <h2>중급반 학습현황</h2>
          <p>통과 기준: 해당 글자수의 모든 파일을 듣고치기 정확도 ${INTERMEDIATE_PASS_ACCURACY}% 이상으로 완료</p>
        </div>
        <a class="panel-link-btn" href="${continueUrl}">이어하기</a>
      </div>
      <div class="intermediate-summary-grid">
        <div class="intermediate-summary-card"><span>현재 열린 진도</span><b>${data.unlockedLevel || 110}자</b></div>
        <div class="intermediate-summary-card"><span>이번 주 중급반 연습</span><b>${data.weeklyCount || 0}회</b></div>
        <div class="intermediate-summary-card"><span>최근 평균 정확도</span><b>${data.recentAvg || 0}%</b></div>
        <div class="intermediate-summary-card wide"><span>최근 연습</span><b>${esc(lastText)}</b></div>
      </div>
      ${renderIntermediateLevelBoard(data)}
    </article>`;
  }
  function renderIntermediateLevelBoard(data) {
    if (!data.materials.length) {
      return '<div class="empty-box">중급반 등록 자료가 없습니다. 중급반 공부방의 자료 등록/수정에서 자료를 먼저 등록하세요.</div>';
    }
    return `<div class="intermediate-level-board">
      ${data.byLevel.map(levelRow => {
        const locked = levelRow.level > data.unlockedLevel;
        return `<div class="intermediate-level-row ${levelRow.passed ? 'passed' : ''} ${locked ? 'locked' : ''}">
          <div class="level-row-head">
            <b>${locked ? '🔒 ' : ''}${levelRow.level}자</b>
            <span>${levelRow.total ? `${levelRow.passedCount}/${levelRow.total}개 통과` : '자료 없음'}</span>
          </div>
          <div class="level-file-list">
            ${levelRow.files.length ? levelRow.files.map(file => renderIntermediateFileChip(file, locked)).join('') : '<em>등록 자료 없음</em>'}
          </div>
        </div>`;
      }).join('')}
    </div>`;
  }
  function renderIntermediateFileChip(file, locked) {
    const best = file.listenBest;
    const scoreText = best ? `${round1(best.accuracy)}%` : '미시작';
    const href = locked ? '#' : file.url;
    return `<a class="intermediate-file-chip ${file.passed ? 'passed' : ''} ${locked ? 'locked' : ''}" href="${href}" ${locked ? 'onclick="return false;"' : ''}>
      <span>${file.index}. ${esc(file.title)}</span>
      <b>${file.passed ? '통과' : scoreText}</b>
    </a>`;
  }
  function renderIntermediateRecentList() {
    const data = state.intermediate.summary || buildIntermediateSummary();
    if (!data.recent.length) return '<div class="empty-box">중급반 공부방에서 채점하면 최근 기록이 여기에 표시됩니다.</div>';
    return `<div class="intermediate-recent-list">${data.recent.map(log => `
      <div class="intermediate-recent-item">
        <div><b>${log.level}자 · ${esc(log.materialTitle || '자료')}</b><span>${log.mode === 'listen' ? '듣고치기' : '보고치기'} · ${fmtDate(log.createdAt)} · ${log.resultLabel || '-'}</span></div>
        <strong>${round1(log.accuracy)}%</strong>
        <em>${Math.floor((Number(log.elapsed) || 0) / 60).toString().padStart(2, '0')}:${Math.floor((Number(log.elapsed) || 0) % 60).toString().padStart(2, '0')} / ${log.cpm || 0}자</em>
      </div>
    `).join('')}</div>`;
  }

  function abbrWrongStorageKey(userKey = state.userKey || 'guest') {
    return `sorizava_abbr_wrong_${userKey || 'guest'}_v1`;
  }
  function abbrWrongLegacyKey() { return 'sorizava_abbr_wrong_v1'; }
  function normalizeAbbrWrongItem(item) {
    if (!item || typeof item !== 'object') return null;
    const abbr = String(item.abbr || item.answer || item.label || '').trim();
    if (!abbr) return null;
    const abbrCode = String(item.abbrCode || item.code || '').trim();
    const key = String(item.key || `${abbrCode}__${abbr}`).trim();
    return {
      key,
      abbr,
      abbrCode,
      wrongCount: Math.max(0, toNumber(item.wrongCount ?? item.count)),
      correctCount: Math.max(0, toNumber(item.correctCount)),
      lastTyped: String(item.lastTyped || '').trim(),
      firstWrongAt: item.firstWrongAt || item.createdAt || '',
      lastWrongAt: item.lastWrongAt || item.updatedAt || item.createdAt || '',
      lastCorrectAt: item.lastCorrectAt || '',
      mastered: Boolean(item.mastered),
      source: item.source || 'dictionary_voice'
    };
  }
  function readAbbrWrongVault() {
    const keys = [abbrWrongStorageKey(), abbrWrongStorageKey('guest'), abbrWrongLegacyKey()];
    const map = new Map();
    keys.forEach(key => {
      const rows = readJson(key, []);
      if (!Array.isArray(rows)) return;
      rows.map(normalizeAbbrWrongItem).filter(Boolean).forEach(item => {
        const prev = map.get(item.key);
        if (!prev || Number(item.wrongCount) > Number(prev.wrongCount) || String(item.lastWrongAt) > String(prev.lastWrongAt)) {
          map.set(item.key, item);
        }
      });
    });
    return Array.from(map.values()).sort((a, b) => {
      if (Number(b.mastered) !== Number(a.mastered)) return Number(a.mastered) - Number(b.mastered);
      return Number(b.wrongCount) - Number(a.wrongCount) || String(b.lastWrongAt).localeCompare(String(a.lastWrongAt));
    });
  }
  function writeCurrentAbbrWrongVault(list) {
    writeJson(abbrWrongStorageKey(), list.map(normalizeAbbrWrongItem).filter(Boolean).slice(0, 300));
  }
  function abbrWrongSummary() {
    const all = readAbbrWrongVault();
    const active = all.filter(item => !item.mastered);
    const today = active.filter(item => kstDate(item.lastWrongAt) === todayKey() || String(item.lastWrongAt || '').slice(0, 10) === todayKey());
    const frequent = active.filter(item => Number(item.wrongCount) >= 2);
    return { all, active, today, frequent, total: active.length, todayCount: today.length, frequentCount: frequent.length };
  }
  function todayPrescriptionRows(data) {
    const level = data.ladder.level || currentLevel(state.records) || 170;
    const weak = data.weak[0];
    const abbr = data.abbrWrong.active[0];
    const fileMission = weak ? `${weak.title} 재응시 1회` : `${level}자 파일 1개 정확도 98% 목표`;
    const reviewMission = data.alerts[0] ? `${data.alerts[0].title} 복습완료 체크` : '최근 기록 확인 후 오답 원인 1개 기록';
    const abbrMission = abbr ? `틀린 약어 ${Math.min(10, data.abbrWrong.active.length)}개 복습` : '약어랜덤 10문항';
    const goalMission = data.ladder.decision === '상위 속도 1회 응시 가능'
      ? `${data.ladder.next}자 테스트 1회만 진행`
      : data.ladder.decision === '하위 속도 안정화 권장'
        ? `${data.ladder.prev}자 안정화 1회 후 현재 속도 복귀`
        : '오류 3개 이하 또는 정확도 98% 달성';
    return [
      { label: '진도', text: fileMission },
      { label: '복습', text: reviewMission },
      { label: '약어', text: abbrMission },
      { label: '목표', text: goalMission }
    ];
  }
  function renderTodayPrescription(data) {
    const rows = todayPrescriptionRows(data);
    return `<section class="study-prescription-panel study-panel">
      <div class="panel-head"><div><h2>오늘의 공부 처방전</h2><p>기존 기록과 약어 오답을 기준으로 오늘 할 일만 압축했습니다.</p></div><button type="button" onclick="window.SorizavaStudyTools.copyEndReport(true)">요약 복사</button></div>
      <div class="prescription-grid">${rows.map((row, idx) => `<div class="prescription-card"><span>${idx + 1}. 오늘 ${esc(row.label)}</span><b>${esc(row.text)}</b></div>`).join('')}</div>
    </section>`;
  }
  function renderStudyFocusBoard(data) {
    const rows = todayPrescriptionRows(data);
    const first = rows[0];
    const rest = rows.slice(1);
    const decision = data.ladder.decision || '기록 누적 필요';
    const promotionClass = decision.includes('상위') ? 'good' : decision.includes('하위') ? 'bad' : decision.includes('유지') ? 'hold' : 'new';
    return `<section class="study-focus-board">
      <article class="study-focus-card primary">
        <div class="focus-eyebrow">오늘의 핵심</div>
        <h2>오늘은 이것부터 진행하세요</h2>
        <div class="focus-main-task"><span>${esc(first.label)}</span><b>${esc(first.text)}</b></div>
        <div class="focus-task-list">${rest.map((row, idx) => `<div class="focus-task"><em>${idx + 2}</em><div><span>${esc(row.label)}</span><b>${esc(row.text)}</b></div></div>`).join('')}</div>
      </article>
      <article class="study-focus-card decision ${promotionClass}">
        <div class="focus-eyebrow">현재 판단</div>
        <h3>${esc(decision)}</h3>
        <p>${esc(data.ladder.action || '기록을 2~3회 더 남기면 판단이 정확해집니다.')}</p>
        <div class="focus-metrics"><span>최근 평균 <b>${data.ladder.recentAvg || 0}%</b></span><span>오류 평균 <b>${data.ladder.errAvg || 0}개</b></span></div>
      </article>
      <article class="study-focus-card shortcuts">
        <div class="focus-eyebrow">바로 실행</div>
        <a href="#studyRequiredBlock">필수 학습 보기</a>
        <a href="wrong-note.html">오답노트 열기</a>
        <a href="random.html?mode=abbr-wrong">약어 오답 복습</a>
        <button type="button" onclick="window.SorizavaStudyTools.copyEndReport(true)">오늘 요약 복사</button>
      </article>
    </section>`;
  }

  function renderAbbrWrongVault(summary, compact = false) {
    const list = (summary?.active || []).slice(0, compact ? 5 : 12);
    if (!list.length) {
      return `<div class="empty-box">약어랜덤에서 틀린 약어가 생기면 자동으로 여기에 모입니다.</div>`;
    }
    return `<div class="abbr-wrong-vault">
      <div class="abbr-wrong-summary"><span>미완료 ${summary.total}개</span><span>오늘 오답 ${summary.todayCount}개</span><span>반복 오답 ${summary.frequentCount}개</span></div>
      <div class="abbr-wrong-actions"><a href="random.html?mode=abbr-wrong">불러온 파일 기준 오답 재출제</a></div>
      <div class="abbr-wrong-list">${list.map(item => `<div class="abbr-wrong-item">
        <div><b>${esc(item.abbr)}</b><span>${item.abbrCode ? `약어 자리 ${esc(item.abbrCode)} · ` : ''}오답 ${item.wrongCount}회${item.lastTyped ? ` · 최근 입력 ${esc(item.lastTyped)}` : ''}</span></div>
        <button type="button" onclick="window.SorizavaStudyTools.markAbbrWrongMastered('${encodeURIComponent(item.key)}')">암기완료</button>
      </div>`).join('')}</div>
    </div>`;
  }
  function fileGraduationRows(records) {
    const rows = [];
    groupByFile(records).forEach((list, key) => {
      if (!list.length) return;
      const last = list[list.length - 1];
      const lastScore = score(last);
      const recent = list.slice(-3);
      const recentScores = recent.map(score).filter(v => v !== null);
      const recentAvg = round1(avg(recentScores));
      const recentErr = round1(avg(recent.map(totalErrors)));
      const lastTwo = list.slice(-2);
      const graduated = lastTwo.length >= 2 && lastTwo.every(row => (score(row) || 0) >= 98 && totalErrors(row) <= 3);
      const stable = !graduated && recentScores.length && recentAvg >= 95;
      const retry = lastScore !== null && (lastScore < 95 || recentErr >= 6);
      const status = graduated ? '졸업' : retry ? '재복습' : stable ? '안정화' : '진행중';
      rows.push({
        key,
        title: cleanTitle(key),
        toolLabel: toolLabel(last.tool_type),
        count: list.length,
        status,
        statusClass: graduated ? 'graduated' : retry ? 'retry' : stable ? 'stable' : 'progress',
        recentAvg,
        recentErr,
        lastDate: last.created_at
      });
    });
    return rows.sort((a, b) => {
      const order = { '재복습': 0, '진행중': 1, '안정화': 2, '졸업': 3 };
      return (order[a.status] ?? 9) - (order[b.status] ?? 9) || new Date(b.lastDate) - new Date(a.lastDate);
    }).slice(0, 18);
  }
  function renderFileGraduationBoard(rows) {
    if (!rows.length) return '<div class="empty-box">파일별 기록이 쌓이면 미진행·진행중·안정화·졸업·재복습 상태가 표시됩니다.</div>';
    return `<div class="graduation-board">${rows.map(row => `<div class="graduation-chip ${row.statusClass}">
      <div><b>${esc(row.title)}</b><span>${esc(row.toolLabel)} · ${row.count}회 · 최근 ${fmtDate(row.lastDate)}</span></div>
      <strong>${esc(row.status)}</strong>
      <em>${row.recentAvg || 0}% / 오류 ${row.recentErr || 0}</em>
    </div>`).join('')}</div>`;
  }
  function renderPromotionCard(ladder) {
    const label = ladder.decision || '기록 누적 필요';
    const className = label.includes('상위') ? 'good' : label.includes('하위') ? 'bad' : label.includes('유지') ? 'hold' : 'new';
    return `<div class="promotion-card ${className}">
      <div class="promotion-main"><span>현재 판단</span><b>${esc(label)}</b><p>${esc(ladder.action)}</p></div>
      <div class="promotion-metrics">
        <div><span>현재</span><b>${ladder.level ? ladder.level + '자' : '-'}</b></div>
        <div><span>다음</span><b>${ladder.next ? ladder.next + '자' : '-'}</b></div>
        <div><span>최근 평균</span><b>${ladder.recentAvg || 0}%</b></div>
        <div><span>오류 평균</span><b>${ladder.errAvg || 0}개</b></div>
      </div>
    </div>`;
  }
  function buildEndReportText(data) {
    const today = todayKey();
    const todayRecords = state.records.filter(record => kstDate(record.created_at) === today);
    const todayScores = todayRecords.map(score).filter(v => v !== null);
    const todayAvg = round1(avg(todayScores));
    const todayErrors = todayRecords.reduce((sum, row) => sum + totalErrors(row), 0);
    const studyTime = window.SorizavaStudyTimer?.getStats?.().todayText || '0분';
    const weak = data.weak[0];
    const next = data.training[0]?.text || '현재 속도 파일 1개 기록 남기기';
    return [
      '[오늘 공부 종료 리포트]',
      `공부시간: ${studyTime}`,
      `오늘 기록: ${todayRecords.length}회`,
      `오늘 평균 정확도: ${todayScores.length ? todayAvg + '%' : '-'}`,
      `오늘 누적 오류: ${todayErrors}개`,
      `약어 오답: ${data.abbrWrong.todayCount}개 / 누적 미완료 ${data.abbrWrong.total}개`,
      `승급 판단: ${data.ladder.decision}`,
      `우선 복습: ${weak ? weak.title + ' (' + weak.avgScore + '%)' : '취약 파일 없음'}`,
      `다음 공부: ${next}`
    ].join('\n');
  }
  function renderEndReport(data) {
    const report = buildEndReportText(data);
    return `<div class="end-report-box"><pre>${esc(report)}</pre><button type="button" onclick="window.SorizavaStudyTools.copyEndReport()">리포트 복사</button></div>`;
  }
  function renderPracticalExamMode() {
    return `<div class="exam-sim-box">
      <div class="exam-sim-grid">
        <label>급수<select id="examSimGrade"><option>3급</option><option>2급</option><option>1급</option></select></label>
        <label>유형<select id="examSimType"><option>연설</option><option>논설</option></select></label>
        <label>속도<input id="examSimLevel" type="number" value="170" min="100" max="280"></label>
        <label>정확도<input id="examSimAcc" type="number" step="0.1" placeholder="96.8"></label>
        <label>오자<input id="examSimWrong" type="number" value="0"></label>
        <label>탈자<input id="examSimMissing" type="number" value="0"></label>
        <label>첨자<input id="examSimAdded" type="number" value="0"></label>
      </div>
      <button type="button" onclick="window.SorizavaStudyTools.savePracticalExam()">실전 결과 저장</button>
      <p>저장하면 승급 판단, 파일별 졸업 도장, 공부 종료 리포트에 같이 반영됩니다.</p>
    </div>`;
  }

  function renderCommandHero(data) {
    const rows = todayPrescriptionRows(data);
    const primary = rows[0] || { label: '진도', text: '오늘 기록 1회 남기기' };
    const studyTimeText = window.SorizavaStudyTimer?.getStats?.().todayText || '0분';
    const decision = data.ladder.decision || '기록 누적 필요';
    const decisionClass = decision.includes('상위') ? 'good' : decision.includes('하위') ? 'bad' : decision.includes('유지') ? 'hold' : 'new';
    const weak = data.weak[0];
    return `<section class="study-command-hero">
      <article class="command-hero-main">
        <div class="command-kicker">STUDY COMMAND CENTER</div>
        <h2>공부방을 오늘 할 일 중심으로 다시 정리했습니다</h2>
        <p>모든 기능을 한꺼번에 펼치지 않고, 오늘 실행할 학습·약점 복구·진도판·실전 기록을 분리해서 보여줍니다.</p>
        <div class="command-primary-mission">
          <span>오늘 1순위</span>
          <strong>${esc(primary.text)}</strong>
          <em>${esc(primary.label)}부터 처리하면 됩니다.</em>
        </div>
      </article>
      <aside class="command-hero-side">
        <div class="command-timer-card">
          <span>오늘 공부시간</span>
          <b data-study-time="today-text">${studyTimeText}</b>
          <em>기존 공부시간 카운트 로직 그대로 사용</em>
        </div>
        <div class="command-decision-card ${decisionClass}">
          <span>현재 판단</span>
          <b>${esc(decision)}</b>
          <p>${esc(data.ladder.action || '기록을 2~3회 더 남기면 판단이 정확해집니다.')}</p>
        </div>
        <div class="command-mini-alert">
          <span>우선 복습</span>
          <b>${weak ? esc(weak.title) : '취약 파일 없음'}</b>
        </div>
      </aside>
    </section>`;
  }

  function renderStudyZoneNav(data) {
    const weakCount = data.weak.length + data.abbrWrong.total;
    const progressCount = data.graduation.length || state.intermediate.summary?.weeklyCount || 0;
    const reportCount = state.records.length;
    const zones = [
      { key: 'today', num: '01', title: '오늘 할 일', desc: '처방전 · 과제', badge: data.training.length + data.assign.total },
      { key: 'weak', num: '02', title: '약점 복구', desc: '오답 · 약어', badge: weakCount },
      { key: 'progress', num: '03', title: '진도판', desc: '중급반 · 졸업도장', badge: progressCount },
      { key: 'lab', num: '04', title: '실전/기록', desc: '시험모드 · 리포트', badge: reportCount }
    ];
    return `<nav class="study-command-menu" aria-label="공부방 작업 구역">
      ${zones.map((zone, idx) => `<button type="button" class="${idx === 0 ? 'active' : ''}" data-study-zone-button="${zone.key}" onclick="window.SorizavaStudyTools.showStudyZone('${zone.key}')">
        <em>${zone.num}</em>
        <strong>${zone.title}</strong>
        <span>${zone.desc}</span>
        <i>${zone.badge}</i>
      </button>`).join('')}
    </nav>`;
  }

  function renderZoneHeader(kicker, title, desc) {
    return `<div class="study-zone-head"><span>${esc(kicker)}</span><h2>${esc(title)}</h2><p>${esc(desc)}</p></div>`;
  }

  function renderStudyZonePanels(data) {
    return `<section class="study-zone-stage">
      <div class="study-zone-panel active zone-today" data-study-zone-panel="today">
        ${renderZoneHeader('TODAY', '오늘 할 일만 남긴 실행 화면', '학생이 처음 들어왔을 때 바로 처리해야 하는 처방전과 과제만 배치했습니다.')}
        ${renderTodayPrescription(data)}
        <div class="study-zone-grid two">
          <article class="study-zone-card mission-card"><div class="panel-head"><div><h2>오늘 훈련 세트</h2><p>바로 실행할 순서입니다.</p></div></div>${renderTrainingList(data.training)}</article>
          <article class="study-zone-card task-card"><div class="panel-head"><h2>과제 제출</h2></div><div class="assignment-add"><input id="newAssignmentText" placeholder="직접 과제 입력"><button type="button" onclick="window.SorizavaStudyTools.addCustomAssignment()">추가</button></div>${renderAssignments(data.assign)}</article>
        </div>
      </div>
      <div class="study-zone-panel zone-weak" data-study-zone-panel="weak">
        ${renderZoneHeader('WEAK POINT', '틀린 것만 다시 잡는 약점 복구실', '파일 오답, 약어 오답, 오답 원인을 한 구역에 모아 복습 전용 화면으로 분리했습니다.')}
        <div class="study-zone-grid two">
          <article class="study-zone-card weak-card"><div class="panel-head"><div><h2>오늘 복습할 파일</h2><p>취약 파일과 복습 예정 파일입니다.</p></div></div>${renderWeak(data.alerts.length ? data.alerts : data.weak, true)}</article>
          <article class="study-zone-card abbr-card"><div class="panel-head"><div><h2>약어 오답 복습함</h2><p>약어랜덤에서 직접 불러온 파일로 틀린 항목만 모입니다.</p></div></div>${renderAbbrWrongVault(data.abbrWrong)}</article>
        </div>
        <article class="study-zone-card cause-card"><div class="panel-head"><h2>오답 원인 체크</h2></div>${renderCauseButtons(data.cause)}</article>
      </div>
      <div class="study-zone-panel zone-progress" data-study-zone-panel="progress">
        ${renderZoneHeader('PROGRESS MAP', '내 진도가 어디까지 왔는지 보는 진도판', '중급반 학습 현황, 최근 기록, 파일별 졸업 도장을 한 화면에서 확인합니다.')}
        <div class="study-zone-grid two progress-grid">
          ${renderIntermediateOverview()}
          <article class="study-zone-card history-card"><div class="panel-head"><h2>최근 중급반 기록</h2></div>${renderIntermediateRecentList()}</article>
        </div>
        <div class="study-zone-grid two">
          <article class="study-zone-card stamp-card"><div class="panel-head"><h2>파일별 졸업 도장</h2></div>${renderFileGraduationBoard(data.graduation)}</article>
          <article class="study-zone-card retry-card"><div class="panel-head"><h2>파일 재응시 비교</h2></div>${renderRetry(data.retry)}</article>
        </div>
      </div>
      <div class="study-zone-panel zone-lab" data-study-zone-panel="lab">
        ${renderZoneHeader('PRACTICE LAB', '실전처럼 기록하고 바로 판단하는 실험실', '실전 시험 모드, 간편 결과 기록, 승급 판단, 공부 종료 리포트를 처리합니다.')}
        <div class="study-zone-grid three">
          <article class="study-zone-card exam-card"><div class="panel-head"><h2>실전 시험 모드</h2></div>${renderPracticalExamMode()}</article>
          <article class="study-zone-card record-card"><div class="panel-head"><h2>간편 결과 기록</h2></div>${renderQuickRecordForm()}</article>
          <article class="study-zone-card decision-card"><div class="panel-head"><h2>승급 판단 카드</h2></div>${renderPromotionCard(data.ladder)}</article>
        </div>
        <div class="study-zone-grid two">
          <article class="study-zone-card report-card"><div class="panel-head"><h2>공부 종료 리포트</h2></div>${renderEndReport(data)}</article>
          <article class="study-zone-card tool-card"><div class="panel-head"><h2>보조 훈련 도구</h2></div><div class="study-tool-split"><div>${renderSegmentTrainer()}</div><div>${renderNumberDrill()}</div></div></article>
        </div>
      </div>
    </section>`;
  }

  function renderStudyRoom() {
    const data = buildData();
    const root = $('studyToolsRoot');
    root.innerHTML = `${renderMiniNav('study-room')}${renderCommandHero(data)}
      <div class="study-command-layout">
        ${renderStudyZoneNav(data)}
        ${renderStudyZonePanels(data)}
      </div>`;
  }


  function renderQuickRecordForm() {
    return `<div class="quick-record">
      <label>파일명<input id="quickTitle" placeholder="예: 연설 170자 12번"></label>
      <label>속도<input id="quickCpm" type="number" placeholder="170"></label>
      <label>정확도<input id="quickAcc" type="number" step="0.1" placeholder="96.8"></label>
      <label>오자<input id="quickWrong" type="number" value="0"></label>
      <label>탈자<input id="quickMissing" type="number" value="0"></label>
      <label>첨자<input id="quickAdded" type="number" value="0"></label>
      <button type="button" onclick="window.SorizavaStudyTools.saveQuickRecord()">기록 저장</button>
    </div>`;
  }
  function baseWrongRandomAnswer(item) {
    return String(item?.answerText || item?.expected || item?.context || '')
      .replace(/_{2,}/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }
  function buildWrongRandomPrompt(item) {
    let answer = compactText(baseWrongRandomAnswer(item), 60);
    if (!answer) answer = compactText(item?.expectedCore || item?.expected || item?.context || '', 60);
    answer = String(answer || '').replace(/\s+/g, ' ').trim();
    return { answer, question: answer };
  }
  function prepareWrongRandomItem(item) {
    if (!item) return null;
    return { ...item, _drillPrompt: buildWrongRandomPrompt(item) };
  }
  function wrongPromptQuestion(item) {
    return item?._drillPrompt?.question || buildWrongRandomPrompt(item).question;
  }
  function renderWrongPrompt(item) {
    if (!item) return '';
    return `<div class="wrong-random-meta">
      <span class="wrong-type ${item.type}">${wrongTypeLabel(item.type)}</span>
      <b>${esc(item.title)}</b>
      <em>${esc(item.toolLabel)} · ${fmtDate(item.date)}${item.score !== null ? ` · ${round1(item.score)}%` : ''}</em>
    </div>
    <div class="wrong-random-question">
      <span>문제</span>
      <strong>${esc(wrongPromptQuestion(item))}</strong>
      <small>어절 단위 오답만 그대로 따라 치세요.</small>
    </div>`;
  }

  function wrongRandomAnswer(item) {
    return item?._drillPrompt?.answer || buildWrongRandomPrompt(item).answer;
  }
  function wrongRandomModeLabel(mode) {
    return mode === 'voice' ? '듣고치기' : '보고치기';
  }
  function speakWrongRandom(text) {
    if (!window.speechSynthesis || !text) return;
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(String(text || '').replace(/\s+/g, ' ').trim());
    utter.lang = 'ko-KR';
    utter.rate = 1;
    const voices = window.speechSynthesis.getVoices ? window.speechSynthesis.getVoices() : [];
    const voice = voices.find(v => v.name.includes('Google') && v.lang.includes('ko')) || voices.find(v => v.lang.includes('ko')) || voices[0];
    if (voice) utter.voice = voice;
    window.speechSynthesis.speak(utter);
  }
  function replayWrongNoteRandom() {
    const item = state.wrongDrill?.current;
    if (!item) return;
    speakWrongRandom(wrongRandomAnswer(item));
    setTimeout(() => $('wrongRandomInput')?.focus(), 30);
  }
  function renderWrongRandomPanel(summary) {
    const active = summary?.active || [];
    const drill = state.wrongDrill || {};
    const item = drill.current;
    const remain = (drill.queue || []).length + (item ? 1 : 0);
    const mode = drill.mode || 'visual';
    if (!active.length) {
      return `<div class="wrong-random-card empty">
        <h2>복습할 오답이 없습니다</h2>
        <p>원문과 입력문이 함께 저장된 채점 기록이 생기면 오자·첨자만 오답노트에 올라옵니다.</p>
      </div>`;
    }
    if (drill.finished) {
      return `<div class="wrong-random-card finish">
        <div class="abbr-display finish-display">Finish!</div>
        <div class="wrong-random-score">${wrongRandomModeLabel(mode)} 완료 · 정답 ${drill.correct || 0}개 / 오답 ${drill.wrong || 0}개</div>
        <div class="wrong-random-mode-choice">
          <button type="button" class="wrong-random-primary" onclick="window.SorizavaStudyTools.startWrongNoteRandom('visual')">보고치기 다시 시작</button>
          <button type="button" class="wrong-random-secondary" onclick="window.SorizavaStudyTools.startWrongNoteRandom('voice')">듣고치기 다시 시작</button>
        </div>
      </div>`;
    }
    if (!drill.started || !item) {
      return `<div class="wrong-random-card ready">
        <div class="wrong-random-counts">
          <span>전체 ${active.length}개</span><span>오자 ${summary.byType.wrong || 0}</span><span>첨자 ${summary.byType.added || 0}</span>
        </div>
        <div class="abbr-display">Start!</div>
        <p>틀린 어절만 랜덤으로 나옵니다. 보이는 어절을 그대로 따라 치면 됩니다.</p>
        <div class="wrong-random-mode-choice">
          <button type="button" class="wrong-random-primary" onclick="window.SorizavaStudyTools.startWrongNoteRandom('visual')">보고치기 시작</button>
          <button type="button" class="wrong-random-secondary" onclick="window.SorizavaStudyTools.startWrongNoteRandom('voice')">듣고치기 시작</button>
        </div>
      </div>`;
    }
    const answer = wrongRandomAnswer(item);
    const promptBlock = mode === 'voice'
      ? `<div class="wrong-random-listen-box">
          <div class="abbr-display blind">듣고치기</div>
          <p>오답 어절을 음성으로 듣고 그대로 입력합니다. 필요하면 다시 듣기를 누르세요.</p>
          <button type="button" class="wrong-random-secondary" onclick="window.SorizavaStudyTools.replayWrongNoteRandom()">🔊 다시 듣기</button>
          <div class="wrong-random-meta compact"><span class="wrong-type ${item.type}">${wrongTypeLabel(item.type)}</span><b>${esc(item.title)}</b><em>${esc(item.toolLabel)} · ${fmtDate(item.date)}${item.score !== null ? ` · ${round1(item.score)}%` : ''}</em></div>
        </div>`
      : renderWrongPrompt(item);
    return `<div class="wrong-random-card playing ${mode === 'voice' ? 'voice-mode' : 'visual-mode'}">
      <div class="wrong-random-status">
        <span>방식 <b>${wrongRandomModeLabel(mode)}</b></span>
        <span>남은 개수 <b>${remain}</b> / ${drill.total || active.length}</span>
        <span>정답 <b>${drill.correct || 0}</b></span>
        <span>오답 <b>${drill.wrong || 0}</b></span>
      </div>
      ${promptBlock}
      <input type="text" id="wrongRandomInput" class="wrong-random-input" placeholder="${mode === 'voice' ? '들은 어절 입력 후 Enter' : '보이는 어절 그대로 입력 후 Enter'}" autocomplete="off" onkeydown="if(event.key==='Enter') window.SorizavaStudyTools.checkWrongNoteRandom()">
      <div id="wrongRandomFeedback" class="wrong-random-feedback ${drill.answerVisible ? 'show' : ''}">${drill.answerVisible ? `다시 칠 어절: ${esc(answer)}` : '틀리면 다시 칠 어절이 표시됩니다.'}</div>
      <div class="wrong-random-actions">
        <button type="button" class="wrong-random-primary" onclick="window.SorizavaStudyTools.checkWrongNoteRandom()">채점</button>
        <button type="button" class="wrong-random-secondary" onclick="window.SorizavaStudyTools.skipWrongNoteRandom()">넘기기</button>
        <button type="button" class="wrong-random-secondary" onclick="window.SorizavaStudyTools.resetWrongNoteRandom()">리셋</button>
      </div>
    </div>`;
  }
  function renderWrongMiniList(summary) {
    const list = (summary?.active || []).slice(0, 10);
    if (!list.length) return '';
    return `<div class="wrong-mini-list">
      ${list.map(item => `<div class="wrong-mini-item"><span>${wrongTypeLabel(item.type)}</span><b>${esc(item.answerText || item.expected || item.context)}</b><em>${esc(item.title)}</em></div>`).join('')}
    </div>`;
  }
  function startWrongNoteRandom(mode = 'visual') {
    const summary = detailedWrongSummary();
    const queue = shuffleWrongItems(summary.active);
    if (!queue.length) return alert('복습할 오답이 없습니다. 채점 기록이 쌓이면 자동으로 생성됩니다.');
    const drillMode = mode === 'voice' ? 'voice' : 'visual';
    state.wrongDrill = { queue, current: null, total: queue.length, correct: 0, wrong: 0, started: true, finished: false, answerVisible: false, mode: drillMode };
    nextWrongNoteRandom();
  }
  function nextWrongNoteRandom() {
    const drill = state.wrongDrill;
    drill.current = prepareWrongRandomItem(drill.queue.shift() || null);
    drill.answerVisible = false;
    if (!drill.current) drill.finished = true;
    renderWrongNote();
    if (drill.mode === 'voice' && drill.current) setTimeout(() => speakWrongRandom(wrongRandomAnswer(drill.current)), 120);
    setTimeout(() => $('wrongRandomInput')?.focus(), 30);
  }
  function rememberWrongPractice(item, isCorrect, typed) {
    if (!item) return;
    const practice = readWrongNotePractice();
    const prev = practice[item.id] || { attempts: 0, correct: 0 };
    practice[item.id] = {
      attempts: Number(prev.attempts || 0) + 1,
      correct: Number(prev.correct || 0) + (isCorrect ? 1 : 0),
      lastAnswer: typed || '',
      lastAt: new Date().toISOString()
    };
    saveWrongNotePractice(practice);
    if (isCorrect) {
      const mastery = readWrongNoteMastery();
      mastery[item.id] = { mastered: true, masteredAt: new Date().toISOString() };
      saveWrongNoteMastery(mastery);
    }
  }
  function checkWrongNoteRandom() {
    const drill = state.wrongDrill;
    const item = drill.current;
    if (!item) return;
    const input = $('wrongRandomInput');
    const typed = input?.value || '';
    const target = wrongRandomAnswer(item);
    if (!typed.trim()) return alert('입력한 내용이 없습니다.');
    if (normalizeWrongAnswer(typed) === normalizeWrongAnswer(target)) {
      drill.correct = Number(drill.correct || 0) + 1;
      rememberWrongPractice(item, true, typed);
      nextWrongNoteRandom();
    } else {
      drill.wrong = Number(drill.wrong || 0) + 1;
      drill.answerVisible = true;
      rememberWrongPractice(item, false, typed);
      renderWrongNote();
      setTimeout(() => $('wrongRandomInput')?.focus(), 30);
    }
  }
  function skipWrongNoteRandom() {
    if (!state.wrongDrill?.started) return;
    nextWrongNoteRandom();
  }
  function resetWrongNoteRandom() {
    state.wrongDrill = { queue: [], current: null, total: 0, correct: 0, wrong: 0, started: false, finished: false, answerVisible: false, mode: 'visual' };
    renderWrongNote();
  }
  function renderWrongNote() {
    const data = buildData();
    const root = $('studyToolsRoot');
    root.innerHTML = `
      <section class="wrong-random-shell wrong-note-only-shell">
        ${renderWrongRandomPanel(data.detailedWrong)}
        <details class="wrong-random-details">
          <summary>현재 쌓인 오답 보기</summary>
          ${renderWrongMiniList(data.detailedWrong)}
        </details>
      </section>`;
  }

  function renderTeacherCheck() {
    const data = buildData();
    const d = dominantError();
    const progress = state.insight?.progressStatus || {};
    const promotion = state.insight?.promotionCandidate || {};
    const weak = data.weak[0];
    const retry = data.retry[0];
    const assignmentRate = data.assign.total ? Math.round(data.assign.done / data.assign.total * 100) : 0;
    const cards = [
      { title: '오늘 수업 핵심', text: promotion.eligible ? `${promotion.currentLevel}자 안정권입니다. ${promotion.nextLevel}자 1회 테스트가 가능합니다.` : progress.status === 'stagnant' ? '진도 정체 가능성이 있습니다. 새 진도보다 기존 파일 오류 감소를 봐야 합니다.' : '정확도와 오류 수를 같이 확인하면서 현재 속도 안정화를 봅니다.' },
      { title: '우선 피드백', text: weak ? `${weak.title} 파일이 취약합니다. 평균 ${weak.avgScore}% / 오류 ${weak.avgErrors}개입니다.` : `${d.label} 기준으로 짧게 피드백하면 됩니다.` },
      { title: '재응시 효과', text: retry ? `${retry.title} 개선폭 ${retry.delta >= 0 ? '+' : ''}${retry.delta}%p입니다.` : '같은 파일을 2회 이상 기록하게 하면 반복 효과가 보입니다.' },
      { title: '과제 상태', text: data.assign.total ? `오늘 과제 제출률 ${assignmentRate}% (${data.assign.done}/${data.assign.total})입니다.` : '등록된 오늘 과제가 없습니다. 공부방에서 과제를 추가하세요.' }
    ];
    const root = $('studyToolsRoot');
    root.innerHTML = `${renderMiniNav('teacher-check')}${renderStatCards(data)}
      <section class="teacher-brief-card study-panel"><div class="panel-head"><div><h2>수업 전 1분 점검</h2><p>수업 시작 전에 볼 내용만 압축했습니다.</p></div><button type="button" onclick="window.SorizavaStudyTools.copyTeacherBrief()">점검 내용 복사</button></div><div class="teacher-brief-grid">${cards.map(card => `<div><b>${esc(card.title)}</b><p>${esc(card.text)}</p></div>`).join('')}</div></section>
      <section class="study-page-grid main">
        <article class="study-panel"><div class="panel-head"><h2>주의 파일</h2></div>${renderWeak(data.weak.slice(0, 6), false)}</article>
        <article class="study-panel"><div class="panel-head"><h2>오늘 훈련 지시</h2></div>${renderTrainingList(data.training)}</article>
      </section>
      <section class="study-page-grid main">
        <article class="study-panel"><div class="panel-head"><h2>승급 판단 카드</h2></div>${renderPromotionCard(data.ladder)}</article>
        <article class="study-panel"><div class="panel-head"><h2>약어 오답</h2></div>${renderAbbrWrongVault(data.abbrWrong, true)}</article>
      </section>`;
  }

  function showStudyZone(zone) {
    const root = $('studyToolsRoot') || document;
    root.querySelectorAll('[data-study-zone-panel]').forEach(panel => {
      panel.classList.toggle('active', panel.getAttribute('data-study-zone-panel') === zone);
    });
    root.querySelectorAll('[data-study-zone-button]').forEach(button => {
      button.classList.toggle('active', button.getAttribute('data-study-zone-button') === zone);
    });
  }

  async function initPage(ctx) {
    const appWrapper = document.getElementById('app-wrapper');
    if (appWrapper) appWrapper.style.display = 'flex';
    state.page = document.body.dataset.studyPage || 'study-room';
    state.profile = ctx?.profile || null;
    state.userKey = ctx?.user?.id || sessionStorage.getItem('shorthand_user_id') || 'guest';
    try {
      const summary = await window.SorizavaRecords.getMyStudyInsight();
      state.records = summary.records || [];
      state.insight = summary.insight || {};
      state.summary = summary || {};
      state.intermediate.materials = await loadIntermediateMaterials();
      state.intermediate.logs = readIntermediateLogs();
      state.intermediate.summary = buildIntermediateSummary();
      const hello = $('studyHello');
      if (hello) hello.textContent = `${state.profile?.name || sessionStorage.getItem('shorthand_user') || 'User'}님의 공부 기능입니다.`;
      if (state.page === 'wrong-note') renderWrongNote();
      else if (state.page === 'teacher-check') renderTeacherCheck();
      else renderStudyRoom();
    } catch (e) {
      console.error(e);
      const root = $('studyToolsRoot');
      if (root) root.innerHTML = '<div class="empty-box error">기록을 불러오지 못했습니다. 로그인 상태와 Supabase 연결을 확인하세요.</div>';
    }
  }
  function refresh() {
    if (state.page === 'wrong-note') renderWrongNote();
    else if (state.page === 'teacher-check') renderTeacherCheck();
    else renderStudyRoom();
  }
  function addAssignment(title) {
    const list = assignments();
    list.unshift({ id: `${Date.now()}_${Math.random().toString(16).slice(2)}`, date: todayKey(), title, submitted: false });
    saveAssignments(list);
    refresh();
  }
  function addAssignmentFromTraining(index) {
    const item = state.data.training[index];
    if (item) addAssignment(item.text);
  }
  function addCustomAssignment() {
    const input = $('newAssignmentText');
    const title = input?.value?.trim();
    if (!title) return alert('추가할 과제를 입력해 주세요.');
    addAssignment(title);
  }
  function toggleAssignment(id) {
    const list = assignments();
    const item = list.find(row => row.id === id);
    if (item) item.submitted = !item.submitted;
    saveAssignments(list);
    refresh();
  }
  function markReviewed(key) {
    const map = reviews();
    map[key] = todayKey();
    saveReviews(map);
    refresh();
  }
  function addCause(cause) {
    const list = causes();
    list.push({ id: `${Date.now()}_${Math.random().toString(16).slice(2)}`, date: todayKey(), cause });
    saveCauses(list);
    refresh();
  }
  function newNumberDrill() {
    const items = NUMBER_DRILL_SETS[Math.floor(Math.random() * NUMBER_DRILL_SETS.length)];
    saveDrills([...drills(), { id: String(Date.now()), date: todayKey(), items, answers: [] }]);
    refresh();
  }
  function normalizeAnswer(text) { return String(text || '').replace(/\s+/g, ' ').trim(); }
  function checkNumberDrill() {
    const saved = drills().slice(-1)[0];
    const items = saved?.items || [];
    const answers = ($('numberDrillInput')?.value || '').split('\n').map(normalizeAnswer).filter(Boolean);
    const correct = items.filter((item, idx) => normalizeAnswer(item) === normalizeAnswer(answers[idx])).length;
    const result = $('numberDrillResult');
    if (result) result.innerHTML = `<b>${correct}/${items.length}개 일치</b><span>${correct === items.length ? '정확합니다.' : '틀린 줄은 숫자·단위·띄어쓰기까지 다시 확인하세요.'}</span>`;
    saveDrills([...drills().slice(0, -1), { ...saved, answers, correct }]);
  }
  function loadSegmentAudio(event) {
    const file = event.target.files && event.target.files[0];
    const audio = $('segmentAudio');
    if (!file || !audio) return;
    if (state.segment.objectUrl) URL.revokeObjectURL(state.segment.objectUrl);
    state.segment.objectUrl = URL.createObjectURL(file);
    audio.src = state.segment.objectUrl;
    const status = $('segmentStatus');
    if (status) status.textContent = `${file.name} 파일을 불러왔습니다. 반복할 시작/끝 구간을 입력하세요.`;
  }
  function playSegment() {
    const audio = $('segmentAudio');
    if (!audio || !audio.src) return alert('먼저 연습 음성 파일을 선택해 주세요.');
    const start = Math.max(0, toNumber($('segmentStart')?.value));
    const end = Math.max(start + 0.5, toNumber($('segmentEnd')?.value, start + 15));
    const loops = Math.max(1, Math.min(20, toNumber($('segmentLoops')?.value, 3)));
    state.segment = { ...state.segment, audio, start, end, loops, currentLoop: 1, playing: true };
    audio.currentTime = start;
    audio.play();
    audio.ontimeupdate = function () {
      if (!state.segment.playing) return;
      if (audio.currentTime >= state.segment.end) {
        if (state.segment.currentLoop >= state.segment.loops) {
          stopSegment();
          const status = $('segmentStatus');
          if (status) status.textContent = `구간 반복 완료: ${start}초~${end}초 / ${loops}회`;
        } else {
          state.segment.currentLoop += 1;
          audio.currentTime = state.segment.start;
          audio.play();
          const status = $('segmentStatus');
          if (status) status.textContent = `${state.segment.currentLoop}/${state.segment.loops}회 반복 중`;
        }
      }
    };
    const status = $('segmentStatus');
    if (status) status.textContent = `1/${loops}회 반복 중`;
  }
  function stopSegment() {
    const audio = $('segmentAudio');
    state.segment.playing = false;
    if (audio) { audio.pause(); audio.ontimeupdate = null; }
  }
  async function saveQuickRecord() {
    const title = $('quickTitle')?.value?.trim();
    const accuracy = toNullableNumber($('quickAcc')?.value);
    if (!title) return alert('파일명을 입력해 주세요.');
    if (accuracy === null) return alert('정확도를 입력해 주세요.');
    const saved = await window.SorizavaRecords.savePracticeRecord({
      tool_type: 'exam',
      practice_title: title,
      cpm: toNullableNumber($('quickCpm')?.value),
      accuracy,
      score: accuracy,
      wrong_count: toNumber($('quickWrong')?.value),
      missing_count: toNumber($('quickMissing')?.value),
      added_count: toNumber($('quickAdded')?.value),
      spacing_error_count: 0,
      memo: '공부방 간편 기록'
    });
    if (!saved) return alert('기록 저장에 실패했습니다.');
    alert('연습 기록을 저장했습니다.');
    const summary = await window.SorizavaRecords.getMyStudyInsight();
    state.records = summary.records || [];
    state.insight = summary.insight || {};
    state.summary = summary || {};
    refresh();
  }
  function copyEndReport(silent) {
    const data = buildData();
    const text = buildEndReportText(data);
    const done = () => { if (!silent) alert('공부 종료 리포트를 복사했습니다.'); };
    if (navigator.clipboard?.writeText) navigator.clipboard.writeText(text).then(done).catch(() => alert(text));
    else alert(text);
  }
  function markAbbrWrongMastered(encodedKey) {
    const key = decodeURIComponent(encodedKey || '');
    const current = readAbbrWrongVault();
    const next = current.map(item => item.key === key ? { ...item, mastered: true, masteredAt: new Date().toISOString() } : item);
    writeCurrentAbbrWrongVault(next);
    refresh();
  }
  async function savePracticalExam() {
    const grade = $('examSimGrade')?.value || '3급';
    const type = $('examSimType')?.value || '연설';
    const level = toNullableNumber($('examSimLevel')?.value);
    const accuracy = toNullableNumber($('examSimAcc')?.value);
    if (accuracy === null) return alert('정확도를 입력해 주세요.');
    const wrong = toNumber($('examSimWrong')?.value);
    const missing = toNumber($('examSimMissing')?.value);
    const added = toNumber($('examSimAdded')?.value);
    const total = wrong + missing + added;
    const passLine = grade === '1급' ? 97 : grade === '2급' ? 96 : 95;
    const verdict = accuracy >= passLine && total <= 5 ? '합격권' : accuracy >= passLine - 1 ? '위험권' : '불합격권';
    const saved = await window.SorizavaRecords.savePracticeRecord({
      tool_type: 'exam',
      practice_title: `실전 시험 모드 ${grade} ${type}${level ? ' ' + level + '자' : ''}`,
      cpm: level,
      accuracy,
      score: accuracy,
      wrong_count: wrong,
      missing_count: missing,
      added_count: added,
      spacing_error_count: 0,
      memo: `실전 시험 모드 판정: ${verdict}`
    });
    if (!saved) return alert('실전 결과 저장에 실패했습니다.');
    alert(`실전 결과를 저장했습니다.\n판정: ${verdict}`);
    const summary = await window.SorizavaRecords.getMyStudyInsight();
    state.records = summary.records || [];
    state.insight = summary.insight || {};
    state.summary = summary || {};
    refresh();
  }

  function copyTeacherBrief() {
    const data = buildData();
    const weak = data.weak[0];
    const lines = [
      '[수업 전 1분 점검]',
      `최근 평균: ${data.volume.avg || 0}% / 이번 주 파일 ${data.volume.files}개`,
      `현재 속도 판단: ${data.ladder.decision}`,
      `우선 파일: ${weak ? `${weak.title} (${weak.avgScore}%)` : '취약 파일 없음'}`,
      '오늘 지시:',
      ...data.training.map((item, idx) => `${idx + 1}. ${item.text}`)
    ];
    navigator.clipboard?.writeText(lines.join('\n')).then(() => alert('점검 내용을 복사했습니다.')).catch(() => alert(lines.join('\n')));
  }

  window.initStudyToolsPage = initPage;
  window.SorizavaStudyTools = {
    addAssignmentFromTraining,
    addCustomAssignment,
    toggleAssignment,
    markReviewed,
    addCause,
    newNumberDrill,
    checkNumberDrill,
    loadSegmentAudio,
    playSegment,
    stopSegment,
    saveQuickRecord,
    savePracticalExam,
    copyEndReport,
    showStudyZone,
    markAbbrWrongMastered,
    startWrongNoteRandom,
    checkWrongNoteRandom,
    skipWrongNoteRandom,
    resetWrongNoteRandom,
    replayWrongNoteRandom,
    copyTeacherBrief
  };
})();
