// Responsive sidebar shell - 2026-05-01
(function () {
  function sidebarElements() {
    return {
      sidebar: document.querySelector('.sidebar'),
      overlay: document.querySelector('.sidebar-overlay')
    };
  }

  function setSidebarOpen(open) {
    var el = sidebarElements();
    if (!el.sidebar || !el.overlay) return;
    el.sidebar.classList.toggle('active', !!open);
    el.overlay.classList.toggle('active', !!open);
    document.body.classList.toggle('sidebar-open', !!open);
  }

  function toggleSidebar(force) {
    var el = sidebarElements();
    if (!el.sidebar) return;
    var shouldOpen = typeof force === 'boolean' ? force : !el.sidebar.classList.contains('active');
    setSidebarOpen(shouldOpen);
  }

  window.toggleSidebar = toggleSidebar;



  // Study time tracker - counts only while the student is actively typing.
  const STUDY_TIMER_VERSION = '20260501-study-timer-v1';
  const STUDY_IDLE_LIMIT_MS = 60 * 1000;
  let studyTimerState = {
    userKey: 'guest',
    lastTypingAt: 0,
    lastTickAt: 0,
    tickHandle: null,
    active: false
  };

  function todayKstKey() {
    const now = new Date();
    const kst = new Date(now.getTime() + 9 * 60 * 60 * 1000);
    return kst.toISOString().slice(0, 10);
  }

  function pad2(value) {
    return String(Math.max(0, Math.floor(value))).padStart(2, '0');
  }

  function formatClock(seconds) {
    const safe = Math.max(0, Math.floor(Number(seconds) || 0));
    const h = Math.floor(safe / 3600);
    const m = Math.floor((safe % 3600) / 60);
    const s = safe % 60;
    return h > 0 ? `${h}:${pad2(m)}:${pad2(s)}` : `${pad2(m)}:${pad2(s)}`;
  }

  function formatStudyDuration(seconds) {
    const safe = Math.max(0, Math.floor(Number(seconds) || 0));
    const h = Math.floor(safe / 3600);
    const m = Math.floor((safe % 3600) / 60);
    if (h > 0 && m > 0) return `${h}시간 ${m}분`;
    if (h > 0) return `${h}시간`;
    if (m > 0) return `${m}분`;
    return safe > 0 ? '1분 미만' : '0분';
  }

  function getStudyUserKey() {
    return sessionStorage.getItem('shorthand_user_id')
      || sessionStorage.getItem('sorizava_user_id')
      || sessionStorage.getItem('shorthand_user')
      || 'guest';
  }

  async function resolveStudyUserKey() {
    const sessionKey = getStudyUserKey();
    if (sessionKey !== 'guest') return sessionKey;
    try {
      if (window.SorizavaAuth && typeof window.SorizavaAuth.getSession === 'function') {
        const session = await window.SorizavaAuth.getSession();
        if (session && session.user && session.user.id) return session.user.id;
      }
    } catch (error) {
      console.warn('공부시간 사용자 확인 실패:', error);
    }
    return 'guest';
  }

  function syncStudyUserKey() {
    const nextKey = getStudyUserKey();
    if (nextKey && nextKey !== 'guest' && nextKey !== studyTimerState.userKey) {
      studyTimerState.userKey = nextKey;
    }
  }

  function studyStorageKey() {
    return `sorizava_study_time_${studyTimerState.userKey}_v1`;
  }

  function readStudyTime() {
    try {
      const raw = localStorage.getItem(studyStorageKey());
      const data = raw ? JSON.parse(raw) : null;
      if (!data || typeof data !== 'object') return { totalSeconds: 0, daily: {}, updatedAt: '' };
      return {
        totalSeconds: Math.max(0, Math.floor(Number(data.totalSeconds) || 0)),
        daily: data.daily && typeof data.daily === 'object' ? data.daily : {},
        updatedAt: data.updatedAt || ''
      };
    } catch (error) {
      return { totalSeconds: 0, daily: {}, updatedAt: '' };
    }
  }

  function writeStudyTime(data) {
    try {
      localStorage.setItem(studyStorageKey(), JSON.stringify(data));
    } catch (error) {
      console.warn('공부시간 저장 실패:', error);
    }
  }

  function getStudyStats() {
    syncStudyUserKey();
    const data = readStudyTime();
    const today = todayKstKey();
    const todaySeconds = Math.max(0, Math.floor(Number(data.daily[today]) || 0));
    return {
      today,
      todaySeconds,
      totalSeconds: Math.max(0, Math.floor(Number(data.totalSeconds) || 0)),
      active: Boolean(studyTimerState.active),
      todayClock: formatClock(todaySeconds),
      totalText: formatStudyDuration(data.totalSeconds),
      todayText: formatStudyDuration(todaySeconds)
    };
  }

  function addStudySeconds(seconds) {
    const add = Math.max(0, Math.min(5, Math.floor(Number(seconds) || 0)));
    if (!add) return;
    const data = readStudyTime();
    const today = todayKstKey();
    data.totalSeconds = Math.max(0, Math.floor(Number(data.totalSeconds) || 0)) + add;
    data.daily[today] = Math.max(0, Math.floor(Number(data.daily[today]) || 0)) + add;
    data.updatedAt = new Date().toISOString();
    writeStudyTime(data);
  }

  function shouldTrackTypingTarget(target) {
    if (!target || !(target instanceof Element)) return false;
    if (target.closest('.no-study-timer, .sidebar, .sidebar-overlay, .admin-card, .modal-overlay, .login-form-container')) return false;
    if (target.isContentEditable) return true;
    const tag = target.tagName;
    if (tag === 'TEXTAREA') return !target.readOnly && !target.disabled;
    if (tag !== 'INPUT') return false;
    const type = String(target.getAttribute('type') || 'text').toLowerCase();
    if (['password', 'email', 'search', 'number', 'file', 'checkbox', 'radio', 'button', 'submit', 'reset', 'hidden', 'date', 'time', 'range', 'color'].includes(type)) return false;
    return !target.readOnly && !target.disabled;
  }

  function updateStudyTimeDisplays() {
    const stats = getStudyStats();
    document.querySelectorAll('[data-study-time="today-clock"]').forEach(el => { el.textContent = stats.todayClock; });
    document.querySelectorAll('[data-study-time="today-text"]').forEach(el => { el.textContent = stats.todayText; });
    document.querySelectorAll('[data-study-time="total-text"]').forEach(el => { el.textContent = stats.totalText; });
    document.querySelectorAll('[data-study-time="state"]').forEach(el => { el.textContent = stats.active ? '입력 중' : '대기'; });
    document.querySelectorAll('.sidebar-study-time-card').forEach(el => { el.classList.toggle('is-active', stats.active); });
    window.dispatchEvent(new CustomEvent('sorizava:studyTimeUpdated', { detail: stats }));
  }

  function ensureSidebarStudyCard() {
    const sidebar = document.querySelector('.sidebar');
    const top = sidebar && sidebar.querySelector('.sidebar-top');
    if (!sidebar || !top || sidebar.querySelector('.sidebar-study-time-card')) return;
    const card = document.createElement('div');
    card.className = 'sidebar-study-time-card';
    card.innerHTML = `
      <div class="study-time-card-head"><span>⏱️ 공부중인 시간</span><em data-study-time="state">대기</em></div>
      <strong data-study-time="today-clock">00:00</strong>
      <small>오늘 누적 <b data-study-time="today-text">0분</b> · 전체 <b data-study-time="total-text">0분</b></small>
    `;
    top.insertAdjacentElement('afterend', card);
  }

  function ensureDashboardStudyCard() {
    const row = document.querySelector('.stats-row');
    if (!row || row.querySelector('.study-time-dashboard-card')) return;
    const card = document.createElement('div');
    card.className = 'stat-card study-time-dashboard-card';
    card.innerHTML = `
      <div class="stat-info">
        <p>오늘 공부시간</p>
        <h3 data-study-time="today-text">0분</h3>
      </div>
      <div class="stat-icon bg-study-time">⏱️</div>
    `;
    row.appendChild(card);
  }

  function tickStudyTimer() {
    const now = Date.now();
    const wasActive = studyTimerState.active;
    const isActive = studyTimerState.lastTypingAt && now - studyTimerState.lastTypingAt < STUDY_IDLE_LIMIT_MS;
    studyTimerState.active = Boolean(isActive);

    if (studyTimerState.active) {
      const elapsed = studyTimerState.lastTickAt ? Math.floor((now - studyTimerState.lastTickAt) / 1000) : 0;
      if (elapsed > 0) {
        addStudySeconds(elapsed);
        studyTimerState.lastTickAt += elapsed * 1000;
      }
    } else {
      studyTimerState.lastTickAt = 0;
    }

    if (wasActive !== studyTimerState.active || studyTimerState.active) updateStudyTimeDisplays();
  }

  function markStudyTyping() {
    syncStudyUserKey();
    const now = Date.now();
    studyTimerState.lastTypingAt = now;
    if (!studyTimerState.lastTickAt || !studyTimerState.active) studyTimerState.lastTickAt = now;
    studyTimerState.active = true;
    if (!studyTimerState.tickHandle) {
      studyTimerState.tickHandle = setInterval(tickStudyTimer, 1000);
    }
    updateStudyTimeDisplays();
  }

  function initStudyTimer() {
    studyTimerState.userKey = getStudyUserKey();
    ensureSidebarStudyCard();
    ensureDashboardStudyCard();
    updateStudyTimeDisplays();

    resolveStudyUserKey().then(function (key) {
      if (key && key !== studyTimerState.userKey) {
        studyTimerState.userKey = key;
        updateStudyTimeDisplays();
      }
    });

    document.addEventListener('input', function (event) {
      if (shouldTrackTypingTarget(event.target)) markStudyTyping();
    }, true);

    document.addEventListener('compositionend', function (event) {
      if (shouldTrackTypingTarget(event.target)) markStudyTyping();
    }, true);

    document.addEventListener('visibilitychange', function () {
      if (document.hidden) {
        studyTimerState.active = false;
        studyTimerState.lastTickAt = 0;
        updateStudyTimeDisplays();
      }
    });

    window.SorizavaStudyTimer = {
      version: STUDY_TIMER_VERSION,
      getStats: getStudyStats,
      formatDuration: formatStudyDuration,
      formatClock: formatClock,
      refresh: updateStudyTimeDisplays
    };
  }

  document.addEventListener('DOMContentLoaded', function () {
    initStudyTimer();
    var activeItem = document.querySelector('.nav-section .nav-item.active');
    if (activeItem) {
      var section = activeItem.closest('.nav-section');
      if (section) section.open = true;
    }

    document.querySelectorAll('.sidebar .nav-item').forEach(function (item) {
      item.addEventListener('click', function () {
        if (window.matchMedia('(max-width: 900px)').matches) setSidebarOpen(false);
      });
    });

    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') setSidebarOpen(false);
    });

    window.addEventListener('resize', function () {
      if (!window.matchMedia('(max-width: 900px)').matches) setSidebarOpen(false);
    });
  });
})();

// Practice focus sidebar hover bridge - 2026-05-06
(function () {
  function isPracticeDesktop() {
    return document.body.classList.contains('practice-focus-body') && window.matchMedia('(min-width: 901px)').matches;
  }
  function ready(fn) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn, { once: true });
    else fn();
  }
  ready(function () {
    var btn = document.querySelector('.mobile-menu-btn');
    var sidebar = document.querySelector('.sidebar');
    if (!btn || !sidebar) return;
    var closeTimer = null;
    function open() {
      if (!isPracticeDesktop()) return;
      clearTimeout(closeTimer);
      window.toggleSidebar && window.toggleSidebar(true);
    }
    function scheduleClose() {
      if (!isPracticeDesktop()) return;
      clearTimeout(closeTimer);
      closeTimer = setTimeout(function () {
        if (!sidebar.matches(':hover') && !btn.matches(':hover')) {
          window.toggleSidebar && window.toggleSidebar(false);
        }
      }, 220);
    }
    btn.addEventListener('mouseenter', open);
    btn.addEventListener('mouseleave', scheduleClose);
    sidebar.addEventListener('mouseenter', open);
    sidebar.addEventListener('mouseleave', scheduleClose);
  });
})();
