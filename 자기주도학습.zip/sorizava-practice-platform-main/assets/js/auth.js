// Shared authentication helpers
(function () {
  const sb = () => window.SORIZAVA_SUPABASE;
  const AUTH_PAGES = ['index.html', 'signup.html', 'pending.html', 'login.html'];

  function currentFile() {
    const f = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
    return f === '' ? 'index.html' : f;
  }

  function setLoading(show) {
    const el = document.getElementById('loading-overlay');
    if (el) el.style.display = show ? 'flex' : 'none';
  }


  const COURSE_META = {
    intermediate: { navKey: 'intermediate', label: '중급반 공부방', href: 'intermediate.html' },
    advanced: { navKey: 'advanced', label: '고급반 공부방', href: 'intermediate.html?course=advanced' },
    grade: { navKey: 'grade', label: '급수반 공부방', href: 'intermediate.html?course=grade' }
  };
  const COURSE_NAV_KEYS = Object.values(COURSE_META).map(item => item.navKey);
  const MANAGER_ROLES = ['admin', 'administrator', 'super_admin', 'superadmin', 'owner', 'manager', 'operator', 'staff', 'teacher', '강사', '선생님', '관리자', '운영팀'];

  function normalizeRole(value) {
    return String(value || '').trim().toLowerCase();
  }

  function hasManagerAccess(profile) {
    return MANAGER_ROLES.includes(normalizeRole(profile?.role));
  }

  function normalizeCourseTrack(value) {
    const raw = String(value || '').trim().toLowerCase();
    if (['advanced', 'high', '고급', '고급반', '고급반 공부방', '190', '210', '230', '250'].includes(raw)) return 'advanced';
    if (['grade', 'level', 'exam', 'certificate', '급수', '급수반', '급수반 공부방', '1급', '2급', '3급'].includes(raw)) return 'grade';
    if (['intermediate', 'middle', '중급', '중급반', '중급반 공부방', '110', '120', '130', '140', '150', '160', '170'].includes(raw)) return 'intermediate';
    const text = String(value || '');
    if (/급수|[123]\s*급|시험|자격증/i.test(text)) return 'grade';
    if (/고급|190\s*자|210\s*자|230\s*자|250\s*자|advanced/i.test(text)) return 'advanced';
    return 'intermediate';
  }

  function profileCourseTrack(profile = {}) {
    return normalizeCourseTrack(
      profile.course_track || profile.assigned_course || profile.current_course || profile.course || profile.track || profile.class_name || profile.current_class || profile.level
    );
  }

  function currentCourseFromUrl() {
    if (currentFile() !== 'intermediate.html') return null;
    const params = new URLSearchParams(location.search);
    return normalizeCourseTrack(params.get('course') || params.get('track') || params.get('type') || 'intermediate');
  }

  function courseHref(course) {
    return COURSE_META[normalizeCourseTrack(course)]?.href || COURSE_META.intermediate.href;
  }

  function runWhenDomReady(fn) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn, { once: true });
    else fn();
  }

  function applyStudentCourseAccess(profile) {
    const role = normalizeRole(profile?.role || 'student');
    const isStudent = !hasManagerAccess(profile) && (!role || role === 'student' || role === '학생');
    const assignedCourse = profileCourseTrack(profile);
    runWhenDomReady(() => {
      document.body?.setAttribute('data-assigned-course', assignedCourse);
      document.body?.classList.toggle('student-course-filtered', isStudent);
      document.querySelectorAll('.nav-item').forEach(item => {
        const key = item.dataset.navKey;
        if (!COURSE_NAV_KEYS.includes(key)) return;
        const visible = !isStudent || key === COURSE_META[assignedCourse].navKey;
        item.hidden = !visible;
        item.style.display = visible ? '' : 'none';
        item.setAttribute('aria-hidden', visible ? 'false' : 'true');
      });
      const link = document.getElementById('dashboardCourseLink');
      if (isStudent && link) {
        link.href = courseHref(assignedCourse);
        link.textContent = `${COURSE_META[assignedCourse].label} 바로 시작`;
      }
    });

    const currentCourse = currentCourseFromUrl();
    if (isStudent && currentCourse && currentCourse !== assignedCourse) {
      location.replace(courseHref(assignedCourse));
      return false;
    }
    return true;
  }

  function cacheProfile(user, profile) {
    if (!user || !profile) return;
    const displayName = profile.name || user.email || 'User';
    sessionStorage.setItem('shorthand_user', displayName);
    sessionStorage.setItem('shorthand_email', user.email || profile.email || '');
    sessionStorage.setItem('shorthand_user_id', user.id);
    sessionStorage.setItem('shorthand_role', profile.role || 'student');
    sessionStorage.setItem('shorthand_status', profile.status || 'pending');
    sessionStorage.setItem('shorthand_course_track', profileCourseTrack(profile));
    sessionStorage.setItem('sorizava_profile', JSON.stringify(profile));
    applyStudentCourseAccess(profile);
    document.querySelectorAll('#sideUserName, #userNameSide').forEach(el => { el.textContent = displayName; });
    document.querySelectorAll('#userAvatar').forEach(el => { el.textContent = displayName.charAt(0); });
  }

  async function getSession() {
    const client = sb();
    if (!client) throw new Error('Supabase client not ready');
    const { data, error } = await client.auth.getSession();
    if (error) throw error;
    return data.session;
  }

  async function getProfile(userId) {
    const client = sb();
    const { data, error } = await client
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
    if (error) throw error;
    return data;
  }

  async function getApprovedStatusByRpc() {
    const client = sb();
    const { data, error } = await client.rpc('is_approved_user');
    if (error) throw error;
    return data === true;
  }

  async function getRoleByRpc() {
    const client = sb();
    const { data, error } = await client.rpc('get_my_role');
    if (error) return 'student';
    return data || 'student';
  }

  async function buildProfileSafe(user) {
    let profile = null;
    try {
      profile = await getProfile(user.id);
    } catch (e) {
      console.warn('profiles 조회 실패, RPC 기준으로 로그인 유지:', e);
    }

    const approved = await getApprovedStatusByRpc();
    const role = profile?.role || await getRoleByRpc();

    return {
      id: user.id,
      email: user.email,
      name: profile?.name || user.user_metadata?.name || user.email || 'User',
      academy_id: profile?.academy_id || user.user_metadata?.academy_id || '',
      phone: profile?.phone || user.user_metadata?.phone || '',
      role: role || 'student',
      status: approved ? 'approved' : (profile?.status || 'pending'),
      course_track: profileCourseTrack({
        ...user.user_metadata,
        ...profile,
        course_track: profile?.course_track || user.user_metadata?.course_track
      })
    };
  }

  async function requireApproved(options = {}) {
    const redirect = options.redirect !== false;
    const session = await getSession();
    if (!session || !session.user) {
      sessionStorage.clear();
      if (redirect && !AUTH_PAGES.includes(currentFile())) location.href = 'index.html';
      return null;
    }

    const profile = await buildProfileSafe(session.user);
    cacheProfile(session.user, profile);

    if (profile.status !== 'approved') {
      if (redirect && currentFile() !== 'pending.html') location.href = 'pending.html';
      return { session, user: session.user, profile, approved: false };
    }
    return { session, user: session.user, profile, approved: true };
  }

  async function bootPage(initFn) {
    setLoading(true);
    try {
      const ctx = await requireApproved({ redirect: true });
      if (!ctx || !ctx.approved) return;
      if (typeof initFn === 'function') initFn(ctx);
    } catch (e) {
      console.error('인증 확인 실패:', e);
      sessionStorage.clear();
      location.href = 'index.html';
    } finally {
      setLoading(false);
    }
  }

  async function signIn(email, password) {
    const cleanEmail = String(email || '').trim().toLowerCase();
    const { data, error } = await sb().auth.signInWithPassword({ email: cleanEmail, password });
    if (error) {
      error.userMessage = error.message || 'Supabase Auth 로그인 실패';
      throw error;
    }

    const profile = await buildProfileSafe(data.user);
    cacheProfile(data.user, profile);

    if (profile.status !== 'approved') {
      const approvalError = new Error('승인 대기 상태입니다. 관리자 승인 후 로그인할 수 있습니다.');
      approvalError.code = 'NOT_APPROVED';
      throw approvalError;
    }

    return { user: data.user, profile };
  }

  async function signUp({ email, password, name, academy_id, phone }) {
    const { data, error } = await sb().auth.signUp({
      email: String(email || '').trim().toLowerCase(),
      password,
      options: { data: { name, academy_id, phone } }
    });
    if (error) throw error;
    return data;
  }

  async function signOut() {
    try { await sb().auth.signOut(); } catch (e) { console.warn(e); }
    sessionStorage.clear();
    location.href = 'index.html';
  }

  async function getCachedOrFreshProfile() {
    try {
      const session = await getSession();
      if (!session) return null;
      const profile = await buildProfileSafe(session.user);
      cacheProfile(session.user, profile);
      return profile;
    } catch (e) { return null; }
  }

  document.addEventListener('DOMContentLoaded', async () => {
    if (document.body && document.body.dataset.auth === 'approved' && !document.body.dataset.manualBoot) {
      try { await requireApproved({ redirect: true }); } catch (e) { location.href = 'index.html'; }
    }
  });

  window.SorizavaAuth = {
    requireApproved,
    bootPage,
    signIn,
    signUp,
    signOut,
    getProfile,
    getSession,
    getApprovedStatusByRpc,
    getRoleByRpc,
    getCachedOrFreshProfile,
    cacheProfile
  };

  window.SorizavaCourseAccess = {
    normalizeCourseTrack,
    profileCourseTrack,
    courseHref,
    applyStudentCourseAccess,
    hasManagerAccess,
    meta: COURSE_META
  };
})();
