// Vercel Serverless Function: 오늘 전체 AI 선생님 피드백 생성

const core = require('./_ai-feedback-core');

function buildDailySystemPrompt() {
  return `${core.buildPaidFeedbackSystemPrompt()}\n\n이번 요청은 파일 1개가 아니라 하루 전체 기록에 대한 종합 피드백이다. 파일별 나열이 아니라 오늘의 공통 약점, 지연 구간 공통 패턴, 약어 사용 상태, 이전 기록 대비 변화를 중심으로 작성한다.`;
}

function buildDailyUserPrompt({ dateKey, todayRecords, previousDayRecords, recentRecords, inputLogs, abbrevLogs }) {
  const todayIds = todayRecords.map(row => row.id);
  const todayInputLogs = inputLogs.filter(row => todayIds.includes(row.practice_record_id));
  const todayAbbrevLogs = abbrevLogs.filter(row => todayIds.includes(row.practice_record_id));
  const payload = {
    feedback_scope: 'daily',
    date: dateKey,
    instruction: '오늘 전체 연습 기록을 종합해 유료급 AI 피드백을 작성한다. 오늘 기록끼리 공통 약점을 뽑고, 직전 학습/최근 기록과 비교한다.',
    today_summary: core.summarizeRecords(todayRecords),
    previous_day_summary: core.summarizeRecords(previousDayRecords),
    recent_40_summary: core.summarizeRecords(recentRecords),
    today_records: todayRecords.map(row => ({
      ...core.compactRecord(row),
      source_text_snapshot: core.trimText(row.source_text_snapshot, 2500),
      typed_text_snapshot: core.trimText(row.typed_text_snapshot, 2500),
      diff_summary: core.trimText(row.diff_summary, 1400),
    })),
    input_flow_logs: todayInputLogs.map(row => ({
      practice_record_id: row.practice_record_id,
      total_duration_ms: row.total_duration_ms,
      pause_count: row.pause_count,
      max_pause_ms: row.max_pause_ms,
      backspace_count: row.backspace_count,
      paste_detected: row.paste_detected,
      section_stats: row.section_stats,
    })),
    abbreviation_logs: todayAbbrevLogs.map(row => ({
      practice_record_id: row.practice_record_id,
      abbrev_hint_enabled: row.abbrev_hint_enabled,
      total_abbrev_count: row.total_abbrev_count,
      correct_abbrev_count: row.correct_abbrev_count,
      slow_abbrev_count: row.slow_abbrev_count,
      error_abbrev_count: row.error_abbrev_count,
      missed_abbrevs: row.missed_abbrevs,
      weak_abbrev_patterns: row.weak_abbrev_patterns,
    })),
    comparison_records: {
      previous_day_records: previousDayRecords.map(core.compactRecord),
      recent_records: recentRecords.slice(0, 20).map(core.compactRecord),
    },
    output_requirements: [
      '오늘 여러 파일에서 공통으로 보이는 느림/탈자/오자 패턴을 먼저 말한다.',
      '직전 학습일 또는 최근 기록보다 좋아진 점과 떨어진 점을 분리한다.',
      '오늘 놓친 약어를 바탕으로 약어 복습 목록을 제시한다.',
      '마지막에는 오늘 약점에 맞춘 맞춤 연습문장 8개와 1분 단락치기 원고를 제공한다.'
    ]
  };
  return `다음 JSON 데이터를 근거로 오늘 전체 AI 피드백을 작성하세요.\n\n${JSON.stringify(payload, null, 2)}`;
}

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') return core.json(res, 405, { ok: false, error: 'POST 요청만 사용할 수 있습니다.' });

  try {
    const token = core.pickBearer(req);
    if (!token) return core.json(res, 401, { ok: false, error: '로그인 토큰이 없습니다.' });
    const { user } = await core.requireApprovedUser(token);
    const body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});
    const dateKey = String(body.date || core.formatKstDate()).slice(0, 10);
    const todayRange = core.kstRange(dateKey);
    const previousDate = core.addDays(dateKey, -1);
    const prevRange = core.kstRange(previousDate);

    const [todayRecords, previousDayRecords, recentRecords] = await Promise.all([
      core.getRecordsByRange(user.id, token, todayRange.start, todayRange.end, 80),
      core.getRecordsByRange(user.id, token, prevRange.start, prevRange.end, 80),
      core.getRecentRecords(user.id, token, 40),
    ]);

    if (!todayRecords.length) return core.json(res, 400, { ok: false, error: '오늘 저장된 학습 기록이 없습니다.' });

    const recordIds = todayRecords.map(row => row.id);
    const [inputLogs, abbrevLogs] = await Promise.all([
      core.getInputLogs(recordIds, user.id, token),
      core.getAbbrevLogs(recordIds, user.id, token),
    ]);

    const feedback = await core.createOpenAiFeedback({
      systemPrompt: buildDailySystemPrompt(),
      userPrompt: buildDailyUserPrompt({ dateKey, todayRecords, previousDayRecords, recentRecords, inputLogs, abbrevLogs }),
    });

    const summary = core.summarizeRecords(todayRecords);
    const saved = await core.insertAiFeedback({
      token,
      userId: user.id,
      recordId: null,
      title: `오늘 전체 AI 피드백 · ${dateKey}`,
      feedback,
      meta: {
        feedback_type: 'daily',
        date: dateKey,
        record_count: todayRecords.length,
        avg_accuracy: summary.avg_accuracy,
        has_input_flow_logs: inputLogs.length > 0,
        has_abbreviation_logs: abbrevLogs.length > 0,
      },
    });

    return core.json(res, 200, { ok: true, feedback: saved });
  } catch (error) {
    console.error('[ai-daily-feedback]', error);
    return core.json(res, 500, { ok: false, error: error.message || '오늘 전체 AI 피드백 생성 중 오류가 발생했습니다.' });
  }
};
