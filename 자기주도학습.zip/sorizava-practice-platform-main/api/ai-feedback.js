// Vercel Serverless Function: 개별 파일 AI 선생님 피드백 생성

const core = require('./_ai-feedback-core');

function buildSingleRecordUserPrompt({ record, recentRecords, inputLogs, abbrevLogs }) {
  const targetInput = inputLogs.find(row => String(row.practice_record_id) === String(record.id)) || null;
  const targetAbbrev = abbrevLogs.find(row => String(row.practice_record_id) === String(record.id)) || null;
  const recent = recentRecords.filter(row => String(row.id) !== String(record.id)).slice(0, 12);
  const recentSummary = core.summarizeRecords(recent);
  const sameTool = recent.filter(row => row.tool_type === record.tool_type).slice(0, 8);
  const sameToolSummary = core.summarizeRecords(sameTool);

  const payload = {
    feedback_scope: 'single_record',
    instruction: '파일 1개에 대한 유료급 세부 피드백을 작성한다. 입력 흐름 로그와 약어 로그가 있으면 반드시 반영한다.',
    target_record: {
      ...core.compactRecord(record),
      source_text_snapshot: core.trimText(record.source_text_snapshot, 6000),
      typed_text_snapshot: core.trimText(record.typed_text_snapshot, 6000),
      diff_summary: core.trimText(record.diff_summary, 3000),
    },
    input_flow_log: targetInput ? {
      total_duration_ms: targetInput.total_duration_ms,
      pause_count: targetInput.pause_count,
      max_pause_ms: targetInput.max_pause_ms,
      backspace_count: targetInput.backspace_count,
      paste_detected: targetInput.paste_detected,
      section_stats: targetInput.section_stats,
    } : null,
    abbreviation_log: targetAbbrev ? {
      abbrev_hint_enabled: targetAbbrev.abbrev_hint_enabled,
      total_abbrev_count: targetAbbrev.total_abbrev_count,
      correct_abbrev_count: targetAbbrev.correct_abbrev_count,
      slow_abbrev_count: targetAbbrev.slow_abbrev_count,
      error_abbrev_count: targetAbbrev.error_abbrev_count,
      missed_abbrevs: targetAbbrev.missed_abbrevs,
      weak_abbrev_patterns: targetAbbrev.weak_abbrev_patterns,
    } : null,
    comparison: {
      recent_12_records_summary: recentSummary,
      same_tool_recent_summary: sameToolSummary,
      recent_records: recent.map(core.compactRecord),
    },
    output_requirements: [
      '어디에서 느려졌고 그 뒤 어떤 탈자/오자가 났는지 연결해서 설명한다.',
      '같은 표현이 반복해서 틀렸다면 예시 표현을 직접 언급한다.',
      '약어 대상 구간이 느리거나 틀렸다면 약어 미사용/자동화 부족 가능성을 분리한다.',
      '마지막에는 학생이 바로 칠 수 있는 맞춤 연습문장 6개와 1분 단락치기 원고를 제공한다.'
    ]
  };

  return `다음 JSON 데이터를 근거로 AI 선생님 피드백을 작성하세요.\n\n${JSON.stringify(payload, null, 2)}`;
}

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') return core.json(res, 405, { ok: false, error: 'POST 요청만 사용할 수 있습니다.' });

  try {
    const token = core.pickBearer(req);
    if (!token) return core.json(res, 401, { ok: false, error: '로그인 토큰이 없습니다.' });
    const { user } = await core.requireApprovedUser(token);
    const body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});
    const recordId = String(body.record_id || '').trim();
    if (!recordId) return core.json(res, 400, { ok: false, error: 'record_id가 필요합니다.' });

    const record = await core.getPracticeRecord(recordId, user.id, token);
    const recentRecords = await core.getRecentRecords(user.id, token, 40);
    const recordIds = [record.id, ...recentRecords.map(row => row.id)];
    const [inputLogs, abbrevLogs] = await Promise.all([
      core.getInputLogs(recordIds, user.id, token),
      core.getAbbrevLogs(recordIds, user.id, token),
    ]);

    const feedback = await core.createOpenAiFeedback({
      systemPrompt: core.buildPaidFeedbackSystemPrompt(),
      userPrompt: buildSingleRecordUserPrompt({ record, recentRecords, inputLogs, abbrevLogs }),
    });

    const saved = await core.insertAiFeedback({
      token,
      userId: user.id,
      recordId: record.id,
      title: record.practice_title || 'AI 선생님 피드백',
      feedback,
      meta: {
        feedback_type: 'single_record',
        tool_type: record.tool_type || null,
        accuracy: record.accuracy ?? record.score ?? null,
        cpm: record.cpm || null,
        wrong_count: record.wrong_count || 0,
        missing_count: record.missing_count || 0,
        added_count: record.added_count || 0,
        spacing_error_count: record.spacing_error_count || 0,
        has_input_flow_log: inputLogs.some(row => String(row.practice_record_id) === String(record.id)),
        has_abbreviation_log: abbrevLogs.some(row => String(row.practice_record_id) === String(record.id)),
      },
    });

    return core.json(res, 200, { ok: true, feedback: saved });
  } catch (error) {
    console.error('[ai-feedback]', error);
    return core.json(res, 500, { ok: false, error: error.message || 'AI 피드백 생성 중 오류가 발생했습니다.' });
  }
};
