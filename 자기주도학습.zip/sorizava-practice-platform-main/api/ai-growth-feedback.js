// Vercel Serverless Function: 최근 7일 성장 비교 AI 피드백 생성

const core = require('./_ai-feedback-core');

function rangeFromOffset(baseDateKey, startOffset, endOffset) {
  const startKey = core.addDays(baseDateKey, startOffset);
  const endKey = core.addDays(baseDateKey, endOffset);
  return { startKey, endKey, start: core.kstRange(startKey).start, end: core.kstRange(endKey).end };
}

function buildGrowthSystemPrompt() {
  return `${core.buildPaidFeedbackSystemPrompt()}\n\n이번 요청은 성장 비교 리포트다. 최근 7일과 그 이전 7일을 비교해 상승/하락, 오류 유형 변화, 약어 자동화 변화, 입력 지연 변화, 승급 가능성을 평가한다. 단순 요약이 아니라 다음 1주일 훈련 계획까지 제시한다.`;
}

function buildGrowthUserPrompt({ currentRange, previousRange, currentRecords, previousRecords, inputLogs, abbrevLogs }) {
  const currentIds = currentRecords.map(row => row.id);
  const payload = {
    feedback_scope: 'growth_7_days',
    instruction: '최근 7일과 이전 7일을 비교해 성장/하락을 판단하고 다음 1주 훈련계획을 작성한다.',
    current_period: currentRange,
    previous_period: previousRange,
    current_summary: core.summarizeRecords(currentRecords),
    previous_summary: core.summarizeRecords(previousRecords),
    current_records: currentRecords.slice(0, 50).map(core.compactRecord),
    previous_records: previousRecords.slice(0, 50).map(core.compactRecord),
    current_input_flow_logs: inputLogs.filter(row => currentIds.includes(row.practice_record_id)).map(row => ({
      practice_record_id: row.practice_record_id,
      pause_count: row.pause_count,
      max_pause_ms: row.max_pause_ms,
      backspace_count: row.backspace_count,
      section_stats: row.section_stats,
    })),
    current_abbreviation_logs: abbrevLogs.filter(row => currentIds.includes(row.practice_record_id)).map(row => ({
      practice_record_id: row.practice_record_id,
      abbrev_hint_enabled: row.abbrev_hint_enabled,
      total_abbrev_count: row.total_abbrev_count,
      correct_abbrev_count: row.correct_abbrev_count,
      slow_abbrev_count: row.slow_abbrev_count,
      error_abbrev_count: row.error_abbrev_count,
      missed_abbrevs: row.missed_abbrevs,
      weak_abbrev_patterns: row.weak_abbrev_patterns,
    })),
    output_requirements: [
      '최근 7일이 이전 7일보다 좋아졌는지/떨어졌는지 정확도와 오류 유형을 근거로 말한다.',
      '기록 수가 부족하면 그 한계를 분명히 말하되, 현재 가능한 판단은 제공한다.',
      '느려지는 구간과 약어 자동화 문제를 다음 1주일 훈련계획에 반영한다.',
      '요일별 또는 회차별 몰림이 있으면 학습 루틴 조정까지 제안한다.',
      '마지막에 다음 7일 과제와 약점 교정 문장을 제공한다.'
    ]
  };
  return `다음 JSON 데이터를 근거로 최근 7일 성장 분석 피드백을 작성하세요.\n\n${JSON.stringify(payload, null, 2)}`;
}

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') return core.json(res, 405, { ok: false, error: 'POST 요청만 사용할 수 있습니다.' });

  try {
    const token = core.pickBearer(req);
    if (!token) return core.json(res, 401, { ok: false, error: '로그인 토큰이 없습니다.' });
    const { user } = await core.requireApprovedUser(token);
    const body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});
    const baseDate = String(body.date || core.formatKstDate()).slice(0, 10);
    const currentRange = rangeFromOffset(baseDate, -6, 0);
    const previousRange = rangeFromOffset(baseDate, -13, -7);

    const [currentRecords, previousRecords] = await Promise.all([
      core.getRecordsByRange(user.id, token, currentRange.start, currentRange.end, 200),
      core.getRecordsByRange(user.id, token, previousRange.start, previousRange.end, 200),
    ]);

    if (!currentRecords.length) return core.json(res, 400, { ok: false, error: '최근 7일 저장된 학습 기록이 없습니다.' });

    const recordIds = currentRecords.map(row => row.id);
    const [inputLogs, abbrevLogs] = await Promise.all([
      core.getInputLogs(recordIds, user.id, token),
      core.getAbbrevLogs(recordIds, user.id, token),
    ]);

    const feedback = await core.createOpenAiFeedback({
      systemPrompt: buildGrowthSystemPrompt(),
      userPrompt: buildGrowthUserPrompt({ currentRange, previousRange, currentRecords, previousRecords, inputLogs, abbrevLogs }),
    });

    const summary = core.summarizeRecords(currentRecords);
    const previousSummary = core.summarizeRecords(previousRecords);
    const saved = await core.insertAiFeedback({
      token,
      userId: user.id,
      recordId: null,
      title: `최근 7일 성장 분석 · ${currentRange.startKey}~${currentRange.endKey}`,
      feedback,
      meta: {
        feedback_type: 'growth_7_days',
        current_start: currentRange.startKey,
        current_end: currentRange.endKey,
        previous_start: previousRange.startKey,
        previous_end: previousRange.endKey,
        current_record_count: currentRecords.length,
        previous_record_count: previousRecords.length,
        current_avg_accuracy: summary.avg_accuracy,
        previous_avg_accuracy: previousSummary.avg_accuracy,
        has_input_flow_logs: inputLogs.length > 0,
        has_abbreviation_logs: abbrevLogs.length > 0,
      },
    });

    return core.json(res, 200, { ok: true, feedback: saved });
  } catch (error) {
    console.error('[ai-growth-feedback]', error);
    return core.json(res, 500, { ok: false, error: error.message || '성장 분석 AI 피드백 생성 중 오류가 발생했습니다.' });
  }
};
