// Shared helpers for AI feedback serverless functions.
// Required env: OPENAI_API_KEY
// Recommended env: SUPABASE_URL, SUPABASE_ANON_KEY, OPENAI_VECTOR_STORE_ID, OPENAI_FEEDBACK_MODEL

const SUPABASE_URL = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://frqcxmkwcecqvpmbxori.supabase.co';
const DEFAULT_SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZycWN4bWt3Y2VjcXZwbWJ4b3JpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzcwNDAxMjUsImV4cCI6MjA5MjYxNjEyNX0.OLcoaCMc69lAqtYoZ8zPRx6k267B2AHv-7w9yMogMhA';
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY || DEFAULT_SUPABASE_ANON_KEY;
const OPENAI_MODEL = process.env.OPENAI_FEEDBACK_MODEL || 'gpt-4.1-mini';
const MAX_TEXT = 14000;

function json(res, status, data) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.end(JSON.stringify(data));
}

function pickBearer(req) {
  const raw = req.headers.authorization || req.headers.Authorization || '';
  const match = String(raw).match(/^Bearer\s+(.+)$/i);
  return match ? match[1] : '';
}

function trimText(value, max = MAX_TEXT) {
  return String(value || '').slice(0, max);
}

function safeNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function round1(value) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.round(n * 10) / 10 : null;
}

function safeJson(value, fallback = null) {
  if (value === null || value === undefined || value === '') return fallback;
  if (typeof value === 'object') return value;
  try { return JSON.parse(String(value)); } catch (_) { return fallback; }
}

function calcAverage(values) {
  const nums = values.map(Number).filter(Number.isFinite);
  if (!nums.length) return null;
  return nums.reduce((sum, value) => sum + value, 0) / nums.length;
}

function scoreOf(record) {
  const accuracy = Number(record?.accuracy);
  if (Number.isFinite(accuracy)) return accuracy;
  const score = Number(record?.score);
  return Number.isFinite(score) ? score : null;
}

function formatKstDate(date = new Date()) {
  return new Date(date).toLocaleDateString('sv-SE', { timeZone: 'Asia/Seoul' });
}

function kstRange(dateKey) {
  return {
    start: `${dateKey}T00:00:00+09:00`,
    end: `${dateKey}T23:59:59.999+09:00`,
  };
}

function addDays(dateKey, days) {
  const d = new Date(`${dateKey}T00:00:00+09:00`);
  d.setDate(d.getDate() + days);
  return formatKstDate(d);
}

async function supabaseFetch(path, token, options = {}) {
  const url = `${SUPABASE_URL.replace(/\/$/, '')}${path}`;
  const headers = {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    ...options.headers,
  };
  const response = await fetch(url, { ...options, headers });
  const text = await response.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch (_) { data = text; }
  if (!response.ok) {
    const message = data?.message || data?.error_description || data?.error || text || `Supabase ${response.status}`;
    const error = new Error(message);
    error.status = response.status;
    error.data = data;
    throw error;
  }
  return data;
}

async function supabaseOptional(path, token, fallback = []) {
  try { return await supabaseFetch(path, token); }
  catch (error) {
    console.warn('[ai-feedback optional supabase]', error.message || error);
    return fallback;
  }
}

async function requireApprovedUser(token) {
  const user = await supabaseFetch('/auth/v1/user', token);
  if (!user?.id) throw new Error('로그인 정보를 확인하지 못했습니다.');

  const profiles = await supabaseFetch(`/rest/v1/profiles?select=*&id=eq.${encodeURIComponent(user.id)}&limit=1`, token);
  const profile = Array.isArray(profiles) ? profiles[0] : null;
  if (profile && profile.status !== 'approved') throw new Error('승인된 회원만 AI 피드백을 생성할 수 있습니다.');
  return { user, profile };
}

const RECORD_SELECT = [
  'id','user_id','tool_type','practice_title','original_length','typed_length','accuracy','score','cpm',
  'wrong_count','missing_count','added_count','spacing_error_count','elapsed_seconds',
  'source_text_snapshot','typed_text_snapshot','diff_summary','memo','created_at'
].join(',');

async function getPracticeRecord(recordId, userId, token) {
  const rows = await supabaseFetch(`/rest/v1/practice_records?select=${RECORD_SELECT}&id=eq.${encodeURIComponent(recordId)}&user_id=eq.${encodeURIComponent(userId)}&limit=1`, token);
  const record = Array.isArray(rows) ? rows[0] : null;
  if (!record) throw new Error('해당 학습 기록을 찾지 못했습니다.');
  return record;
}

async function getRecentRecords(userId, token, limit = 40) {
  const rows = await supabaseOptional(`/rest/v1/practice_records?select=${RECORD_SELECT}&user_id=eq.${encodeURIComponent(userId)}&order=created_at.desc&limit=${limit}`, token, []);
  return Array.isArray(rows) ? rows : [];
}

async function getRecordsByRange(userId, token, startIso, endIso, limit = 200) {
  const path = `/rest/v1/practice_records?select=${RECORD_SELECT}&user_id=eq.${encodeURIComponent(userId)}&created_at=gte.${encodeURIComponent(startIso)}&created_at=lte.${encodeURIComponent(endIso)}&order=created_at.asc&limit=${limit}`;
  const rows = await supabaseOptional(path, token, []);
  return Array.isArray(rows) ? rows : [];
}

function idInFilter(ids) {
  const list = Array.from(new Set((ids || []).map(String).filter(Boolean))).slice(0, 80);
  if (!list.length) return '';
  return `in.(${list.join(',')})`;
}

async function getInputLogs(recordIds, userId, token) {
  const inFilter = idInFilter(recordIds);
  if (!inFilter) return [];
  const select = 'id,user_id,practice_record_id,total_duration_ms,pause_count,max_pause_ms,backspace_count,paste_detected,raw_events,section_stats,created_at';
  const path = `/rest/v1/practice_input_logs?select=${select}&user_id=eq.${encodeURIComponent(userId)}&practice_record_id=${inFilter}&order=created_at.desc&limit=100`;
  const rows = await supabaseOptional(path, token, []);
  return Array.isArray(rows) ? rows : [];
}

async function getAbbrevLogs(recordIds, userId, token) {
  const inFilter = idInFilter(recordIds);
  if (!inFilter) return [];
  const select = 'id,user_id,practice_record_id,abbrev_hint_enabled,total_abbrev_count,correct_abbrev_count,slow_abbrev_count,error_abbrev_count,missed_abbrevs,weak_abbrev_patterns,created_at';
  const path = `/rest/v1/practice_abbrev_logs?select=${select}&user_id=eq.${encodeURIComponent(userId)}&practice_record_id=${inFilter}&order=created_at.desc&limit=100`;
  const rows = await supabaseOptional(path, token, []);
  return Array.isArray(rows) ? rows : [];
}

function compactRecord(record) {
  return {
    id: record.id,
    title: record.practice_title || '',
    tool_type: record.tool_type || '',
    accuracy: scoreOf(record),
    cpm: safeNumber(record.cpm, null),
    elapsed_seconds: safeNumber(record.elapsed_seconds, null),
    wrong_count: safeNumber(record.wrong_count),
    missing_count: safeNumber(record.missing_count),
    added_count: safeNumber(record.added_count),
    spacing_error_count: safeNumber(record.spacing_error_count),
    created_at: record.created_at,
    memo: safeJson(record.memo, null),
  };
}

function summarizeRecords(records) {
  const scores = records.map(scoreOf).filter(v => v !== null);
  const avg = round1(calcAverage(scores));
  const errors = records.reduce((acc, r) => {
    acc.wrong += safeNumber(r.wrong_count);
    acc.missing += safeNumber(r.missing_count);
    acc.added += safeNumber(r.added_count);
    acc.spacing += safeNumber(r.spacing_error_count);
    return acc;
  }, { wrong: 0, missing: 0, added: 0, spacing: 0 });
  const dominant = Object.entries(errors).sort((a, b) => b[1] - a[1])[0] || ['wrong', 0];
  return {
    count: records.length,
    avg_accuracy: avg,
    best_accuracy: scores.length ? Math.max(...scores) : null,
    worst_accuracy: scores.length ? Math.min(...scores) : null,
    total_errors: errors,
    dominant_error: { type: dominant[0], count: dominant[1] },
  };
}

function mapLogsToRecords(records, inputLogs, abbrevLogs) {
  const inputMap = new Map();
  inputLogs.forEach(row => { if (!inputMap.has(String(row.practice_record_id))) inputMap.set(String(row.practice_record_id), row); });
  const abbrMap = new Map();
  abbrevLogs.forEach(row => { if (!abbrMap.has(String(row.practice_record_id))) abbrMap.set(String(row.practice_record_id), row); });
  return records.map(record => ({
    record: compactRecord(record),
    input_log: inputMap.get(String(record.id)) || null,
    abbrev_log: abbrMap.get(String(record.id)) || null,
  }));
}

function buildPaidFeedbackSystemPrompt() {
  return `너는 소리자바 아카데미의 유료 'AI 선생님 피드백'을 작성한다.
학생에게 보여줄 최종 문안이므로 일반적인 격려문이 아니라 속기 훈련 리포트처럼 작성한다.

핵심 원칙:
1. 수치만 반복하지 말고, 입력 지연 구간·오류 위치·약어 구간을 연결해 원인을 설명한다.
2. AI가 추측하면 안 되는 부분은 '기록상 ~로 보입니다'라고 표현한다.
3. 탈자는 어디서 느려진 뒤 빠졌는지, 오자는 어느 표현이 반복되는지, 첨자는 왜 추가됐는지 구분한다.
4. 약어 표시 ON/OFF와 약어 대상 구간의 지연/오류를 반영해 약어 암기 부족인지, 문장 적용 자동화 부족인지 나눈다.
5. 이전 기록 대비 상승/하락을 반드시 말한다. 비교 데이터가 부족하면 부족하다고 쓴다.
6. 피드백 말미에는 학생이 바로 칠 수 있는 맞춤 연습문장과 1분 단락치기용 짧은 원고를 제공한다.
7. '더 연습하세요', '집중하세요'처럼 막연한 문장은 금지한다.
8. 비난, 낙인, 과장된 진단은 금지한다. 단호하지만 전문적으로 작성한다.

출력 형식:
[AI 선생님 피드백]
1. 핵심 진단
2. 입력 흐름 분석
3. 오류 유형 분석
- 탈자:
- 오자:
- 첨자:
4. 약어 사용 분석
5. 이전 기록 대비 변화
6. 오늘의 교정 지시
7. 맞춤 연습문장
8. 1분 약점 교정 원고
9. 다음 과제

분량은 1800~2600자 안에서 구체적으로 작성한다.`;
}

function getOutputText(data) {
  if (typeof data?.output_text === 'string') return data.output_text.trim();
  const parts = [];
  for (const item of data?.output || []) {
    for (const content of item?.content || []) {
      if (typeof content?.text === 'string') parts.push(content.text);
    }
  }
  return parts.join('\n').trim();
}

async function createOpenAiFeedback({ systemPrompt, userPrompt }) {
  if (!process.env.OPENAI_API_KEY) throw new Error('OPENAI_API_KEY 환경변수가 설정되어 있지 않습니다.');
  const tools = [];
  const vectorStoreId = process.env.OPENAI_VECTOR_STORE_ID;
  if (vectorStoreId) {
    tools.push({ type: 'file_search', vector_store_ids: [vectorStoreId], max_num_results: 8 });
  }

  const body = {
    model: OPENAI_MODEL,
    input: [
      { role: 'system', content: [{ type: 'input_text', text: systemPrompt }] },
      { role: 'user', content: [{ type: 'input_text', text: userPrompt }] },
    ],
  };
  if (tools.length) body.tools = tools;

  const response = await fetch('https://api.openai.com/v1/responses', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
    },
    body: JSON.stringify(body),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data?.error?.message || `OpenAI API 오류: ${response.status}`);
  }
  const text = getOutputText(data);
  if (!text) throw new Error('AI 피드백 응답이 비어 있습니다.');
  return { text, model: data.model || OPENAI_MODEL, sourceMode: vectorStoreId ? 'vector_store' : 'analysis_logs' };
}

async function insertAiFeedback({ token, userId, recordId = null, title, feedback, meta = {} }) {
  const payload = {
    user_id: userId,
    record_id: recordId || null,
    title: title || 'AI 선생님 피드백',
    status: 'draft',
    feedback_text: feedback.text,
    model: feedback.model,
    source_mode: feedback.sourceMode,
    meta,
  };
  const rows = await supabaseFetch('/rest/v1/ai_feedbacks', token, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Prefer: 'return=representation',
    },
    body: JSON.stringify(payload),
  });
  return Array.isArray(rows) ? rows[0] : rows;
}

module.exports = {
  json,
  pickBearer,
  trimText,
  safeNumber,
  round1,
  safeJson,
  calcAverage,
  scoreOf,
  formatKstDate,
  kstRange,
  addDays,
  supabaseFetch,
  supabaseOptional,
  requireApprovedUser,
  getPracticeRecord,
  getRecentRecords,
  getRecordsByRange,
  getInputLogs,
  getAbbrevLogs,
  compactRecord,
  summarizeRecords,
  mapLogsToRecords,
  buildPaidFeedbackSystemPrompt,
  createOpenAiFeedback,
  insertAiFeedback,
};
